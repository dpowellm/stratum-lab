"""
ESCAI Framework CLI Package
"""

from escai_framework import __version__