"""
CLI utilities package
"""