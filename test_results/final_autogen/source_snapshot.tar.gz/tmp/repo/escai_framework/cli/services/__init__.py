"""
CLI services package
"""