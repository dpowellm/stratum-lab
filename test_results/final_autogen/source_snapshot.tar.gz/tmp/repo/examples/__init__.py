"""
ESCAI Framework Examples

This package contains example scripts demonstrating how to use the ESCAI framework
for monitoring and analyzing autonomous agent behavior.
"""