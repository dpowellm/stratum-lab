"""
Shared pytest fixtures for the test suite.

This module provides common fixtures used across all tests.
"""

import asyncio
import uuid
from collections.abc import AsyncGenerator, Generator
from typing import Any

import pytest
import pytest_asyncio
from fastapi.testclient import TestClient
from httpx import ASGITransport, AsyncClient
from sqlalchemy.dialects.postgresql import JSONB, UUID as PG_UUID
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

# ---------------------------------------------------------------------------
# SQLite compatibility: compile PostgreSQL types for SQLite test backend
# ---------------------------------------------------------------------------
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.pool import StaticPool

from src.api.main import app
from src.config.settings import Settings, clear_settings_cache, get_settings
from src.models.database.base import Base


@compiles(JSONB, "sqlite")
def _compile_jsonb_sqlite(type_, compiler, **kw):
    return "JSON"


@compiles(PG_UUID, "sqlite")
def _compile_pg_uuid_sqlite(type_, compiler, **kw):
    return "VARCHAR(36)"


# ============================================================================
# Event Loop Fixture
# ============================================================================


@pytest.fixture(scope="session")
def event_loop() -> Generator[asyncio.AbstractEventLoop, None, None]:
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


# ============================================================================
# Settings Fixtures
# ============================================================================


@pytest.fixture
def test_settings() -> Settings:
    """Get test settings with test-specific overrides."""
    # Clear cache to ensure fresh settings
    clear_settings_cache()

    # Create test settings
    settings = get_settings()

    # Override for testing
    settings.app.env = "development"
    settings.app.debug = True
    settings.database.url = "sqlite+aiosqlite:///:memory:"

    return settings


# ============================================================================
# Database Fixtures
# ============================================================================


@pytest_asyncio.fixture
async def test_engine():
    """Create a test database engine using SQLite in-memory."""
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=False,
    )

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    yield engine

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)

    await engine.dispose()


@pytest_asyncio.fixture
async def test_session(test_engine) -> AsyncGenerator[AsyncSession, None]:
    """Create a test database session."""
    session_factory = async_sessionmaker(
        bind=test_engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )

    async with session_factory() as session:
        yield session


# ============================================================================
# API Client Fixtures
# ============================================================================


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Create a synchronous test client."""
    with TestClient(app) as client:
        yield client


@pytest_asyncio.fixture
async def async_client() -> AsyncGenerator[AsyncClient, None]:
    """Create an async test client."""
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as client:
        yield client


# ============================================================================
# Factory Fixtures
# ============================================================================


@pytest.fixture
def document_data() -> dict[str, Any]:
    """Generate sample document data."""
    return {
        "filename": "test_invoice.pdf",
        "storage_path": f"documents/{uuid.uuid4()}/test_invoice.pdf",
        "file_size": 1024000,
        "mime_type": "application/pdf",
        "checksum": uuid.uuid4().hex,
    }


@pytest.fixture
def council_session_data() -> dict[str, Any]:
    """Generate sample council session data."""
    return {
        "voting_strategy": "confidence_weighted",
        "consensus_threshold": 0.85,
        "participating_members": ["paddle_ocr", "olmocr", "qwen", "colpali"],
    }


@pytest.fixture
def extraction_data() -> dict[str, Any]:
    """Generate sample extraction data."""
    return {
        "overall_confidence": 0.92,
        "field_count": 5,
        "extracted_data": {
            "invoice_number": "INV-2026-001",
            "date": "2026-01-29",
            "total": 1500.00,
            "vendor": "Test Company",
            "items": [
                {"description": "Item 1", "quantity": 2, "price": 500.00},
                {"description": "Item 2", "quantity": 1, "price": 500.00},
            ],
        },
    }


# ============================================================================
# Mock Fixtures
# ============================================================================


@pytest.fixture
def mock_ocr_result() -> dict[str, Any]:
    """Generate mock OCR result."""
    return {
        "text": "Invoice #INV-2026-001\nDate: 2026-01-29\nTotal: $1,500.00",
        "confidence": 0.95,
        "blocks": [
            {
                "text": "Invoice #INV-2026-001",
                "confidence": 0.98,
                "bbox": {"x": 100, "y": 50, "width": 200, "height": 30},
            },
            {
                "text": "Date: 2026-01-29",
                "confidence": 0.96,
                "bbox": {"x": 100, "y": 100, "width": 150, "height": 25},
            },
            {
                "text": "Total: $1,500.00",
                "confidence": 0.94,
                "bbox": {"x": 100, "y": 150, "width": 120, "height": 25},
            },
        ],
    }


@pytest.fixture
def mock_council_votes() -> list[dict[str, Any]]:
    """Generate mock council member votes."""
    return [
        {
            "member_name": "paddle_ocr",
            "overall_confidence": 0.92,
            "extracted_fields": {
                "invoice_number": "INV-2026-001",
                "date": "2026-01-29",
                "total": 1500.00,
            },
            "field_confidences": {
                "invoice_number": 0.98,
                "date": 0.95,
                "total": 0.90,
            },
        },
        {
            "member_name": "olmocr",
            "overall_confidence": 0.90,
            "extracted_fields": {
                "invoice_number": "INV-2026-001",
                "date": "2026-01-29",
                "total": 1500.00,
            },
            "field_confidences": {
                "invoice_number": 0.95,
                "date": 0.92,
                "total": 0.88,
            },
        },
        {
            "member_name": "qwen",
            "overall_confidence": 0.88,
            "extracted_fields": {
                "invoice_number": "INV-2026-001",
                "date": "2026-01-29",
                "total": 1500.00,
            },
            "field_confidences": {
                "invoice_number": 0.92,
                "date": 0.90,
                "total": 0.85,
            },
        },
    ]
