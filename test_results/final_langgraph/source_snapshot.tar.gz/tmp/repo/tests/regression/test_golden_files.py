"""Golden-file regression tests.

Phase 4.1: Verify extraction accuracy against known ground-truth
documents. Uses programmatically generated PDFs with known field values
to test the evaluation framework and detect regressions.
"""

import json
from pathlib import Path

from src.services.evals.golden import AggregateReport, GoldenFileEvaluator

GOLDEN_DIR = Path(__file__).parent.parent / "fixtures" / "golden"


class TestGoldenFileEvaluation:
    """Tests for per-field golden file comparison."""

    def test_invoice_extraction_matches_golden(self):
        """Per-field comparison: perfect extraction → F1 = 1.0."""
        evaluator = GoldenFileEvaluator()
        golden = json.loads((GOLDEN_DIR / "invoice_001.json").read_text())

        # Simulate perfect extraction (all fields match ground truth)
        extracted = {field_name: info["value"] for field_name, info in golden["fields"].items()}

        report = evaluator.evaluate(extracted, golden, "invoice_001")

        assert report.f1 == 1.0
        assert report.precision == 1.0
        assert report.recall == 1.0
        assert report.matched_fields == report.total_fields
        assert report.missing_fields == 0

    def test_receipt_extraction_matches_golden(self):
        """Receipt golden file with equivalent currency formats."""
        evaluator = GoldenFileEvaluator()
        golden = json.loads((GOLDEN_DIR / "receipt_001.json").read_text())

        # Extraction uses currency format variants (should still match)
        extracted = {
            "store_name": "QUICK MART",  # case diff → fuzzy match
            "receipt_number": "R-88431",
            "date": "02/05/2026",  # different date format
            "subtotal": "$17.15",  # with $ sign
            "tax": "1.63",
            "total_amount": "$18.78",
            "payment_method": "VISA **** 4821",
        }

        report = evaluator.evaluate(extracted, golden, "receipt_001")

        # All should match via semantic normalization
        assert report.matched_fields == report.total_fields
        assert report.f1 == 1.0

    def test_contract_extraction_matches_golden(self):
        """Contract golden file with date and currency normalization."""
        evaluator = GoldenFileEvaluator()
        golden = json.loads((GOLDEN_DIR / "contract_001.json").read_text())

        extracted = {
            "contract_number": "SA-2026-1187",
            "effective_date": "March 1, 2026",  # text date → normalized
            "party_a": "TechSolutions Inc.",
            "party_b": "GlobalRetail Corp.",
            "end_date": "2027-02-28",
            "monthly_fee": "$12,500.00",  # currency format
            "total_value": "150000.00",
        }

        report = evaluator.evaluate(extracted, golden, "contract_001")
        assert report.f1 == 1.0
        assert report.matched_fields == 7

    def test_partial_extraction_scores_correctly(self):
        """Missing fields → recall < 1, but precision can be 1."""
        evaluator = GoldenFileEvaluator()
        golden = json.loads((GOLDEN_DIR / "invoice_001.json").read_text())

        # Only extract 5 of 9 fields, all correct
        extracted = {
            "invoice_number": "INV-2026-0042",
            "date": "2026-01-15",
            "vendor_name": "Acme Corporation",
            "total_amount": "$9,546.92",
            "due_date": "February 14, 2026",
        }

        report = evaluator.evaluate(extracted, golden, "invoice_partial")
        assert report.precision == 1.0  # all extracted fields correct
        assert report.recall < 1.0  # missing fields
        assert report.missing_fields == 4
        assert report.matched_fields == 5

    def test_wrong_values_lower_precision(self):
        """Incorrect field values → precision < 1."""
        evaluator = GoldenFileEvaluator()
        golden = json.loads((GOLDEN_DIR / "invoice_001.json").read_text())

        # All fields present but 2 are wrong
        extracted = {field_name: info["value"] for field_name, info in golden["fields"].items()}
        extracted["invoice_number"] = "WRONG-NUMBER"
        extracted["total_amount"] = "999.99"

        report = evaluator.evaluate(extracted, golden, "invoice_wrong")
        assert report.precision < 1.0
        assert report.matched_fields == 7  # 9 total, 2 wrong

    def test_extra_fields_tracked(self):
        """Extracted fields not in golden are counted as extra."""
        evaluator = GoldenFileEvaluator()
        golden = json.loads((GOLDEN_DIR / "receipt_001.json").read_text())

        extracted = {field_name: info["value"] for field_name, info in golden["fields"].items()}
        extracted["spurious_field"] = "some value"
        extracted["another_extra"] = "extra"

        report = evaluator.evaluate(extracted, golden, "receipt_extra")
        assert report.extra_fields == 2
        # Precision/recall should still be perfect for golden fields
        assert report.f1 == 1.0


class TestAccuracyThreshold:
    """Tests for accuracy threshold requirements."""

    def test_accuracy_above_85_percent(self):
        """Simulated extraction achieving ≥ 0.85 F1 across all golden files."""
        evaluator = GoldenFileEvaluator()
        results = []

        for json_file in sorted(GOLDEN_DIR.glob("*.json")):
            golden = json.loads(json_file.read_text())
            doc_name = json_file.stem

            # Simulate good (but not perfect) extraction
            extracted = {}
            fields = list(golden["fields"].items())
            for i, (field_name, info) in enumerate(fields):
                if i == 0 and len(fields) > 5:
                    # Skip one field for docs with many fields (miss 1)
                    continue
                extracted[field_name] = info["value"]

            results.append((doc_name, extracted, golden))

        aggregate = evaluator.evaluate_batch(results)
        assert aggregate.macro_f1 >= 0.85
        assert aggregate.macro_precision >= 0.85
        assert aggregate.macro_recall >= 0.85


class TestRegressionDetection:
    """Tests for baseline regression detection."""

    def test_no_regression_vs_baseline(self, tmp_path: Path):
        """Current F1 ≥ baseline - tolerance → no regression."""
        evaluator = GoldenFileEvaluator()

        # Create a baseline
        baseline = {
            "macro_f1": 0.90,
            "macro_precision": 0.92,
            "macro_recall": 0.88,
            "per_type": {},
        }
        baseline_path = tmp_path / "baseline.json"
        baseline_path.write_text(json.dumps(baseline))

        # Current results meet baseline
        current = AggregateReport(
            total_documents=3,
            total_fields=23,
            total_matched=21,
            total_missing=2,
            macro_precision=0.93,
            macro_recall=0.89,
            macro_f1=0.91,
            per_document=[],
            per_type={},
        )

        loaded_baseline = evaluator.load_baseline(baseline_path)
        has_regression, reasons = evaluator.check_regression(current, loaded_baseline)
        assert not has_regression
        assert len(reasons) == 0

    def test_regression_detected_on_f1_drop(self, tmp_path: Path):
        """F1 drops by > tolerance → regression detected."""
        evaluator = GoldenFileEvaluator()

        baseline = {
            "macro_f1": 0.92,
            "macro_precision": 0.93,
            "macro_recall": 0.91,
        }
        baseline_path = tmp_path / "baseline.json"
        baseline_path.write_text(json.dumps(baseline))

        # Current results significantly worse
        current = AggregateReport(
            total_documents=3,
            total_fields=23,
            total_matched=16,
            total_missing=7,
            macro_precision=0.80,
            macro_recall=0.70,
            macro_f1=0.74,
            per_document=[],
            per_type={},
        )

        loaded_baseline = evaluator.load_baseline(baseline_path)
        has_regression, reasons = evaluator.check_regression(
            current, loaded_baseline, tolerance=0.02
        )
        assert has_regression
        assert any("F1" in r for r in reasons)

    def test_save_and_load_baseline(self, tmp_path: Path):
        """Baseline round-trips through save/load."""
        evaluator = GoldenFileEvaluator()

        report = AggregateReport(
            total_documents=3,
            total_fields=23,
            total_matched=21,
            total_missing=2,
            macro_precision=0.93,
            macro_recall=0.89,
            macro_f1=0.91,
            per_document=[],
            per_type={"invoice": {"f1": 0.95, "precision": 0.96, "recall": 0.94, "count": 1.0}},
        )

        path = tmp_path / "saved_baseline.json"
        evaluator.save_baseline(report, path)
        loaded = evaluator.load_baseline(path)

        assert loaded["macro_f1"] == 0.91
        assert loaded["macro_precision"] == 0.93
        assert loaded["per_type"]["invoice"]["f1"] == 0.95

    def test_batch_evaluation_per_type(self):
        """Batch evaluation produces per-type metrics."""
        evaluator = GoldenFileEvaluator()
        results = []

        for json_file in sorted(GOLDEN_DIR.glob("*.json")):
            golden = json.loads(json_file.read_text())
            doc_name = json_file.stem
            # Perfect extraction
            extracted = {field_name: info["value"] for field_name, info in golden["fields"].items()}
            results.append((doc_name, extracted, golden))

        aggregate = evaluator.evaluate_batch(results)
        assert aggregate.total_documents == 3
        assert "invoice" in aggregate.per_type
        assert "receipt" in aggregate.per_type
        assert "contract" in aggregate.per_type
        for doc_type, metrics in aggregate.per_type.items():
            assert metrics["f1"] == 1.0, f"{doc_type} should have F1=1.0"
