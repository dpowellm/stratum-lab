"""Tests for council explainability features."""

from datetime import datetime
from unittest.mock import MagicMock

from src.models.schemas.council import (
    CouncilSession,
    VotingStrategy,
)

# ============================================================================
# Schema tests: new explainability fields
# ============================================================================


class TestCouncilSessionExplainabilityFields:
    """Tests for new explainability fields on CouncilSession schema."""

    def test_defaults_for_new_fields(self):
        session = CouncilSession(
            session_id="sess_001",
            document_id="doc_001",
            voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED,
            total_fields=5,
            fields_with_consensus=4,
            disputed_fields=1,
            overall_confidence=0.9,
            consensus_score=0.8,
        )
        assert session.judge_invoked is False
        assert session.judge_model is None
        assert session.judge_reasoning is None
        assert session.judge_confidence is None
        assert session.resolution_method is None
        assert session.conflict_details == []
        assert session.unified_extraction == {}

    def test_explicit_judge_fields(self):
        session = CouncilSession(
            session_id="sess_002",
            document_id="doc_002",
            voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED,
            total_fields=5,
            fields_with_consensus=3,
            disputed_fields=2,
            overall_confidence=0.85,
            consensus_score=0.6,
            judge_invoked=True,
            judge_model="olmocr-2-7b",
            judge_reasoning="olmOCR had highest per-field confidence on disputed fields.",
            judge_confidence=0.92,
            resolution_method="judge_decision",
        )
        assert session.judge_invoked is True
        assert session.judge_model == "olmocr-2-7b"
        assert session.judge_reasoning is not None
        assert session.judge_confidence == 0.92
        assert session.resolution_method == "judge_decision"

    def test_conflict_details_serialization(self):
        session = CouncilSession(
            session_id="sess_003",
            document_id="doc_003",
            voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED,
            total_fields=3,
            fields_with_consensus=2,
            disputed_fields=1,
            overall_confidence=0.88,
            consensus_score=0.67,
            conflict_details=[
                {
                    "field_name": "invoice_total",
                    "votes": [
                        {"member": "paddle_ocr", "value": "1500.00", "confidence": 0.95},
                        {"member": "olmocr", "value": "1500", "confidence": 0.90},
                        {"member": "qwen", "value": "15000", "confidence": 0.60},
                    ],
                }
            ],
        )
        data = session.model_dump()
        assert len(data["conflict_details"]) == 1
        assert data["conflict_details"][0]["field_name"] == "invoice_total"

    def test_unified_extraction_serialization(self):
        session = CouncilSession(
            session_id="sess_004",
            document_id="doc_004",
            voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED,
            total_fields=2,
            fields_with_consensus=2,
            disputed_fields=0,
            overall_confidence=0.95,
            consensus_score=1.0,
            unified_extraction={
                "invoice_number": "INV-001",
                "total": 1500.00,
            },
        )
        data = session.model_dump()
        assert data["unified_extraction"]["invoice_number"] == "INV-001"

    def test_json_round_trip(self):
        session = CouncilSession(
            session_id="sess_005",
            document_id="doc_005",
            voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED,
            total_fields=1,
            fields_with_consensus=1,
            disputed_fields=0,
            overall_confidence=0.95,
            consensus_score=1.0,
            judge_invoked=True,
            judge_model="gpt-4",
            judge_confidence=0.99,
            resolution_method="judge_decision",
            conflict_details=[{"field": "name", "conflict": "minor"}],
            unified_extraction={"name": "John"},
        )
        json_str = session.model_dump_json()
        restored = CouncilSession.model_validate_json(json_str)
        assert restored.judge_invoked is True
        assert restored.judge_model == "gpt-4"
        assert restored.resolution_method == "judge_decision"
        assert len(restored.conflict_details) == 1


# ============================================================================
# API mapping tests: _db_session_to_schema
# ============================================================================


class TestDbSessionToSchema:
    """Tests for _db_session_to_schema mapping new fields."""

    def _make_mock_db_session(self, **overrides) -> MagicMock:
        """Create a mock DB CouncilSession with default values."""
        mock = MagicMock()
        mock.id = "00000000-0000-0000-0000-000000000001"
        mock.document_id = "00000000-0000-0000-0000-000000000002"
        mock.created_at = datetime(2026, 1, 30, 12, 0, 0)
        mock.updated_at = datetime(2026, 1, 30, 12, 0, 5)
        mock.participating_members = ["paddle_ocr", "olmocr", "qwen"]
        mock.voting_strategy = MagicMock()
        mock.voting_strategy.value = "confidence_weighted"
        mock.total_fields = 5
        mock.agreed_fields = 4
        mock.disputed_fields = 1
        mock.final_confidence = 0.92
        mock.consensus_score = 0.80
        mock.conflict_level = MagicMock()
        mock.conflict_level.value = "minor"
        mock.judge_invoked = False
        mock.judge_model = None
        mock.judge_reasoning = None
        mock.judge_confidence = None
        mock.resolution_method = MagicMock()
        mock.resolution_method.value = "not_applicable"
        mock.conflict_details = None
        mock.unified_extraction = None
        mock.human_review_required = False
        mock.total_processing_time_ms = 3000.0
        mock.member_votes = []
        mock.is_deleted = False

        for key, val in overrides.items():
            setattr(mock, key, val)
        return mock

    def test_maps_judge_invoked(self):
        from src.api.routes.council import _db_session_to_schema

        db_sess = self._make_mock_db_session(judge_invoked=True)
        schema = _db_session_to_schema(db_sess)
        assert schema.judge_invoked is True

    def test_maps_judge_model(self):
        from src.api.routes.council import _db_session_to_schema

        db_sess = self._make_mock_db_session(
            judge_invoked=True,
            judge_model="olmocr-2-7b",
        )
        schema = _db_session_to_schema(db_sess)
        assert schema.judge_model == "olmocr-2-7b"

    def test_maps_judge_reasoning(self):
        from src.api.routes.council import _db_session_to_schema

        db_sess = self._make_mock_db_session(
            judge_invoked=True,
            judge_reasoning="Member X had highest confidence on disputed fields.",
        )
        schema = _db_session_to_schema(db_sess)
        assert schema.judge_reasoning is not None
        assert "highest confidence" in schema.judge_reasoning

    def test_maps_judge_confidence(self):
        from src.api.routes.council import _db_session_to_schema

        db_sess = self._make_mock_db_session(judge_confidence=0.88)
        schema = _db_session_to_schema(db_sess)
        assert schema.judge_confidence == 0.88

    def test_maps_resolution_method(self):
        from src.api.routes.council import _db_session_to_schema

        mock_method = MagicMock()
        mock_method.value = "judge_decision"
        db_sess = self._make_mock_db_session(resolution_method=mock_method)
        schema = _db_session_to_schema(db_sess)
        assert schema.resolution_method == "judge_decision"

    def test_maps_conflict_details(self):
        from src.api.routes.council import _db_session_to_schema

        details = [{"field": "total", "votes": []}]
        db_sess = self._make_mock_db_session(conflict_details=details)
        schema = _db_session_to_schema(db_sess)
        assert schema.conflict_details == details

    def test_maps_unified_extraction(self):
        from src.api.routes.council import _db_session_to_schema

        extraction = {"invoice_number": "INV-001", "total": 1500}
        db_sess = self._make_mock_db_session(unified_extraction=extraction)
        schema = _db_session_to_schema(db_sess)
        assert schema.unified_extraction == extraction

    def test_defaults_when_null(self):
        from src.api.routes.council import _db_session_to_schema

        db_sess = self._make_mock_db_session(
            conflict_details=None,
            unified_extraction=None,
            resolution_method=None,
        )
        schema = _db_session_to_schema(db_sess)
        assert schema.conflict_details == []
        assert schema.unified_extraction == {}
        assert schema.resolution_method is None
