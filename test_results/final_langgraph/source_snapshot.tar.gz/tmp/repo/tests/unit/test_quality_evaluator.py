"""Tests for QualityEvaluator service."""

import pytest


@pytest.mark.unit
class TestQualityEvaluator:
    """Test quality evaluation metrics."""

    def _make_evaluator(self):
        from src.services.evals.quality import QualityEvaluator

        return QualityEvaluator()

    def test_record_and_compute(self):
        evaluator = self._make_evaluator()
        evaluator.record_extraction_result("name", "Alice", 0.9, "model_a", "invoice")
        evaluator.record_extraction_result("date", "2024-01-01", 0.85, "model_a", "invoice")
        evaluator.record_correction("name", "Alice", "Bob", "model_a", "invoice")

        report = evaluator.compute_overall_metrics()
        assert report.total_predictions == 2
        assert report.total_corrections == 1
        assert len(report.per_field_metrics) > 0

    def test_precision_recall_per_field(self):
        evaluator = self._make_evaluator()
        # 3 predictions, 1 correction
        evaluator.record_extraction_result("name", "A", 0.9, "m1", "inv")
        evaluator.record_extraction_result("name", "B", 0.8, "m1", "inv")
        evaluator.record_extraction_result("name", "C", 0.7, "m1", "inv")
        evaluator.record_correction("name", "A", "D", "m1", "inv")

        report = evaluator.compute_overall_metrics()
        name_metrics = next((f for f in report.per_field_metrics if f.field_name == "name"), None)
        assert name_metrics is not None
        assert name_metrics.sample_count == 3
        assert name_metrics.incorrect_count == 1

    def test_worst_performing_fields(self):
        evaluator = self._make_evaluator()
        # Create fields with different error rates
        for i in range(5):
            evaluator.record_extraction_result(f"field_{i}", "val", 0.9, "m", "t")
        # Make field_0 worst
        evaluator.record_correction("field_0", "val", "new", "m", "t")
        evaluator.record_correction("field_0", "val", "new2", "m", "t")

        worst = evaluator.get_worst_performing_fields(3)
        assert len(worst) <= 3
        assert worst[0].field_name == "field_0"

    def test_empty_evaluator(self):
        evaluator = self._make_evaluator()
        report = evaluator.compute_overall_metrics()
        assert report.total_predictions == 0
        assert report.overall_f1 == 0.0
