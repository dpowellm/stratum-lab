"""Integration tests for real council member extraction.

Phase 1.2: Verify each member can extract fields from real documents,
handles errors gracefully, and respects timeouts.

These tests require real models to be available. Mark with
`pytest.mark.integration` so they can be skipped in CI.
"""

import asyncio

import fitz
import pytest

from src.council.members.base import ExtractionResult


def _create_sample_invoice_image() -> bytes:
    """Create a simple invoice image for testing."""
    # Create a PDF page with invoice text, then render to image
    doc = fitz.open()
    page = doc.new_page(width=612, height=792)
    page.insert_text((72, 72), "INVOICE", fontsize=24)
    page.insert_text((72, 110), "Invoice Number: INV-2026-001")
    page.insert_text((72, 130), "Date: January 15, 2026")
    page.insert_text((72, 150), "Vendor: Acme Corporation")
    page.insert_text((72, 190), "Description          Qty    Price")
    page.insert_text((72, 210), "Widget A              2    $500.00")
    page.insert_text((72, 230), "Widget B              1    $250.00")
    page.insert_text((72, 270), "Total: $1,250.00")
    pix = page.get_pixmap(dpi=200)
    img_bytes = pix.tobytes("png")
    doc.close()
    return img_bytes


def _create_corrupt_image() -> bytes:
    """Create corrupt image bytes."""
    return b"this is not a valid image at all \x00\xff\xfe"


@pytest.mark.integration
class TestPaddleOCRExtraction:
    """Test PaddleOCR member with real model."""

    async def test_paddle_ocr_extracts_from_invoice(self):
        """PaddleOCR should extract non-empty fields from a sample invoice."""
        from src.council.members.paddle_ocr import PaddleOCRMember

        member = PaddleOCRMember()
        try:
            await member.initialize()
        except (RuntimeError, ImportError):
            pytest.skip("PaddleOCR not available")

        image_data = _create_sample_invoice_image()
        result = await member.extract(image_data, document_type="invoice")

        assert isinstance(result, ExtractionResult)
        assert result.status == "success"
        assert len(result.fields) > 0
        assert result.processing_time_ms > 0
        await member.shutdown()


@pytest.mark.integration
class TestOlmOCRExtraction:
    """Test olmOCR member with real GGUF model."""

    async def test_olmocr_extracts_with_gguf(self):
        """olmOCR with GGUF should extract fields with confidence > 0."""
        # Try to find GGUF model
        from pathlib import Path

        from src.council.members.olmocr import OlmOCRMember

        cache_dir = Path.home() / ".cache" / "huggingface" / "hub"
        gguf_files = list(cache_dir.rglob("*olmocr*/*.gguf")) if cache_dir.exists() else []
        if not gguf_files:
            pytest.skip("olmOCR GGUF model not available")

        member = OlmOCRMember(gguf_path=str(gguf_files[0]))
        await member.initialize()

        image_data = _create_sample_invoice_image()
        result = await member.extract(image_data, document_type="invoice")

        assert isinstance(result, ExtractionResult)
        assert result.status == "success"
        for field in result.fields:
            assert field.confidence > 0

        await member.shutdown()


@pytest.mark.integration
class TestQwenExtraction:
    """Test Qwen VLM member."""

    async def test_qwen_vlm_extracts_with_reasoning(self):
        """Qwen VLM should extract fields including reasoning."""
        from pathlib import Path

        from src.council.members.qwen_vlm import QwenVLMMember

        cache_dir = Path.home() / ".cache" / "huggingface" / "hub"
        gguf_files = list(cache_dir.rglob("*qwen*/*.gguf")) if cache_dir.exists() else []
        if not gguf_files:
            pytest.skip("Qwen GGUF model not available")

        member = QwenVLMMember(gguf_path=str(gguf_files[0]))
        await member.initialize()

        image_data = _create_sample_invoice_image()
        result = await member.extract(image_data, document_type="invoice")

        assert isinstance(result, ExtractionResult)
        assert result.status == "success"

        await member.shutdown()


@pytest.mark.integration
class TestColPaliExtraction:
    """Test ColPali VLM member."""

    async def test_colpali_visual_extraction(self):
        """ColPali should perform visual document understanding."""
        from pathlib import Path

        from src.council.members.colpali_vlm import ColPaliVLMMember

        cache_dir = Path.home() / ".cache" / "huggingface" / "hub"
        gguf_files = list(cache_dir.rglob("*colpali*/*.gguf")) if cache_dir.exists() else []
        if not gguf_files:
            pytest.skip("ColPali GGUF model not available")

        member = ColPaliVLMMember(gguf_path=str(gguf_files[0]))
        await member.initialize()

        image_data = _create_sample_invoice_image()
        result = await member.extract(image_data)

        assert isinstance(result, ExtractionResult)
        assert result.status == "success"

        await member.shutdown()


class TestMemberErrorHandling:
    """Test error handling for council members."""

    async def test_member_handles_corrupt_image(self):
        """Corrupt image bytes → ExtractionResult with status='error'."""

        # Use _safe_extract wrapper via any member
        from src.council.members.paddle_ocr import PaddleOCRMember

        member = PaddleOCRMember()
        try:
            await member.initialize()
        except (RuntimeError, ImportError):
            pytest.skip("PaddleOCR not available")

        corrupt_data = _create_corrupt_image()
        result = await member.extract(corrupt_data)

        assert isinstance(result, ExtractionResult)
        assert result.status == "error"
        assert result.error_message is not None

    async def test_safe_extract_returns_error_on_timeout(self):
        """_safe_extract should return error ExtractionResult on timeout."""
        from src.council.members.base import ExtractionResult, _safe_extract

        class SlowMember:
            name = "slow"
            model_version = "1.0"

            async def extract(self, *args, **kwargs):
                await asyncio.sleep(10)

        member = SlowMember()
        result = await _safe_extract(member, b"image_data", timeout_seconds=0.1)
        assert isinstance(result, ExtractionResult)
        assert result.status == "error"
        assert "timeout" in result.error_message.lower() or "cancel" in result.error_message.lower()
