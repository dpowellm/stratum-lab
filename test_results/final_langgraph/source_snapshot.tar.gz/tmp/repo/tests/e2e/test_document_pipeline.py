"""End-to-end tests for the document processing pipeline.

These tests verify the complete flow from document upload
to extraction result, using an in-memory SQLite database.
"""

import uuid

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import StaticPool

from src.api.main import create_app
from src.models.database.base import Base, get_session

# ---------------------------------------------------------------------------
# Shared E2E fixture: app with in-memory SQLite
# ---------------------------------------------------------------------------


@pytest.fixture()
def e2e_app():
    """Create a FastAPI app with an in-memory SQLite database.

    Each test function gets a fresh database to avoid cross-test
    duplicate-checksum conflicts.
    """
    import asyncio

    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=False,
    )

    loop = asyncio.new_event_loop()
    loop.run_until_complete(_create_tables(engine))
    loop.close()

    session_factory = async_sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )

    async def _override_session():
        async with session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception:
                await session.rollback()
                raise

    app = create_app()
    app.dependency_overrides[get_session] = _override_session

    yield app

    app.dependency_overrides.clear()


async def _create_tables(engine):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


@pytest.fixture
def client(e2e_app) -> TestClient:
    """Create a synchronous test client from the E2E app."""
    return TestClient(e2e_app)


# ---------------------------------------------------------------------------
# Sample data fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def sample_invoice_pdf() -> bytes:
    """Create a minimal PDF.

    Uses a unique trailer comment each time so the checksum differs,
    allowing multiple tests to upload without hitting duplicate detection.
    """
    uid = uuid.uuid4().hex[:16]
    return (
        b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
        b"2 0 obj<</Type/Pages/Count 0/Kids[]>>endobj\n"
        b"xref\n0 3\n0000000000 65535 f \n0000000009 00000 n \n"
        b"0000000052 00000 n \n"
        b"trailer<</Size 3/Root 1 0 R>>\nstartxref\n101\n%%EOF\n"
        b"% " + uid.encode()
    )


@pytest.fixture
def sample_image() -> bytes:
    """Create a minimal PNG image with a unique trailing comment."""
    uid = uuid.uuid4().bytes[:4]
    return (
        bytes(
            [
                0x89,
                0x50,
                0x4E,
                0x47,
                0x0D,
                0x0A,
                0x1A,
                0x0A,
                0x00,
                0x00,
                0x00,
                0x0D,
                0x49,
                0x48,
                0x44,
                0x52,
                0x00,
                0x00,
                0x00,
                0x01,
                0x00,
                0x00,
                0x00,
                0x01,
                0x08,
                0x02,
                0x00,
                0x00,
                0x00,
                0x90,
                0x77,
                0x53,
                0xDE,
                0x00,
                0x00,
                0x00,
                0x0C,
                0x49,
                0x44,
                0x41,
                0x54,
                0x08,
                0xD7,
                0x63,
                0xF8,
                0xFF,
                0xFF,
                0x3F,
                0x00,
                0x05,
                0xFE,
                0x02,
                0xFE,
                0xDC,
                0xCC,
                0x59,
                0xE7,
                0x00,
                0x00,
                0x00,
                0x00,
                0x49,
                0x45,
                0x4E,
                0x44,
                0xAE,
                0x42,
                0x60,
                0x82,
            ]
        )
        + uid
    )


# ===========================================================================
# Document Pipeline E2E Tests
# ===========================================================================


class TestDocumentPipelineE2E:
    """E2E tests for document processing pipeline."""

    def test_full_document_upload_flow(
        self,
        client: TestClient,
        sample_invoice_pdf: bytes,
    ) -> None:
        """Test complete document upload and status tracking flow."""
        # Step 1: Upload document
        response = client.post(
            "/api/v1/documents/upload",
            files={"file": ("invoice.pdf", sample_invoice_pdf, "application/pdf")},
        )

        assert response.status_code == 202
        data = response.json()
        document_id = data["document_id"]
        assert data["status"] == "pending"
        assert data["filename"] == "invoice.pdf"
        assert "content_hash" in data

        # Step 2: Check initial status (route is GET /documents/{id})
        status_response = client.get(f"/api/v1/documents/{document_id}")
        assert status_response.status_code == 200
        status_data = status_response.json()
        assert status_data["document_id"] == document_id
        assert "status" in status_data

        # Step 3: Verify document appears in list
        list_response = client.get("/api/v1/documents")
        assert list_response.status_code == 200
        list_data = list_response.json()
        assert list_data["total_count"] >= 1

        # Step 4: Clean up (returns 200 with DocumentDeleteResponse)
        delete_response = client.delete(f"/api/v1/documents/{document_id}")
        assert delete_response.status_code == 200
        assert delete_response.json()["success"] is True

    def test_document_upload_with_options(
        self,
        client: TestClient,
        sample_invoice_pdf: bytes,
    ) -> None:
        """Test document upload with processing options."""
        response = client.post(
            "/api/v1/documents/upload",
            files={"file": ("invoice.pdf", sample_invoice_pdf, "application/pdf")},
            data={
                "document_type": "invoice",
                "priority": "high",
            },
        )

        assert response.status_code == 202
        data = response.json()
        document_id = data["document_id"]

        # Clean up
        client.delete(f"/api/v1/documents/{document_id}")

    def test_image_document_upload(
        self,
        client: TestClient,
        sample_image: bytes,
    ) -> None:
        """Test uploading an image document."""
        response = client.post(
            "/api/v1/documents/upload",
            files={"file": ("receipt.png", sample_image, "image/png")},
        )

        assert response.status_code == 202
        data = response.json()
        assert data["file_format"] == "png"

        # Clean up
        client.delete(f"/api/v1/documents/{data['document_id']}")

    def test_invalid_file_rejected(
        self,
        client: TestClient,
    ) -> None:
        """Test that invalid files are rejected."""
        response = client.post(
            "/api/v1/documents/upload",
            files={"file": ("malware.exe", b"invalid content", "application/octet-stream")},
        )

        assert response.status_code == 400
        assert "not supported" in response.json()["detail"].lower()

    def test_duplicate_document_returns_409(
        self,
        client: TestClient,
    ) -> None:
        """Test that uploading the same content twice returns 409."""
        content = b"%PDF-1.4\nDuplicate test content"

        # First upload
        resp1 = client.post(
            "/api/v1/documents/upload",
            files={"file": ("doc.pdf", content, "application/pdf")},
        )
        assert resp1.status_code == 202

        # Second upload of same content
        resp2 = client.post(
            "/api/v1/documents/upload",
            files={"file": ("doc.pdf", content, "application/pdf")},
        )
        assert resp2.status_code == 409

    def test_extraction_result_retrieval(
        self,
        client: TestClient,
        sample_invoice_pdf: bytes,
    ) -> None:
        """Test retrieving extraction results."""
        # Upload document
        upload_response = client.post(
            "/api/v1/documents/upload",
            files={"file": ("invoice.pdf", sample_invoice_pdf, "application/pdf")},
        )
        assert upload_response.status_code == 202
        document_id = upload_response.json()["document_id"]

        # Try to get extraction (may be pending)
        extraction_response = client.get(f"/api/v1/documents/{document_id}/extraction")

        # 404 when no extraction has been created yet is expected
        assert extraction_response.status_code in (200, 202, 400, 404)

        # Clean up
        client.delete(f"/api/v1/documents/{document_id}")


# ===========================================================================
# Q&A Pipeline E2E Tests
# ===========================================================================


class TestQAPipelineE2E:
    """E2E tests for Q&A pipeline."""

    def test_ask_question(self, client: TestClient) -> None:
        """Test asking a question."""
        response = client.post(
            "/api/v1/qa/ask",
            json={
                "question": "What is the total amount on the invoice?",
                "top_k": 5,
                "include_sources": True,
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert "answer_id" in data
        assert "answer" in data
        assert "question" in data
        assert data["question"] == "What is the total amount on the invoice?"

    def test_batch_questions(self, client: TestClient) -> None:
        """Test batch question answering."""
        response = client.post(
            "/api/v1/qa/ask/batch",
            json={
                "questions": [
                    {"question": "What is the invoice number?"},
                    {"question": "Who is the vendor?"},
                ]
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert data["total_questions"] == 2
        assert len(data["answers"]) == 2

    def test_semantic_search(self, client: TestClient) -> None:
        """Test semantic search."""
        response = client.post(
            "/api/v1/qa/search",
            json={
                "query": "invoice total amount",
                "top_k": 10,
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert "results" in data
        assert "total_results" in data

    def test_get_suggestions(self, client: TestClient) -> None:
        """Test question suggestions."""
        response = client.get("/api/v1/qa/suggest?limit=5")

        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) <= 5

    def test_answer_retrieval(self, client: TestClient) -> None:
        """Test retrieving a previous answer."""
        # First, ask a question
        ask_response = client.post(
            "/api/v1/qa/ask",
            json={"question": "Test question"},
        )
        answer_id = ask_response.json()["answer_id"]

        # Then retrieve it
        get_response = client.get(f"/api/v1/qa/answers/{answer_id}")
        assert get_response.status_code == 200
        assert get_response.json()["answer_id"] == answer_id

    def test_answer_feedback(self, client: TestClient) -> None:
        """Test submitting answer feedback."""
        # First, ask a question
        ask_response = client.post(
            "/api/v1/qa/ask",
            json={"question": "Test question"},
        )
        answer_id = ask_response.json()["answer_id"]

        # Submit feedback
        feedback_response = client.post(
            "/api/v1/qa/feedback",
            params={
                "answer_id": answer_id,
                "helpful": True,
                "comment": "Great answer!",
            },
        )
        assert feedback_response.status_code == 201


# ===========================================================================
# Health Check E2E Tests
# ===========================================================================


class TestHealthChecksE2E:
    """E2E tests for health endpoints."""

    def test_health_endpoint(self, client: TestClient) -> None:
        """Test basic health check."""
        response = client.get("/api/v1/health")
        assert response.status_code == 200
        assert response.json()["status"] == "healthy"

    def test_readiness_endpoint(self, client: TestClient) -> None:
        """Test readiness check."""
        response = client.get("/api/v1/health/ready")
        assert response.status_code == 200
        assert "components" in response.json()

    def test_liveness_endpoint(self, client: TestClient) -> None:
        """Test liveness check."""
        response = client.get("/api/v1/health/live")
        assert response.status_code == 200
        assert response.json()["status"] == "alive"

    def test_root_endpoint(self, client: TestClient) -> None:
        """Test root endpoint."""
        response = client.get("/")
        assert response.status_code == 200
        assert "name" in response.json()
        assert "version" in response.json()
