"""End-to-end smoke test for the document extraction pipeline.

Requires the full stack to be running (API, workers, infrastructure).
Skips automatically if the API is not reachable.

Run with:
    uv run pytest tests/e2e/test_smoke.py -v
"""

import time
from pathlib import Path

import pytest
import requests

API_BASE = "http://localhost:8000"
FIXTURE_DIR = Path(__file__).parent.parent / "fixtures"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def api_healthy() -> bool:
    """Check if the API server is reachable."""
    try:
        resp = requests.get(f"{API_BASE}/health", timeout=3)
        return resp.status_code == 200
    except Exception:
        return False


def poll_status(doc_id: str, timeout: int = 120) -> dict:
    """Poll document status until completed/failed or timeout."""
    elapsed = 0
    interval = 3
    while elapsed < timeout:
        resp = requests.get(f"{API_BASE}/api/v1/documents/{doc_id}", timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            status = data.get("status", "")
            if status in ("processed", "completed", "failed"):
                return data
        time.sleep(interval)
        elapsed += interval
    return {"status": "timeout"}


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

pytestmark = [
    pytest.mark.e2e,
    pytest.mark.skipif(not api_healthy(), reason="API server not reachable"),
]


@pytest.fixture()
def sample_invoice_path() -> Path:
    """Get or create sample invoice PDF."""
    pdf_path = FIXTURE_DIR / "sample_invoice.pdf"
    if not pdf_path.exists():
        from tests.fixtures.create_sample_invoice import create_sample_invoice

        create_sample_invoice()
    return pdf_path


def test_health_endpoint():
    """Verify the health endpoint returns 200."""
    resp = requests.get(f"{API_BASE}/health", timeout=5)
    assert resp.status_code == 200
    data = resp.json()
    assert data.get("status") in ("healthy", "ok", "degraded")


def test_ready_endpoint():
    """Verify the readiness endpoint returns service info."""
    resp = requests.get(f"{API_BASE}/api/v1/health/ready", timeout=5)
    assert resp.status_code == 200
    data = resp.json()
    assert "status" in data


def test_upload_and_process(sample_invoice_path: Path):
    """Upload a sample invoice, poll until processed, and verify extraction."""
    # Step 1: Upload
    with sample_invoice_path.open("rb") as f:
        resp = requests.post(
            f"{API_BASE}/api/v1/documents/upload",
            files={"file": ("sample_invoice.pdf", f, "application/pdf")},
            timeout=30,
        )
    # Accept 409 (duplicate) — extract existing doc_id from the detail message
    if resp.status_code == 409:
        detail = resp.json().get("detail", "")
        # Detail format: Document already exists with ID followed by UUID
        doc_id = detail.rsplit(": ", 1)[-1] if ": " in detail else ""
    else:
        assert resp.status_code in (200, 201, 202), f"Upload failed: {resp.text}"
        upload_data = resp.json()
        doc_id = upload_data.get("document_id", "")
    assert doc_id, "No document_id returned from upload"

    # Step 2: Poll status
    final_status = poll_status(doc_id)
    status = final_status.get("status", "")
    assert status != "timeout", "Document processing timed out"
    assert status != "failed", (
        f"Document processing failed: {final_status.get('error_message', 'unknown')}"
    )
    assert status in ("processed", "completed")

    # Step 3: Fetch extraction
    resp = requests.get(f"{API_BASE}/api/v1/extractions/{doc_id}", timeout=10)
    assert resp.status_code == 200, f"Extraction fetch failed: {resp.text}"
    extraction = resp.json()

    # Step 4: Verify fields
    fields = extraction.get("fields", [])
    assert len(fields) > 0, "No fields extracted"

    field_names = [f.get("name", "") for f in fields]
    assert "document_title" in field_names, f"Expected document_title, got: {field_names}"


def test_document_list():
    """Verify the document list endpoint works."""
    resp = requests.get(
        f"{API_BASE}/api/v1/documents",
        params={"page_size": 5},
        timeout=10,
    )
    assert resp.status_code == 200
    data = resp.json()
    assert "documents" in data or "items" in data or isinstance(data, list)


def test_council_stats():
    """Verify council stats endpoint works."""
    resp = requests.get(
        f"{API_BASE}/api/v1/council/stats",
        params={"period": "all"},
        timeout=10,
    )
    # May return 200 with data or 404 if no sessions yet
    assert resp.status_code in (200, 404)
