#!/usr/bin/env python
# ============================================================================
# Agentic Document Extraction System - Download Models Script
# ============================================================================
# Downloads GGUF quantized models via llama.cpp from HuggingFace,
# plus PaddleOCR and BGE-M3 embedding models.
#
# Models are downloaded as GGUF files which are:
#   - Smaller (~4-8GB vs ~14GB for full weights)
#   - Faster to load and run via llama.cpp
#   - Compatible with Metal (Apple Silicon), CUDA, CPU, ROCm, Vulkan
#
# Usage:
#   python scripts/download_models.py                  # Download all models
#   python scripts/download_models.py --model paddle   # Download PaddleOCR only
#   python scripts/download_models.py --model qwen     # Download Qwen VLM GGUF
#   python scripts/download_models.py --model olmocr   # Download olmOCR GGUF
#   python scripts/download_models.py --model colpali  # Download ColPali GGUF
#   python scripts/download_models.py --model bge      # Download BGE-M3 only
#   python scripts/download_models.py --device cpu     # Force CPU device
#   python scripts/download_models.py --device mps     # Force MPS device
#   python scripts/download_models.py --device cuda    # Force CUDA device
#   python scripts/download_models.py --quant Q4_K_M   # Set quantization level
# ============================================================================

import argparse
import asyncio
import logging
import sys
import time
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Valid model choices for the --model flag
VALID_MODELS = ("all", "paddle", "qwen", "olmocr", "colpali", "bge")

# Valid device choices for the --device flag
VALID_DEVICES = ("auto", "cpu", "cuda", "mps")

# Valid quantization levels for GGUF models
VALID_QUANTS = ("Q4_K_M", "Q5_K_M", "Q8_0", "F16")

# GGUF model configurations on HuggingFace
GGUF_MODELS = {
    "qwen": {
        "repo_id": "unsloth/Qwen2.5-VL-7B-Instruct-GGUF",
        "filenames": {
            "Q4_K_M": "Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf",
            "Q5_K_M": "Qwen2.5-VL-7B-Instruct-Q5_K_M.gguf",
            "Q8_0": "Qwen2.5-VL-7B-Instruct-Q8_0.gguf",
            "F16": "Qwen2.5-VL-7B-Instruct-BF16.gguf",
        },
        "mmproj": "mmproj-F16.gguf",
        "description": "Qwen2.5-VL 7B (Vision-Language, Reasoning Expert)",
        "sizes": {
            "Q4_K_M": "~4.9GB",
            "Q5_K_M": "~5.7GB",
            "Q8_0": "~8.1GB",
            "F16": "~14.2GB",
        },
    },
    "olmocr": {
        "repo_id": "bartowski/allenai_olmOCR-2-7B-1025-GGUF",
        "filenames": {
            "Q4_K_M": "allenai_olmOCR-2-7B-1025-Q4_K_M.gguf",
            "Q5_K_M": "allenai_olmOCR-2-7B-1025-Q5_K_M.gguf",
            "Q8_0": "allenai_olmOCR-2-7B-1025-Q8_0.gguf",
            "F16": "allenai_olmOCR-2-7B-1025-BF16.gguf",
        },
        "mmproj": None,
        "description": "olmOCR-2-7B (Allen AI OCR Expert, qwen2vl architecture)",
        "sizes": {"Q4_K_M": "~4.7GB", "Q5_K_M": "~5.4GB", "Q8_0": "~8.1GB", "F16": "~15.2GB"},
    },
    "colpali": {
        "repo_id": "abetlen/paligemma-3b-mix-224-gguf",
        "filenames": {
            "Q4_K_M": "paligemma-3b-mix-224-text-model-q4_k_m.gguf",
            "Q5_K_M": "paligemma-3b-mix-224-text-model-q4_k_m.gguf",  # No Q5 available, use Q4
            "Q8_0": "paligemma-3b-mix-224-text-model-q8_0.gguf",
            "F16": "paligemma-3b-mix-224-text-model-f16.gguf",
        },
        "mmproj": "paligemma-3b-mix-224-mmproj-f16.gguf",
        "description": "PaliGemma 3B (Visual Document Expert, ColPali-style)",
        "sizes": {
            "Q4_K_M": "~2.0GB",
            "Q5_K_M": "~2.0GB",
            "Q8_0": "~3.3GB",
            "F16": "~5.8GB",
        },
    },
}


def detect_device() -> str:
    """
    Detect the best available compute device.

    Checks for Apple Silicon MPS, then NVIDIA CUDA, and falls back to CPU.

    Returns:
        One of "mps", "cuda", or "cpu".
    """
    try:
        import torch
    except ImportError:
        logger.warning(
            "PyTorch is not installed. Cannot detect device. Defaulting to CPU. "
            "Install with: uv sync --extra cpu  (or --extra gpu / --extra metal)"
        )
        return "cpu"

    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"

    if torch.cuda.is_available():
        return "cuda"

    return "cpu"


def _format_size(num_bytes: float) -> str:
    """Format a byte count into a human-readable string."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(num_bytes) < 1024.0:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f} PB"


class ModelDownloader:
    """
    Handles downloading and caching ML models for the council.

    Downloads GGUF quantized models from HuggingFace for use with
    llama.cpp, plus PaddleOCR and BGE-M3 embedding models.
    """

    def __init__(
        self,
        cache_dir: Path | None = None,
        device: str = "auto",
        quant: str = "Q4_K_M",
    ) -> None:
        """
        Initialize the model downloader.

        Args:
            cache_dir: Directory to cache downloaded models.
                      Defaults to ~/.cache/agentic-doc-extraction/models
            device: Compute device to target. One of "auto", "cpu", "cuda", "mps".
                    When "auto", the best available device is detected.
            quant: Quantization level for GGUF models.
                   Q4_K_M (smallest), Q5_K_M, Q8_0, F16 (largest).
        """
        if cache_dir is None:
            cache_dir = Path.home() / ".cache" / "agentic-doc-extraction" / "models"

        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        if device == "auto":
            self.device = detect_device()
        else:
            self.device = device

        self.quant = quant

        logger.info(f"Model cache directory: {self.cache_dir}")
        logger.info(f"Target device: {self.device}")
        logger.info(f"GGUF quantization: {self.quant}")

    async def download_gguf_model(self, model_key: str) -> bool:
        """
        Download a GGUF model and its multimodal projector from HuggingFace.

        Args:
            model_key: Model key from GGUF_MODELS dict ("qwen" or "olmocr").

        Returns:
            True if successful, False otherwise.
        """
        config = GGUF_MODELS[model_key]

        if config.get("unsupported"):
            logger.warning(
                f"Skipping {config['description']}: {config.get('unsupported_reason', 'unsupported architecture')}"
            )
            return False

        repo_id = config["repo_id"]
        filename = config["filenames"].get(self.quant)
        mmproj = config.get("mmproj")
        size = config["sizes"].get(self.quant, "unknown")

        if not filename:
            logger.error(f"Quantization {self.quant} not available for {model_key}")
            return False

        logger.info(f"Downloading {config['description']} ({self.quant}, {size})...")
        logger.info(f"  Repository: {repo_id}")
        logger.info(f"  Model file: {filename}")
        if mmproj:
            logger.info(f"  Projector:  {mmproj}")

        try:
            from huggingface_hub import hf_hub_download
        except ImportError:
            logger.error(
                "huggingface_hub is not installed. "
                "Install with: uv sync --extra metal (or --extra gpu / --extra cpu)"
            )
            return False

        try:
            start = time.monotonic()
            gguf_dir = self.cache_dir / "gguf"
            gguf_dir.mkdir(parents=True, exist_ok=True)

            loop = asyncio.get_running_loop()

            # Download main model GGUF
            model_path = await loop.run_in_executor(
                None,
                lambda: hf_hub_download(
                    repo_id=repo_id,
                    filename=filename,
                    local_dir=str(gguf_dir / model_key),
                ),
            )
            logger.info(f"  Model downloaded: {model_path}")

            # Download multimodal projector if available
            if mmproj:
                try:
                    mmproj_path = await loop.run_in_executor(
                        None,
                        lambda: hf_hub_download(
                            repo_id=repo_id,
                            filename=mmproj,
                            local_dir=str(gguf_dir / model_key),
                        ),
                    )
                    logger.info(f"  Projector downloaded: {mmproj_path}")
                except Exception as e:
                    logger.warning(
                        f"  Multimodal projector not available: {e}. "
                        f"Vision features may be limited."
                    )

            elapsed = time.monotonic() - start
            logger.info(f"{config['description']} downloaded ({elapsed:.1f}s)")
            return True

        except Exception as e:
            logger.error(f"Failed to download {model_key}: {e}")
            logger.info(f"You can retry manually: huggingface-cli download {repo_id} {filename}")
            return False

    async def download_paddle_ocr(self) -> bool:
        """
        Download PaddleOCR models (~200MB).

        Initializes PaddleOCR with angle classification and English language
        support, which triggers the model download on first instantiation.

        Returns:
            True if successful, False otherwise.
        """
        logger.info("Downloading PaddleOCR models (~200MB)...")

        try:
            from paddleocr import PaddleOCR
        except ImportError:
            logger.error(
                "PaddleOCR is not installed. Install with: uv sync --extra cpu  (or --extra gpu)"
            )
            return False

        try:
            start = time.monotonic()

            loop = asyncio.get_running_loop()
            await loop.run_in_executor(
                None,
                lambda: PaddleOCR(
                    use_angle_cls=True,
                    lang="en",
                    show_log=False,
                ),
            )

            elapsed = time.monotonic() - start
            logger.info(
                f"PaddleOCR models downloaded successfully ({elapsed:.1f}s). "
                f"Cached in: ~/.paddleocr/"
            )
            return True

        except Exception as e:
            logger.error(f"Failed to download PaddleOCR models: {e}")
            logger.info(
                "You can retry manually: "
                'python -c "from paddleocr import PaddleOCR; '
                "PaddleOCR(use_angle_cls=True, lang='en')\""
            )
            return False

    async def download_bge_embedding(self) -> bool:
        """
        Download BGE-M3 embedding model (~2GB).

        Uses SentenceTransformer to download and cache the BAAI/bge-m3 model.

        Returns:
            True if successful, False otherwise.
        """
        model_id = "BAAI/bge-m3"
        logger.info(f"Downloading BGE-M3 embedding model: {model_id} (~2GB)...")

        try:
            from sentence_transformers import SentenceTransformer
        except ImportError:
            logger.error(
                "sentence-transformers is not installed. "
                "Install with: uv sync  (included in base dependencies)"
            )
            return False

        try:
            start = time.monotonic()

            loop = asyncio.get_running_loop()
            await loop.run_in_executor(
                None,
                lambda: SentenceTransformer(
                    model_id,
                    cache_folder=str(self.cache_dir / "sentence-transformers"),
                    device=self.device,
                ),
            )

            elapsed = time.monotonic() - start
            logger.info(
                f"BGE-M3 embedding model downloaded successfully ({elapsed:.1f}s). "
                f"Cached in: {self.cache_dir / 'sentence-transformers'}"
            )
            return True

        except Exception as e:
            logger.error(f"Failed to download BGE-M3 embedding model: {e}")
            logger.info(
                f"You can retry manually: "
                f'python -c "from sentence_transformers import SentenceTransformer; '
                f"SentenceTransformer('{model_id}')\""
            )
            return False

    async def download_all(self) -> dict[str, bool]:
        """
        Download all models sequentially.

        Returns:
            A dict mapping model names to their download success status.
        """
        results: dict[str, bool] = {}

        results["PaddleOCR"] = await self.download_paddle_ocr()
        logger.info("")

        results["Qwen VLM (GGUF)"] = await self.download_gguf_model("qwen")
        logger.info("")

        results["olmOCR (GGUF)"] = await self.download_gguf_model("olmocr")
        logger.info("")

        results["ColPali (GGUF)"] = await self.download_gguf_model("colpali")
        logger.info("")

        results["BGE-M3 Embedding"] = await self.download_bge_embedding()
        logger.info("")

        return results

    def get_model_path(self, model_key: str) -> Path | None:
        """
        Get the local path to a downloaded GGUF model.

        Args:
            model_key: Model key ("qwen" or "olmocr").

        Returns:
            Path to the GGUF file, or None if not downloaded.
        """
        config = GGUF_MODELS.get(model_key)
        if not config:
            return None

        filename = config["filenames"].get(self.quant)
        if not filename:
            return None

        path = self.cache_dir / "gguf" / model_key / filename
        return path if path.exists() else None

    def get_mmproj_path(self, model_key: str) -> Path | None:
        """
        Get the local path to a downloaded multimodal projector.

        Args:
            model_key: Model key ("qwen" or "olmocr").

        Returns:
            Path to the mmproj GGUF file, or None if not downloaded.
        """
        config = GGUF_MODELS.get(model_key)
        if not config or not config.get("mmproj"):
            return None

        path = self.cache_dir / "gguf" / model_key / config["mmproj"]
        return path if path.exists() else None


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser for the download script."""
    parser = argparse.ArgumentParser(
        description="Download ML models for the Agentic Document Extraction System.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  %(prog)s                        Download all models\n"
            "  %(prog)s --model paddle          Download PaddleOCR only\n"
            "  %(prog)s --model qwen            Download Qwen VLM GGUF\n"
            "  %(prog)s --model olmocr           Download olmOCR GGUF\n"
            "  %(prog)s --model bge             Download BGE-M3 only\n"
            "  %(prog)s --device cpu            Force CPU device\n"
            "  %(prog)s --device mps            Force MPS (Apple Silicon)\n"
            "  %(prog)s --device cuda           Force CUDA (NVIDIA GPU)\n"
            "  %(prog)s --quant Q8_0            Use Q8_0 quantization (larger, better)\n"
            "  %(prog)s --quant Q4_K_M          Use Q4_K_M quantization (default)\n"
            "  %(prog)s --cache-dir /tmp/m      Use custom cache directory\n"
        ),
    )

    parser.add_argument(
        "--model",
        type=str,
        default="all",
        choices=VALID_MODELS,
        help="Which model to download. Defaults to 'all'.",
    )

    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        choices=VALID_DEVICES,
        help=(
            "Compute device to target. 'auto' detects the best available device. "
            "Defaults to 'auto'."
        ),
    )

    parser.add_argument(
        "--quant",
        type=str,
        default="Q4_K_M",
        choices=VALID_QUANTS,
        help=(
            "GGUF quantization level. Q4_K_M (smallest/fastest), Q5_K_M, "
            "Q8_0 (balanced), F16 (full precision). Defaults to 'Q4_K_M'."
        ),
    )

    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=None,
        help=(
            "Directory to cache downloaded models. "
            "Defaults to ~/.cache/agentic-doc-extraction/models"
        ),
    )

    return parser


async def main() -> None:
    """Entry point for the model download script."""
    parser = build_parser()
    args = parser.parse_args()

    logger.info("=" * 70)
    logger.info("Agentic Document Extraction System - Model Download")
    logger.info("=" * 70)
    logger.info("")
    logger.info("Backend: llama.cpp (GGUF quantized models)")
    logger.info("")

    downloader = ModelDownloader(
        cache_dir=args.cache_dir,
        device=args.device,
        quant=args.quant,
    )

    logger.info("")
    logger.info("Download Plan")
    logger.info("-" * 70)

    model_choice: str = args.model
    quant = args.quant

    if model_choice == "all":
        qwen_size = GGUF_MODELS["qwen"]["sizes"][quant]
        olmocr_size = GGUF_MODELS["olmocr"]["sizes"][quant]
        cp_size = GGUF_MODELS["colpali"]["sizes"][quant]
        logger.info("  1. PaddleOCR         ~200MB   (OCR engine)")
        logger.info(f"  2. Qwen VLM (GGUF)   {qwen_size:<8} (Vision-Language, {quant})")
        logger.info(f"  3. olmOCR (GGUF)     {olmocr_size:<8} (OCR Expert, {quant})")
        logger.info(f"  4. ColPali (GGUF)    {cp_size:<8} (Visual Document, {quant})")
        logger.info("  5. BGE-M3 Embedding  ~2GB     (Vector embeddings)")
    else:
        names = {
            "paddle": "PaddleOCR         ~200MB",
            "qwen": f"Qwen VLM (GGUF)   {GGUF_MODELS['qwen']['sizes'][quant]} ({quant})",
            "olmocr": f"olmOCR (GGUF)     {GGUF_MODELS['olmocr']['sizes'][quant]} ({quant})",
            "colpali": f"ColPali (GGUF)    {GGUF_MODELS['colpali']['sizes'][quant]} ({quant})",
            "bge": "BGE-M3 Embedding  ~2GB",
        }
        logger.info(f"  {names[model_choice]}")

    logger.info("")
    logger.info(f"Device:       {downloader.device}")
    logger.info(f"Quantization: {quant}")
    logger.info(f"Cache:        {downloader.cache_dir}")
    logger.info("-" * 70)
    logger.info("")

    results: dict[str, bool] = {}

    if model_choice == "all":
        results = await downloader.download_all()
    elif model_choice == "paddle":
        results["PaddleOCR"] = await downloader.download_paddle_ocr()
    elif model_choice == "qwen":
        results["Qwen VLM (GGUF)"] = await downloader.download_gguf_model("qwen")
    elif model_choice == "olmocr":
        results["olmOCR (GGUF)"] = await downloader.download_gguf_model("olmocr")
    elif model_choice == "colpali":
        results["ColPali (GGUF)"] = await downloader.download_gguf_model("colpali")
    elif model_choice == "bge":
        results["BGE-M3 Embedding"] = await downloader.download_bge_embedding()

    # Summary
    logger.info("")
    logger.info("=" * 70)
    logger.info("Download Summary")
    logger.info("=" * 70)
    logger.info("")

    all_ok = True
    for model_name, success in results.items():
        status_str = "OK" if success else "FAILED"
        logger.info(f"  {model_name}: {status_str}")
        if not success:
            all_ok = False

    logger.info("")

    if all_ok:
        logger.info("All requested models downloaded successfully.")
    else:
        logger.warning("Some models failed to download. See errors above for details.")

    logger.info("")
    logger.info("Next steps:")
    logger.info(
        "  1. Start infrastructure: docker-compose -f deploy/docker/docker-compose.yml up -d"
    )
    logger.info("  2. Run migrations: alembic upgrade head")
    logger.info("  3. Start services: ./scripts/run.sh")
    logger.info("")

    if not all_ok:
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
