#!/usr/bin/env python3
"""
Quick module test script.

Tests basic functionality of core modules without external dependencies.
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))


def test_settings():
    """Test settings module."""
    print("Testing settings module...")
    from src.config.settings import AppSettings, CouncilSettings

    # Test default settings
    app_settings = AppSettings()
    assert app_settings.name == "agentic-doc-extraction"
    assert app_settings.version == "0.1.0"
    print("  ✓ AppSettings defaults work")

    # Test council settings
    council_settings = CouncilSettings()
    assert council_settings.consensus_threshold == 0.85
    assert council_settings.paddle_ocr_enabled is True
    print("  ✓ CouncilSettings defaults work")

    print("  ✓ Settings module OK")


def test_ocr_interface():
    """Test OCR service interface."""
    print("Testing OCR interface...")
    from src.services.ocr.base import (
        BoundingBox,
        Capability,
        MockOCRService,
        TableCell,
        TableData,
        TextBlock,
    )

    # Test data classes
    bbox = BoundingBox(x=10, y=20, width=100, height=50)
    assert bbox.to_dict() == {"x": 10, "y": 20, "width": 100, "height": 50}
    print("  ✓ BoundingBox works")

    # Test TextBlock
    block = TextBlock(text="Hello", confidence=0.95, bbox=bbox)
    block_dict = block.to_dict()
    assert block_dict["text"] == "Hello"
    assert block_dict["confidence"] == 0.95
    print("  ✓ TextBlock works")

    # Test TableData
    table = TableData(
        cells=[
            TableCell(text="A", row=0, col=0, is_header=True),
            TableCell(text="B", row=0, col=1, is_header=True),
            TableCell(text="1", row=1, col=0),
            TableCell(text="2", row=1, col=1),
        ],
        rows=2,
        cols=2,
    )
    markdown = table.to_markdown()
    assert "| A | B |" in markdown
    assert "| 1 | 2 |" in markdown
    print("  ✓ TableData works")

    # Test MockOCRService
    mock_service = MockOCRService()
    assert mock_service.model_name == "mock-ocr"
    assert Capability.FAST_EXTRACTION in mock_service.capabilities
    print("  ✓ MockOCRService works")

    print("  ✓ OCR interface OK")


def test_consensus_engine():
    """Test consensus engine."""
    print("Testing consensus engine...")
    from src.council.consensus import (
        ConflictLevel,
        ConsensusEngine,
        MemberVote,
        VotingStrategy,
    )

    engine = ConsensusEngine(
        consensus_threshold=0.85,
        unanimous_threshold=0.95,
        min_confidence=0.60,
    )

    # Test unanimous votes
    unanimous_votes = {
        "invoice_number": {
            "paddle": MemberVote("paddle", "INV-123", 0.95),
            "olmocr": MemberVote("olmocr", "INV-123", 0.92),
            "qwen": MemberVote("qwen", "INV-123", 0.90),
        },
    }

    result = engine.calculate_consensus(
        session_id="test-1",
        member_results={},
        extracted_fields=unanimous_votes,
        voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED,
    )

    assert result.consensus_score == 1.0
    assert result.agreed_fields == 1
    assert result.disputed_fields == 0
    assert result.conflict_level == ConflictLevel.NONE
    print("  ✓ Unanimous consensus works")

    # Test conflicting votes (2-1 split)
    conflicting_votes = {
        "amount": {
            "paddle": MemberVote("paddle", "$100", 0.95),
            "olmocr": MemberVote("olmocr", "$100", 0.92),
            "qwen": MemberVote("qwen", "$101", 0.70),  # Different
        },
    }

    result = engine.calculate_consensus(
        session_id="test-2",
        member_results={},
        extracted_fields=conflicting_votes,
        voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED,
    )

    assert result.fields[0].final_value == "$100"  # Majority wins
    assert result.fields[0].conflict_level == ConflictLevel.MINOR
    print("  ✓ Conflict resolution works")

    # Test result serialization
    result_dict = result.to_dict()
    assert "session_id" in result_dict
    assert "consensus_score" in result_dict
    assert "fields" in result_dict
    print("  ✓ Result serialization works")

    print("  ✓ Consensus engine OK")


def test_document_models():
    """Test document models."""
    print("Testing document models...")
    from src.api.routes.documents import (
        MAX_FILE_SIZE,
        DocumentType,
        ProcessingStatus,
        _calculate_checksum,
    )

    # Test constants
    assert MAX_FILE_SIZE == 300 * 1024 * 1024  # 300MB
    print("  ✓ MAX_FILE_SIZE is 300MB")

    # Test checksum
    checksum = _calculate_checksum(b"test content")
    assert len(checksum) == 64  # SHA-256 hex length
    print("  ✓ Checksum calculation works")

    # Test ProcessingStatus enum
    assert ProcessingStatus.PENDING.value == "pending"
    assert ProcessingStatus.COMPLETED.value == "completed"
    print("  ✓ ProcessingStatus enum works")

    # Test DocumentType enum
    assert DocumentType.INVOICE.value == "invoice"
    assert DocumentType.CONTRACT.value == "contract"
    print("  ✓ DocumentType enum works")

    print("  ✓ Document models OK")


def main():
    """Run all tests."""
    print("=" * 60)
    print("Agentic Document Extraction - Module Tests")
    print("=" * 60)
    print()

    try:
        test_settings()
        print()
        test_ocr_interface()
        print()
        test_consensus_engine()
        print()
        test_document_models()
        print()

        print("=" * 60)
        print("ALL TESTS PASSED!")
        print("=" * 60)
        return 0

    except Exception as e:
        print()
        print("=" * 60)
        print(f"TEST FAILED: {e}")
        print("=" * 60)
        import traceback

        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
