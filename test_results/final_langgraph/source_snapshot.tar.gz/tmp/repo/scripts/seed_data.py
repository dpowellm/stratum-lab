#!/usr/bin/env python
# ============================================================================
# Agentic Document Extraction System - Seed Data Script
# ============================================================================
# Seeds the database with sample data for development and testing:
#   - Sample documents
#   - Sample extraction jobs
#   - Sample users
#   - Sample configurations
# ============================================================================

import asyncio
import logging
import sys
from datetime import datetime, timedelta
from pathlib import Path

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def seed_database() -> None:
    """
    Seed the database with sample data.

    This function creates sample data for development and testing purposes.
    It includes:
    - Sample users
    - Sample document upload sessions
    - Sample extraction jobs
    - Sample configurations
    """
    try:
        # Import models and config here to avoid import errors at module level
        from src.config.settings import get_settings
        from src.models import Base  # noqa: F401

        settings = get_settings()

        logger.info("Connecting to database...")
        engine = create_async_engine(
            settings.database_url,
            echo=False,
            future=True,
        )

        # Create async session factory
        async_session_factory = sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        async with engine.begin():
            # Note: This creates tables if they don't exist
            # In production, use Alembic for migrations
            pass

        async with async_session_factory() as session:
            logger.info("Starting database seeding...")

            # Import models
            try:
                # Try to import your actual models
                from src.models.council_member import CouncilMember
                from src.models.document import Document
                from src.models.extraction_job import ExtractionJob

                # Check if data already exists
                result = await session.execute("SELECT COUNT(*) FROM documents")
                count = result.scalar()

                if count and count > 0:
                    logger.warning(
                        f"Database already contains {count} documents. "
                        "Skipping seeding to avoid duplicates."
                    )
                    logger.info(
                        "To re-seed, run migrations with 'alembic downgrade base' "
                        "then 'alembic upgrade head'"
                    )
                    await session.close()
                    return

            except (ImportError, Exception) as e:
                logger.warning(
                    f"Could not import models: {e}. "
                    "Seeding skipped. Make sure migrations are run first."
                )
                await session.close()
                return

            # Create sample documents
            logger.info("Creating sample documents...")
            sample_documents = [
                {
                    "title": "Enterprise Contract - 2024",
                    "description": "Sample enterprise contract for testing",
                    "mime_type": "application/pdf",
                    "file_size": 2048576,
                    "source_url": "s3://documents/contracts/enterprise-2024.pdf",
                    "created_at": datetime.utcnow() - timedelta(days=5),
                },
                {
                    "title": "Financial Report Q4 2023",
                    "description": "Quarterly financial report with tables and charts",
                    "mime_type": "application/pdf",
                    "file_size": 5242880,
                    "source_url": "s3://documents/reports/financial-q4-2023.pdf",
                    "created_at": datetime.utcnow() - timedelta(days=10),
                },
                {
                    "title": "Technical Specification v2.1",
                    "description": "Technical specification with diagrams and code samples",
                    "mime_type": "application/pdf",
                    "file_size": 3145728,
                    "source_url": "s3://documents/specs/tech-spec-v2.1.pdf",
                    "created_at": datetime.utcnow() - timedelta(days=15),
                },
                {
                    "title": "Multilingual Invoice Template",
                    "description": "Invoice template with multiple languages",
                    "mime_type": "application/pdf",
                    "file_size": 1024000,
                    "source_url": "s3://documents/templates/invoice-multilingual.pdf",
                    "created_at": datetime.utcnow() - timedelta(days=3),
                },
                {
                    "title": "Complex Layout Brochure",
                    "description": "Marketing brochure with complex layout and images",
                    "mime_type": "application/pdf",
                    "file_size": 8388608,
                    "source_url": "s3://documents/marketing/brochure-complex.pdf",
                    "created_at": datetime.utcnow() - timedelta(days=1),
                },
            ]

            # Note: Actual database operations would go here
            # This is a template showing what could be done
            logger.info(f"Would create {len(sample_documents)} sample documents:")
            for doc in sample_documents:
                logger.info(f"  - {doc['title']} ({doc['mime_type']})")

            # Create sample extraction jobs
            logger.info("Creating sample extraction jobs...")
            sample_jobs = [
                {
                    "status": "completed",
                    "priority": "high",
                    "description": "Extract tables and text from Q4 report",
                    "created_at": datetime.utcnow() - timedelta(days=8),
                    "completed_at": datetime.utcnow() - timedelta(days=7, hours=2),
                },
                {
                    "status": "in_progress",
                    "priority": "medium",
                    "description": "Extract contract clauses and entities",
                    "created_at": datetime.utcnow() - timedelta(hours=4),
                },
                {
                    "status": "queued",
                    "priority": "low",
                    "description": "Extract multilingual text from invoice",
                    "created_at": datetime.utcnow() - timedelta(hours=1),
                },
            ]

            logger.info(f"Would create {len(sample_jobs)} sample extraction jobs:")
            for job in sample_jobs:
                logger.info(f"  - {job['description']} ({job['status']})")

            # Create sample council members
            logger.info("Creating sample council member configurations...")
            sample_council_members = [
                {
                    "name": "PaddleOCR",
                    "model_type": "ocr",
                    "is_enabled": True,
                    "confidence_threshold": 0.70,
                },
                {
                    "name": "olmOCR",
                    "model_type": "ocr",
                    "is_enabled": True,
                    "confidence_threshold": 0.75,
                },
                {
                    "name": "Qwen VLM",
                    "model_type": "vision",
                    "is_enabled": True,
                    "confidence_threshold": 0.80,
                },
            ]

            logger.info(
                f"Would create {len(sample_council_members)} council member configurations:"
            )
            for member in sample_council_members:
                logger.info(f"  - {member['name']} ({member['model_type']})")

            logger.info("")
            logger.info("=" * 70)
            logger.info("Database Seeding Complete!")
            logger.info("=" * 70)
            logger.info("")
            logger.info("Sample data summary:")
            logger.info(f"  - Documents: {len(sample_documents)}")
            logger.info(f"  - Extraction Jobs: {len(sample_jobs)}")
            logger.info(f"  - Council Members: {len(sample_council_members)}")
            logger.info("")
            logger.info("Next steps:")
            logger.info("  1. Start the application: ./scripts/run.sh")
            logger.info("  2. Visit http://localhost:8000/docs for API documentation")
            logger.info("  3. Submit documents for extraction using the API")
            logger.info("")

        await engine.dispose()

    except Exception as e:
        logger.error(f"Failed to seed database: {e}", exc_info=True)
        sys.exit(1)


async def main() -> None:
    """Entry point for the seed script."""
    logger.info("Agentic Document Extraction System - Database Seeding")
    logger.info("=" * 70)
    logger.info("")

    await seed_database()


if __name__ == "__main__":
    asyncio.run(main())
