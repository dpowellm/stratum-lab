#!/usr/bin/env python3
"""
Standalone syntax verification test.

Tests Python file syntax without requiring external dependencies.
"""

import ast
import sys
from pathlib import Path


def test_file_syntax(file_path: Path) -> tuple[bool, str]:
    """Test if a Python file has valid syntax."""
    try:
        with open(file_path, encoding="utf-8") as f:
            source = f.read()
        ast.parse(source)
        return True, "OK"
    except SyntaxError as e:
        return False, f"Syntax error at line {e.lineno}: {e.msg}"


def test_imports_structure(file_path: Path) -> list[str]:
    """Extract imports from a file to verify structure."""
    try:
        with open(file_path, encoding="utf-8") as f:
            source = f.read()
        tree = ast.parse(source)

        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imports.append(node.module)

        return imports
    except Exception:
        return []


def count_classes_and_functions(file_path: Path) -> tuple[int, int]:
    """Count classes and functions in a file."""
    try:
        with open(file_path, encoding="utf-8") as f:
            source = f.read()
        tree = ast.parse(source)

        classes = 0
        functions = 0

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                classes += 1
            elif isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                functions += 1

        return classes, functions
    except Exception:
        return 0, 0


def main() -> int:
    """Run syntax tests."""
    project_root = Path(__file__).parent.parent

    print("=" * 60)
    print("Agentic Document Extraction - Syntax Verification")
    print("=" * 60)
    print()

    # Key files to test
    key_files = [
        ("Settings", "src/config/settings.py"),
        ("Logging", "src/core/logging.py"),
        ("Consensus Engine", "src/council/consensus.py"),
        ("OCR Interface", "src/services/ocr/base.py"),
        ("API Main", "src/api/main.py"),
        ("Documents Route", "src/api/routes/documents.py"),
        ("Health Route", "src/api/routes/health.py"),
        ("Celery App", "src/workers/celery_app.py"),
        ("Database Base", "src/models/database/base.py"),
        ("Document Model", "src/models/database/document.py"),
        ("Council Session Model", "src/models/database/council_session.py"),
        ("Extraction Model", "src/models/database/extraction.py"),
        ("Test API", "tests/unit/test_api.py"),
        ("Test Settings", "tests/unit/test_settings.py"),
        ("Test Consensus", "tests/unit/test_consensus.py"),
    ]

    errors = []
    total_classes = 0
    total_functions = 0

    for name, rel_path in key_files:
        file_path = project_root / rel_path

        if not file_path.exists():
            print(f"  ✗ {name}: File not found")
            errors.append(f"{name}: File not found")
            continue

        is_valid, message = test_file_syntax(file_path)
        classes, functions = count_classes_and_functions(file_path)
        total_classes += classes
        total_functions += functions

        if is_valid:
            print(f"  ✓ {name}: {classes} classes, {functions} functions")
        else:
            print(f"  ✗ {name}: {message}")
            errors.append(f"{name}: {message}")

    print()
    print("-" * 60)
    print(f"Total: {total_classes} classes, {total_functions} functions")
    print("-" * 60)
    print()

    # Check key components exist
    print("Verifying key components...")

    components_to_check = [
        ("ConsensusEngine class", "src/council/consensus.py", "ConsensusEngine"),
        ("OCRServiceInterface class", "src/services/ocr/base.py", "OCRServiceInterface"),
        ("Settings class", "src/config/settings.py", "Settings"),
        ("create_app function", "src/api/main.py", "create_app"),
        ("upload_document function", "src/api/routes/documents.py", "upload_document"),
    ]

    for component_name, rel_path, identifier in components_to_check:
        file_path = project_root / rel_path
        try:
            with open(file_path, encoding="utf-8") as f:
                content = f.read()
            if identifier in content:
                print(f"  ✓ {component_name} found")
            else:
                print(f"  ✗ {component_name} not found")
                errors.append(f"{component_name} not found in {rel_path}")
        except Exception as e:
            print(f"  ✗ {component_name}: {e}")
            errors.append(f"{component_name}: {e}")

    print()
    print("=" * 60)

    if errors:
        print("VERIFICATION FAILED")
        print("=" * 60)
        for error in errors:
            print(f"  - {error}")
        return 1
    else:
        print("ALL SYNTAX TESTS PASSED!")
        print("=" * 60)
        print()
        print("Project Statistics:")
        print(f"  - {total_classes} classes defined")
        print(f"  - {total_functions} functions defined")
        print()
        print("The project is ready for dependency installation and testing.")
        print()
        print("To run full tests with dependencies:")
        print("  1. Install uv: curl -LsSf https://astral.sh/uv/install.sh | sh")
        print("  2. Install deps: make install-dev")
        print("  3. Run tests: make test")
        return 0


if __name__ == "__main__":
    sys.exit(main())
