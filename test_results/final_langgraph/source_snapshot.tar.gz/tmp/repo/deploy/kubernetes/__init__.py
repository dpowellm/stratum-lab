"""Kubernetes deployment configuration package."""
