"""
GPU Scheduling Configuration.

Task 3.3.3: Configures GPU resource scheduling for council workers.
"""

from dataclasses import dataclass, field
from typing import Any
from enum import Enum

from src.core.logging import get_logger

logger = get_logger(__name__)


class GPUVendor(str, Enum):
    """GPU vendors."""

    NVIDIA = "nvidia"
    AMD = "amd"
    INTEL = "intel"


class GPUType(str, Enum):
    """GPU types for scheduling."""

    # NVIDIA
    NVIDIA_T4 = "nvidia-tesla-t4"
    NVIDIA_V100 = "nvidia-tesla-v100"
    NVIDIA_A100 = "nvidia-tesla-a100"
    NVIDIA_A10G = "nvidia-tesla-a10g"
    NVIDIA_L4 = "nvidia-l4"
    NVIDIA_H100 = "nvidia-h100"
    # AMD
    AMD_MI250 = "amd-instinct-mi250"
    AMD_MI300 = "amd-instinct-mi300"
    # Generic
    ANY = "any"


@dataclass
class GPUResourceConfig:
    """GPU resource configuration for a workload."""

    gpu_count: int = 1
    gpu_type: GPUType = GPUType.ANY
    gpu_vendor: GPUVendor = GPUVendor.NVIDIA
    memory_gb: int | None = None
    mig_profile: str | None = None  # NVIDIA MIG profile
    shared: bool = False
    time_slicing: bool = False

    def to_resource_spec(self) -> dict[str, Any]:
        """Generate Kubernetes resource spec for GPU."""
        resources: dict[str, Any] = {"limits": {}, "requests": {}}

        if self.gpu_vendor == GPUVendor.NVIDIA:
            resource_key = "nvidia.com/gpu"
        elif self.gpu_vendor == GPUVendor.AMD:
            resource_key = "amd.com/gpu"
        else:
            resource_key = "gpu.intel.com/i915"

        resources["limits"][resource_key] = self.gpu_count
        resources["requests"][resource_key] = self.gpu_count

        return resources

    def to_node_selector(self) -> dict[str, str]:
        """Generate node selector for GPU type."""
        if self.gpu_type == GPUType.ANY:
            return {}

        return {
            "accelerator": self.gpu_type.value,
        }

    def to_tolerations(self) -> list[dict[str, Any]]:
        """Generate tolerations for GPU nodes."""
        return [
            {
                "key": "nvidia.com/gpu",
                "operator": "Exists",
                "effect": "NoSchedule",
            },
        ]


@dataclass
class GPUWorkload:
    """GPU workload configuration."""

    name: str
    gpu_config: GPUResourceConfig
    cpu_request: str = "2"
    cpu_limit: str = "8"
    memory_request: str = "8Gi"
    memory_limit: str = "32Gi"
    priority_class: str = "high-priority"

    def to_pod_spec(self) -> dict[str, Any]:
        """Generate pod spec with GPU resources."""
        gpu_resources = self.gpu_config.to_resource_spec()

        return {
            "nodeSelector": self.gpu_config.to_node_selector(),
            "tolerations": self.gpu_config.to_tolerations(),
            "priorityClassName": self.priority_class,
            "containers": [
                {
                    "name": self.name,
                    "resources": {
                        "limits": {
                            **gpu_resources["limits"],
                            "cpu": self.cpu_limit,
                            "memory": self.memory_limit,
                        },
                        "requests": {
                            **gpu_resources["requests"],
                            "cpu": self.cpu_request,
                            "memory": self.memory_request,
                        },
                    },
                }
            ],
        }


class GPUSchedulingManager:
    """
    GPU Scheduling Manager.

    Features:
    - GPU resource allocation
    - Node selection
    - Priority scheduling
    - MIG support
    """

    def __init__(self):
        """Initialize GPU scheduling manager."""
        self._workloads: dict[str, GPUWorkload] = {}
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize with default GPU workloads."""
        # Council member workloads
        for model_name in ["paddle_ocr", "olmocr", "qwen"]:
            workload = GPUWorkload(
                name=f"council-{model_name}",
                gpu_config=GPUResourceConfig(
                    gpu_count=1,
                    gpu_type=GPUType.NVIDIA_T4,
                ),
            )
            self._workloads[workload.name] = workload

        self._initialized = True
        logger.info("GPU scheduling manager initialized")
        return True

    def create_workload(
        self,
        name: str,
        gpu_count: int = 1,
        gpu_type: GPUType = GPUType.ANY,
        memory_request: str = "8Gi",
        memory_limit: str = "32Gi",
    ) -> GPUWorkload:
        """Create a new GPU workload."""
        gpu_config = GPUResourceConfig(
            gpu_count=gpu_count,
            gpu_type=gpu_type,
        )
        workload = GPUWorkload(
            name=name,
            gpu_config=gpu_config,
            memory_request=memory_request,
            memory_limit=memory_limit,
        )
        self._workloads[name] = workload
        return workload

    def get_workload(self, name: str) -> GPUWorkload | None:
        """Get a workload by name."""
        return self._workloads.get(name)

    def set_gpu_type(
        self,
        workload_name: str,
        gpu_type: GPUType,
    ) -> bool:
        """Set GPU type for a workload."""
        workload = self._workloads.get(workload_name)
        if not workload:
            return False
        workload.gpu_config.gpu_type = gpu_type
        return True

    def enable_mig(
        self,
        workload_name: str,
        mig_profile: str,
    ) -> bool:
        """Enable MIG (Multi-Instance GPU) for a workload."""
        workload = self._workloads.get(workload_name)
        if not workload:
            return False
        workload.gpu_config.mig_profile = mig_profile
        return True

    def generate_deployment(
        self,
        workload_name: str,
        replicas: int = 1,
    ) -> dict[str, Any]:
        """Generate Kubernetes deployment for GPU workload."""
        workload = self._workloads.get(workload_name)
        if not workload:
            return {}

        pod_spec = workload.to_pod_spec()

        return {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {
                "name": workload_name,
            },
            "spec": {
                "replicas": replicas,
                "selector": {
                    "matchLabels": {"app": workload_name},
                },
                "template": {
                    "metadata": {
                        "labels": {"app": workload_name},
                    },
                    "spec": pod_spec,
                },
            },
        }

    def get_all_workloads(self) -> list[GPUWorkload]:
        """Get all GPU workloads."""
        return list(self._workloads.values())

    def get_total_gpu_requirements(self) -> dict[str, int]:
        """Calculate total GPU requirements."""
        requirements: dict[str, int] = {}
        for workload in self._workloads.values():
            gpu_type = workload.gpu_config.gpu_type.value
            requirements[gpu_type] = requirements.get(gpu_type, 0) + workload.gpu_config.gpu_count
        return requirements


# Singleton instance
_gpu_manager: GPUSchedulingManager | None = None


def get_gpu_scheduling_manager() -> GPUSchedulingManager:
    """Get or create GPU scheduling manager singleton."""
    global _gpu_manager
    if _gpu_manager is None:
        _gpu_manager = GPUSchedulingManager()
        _gpu_manager.initialize()
    return _gpu_manager
