"""Rename documents.metadata to documents.custom_metadata

Revision ID: 002
Revises: 001
Create Date: 2026-01-30 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op


# Revision identifiers, used by Alembic.
revision: str = "002"
down_revision: Union[str, None] = "001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Rename metadata column to custom_metadata to match ORM model."""
    op.alter_column("documents", "metadata", new_column_name="custom_metadata")


def downgrade() -> None:
    """Revert column name back to metadata."""
    op.alter_column("documents", "custom_metadata", new_column_name="metadata")
