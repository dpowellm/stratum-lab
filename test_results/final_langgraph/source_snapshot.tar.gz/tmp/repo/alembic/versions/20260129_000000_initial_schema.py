"""Initial schema for Agentic Document Extraction System

Revision ID: 001
Revises:
Create Date: 2026-01-29 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# Revision identifiers, used by Alembic.
revision: str = "001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Create initial database schema."""
    # Create enum types
    op.execute("""
        CREATE TYPE processingstatus AS ENUM (
            'pending', 'preprocessing', 'extracting', 'council_deliberating',
            'validating', 'correcting', 'human_review', 'indexing',
            'completed', 'failed'
        )
    """)

    op.execute("""
        CREATE TYPE documenttype AS ENUM (
            'invoice', 'receipt', 'contract', 'form', 'report', 'letter',
            'id_document', 'financial', 'medical', 'legal', 'technical',
            'other', 'unknown'
        )
    """)

    op.execute("""
        CREATE TYPE votingstrategy AS ENUM (
            'confidence_weighted', 'unanimous', 'expertise_delegation', 'cascading'
        )
    """)

    op.execute("""
        CREATE TYPE conflictlevel AS ENUM (
            'none', 'minor', 'moderate', 'major'
        )
    """)

    op.execute("""
        CREATE TYPE conflictresolution AS ENUM (
            'not_applicable', 'majority_vote', 'judge_decision', 'human_review'
        )
    """)

    op.execute("""
        CREATE TYPE validationstatus AS ENUM (
            'pending', 'valid', 'invalid', 'corrected', 'human_verified'
        )
    """)

    op.execute("""
        CREATE TYPE fieldtype AS ENUM (
            'text', 'number', 'date', 'currency', 'percentage', 'email',
            'phone', 'address', 'table', 'list', 'boolean', 'unknown'
        )
    """)

    # Create documents table
    op.create_table(
        "documents",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column("is_deleted", sa.Boolean(), default=False, nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        # File information
        sa.Column("filename", sa.String(512), nullable=False, index=True),
        sa.Column("storage_path", sa.String(1024), nullable=False, unique=True),
        sa.Column("file_size", sa.BigInteger(), nullable=False),
        sa.Column("mime_type", sa.String(128), nullable=False),
        sa.Column("checksum", sa.String(64), nullable=False, unique=True, index=True),
        # Classification
        sa.Column("document_type", postgresql.ENUM("invoice", "receipt", "contract", "form", "report", "letter", "id_document", "financial", "medical", "legal", "technical", "other", "unknown", name="documenttype", create_type=False), default="unknown", nullable=False, index=True),
        sa.Column("type_confidence", sa.Float(), nullable=True),
        # Metadata
        sa.Column("page_count", sa.Integer(), nullable=True),
        sa.Column("language", sa.String(10), nullable=True),
        sa.Column("metadata", postgresql.JSONB(), nullable=True, default={}),
        # Processing status
        sa.Column("status", postgresql.ENUM("pending", "preprocessing", "extracting", "council_deliberating", "validating", "correcting", "human_review", "indexing", "completed", "failed", name="processingstatus", create_type=False), default="pending", nullable=False, index=True),
        sa.Column("status_message", sa.String(512), nullable=True),
        sa.Column("progress_percent", sa.Integer(), default=0, nullable=False),
        sa.Column("processing_started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("processing_completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        # Council integration (FK added later)
        sa.Column("council_session_id", postgresql.UUID(as_uuid=True), nullable=True, index=True),
        sa.Column("consensus_score", sa.Float(), nullable=True),
    )

    # Create council_sessions table
    op.create_table(
        "council_sessions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column("is_deleted", sa.Boolean(), default=False, nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        # Document reference
        sa.Column("document_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True),
        # Council configuration
        sa.Column("voting_strategy", postgresql.ENUM("confidence_weighted", "unanimous", "expertise_delegation", "cascading", name="votingstrategy", create_type=False), default="confidence_weighted", nullable=False),
        sa.Column("consensus_threshold", sa.Float(), default=0.85, nullable=False),
        sa.Column("participating_members", postgresql.JSONB(), nullable=False, default=[]),
        # Consensus results
        sa.Column("consensus_score", sa.Float(), nullable=True),
        sa.Column("agreed_fields", sa.Integer(), default=0, nullable=False),
        sa.Column("disputed_fields", sa.Integer(), default=0, nullable=False),
        sa.Column("total_fields", sa.Integer(), default=0, nullable=False),
        # Conflict information
        sa.Column("conflict_level", postgresql.ENUM("none", "minor", "moderate", "major", name="conflictlevel", create_type=False), default="none", nullable=False),
        sa.Column("conflict_details", postgresql.JSONB(), nullable=True),
        sa.Column("resolution_method", postgresql.ENUM("not_applicable", "majority_vote", "judge_decision", "human_review", name="conflictresolution", create_type=False), default="not_applicable", nullable=False),
        # Judge model
        sa.Column("judge_invoked", sa.Boolean(), default=False, nullable=False),
        sa.Column("judge_model", sa.String(128), nullable=True),
        sa.Column("judge_reasoning", sa.Text(), nullable=True),
        sa.Column("judge_confidence", sa.Float(), nullable=True),
        # Human review
        sa.Column("human_review_required", sa.Boolean(), default=False, nullable=False),
        sa.Column("human_review_reason", sa.String(512), nullable=True),
        sa.Column("human_reviewed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("human_reviewer_id", sa.String(128), nullable=True),
        # Processing metrics
        sa.Column("total_processing_time_ms", sa.Float(), nullable=True),
        sa.Column("consensus_calculation_time_ms", sa.Float(), nullable=True),
        # Final result
        sa.Column("unified_extraction", postgresql.JSONB(), nullable=True),
        sa.Column("final_confidence", sa.Float(), nullable=True),
        sa.Column("session_metadata", postgresql.JSONB(), nullable=True, default={}),
    )

    # Add foreign key from documents to council_sessions
    op.create_foreign_key(
        "fk_documents_council_session",
        "documents",
        "council_sessions",
        ["council_session_id"],
        ["id"],
        ondelete="SET NULL",
    )

    # Create member_votes table
    op.create_table(
        "member_votes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column("is_deleted", sa.Boolean(), default=False, nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        # Council session reference
        sa.Column("council_session_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("council_sessions.id", ondelete="CASCADE"), nullable=False, index=True),
        # Member information
        sa.Column("member_name", sa.String(64), nullable=False, index=True),
        sa.Column("member_version", sa.String(32), nullable=True),
        # Extraction result
        sa.Column("extracted_fields", postgresql.JSONB(), nullable=False, default={}),
        sa.Column("overall_confidence", sa.Float(), nullable=False),
        sa.Column("field_confidences", postgresql.JSONB(), nullable=False, default={}),
        # Processing metrics
        sa.Column("processing_time_ms", sa.Float(), nullable=False),
        sa.Column("tokens_used", sa.Integer(), nullable=True),
        sa.Column("raw_output", sa.Text(), nullable=True),
        # Error tracking
        sa.Column("had_error", sa.Boolean(), default=False, nullable=False),
        sa.Column("error_message", sa.Text(), nullable=True),
    )

    # Create extractions table
    op.create_table(
        "extractions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column("is_deleted", sa.Boolean(), default=False, nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        # References
        sa.Column("document_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("council_session_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("council_sessions.id", ondelete="SET NULL"), nullable=True, index=True),
        # Version tracking
        sa.Column("version", sa.Integer(), default=1, nullable=False),
        sa.Column("is_latest", sa.Boolean(), default=True, nullable=False, index=True),
        sa.Column("previous_version_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("extractions.id", ondelete="SET NULL"), nullable=True),
        # Extraction metadata
        sa.Column("overall_confidence", sa.Float(), nullable=False),
        sa.Column("field_count", sa.Integer(), default=0, nullable=False),
        # Validation
        sa.Column("validation_status", postgresql.ENUM("pending", "valid", "invalid", "corrected", "human_verified", name="validationstatus", create_type=False), default="pending", nullable=False, index=True),
        sa.Column("validation_errors", postgresql.JSONB(), nullable=True),
        sa.Column("validated_at", sa.DateTime(timezone=True), nullable=True),
        # Human review
        sa.Column("human_reviewed", sa.Boolean(), default=False, nullable=False),
        sa.Column("human_reviewer_id", sa.String(128), nullable=True),
        sa.Column("human_reviewed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("human_corrections_count", sa.Integer(), default=0, nullable=False),
        # Denormalized data
        sa.Column("extracted_data", postgresql.JSONB(), nullable=False, default={}),
        sa.Column("extraction_metadata", postgresql.JSONB(), nullable=True, default={}),
    )

    # Create extracted_fields table
    op.create_table(
        "extracted_fields",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column("is_deleted", sa.Boolean(), default=False, nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        # Extraction reference
        sa.Column("extraction_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("extractions.id", ondelete="CASCADE"), nullable=False, index=True),
        # Field information
        sa.Column("field_name", sa.String(256), nullable=False, index=True),
        sa.Column("field_type", postgresql.ENUM("text", "number", "date", "currency", "percentage", "email", "phone", "address", "table", "list", "boolean", "unknown", name="fieldtype", create_type=False), default="text", nullable=False),
        sa.Column("value", postgresql.JSONB(), nullable=True),
        sa.Column("raw_value", sa.Text(), nullable=True),
        # Confidence and source
        sa.Column("confidence", sa.Float(), nullable=False),
        sa.Column("source_model", sa.String(64), nullable=False),
        sa.Column("alternative_values", postgresql.JSONB(), nullable=True),
        # Position
        sa.Column("page_number", sa.Integer(), nullable=True),
        sa.Column("bounding_box", postgresql.JSONB(), nullable=True),
        # Validation
        sa.Column("validation_status", postgresql.ENUM("pending", "valid", "invalid", "corrected", "human_verified", name="validationstatus", create_type=False), default="pending", nullable=False),
        sa.Column("validation_errors", postgresql.JSONB(), nullable=True),
        # Correction tracking
        sa.Column("was_corrected", sa.Boolean(), default=False, nullable=False),
        sa.Column("original_value", postgresql.JSONB(), nullable=True),
        sa.Column("correction_source", sa.String(64), nullable=True),
        sa.Column("corrected_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("corrected_by", sa.String(128), nullable=True),
    )

    # Create indexes
    op.create_index("ix_documents_is_deleted", "documents", ["is_deleted"])
    op.create_index("ix_council_sessions_is_deleted", "council_sessions", ["is_deleted"])
    op.create_index("ix_extractions_is_deleted", "extractions", ["is_deleted"])


def downgrade() -> None:
    """Drop all tables and enum types."""
    # Drop tables in reverse order of creation
    op.drop_table("extracted_fields")
    op.drop_table("extractions")
    op.drop_table("member_votes")

    # Drop foreign key before dropping council_sessions
    op.drop_constraint("fk_documents_council_session", "documents", type_="foreignkey")

    op.drop_table("council_sessions")
    op.drop_table("documents")

    # Drop enum types
    op.execute("DROP TYPE IF EXISTS fieldtype")
    op.execute("DROP TYPE IF EXISTS validationstatus")
    op.execute("DROP TYPE IF EXISTS conflictresolution")
    op.execute("DROP TYPE IF EXISTS conflictlevel")
    op.execute("DROP TYPE IF EXISTS votingstrategy")
    op.execute("DROP TYPE IF EXISTS documenttype")
    op.execute("DROP TYPE IF EXISTS processingstatus")
