"""Core utilities for the Agentic Document Extraction System."""

from src.core.logging import configure_logging, get_logger

__all__ = ["configure_logging", "get_logger"]
