"""
Structured logging configuration using structlog.

This module provides:
- JSON logging for production
- Colored console logging for development
- Request ID propagation
- Council decision logging
- Performance timing logs
"""

import logging
import sys
from contextvars import ContextVar
from typing import Any

import structlog
from structlog.types import Processor

from src.config.settings import get_settings

# Context variable for request ID propagation
request_id_ctx: ContextVar[str | None] = ContextVar("request_id", default=None)

# Context variable for council session ID
council_session_ctx: ContextVar[str | None] = ContextVar("council_session", default=None)


def add_request_id(
    _logger: logging.Logger, _method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Add request ID to log entries if available."""
    request_id = request_id_ctx.get()
    if request_id:
        event_dict["request_id"] = request_id
    return event_dict


def add_council_session(
    _logger: logging.Logger, _method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Add council session ID to log entries if available."""
    council_session = council_session_ctx.get()
    if council_session:
        event_dict["council_session_id"] = council_session
    return event_dict


def add_app_context(
    _logger: logging.Logger, _method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Add application context to log entries."""
    settings = get_settings()
    event_dict["app_name"] = settings.app.name
    event_dict["app_version"] = settings.app.version
    event_dict["environment"] = settings.app.env
    return event_dict


def get_processors(json_format: bool = True) -> list[Processor]:
    """
    Get list of structlog processors based on format.

    Args:
        json_format: If True, use JSON format; otherwise, use console format.

    Returns:
        List of processors for structlog configuration.
    """
    shared_processors: list[Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
        add_request_id,
        add_council_session,
    ]

    if json_format:
        shared_processors.extend(
            [
                structlog.processors.format_exc_info,
                structlog.processors.JSONRenderer(),
            ]
        )
    else:
        shared_processors.extend(
            [
                structlog.dev.ConsoleRenderer(colors=True),
            ]
        )

    return shared_processors


def configure_logging() -> None:
    """
    Configure structured logging for the application.

    This function should be called once at application startup.
    It configures both structlog and the standard library logging.
    """
    settings = get_settings()

    # Determine format based on settings
    json_format = settings.logging.format == "json"

    # Get log level
    log_level = getattr(logging, settings.logging.level.upper(), logging.INFO)

    # Configure structlog
    structlog.configure(
        processors=get_processors(json_format),
        wrapper_class=structlog.make_filtering_bound_logger(log_level),
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    # Configure standard library logging
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(log_level)

    if json_format:
        formatter = structlog.stdlib.ProcessorFormatter(
            processor=structlog.processors.JSONRenderer(),
            foreign_pre_chain=[
                structlog.stdlib.add_log_level,
                structlog.stdlib.add_logger_name,
                structlog.processors.TimeStamper(fmt="iso"),
            ],
        )
    else:
        formatter = structlog.stdlib.ProcessorFormatter(
            processor=structlog.dev.ConsoleRenderer(colors=True),
            foreign_pre_chain=[
                structlog.stdlib.add_log_level,
                structlog.stdlib.add_logger_name,
                structlog.processors.TimeStamper(fmt="iso"),
            ],
        )

    handler.setFormatter(formatter)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.addHandler(handler)
    root_logger.setLevel(log_level)

    # Configure specific loggers
    for logger_name in ["uvicorn", "uvicorn.access", "uvicorn.error"]:
        logger = logging.getLogger(logger_name)
        logger.handlers.clear()
        logger.addHandler(handler)
        logger.setLevel(log_level)

    # Reduce noise from third-party libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    logging.getLogger("aiobotocore").setLevel(logging.WARNING)

    # Add file handler if configured
    if settings.logging.file:
        file_handler = logging.FileHandler(settings.logging.file)
        file_handler.setLevel(log_level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)


def get_logger(name: str | None = None) -> structlog.BoundLogger:
    """
    Get a structured logger instance.

    Args:
        name: Logger name. If None, uses the caller's module name.

    Returns:
        Bound structlog logger instance.

    Example:
        logger = get_logger(__name__)
        logger.info("Processing document", document_id="123")
    """
    return structlog.get_logger(name)


class CouncilLogger:
    """
    Specialized logger for LLM Council operations.

    Provides structured logging for council deliberation, voting,
    and conflict resolution.
    """

    def __init__(self, session_id: str | None = None) -> None:
        """Initialize council logger with optional session ID."""
        self.logger = get_logger("council")
        self.session_id = session_id

    def log_extraction_start(self, document_id: str, members: list[str], strategy: str) -> None:
        """Log the start of council extraction."""
        self.logger.info(
            "Council extraction started",
            council_session_id=self.session_id,
            document_id=document_id,
            council_members=members,
            voting_strategy=strategy,
        )

    def log_member_result(
        self,
        member: str,
        confidence: float,
        processing_time_ms: float,
        field_count: int,
    ) -> None:
        """Log individual council member result."""
        self.logger.info(
            "Council member completed",
            council_session_id=self.session_id,
            member=member,
            confidence=confidence,
            processing_time_ms=processing_time_ms,
            field_count=field_count,
        )

    def log_consensus_result(
        self,
        consensus_score: float,
        agreed_fields: int,
        disputed_fields: int,
        total_fields: int,
    ) -> None:
        """Log consensus calculation result."""
        self.logger.info(
            "Council consensus calculated",
            council_session_id=self.session_id,
            consensus_score=consensus_score,
            agreed_fields=agreed_fields,
            disputed_fields=disputed_fields,
            total_fields=total_fields,
        )

    def log_conflict(
        self,
        field_name: str,
        conflict_level: str,
        member_values: dict[str, Any],
    ) -> None:
        """Log a conflict between council members."""
        self.logger.warning(
            "Council conflict detected",
            council_session_id=self.session_id,
            field_name=field_name,
            conflict_level=conflict_level,
            member_values=member_values,
        )

    def log_judge_decision(
        self,
        field_name: str,
        decision: Any,
        reasoning: str,
        confidence: float,
    ) -> None:
        """Log judge model decision."""
        self.logger.info(
            "Judge model decision",
            council_session_id=self.session_id,
            field_name=field_name,
            decision=str(decision),
            reasoning=reasoning,
            confidence=confidence,
        )

    def log_human_review_flagged(self, field_names: list[str], reason: str) -> None:
        """Log human review flag."""
        self.logger.info(
            "Flagged for human review",
            council_session_id=self.session_id,
            flagged_fields=field_names,
            reason=reason,
        )

    def log_extraction_complete(
        self,
        document_id: str,
        total_time_ms: float,
        final_confidence: float,
        human_review_required: bool,
    ) -> None:
        """Log completion of council extraction."""
        self.logger.info(
            "Council extraction completed",
            council_session_id=self.session_id,
            document_id=document_id,
            total_time_ms=total_time_ms,
            final_confidence=final_confidence,
            human_review_required=human_review_required,
        )


def set_request_id(request_id: str) -> None:
    """Set the request ID for the current context."""
    request_id_ctx.set(request_id)


def set_council_session(session_id: str) -> None:
    """Set the council session ID for the current context."""
    council_session_ctx.set(session_id)


def clear_context() -> None:
    """Clear all context variables."""
    request_id_ctx.set(None)
    council_session_ctx.set(None)
