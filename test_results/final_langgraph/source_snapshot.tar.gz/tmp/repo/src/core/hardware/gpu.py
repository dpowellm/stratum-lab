"""
GPU Management and Acceleration.

Provides unified GPU acceleration across:
- NVIDIA CUDA
- Apple Metal (MPS)
- AMD ROCm
"""

import contextlib
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from src.core.hardware.device import DeviceManager, DeviceType, get_device_manager
from src.core.logging import get_logger

logger = get_logger(__name__)


class GPUBackend(StrEnum):
    """GPU backend types."""

    AUTO = "auto"  # Automatic selection
    CUDA = "cuda"  # NVIDIA CUDA
    METAL = "metal"  # Apple Metal
    ROCM = "rocm"  # AMD ROCm
    CPU = "cpu"  # CPU fallback


@dataclass
class GPUConfig:
    """GPU configuration options."""

    backend: GPUBackend = GPUBackend.AUTO
    device_id: int = 0
    memory_fraction: float = 0.9  # Max GPU memory to use
    allow_growth: bool = True
    enable_mixed_precision: bool = True
    enable_flash_attention: bool = True
    batch_size: int = 1
    num_workers: int = 4
    compile_mode: str | None = None  # torch.compile mode
    metal_options: dict[str, Any] = field(default_factory=dict)
    cuda_options: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "backend": self.backend.value,
            "device_id": self.device_id,
            "memory_fraction": self.memory_fraction,
            "allow_growth": self.allow_growth,
            "enable_mixed_precision": self.enable_mixed_precision,
            "enable_flash_attention": self.enable_flash_attention,
            "batch_size": self.batch_size,
            "num_workers": self.num_workers,
            "compile_mode": self.compile_mode,
            "metal_options": self.metal_options,
            "cuda_options": self.cuda_options,
        }


@dataclass
class GPUMemoryStats:
    """GPU memory statistics."""

    total_memory_gb: float = 0.0
    allocated_memory_gb: float = 0.0
    cached_memory_gb: float = 0.0
    free_memory_gb: float = 0.0
    peak_memory_gb: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "total_memory_gb": self.total_memory_gb,
            "allocated_memory_gb": self.allocated_memory_gb,
            "cached_memory_gb": self.cached_memory_gb,
            "free_memory_gb": self.free_memory_gb,
            "peak_memory_gb": self.peak_memory_gb,
            "utilization_percent": (self.allocated_memory_gb / max(0.01, self.total_memory_gb))
            * 100,
        }


class GPUManager:
    """
    GPU management and acceleration.

    Features:
    - Automatic backend selection
    - Memory management
    - Mixed precision support
    - Device context management
    """

    def __init__(
        self,
        config: GPUConfig | None = None,
        device_manager: DeviceManager | None = None,
    ):
        """
        Initialize GPU manager.

        Args:
            config: GPU configuration
            device_manager: Device manager instance
        """
        self.config = config or GPUConfig()
        self.device_manager = device_manager or get_device_manager()
        self._active_backend: GPUBackend | None = None
        self._device_string: str = "cpu"
        self._initialized = False

    def initialize(self) -> bool:
        """
        Initialize GPU backend.

        Returns:
            True if GPU initialization successful
        """
        if self._initialized:
            return self._active_backend != GPUBackend.CPU

        # Select backend
        if self.config.backend == GPUBackend.AUTO:
            self._active_backend = self._auto_select_backend()
        else:
            self._active_backend = self._validate_backend(self.config.backend)

        # Configure backend
        success = self._configure_backend()

        # Get device string
        self._device_string = self._get_device_string()

        self._initialized = True

        logger.info(
            "GPU manager initialized",
            backend=self._active_backend.value,
            device=self._device_string,
            success=success,
        )

        return success and self._active_backend != GPUBackend.CPU

    def _auto_select_backend(self) -> GPUBackend:
        """Automatically select the best available backend."""
        if self.device_manager.is_cuda_available():
            return GPUBackend.CUDA
        elif self.device_manager.is_metal_available():
            return GPUBackend.METAL
        elif any(d.device_type == DeviceType.ROCM for d in self.device_manager.get_all_devices()):
            return GPUBackend.ROCM
        return GPUBackend.CPU

    def _validate_backend(self, backend: GPUBackend) -> GPUBackend:
        """Validate requested backend is available."""
        if backend == GPUBackend.CUDA and not self.device_manager.is_cuda_available():
            logger.warning("CUDA requested but not available, falling back to CPU")
            return GPUBackend.CPU

        if backend == GPUBackend.METAL and not self.device_manager.is_metal_available():
            logger.warning("Metal requested but not available, falling back to CPU")
            return GPUBackend.CPU

        if backend == GPUBackend.ROCM:
            rocm_devices = self.device_manager.get_devices_by_type(DeviceType.ROCM)
            if not rocm_devices:
                logger.warning("ROCm requested but not available, falling back to CPU")
                return GPUBackend.CPU

        return backend

    def _configure_backend(self) -> bool:
        """Configure the selected backend."""
        try:
            if self._active_backend == GPUBackend.CUDA:
                return self._configure_cuda()
            elif self._active_backend == GPUBackend.METAL:
                return self._configure_metal()
            elif self._active_backend == GPUBackend.ROCM:
                return self._configure_rocm()
            return True  # CPU always succeeds
        except Exception as e:
            logger.error(
                "Backend configuration failed",
                backend=self._active_backend.value,
                error=str(e),
            )
            self._active_backend = GPUBackend.CPU
            return False

    def _configure_cuda(self) -> bool:
        """Configure CUDA backend."""
        try:
            import torch

            # Set device
            if torch.cuda.is_available():
                torch.cuda.set_device(self.config.device_id)

                # Memory management
                if self.config.allow_growth:
                    # PyTorch manages memory dynamically by default
                    pass

                # Set memory fraction
                if self.config.memory_fraction < 1.0:
                    torch.cuda.set_per_process_memory_fraction(
                        self.config.memory_fraction,
                        self.config.device_id,
                    )

                # Enable TF32 for Ampere+ GPUs
                torch.backends.cuda.matmul.allow_tf32 = True
                torch.backends.cudnn.allow_tf32 = True

                # cuDNN benchmark
                torch.backends.cudnn.benchmark = True

                logger.info(
                    "CUDA configured",
                    device_id=self.config.device_id,
                    device_name=torch.cuda.get_device_name(self.config.device_id),
                )
                return True

        except Exception as e:
            logger.error("CUDA configuration failed", error=str(e))
        return False

    def _configure_metal(self) -> bool:
        """Configure Metal (Apple Silicon) backend."""
        try:
            import torch

            if torch.backends.mps.is_available():
                # Metal-specific optimizations
                # Note: MPS doesn't have as many config options as CUDA

                # Enable high bandwidth memory operations if available

                logger.info(
                    "Metal configured",
                    mps_available=torch.backends.mps.is_available(),
                    mps_built=torch.backends.mps.is_built(),
                )
                return True

        except Exception as e:
            logger.error("Metal configuration failed", error=str(e))
        return False

    def _configure_rocm(self) -> bool:
        """Configure ROCm backend."""
        try:
            import torch

            if hasattr(torch, "hip") and torch.hip.is_available():
                torch.hip.set_device(self.config.device_id)

                logger.info(
                    "ROCm configured",
                    device_id=self.config.device_id,
                )
                return True

        except Exception as e:
            logger.error("ROCm configuration failed", error=str(e))
        return False

    def _get_device_string(self) -> str:
        """Get PyTorch device string for current backend."""
        if self._active_backend == GPUBackend.CUDA:
            return f"cuda:{self.config.device_id}"
        elif self._active_backend == GPUBackend.METAL:
            return "mps"
        elif self._active_backend == GPUBackend.ROCM:
            return f"cuda:{self.config.device_id}"  # ROCm uses CUDA API
        return "cpu"

    def get_device(self) -> str:
        """Get the current device string."""
        if not self._initialized:
            self.initialize()
        return self._device_string

    def get_backend(self) -> GPUBackend:
        """Get the active backend."""
        if not self._initialized:
            self.initialize()
        return self._active_backend or GPUBackend.CPU

    def is_gpu_active(self) -> bool:
        """Check if GPU is actively being used."""
        if not self._initialized:
            self.initialize()
        return self._active_backend not in [GPUBackend.CPU, None]

    def get_memory_stats(self) -> GPUMemoryStats:
        """Get current GPU memory statistics."""
        if not self._initialized:
            self.initialize()

        stats = GPUMemoryStats()

        try:
            import torch

            if self._active_backend == GPUBackend.CUDA:
                stats.total_memory_gb = torch.cuda.get_device_properties(
                    self.config.device_id
                ).total_memory / (1024**3)
                stats.allocated_memory_gb = torch.cuda.memory_allocated(self.config.device_id) / (
                    1024**3
                )
                stats.cached_memory_gb = torch.cuda.memory_reserved(self.config.device_id) / (
                    1024**3
                )
                stats.peak_memory_gb = torch.cuda.max_memory_allocated(self.config.device_id) / (
                    1024**3
                )
                stats.free_memory_gb = stats.total_memory_gb - stats.allocated_memory_gb

            elif self._active_backend == GPUBackend.METAL:
                # MPS doesn't have detailed memory stats
                device_info = self.device_manager.get_device(DeviceType.MPS)
                if device_info:
                    stats.total_memory_gb = device_info.total_memory_gb
                    stats.free_memory_gb = device_info.available_memory_gb

        except Exception as e:
            logger.warning("Failed to get memory stats", error=str(e))

        return stats

    def clear_memory(self) -> None:
        """Clear GPU memory cache."""
        try:
            import torch

            if self._active_backend == GPUBackend.CUDA:
                torch.cuda.empty_cache()
                torch.cuda.reset_peak_memory_stats()
            elif self._active_backend == GPUBackend.METAL:
                # MPS memory is managed by macOS
                import gc

                gc.collect()
                if hasattr(torch.mps, "empty_cache"):
                    torch.mps.empty_cache()

            logger.debug("GPU memory cleared")

        except Exception as e:
            logger.warning("Failed to clear GPU memory", error=str(e))

    @contextlib.contextmanager
    def device_context(self):
        """Context manager for GPU device operations."""
        try:
            import torch

            if self._active_backend == GPUBackend.CUDA:
                with torch.cuda.device(self.config.device_id):
                    yield
            else:
                yield

        except ImportError:
            yield

    @contextlib.contextmanager
    def autocast_context(self, enabled: bool = True):
        """
        Context manager for automatic mixed precision.

        Args:
            enabled: Whether to enable autocast
        """
        if not enabled or not self.config.enable_mixed_precision:
            yield
            return

        try:
            import torch

            if self._active_backend == GPUBackend.CUDA:
                with torch.cuda.amp.autocast(enabled=True):
                    yield
            elif self._active_backend == GPUBackend.METAL:
                # MPS autocast support
                with torch.autocast(device_type="mps", dtype=torch.float16, enabled=True):
                    yield
            else:
                yield

        except Exception:
            yield

    def to_device(self, tensor: Any) -> Any:
        """
        Move a tensor to the current device.

        Args:
            tensor: PyTorch tensor

        Returns:
            Tensor on current device
        """
        try:
            import torch

            if isinstance(tensor, torch.Tensor):
                return tensor.to(self._device_string)
            return tensor

        except ImportError:
            return tensor

    def get_optimal_batch_size(
        self,
        model_memory_gb: float = 2.0,
        sample_memory_gb: float = 0.1,
    ) -> int:
        """
        Calculate optimal batch size based on available memory.

        Args:
            model_memory_gb: Estimated model memory usage
            sample_memory_gb: Estimated memory per sample

        Returns:
            Recommended batch size
        """
        stats = self.get_memory_stats()
        available = stats.free_memory_gb - model_memory_gb

        if available <= 0:
            return 1

        batch_size = int(available / sample_memory_gb)
        return max(1, min(batch_size, 64))  # Cap at 64

    def get_summary(self) -> dict[str, Any]:
        """Get GPU manager summary."""
        if not self._initialized:
            self.initialize()

        return {
            "initialized": self._initialized,
            "active_backend": self._active_backend.value if self._active_backend else "none",
            "device_string": self._device_string,
            "gpu_active": self.is_gpu_active(),
            "config": self.config.to_dict(),
            "memory_stats": self.get_memory_stats().to_dict(),
        }


# Singleton instance
_gpu_manager: GPUManager | None = None


def get_gpu_manager() -> GPUManager:
    """Get or create the GPU manager singleton."""
    global _gpu_manager
    if _gpu_manager is None:
        _gpu_manager = GPUManager()
        _gpu_manager.initialize()
    return _gpu_manager
