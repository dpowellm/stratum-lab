"""
Device Detection and Management.

Provides unified interface for detecting and managing compute devices:
- CPU
- NVIDIA CUDA GPUs
- Apple Metal (Apple Silicon)
- AMD ROCm GPUs
"""

import os
import platform
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class DeviceType(StrEnum):
    """Type of compute device."""

    CPU = "cpu"
    CUDA = "cuda"  # NVIDIA CUDA
    MPS = "mps"  # Apple Metal Performance Shaders
    ROCM = "rocm"  # AMD ROCm
    VULKAN = "vulkan"  # Vulkan compute
    ONEAPI = "oneapi"  # Intel oneAPI


@dataclass
class DeviceInfo:
    """Information about a compute device."""

    device_type: DeviceType
    device_id: int
    name: str
    total_memory_gb: float
    available_memory_gb: float
    compute_capability: str | None = None
    driver_version: str | None = None
    is_available: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "device_type": self.device_type.value,
            "device_id": self.device_id,
            "name": self.name,
            "total_memory_gb": self.total_memory_gb,
            "available_memory_gb": self.available_memory_gb,
            "compute_capability": self.compute_capability,
            "driver_version": self.driver_version,
            "is_available": self.is_available,
            "metadata": self.metadata,
        }


class DeviceManager:
    """
    Device detection and management.

    Features:
    - Automatic device detection
    - Multi-device support
    - Device selection strategies
    - Resource monitoring
    """

    def __init__(self):
        """Initialize device manager."""
        self._devices: list[DeviceInfo] = []
        self._default_device: DeviceType | None = None
        self._initialized = False

    def initialize(self) -> None:
        """Initialize and detect available devices."""
        if self._initialized:
            return

        self._devices.clear()

        # Always add CPU
        self._add_cpu_device()

        # Detect CUDA
        if self._check_cuda_available():
            self._detect_cuda_devices()

        # Detect Metal (Apple Silicon)
        if self._check_metal_available():
            self._detect_metal_devices()

        # Detect ROCm
        if self._check_rocm_available():
            self._detect_rocm_devices()

        # Set default device
        self._set_default_device()

        self._initialized = True
        logger.info(
            "Device manager initialized",
            devices=len(self._devices),
            default=self._default_device.value if self._default_device else "cpu",
        )

    def _add_cpu_device(self) -> None:
        """Add CPU device info."""
        import multiprocessing

        cpu_info = DeviceInfo(
            device_type=DeviceType.CPU,
            device_id=0,
            name=platform.processor() or "CPU",
            total_memory_gb=self._get_system_memory_gb(),
            available_memory_gb=self._get_available_memory_gb(),
            metadata={
                "cores": multiprocessing.cpu_count(),
                "platform": platform.platform(),
                "architecture": platform.machine(),
            },
        )
        self._devices.append(cpu_info)

    def _get_system_memory_gb(self) -> float:
        """Get total system memory in GB."""
        try:
            import psutil

            return psutil.virtual_memory().total / (1024**3)
        except ImportError:
            return 8.0  # Default fallback

    def _get_available_memory_gb(self) -> float:
        """Get available system memory in GB."""
        try:
            import psutil

            return psutil.virtual_memory().available / (1024**3)
        except ImportError:
            return 4.0  # Default fallback

    def _check_cuda_available(self) -> bool:
        """Check if CUDA is available."""
        try:
            import torch

            return torch.cuda.is_available()
        except ImportError:
            return False

    def _detect_cuda_devices(self) -> None:
        """Detect CUDA devices."""
        try:
            import torch

            for i in range(torch.cuda.device_count()):
                props = torch.cuda.get_device_properties(i)
                device_info = DeviceInfo(
                    device_type=DeviceType.CUDA,
                    device_id=i,
                    name=props.name,
                    total_memory_gb=props.total_memory / (1024**3),
                    available_memory_gb=(props.total_memory - torch.cuda.memory_allocated(i))
                    / (1024**3),
                    compute_capability=f"{props.major}.{props.minor}",
                    driver_version=torch.version.cuda,
                    metadata={
                        "multi_processor_count": props.multi_processor_count,
                        "max_threads_per_block": props.max_threads_per_block,
                    },
                )
                self._devices.append(device_info)

            logger.info(
                "CUDA devices detected",
                count=torch.cuda.device_count(),
            )
        except Exception as e:
            logger.warning("CUDA detection failed", error=str(e))

    def _check_metal_available(self) -> bool:
        """Check if Metal (Apple Silicon) is available."""
        if platform.system() != "Darwin":
            return False

        try:
            import torch

            return torch.backends.mps.is_available()
        except (ImportError, AttributeError):
            # Check for Metal via platform
            return platform.machine() == "arm64"

    def _detect_metal_devices(self) -> None:
        """Detect Metal (Apple Silicon) devices."""
        try:
            import torch

            if torch.backends.mps.is_available():
                # Get Apple Silicon info
                device_info = DeviceInfo(
                    device_type=DeviceType.MPS,
                    device_id=0,
                    name=self._get_apple_silicon_name(),
                    total_memory_gb=self._get_unified_memory_gb(),
                    available_memory_gb=self._get_unified_memory_gb() * 0.75,  # Estimate
                    metadata={
                        "unified_memory": True,
                        "platform": "Apple Silicon",
                        "mps_built": torch.backends.mps.is_built(),
                    },
                )
                self._devices.append(device_info)

                logger.info(
                    "Metal device detected",
                    name=device_info.name,
                )
        except Exception as e:
            logger.warning("Metal detection failed", error=str(e))

    def _get_apple_silicon_name(self) -> str:
        """Get Apple Silicon chip name."""
        try:
            import subprocess

            result = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],  # noqa: S607
                capture_output=True,
                text=True,
                check=False,
            )
            return result.stdout.strip() or "Apple Silicon"
        except Exception:
            return "Apple Silicon"

    def _get_unified_memory_gb(self) -> float:
        """Get unified memory size for Apple Silicon."""
        return self._get_system_memory_gb()

    def _check_rocm_available(self) -> bool:
        """Check if AMD ROCm is available."""
        return Path("/opt/rocm").exists() or os.environ.get("ROCM_HOME") is not None

    def _detect_rocm_devices(self) -> None:
        """Detect AMD ROCm devices."""
        try:
            import torch

            if hasattr(torch, "hip") and torch.hip.is_available():
                for i in range(torch.hip.device_count()):
                    props = torch.hip.get_device_properties(i)
                    device_info = DeviceInfo(
                        device_type=DeviceType.ROCM,
                        device_id=i,
                        name=props.name,
                        total_memory_gb=props.total_memory / (1024**3),
                        available_memory_gb=props.total_memory / (1024**3) * 0.9,
                        metadata={
                            "gcn_arch": getattr(props, "gcnArchName", "unknown"),
                        },
                    )
                    self._devices.append(device_info)

                logger.info(
                    "ROCm devices detected",
                    count=torch.hip.device_count(),
                )
        except Exception as e:
            logger.debug("ROCm detection skipped", error=str(e))

    def _set_default_device(self) -> None:
        """Set the default device based on availability."""
        # Device priority order: CUDA first, then MPS, then ROCm, finally CPU
        for device_type in [DeviceType.CUDA, DeviceType.MPS, DeviceType.ROCM, DeviceType.CPU]:
            if any(d.device_type == device_type and d.is_available for d in self._devices):
                self._default_device = device_type
                break
        else:
            self._default_device = DeviceType.CPU

    def get_default_device(self) -> DeviceType:
        """Get the default compute device."""
        if not self._initialized:
            self.initialize()
        return self._default_device or DeviceType.CPU

    def get_device(
        self,
        device_type: DeviceType,
        device_id: int = 0,
    ) -> DeviceInfo | None:
        """Get a specific device by type and ID."""
        if not self._initialized:
            self.initialize()

        for device in self._devices:
            if device.device_type == device_type and device.device_id == device_id:
                return device
        return None

    def get_all_devices(self) -> list[DeviceInfo]:
        """Get all detected devices."""
        if not self._initialized:
            self.initialize()
        return self._devices.copy()

    def get_devices_by_type(self, device_type: DeviceType) -> list[DeviceInfo]:
        """Get all devices of a specific type."""
        if not self._initialized:
            self.initialize()
        return [d for d in self._devices if d.device_type == device_type]

    def get_best_available_device(
        self,
        min_memory_gb: float = 0.0,
    ) -> DeviceInfo:
        """
        Get the best available device meeting requirements.

        Args:
            min_memory_gb: Minimum memory required

        Returns:
            Best matching device
        """
        if not self._initialized:
            self.initialize()

        # Filter by memory requirement
        candidates = [d for d in self._devices if d.available_memory_gb >= min_memory_gb]

        if not candidates:
            # Fallback to CPU
            return self.get_device(DeviceType.CPU, 0)

        # Priority order
        priority = {
            DeviceType.CUDA: 4,
            DeviceType.MPS: 3,
            DeviceType.ROCM: 2,
            DeviceType.CPU: 1,
        }

        candidates.sort(
            key=lambda d: (priority.get(d.device_type, 0), d.available_memory_gb),
            reverse=True,
        )

        return candidates[0]

    def is_gpu_available(self) -> bool:
        """Check if any GPU is available."""
        if not self._initialized:
            self.initialize()

        return any(
            d.device_type in [DeviceType.CUDA, DeviceType.MPS, DeviceType.ROCM]
            for d in self._devices
        )

    def is_metal_available(self) -> bool:
        """Check if Metal (Apple Silicon) is available."""
        if not self._initialized:
            self.initialize()

        return any(d.device_type == DeviceType.MPS for d in self._devices)

    def is_cuda_available(self) -> bool:
        """Check if CUDA is available."""
        if not self._initialized:
            self.initialize()

        return any(d.device_type == DeviceType.CUDA for d in self._devices)

    def get_torch_device_string(
        self,
        device_type: DeviceType | None = None,
        device_id: int = 0,
    ) -> str:
        """
        Get PyTorch device string.

        Args:
            device_type: Specific device type or None for default
            device_id: Device ID for multi-GPU

        Returns:
            PyTorch device string (e.g., "cuda:0", "mps", "cpu")
        """
        if device_type is None:
            device_type = self.get_default_device()

        if device_type == DeviceType.CUDA:
            return f"cuda:{device_id}"
        elif device_type == DeviceType.MPS:
            return "mps"
        elif device_type == DeviceType.ROCM:
            return f"cuda:{device_id}"  # ROCm uses CUDA API
        return "cpu"

    def get_summary(self) -> dict[str, Any]:
        """Get device manager summary."""
        if not self._initialized:
            self.initialize()

        return {
            "initialized": self._initialized,
            "default_device": self._default_device.value if self._default_device else "cpu",
            "total_devices": len(self._devices),
            "gpu_available": self.is_gpu_available(),
            "cuda_available": self.is_cuda_available(),
            "metal_available": self.is_metal_available(),
            "devices": [d.to_dict() for d in self._devices],
        }


# Singleton instance
_device_manager: DeviceManager | None = None


def get_device_manager() -> DeviceManager:
    """Get or create the device manager singleton."""
    global _device_manager
    if _device_manager is None:
        _device_manager = DeviceManager()
        _device_manager.initialize()
    return _device_manager
