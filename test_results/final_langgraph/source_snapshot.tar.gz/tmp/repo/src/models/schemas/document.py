"""
Document Request and Response Schemas.

Task 2.2.0: Creates schemas for document upload, status queries,
and document-related API endpoints using Pydantic v2.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field


class DocumentType(str, Enum):
    """Type of document."""

    FORM = "form"
    CONTRACT = "contract"
    RECEIPT = "receipt"
    INVOICE = "invoice"
    IDENTITY = "identity"
    MEDICAL = "medical"
    FINANCIAL = "financial"
    OTHER = "other"
    UNKNOWN = "unknown"


class DocumentStatus(str, Enum):
    """Status of document processing."""

    PENDING = "pending"
    UPLOADED = "uploaded"
    PROCESSING = "processing"
    PROCESSED = "processed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class DocumentFormat(str, Enum):
    """Format of document file."""

    PDF = "pdf"
    PNG = "png"
    JPG = "jpg"
    JPEG = "jpeg"
    TIFF = "tiff"
    BMP = "bmp"
    GIF = "gif"
    WEBP = "webp"
    SVG = "svg"
    HEIC = "heic"
    HEIF = "heif"
    DOCX = "docx"
    DOC = "doc"
    XLSX = "xlsx"
    XLS = "xls"
    PPTX = "pptx"
    PPT = "ppt"
    TXT = "txt"
    CSV = "csv"
    HTML = "html"
    RTF = "rtf"


class DocumentUploadRequest(BaseModel):
    """
    Request to upload a document for extraction.

    Attributes:
        filename: Name of the document file
        file_size_bytes: Size of file in bytes
        file_format: Format of file
        document_type: Type of document (optional auto-detect)
        batch_id: Batch ID if part of batch processing
        metadata: Custom metadata
        priority: Processing priority (low/normal/high)
        callback_url: URL to call when processing complete
    """

    filename: str = Field(..., description="File name")
    file_size_bytes: int = Field(..., ge=0, description="File size in bytes")
    file_format: DocumentFormat = Field(
        ..., description="Document format"
    )
    document_type: Optional[DocumentType] = Field(
        default=None, description="Document type (optional)"
    )
    batch_id: Optional[str] = Field(
        default=None, description="Batch ID if applicable"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Custom metadata"
    )
    priority: str = Field(
        default="normal",
        pattern="^(low|normal|high)$",
        description="Processing priority",
    )
    callback_url: Optional[str] = Field(
        default=None, description="Callback URL for completion"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "filename": "form_submission.pdf",
                "file_size_bytes": 1024000,
                "file_format": "pdf",
                "document_type": "form",
                "batch_id": "batch_001",
                "metadata": {"source": "web_portal"},
                "priority": "normal",
                "callback_url": None,
            }
        }
    )


class DocumentUploadResponse(BaseModel):
    """
    Response to document upload request.

    Attributes:
        document_id: Unique document identifier
        filename: Original filename
        upload_timestamp: When uploaded
        status: Current processing status
        size_bytes: File size
        file_format: Document format
        content_hash: Hash of file content
        extraction_id: Associated extraction ID
    """

    document_id: str = Field(
        ..., description="Unique document identifier"
    )
    filename: str = Field(..., description="Original filename")
    upload_timestamp: datetime = Field(
        default_factory=datetime.utcnow,
        description="When uploaded",
    )
    status: DocumentStatus = Field(
        default=DocumentStatus.PENDING, description="Processing status"
    )
    size_bytes: int = Field(..., ge=0, description="File size")
    file_format: DocumentFormat = Field(..., description="Document format")
    content_hash: Optional[str] = Field(
        default=None, description="File content hash"
    )
    extraction_id: Optional[str] = Field(
        default=None, description="Associated extraction ID"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "document_id": "doc_001",
                "filename": "form_submission.pdf",
                "upload_timestamp": "2025-01-29T16:30:00Z",
                "status": "pending",
                "size_bytes": 1024000,
                "file_format": "pdf",
                "content_hash": "abc123def456",
                "extraction_id": None,
            }
        }
    )


class DocumentStatusQuery(BaseModel):
    """
    Request to query document processing status.

    Attributes:
        document_id: Document ID to query
        include_extraction: Include extraction results
        include_metadata: Include metadata
    """

    document_id: str = Field(..., description="Document ID to query")
    include_extraction: bool = Field(
        default=False, description="Include extraction results"
    )
    include_metadata: bool = Field(
        default=False, description="Include metadata"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "document_id": "doc_001",
                "include_extraction": True,
                "include_metadata": False,
            }
        }
    )


class DocumentStatusResponse(BaseModel):
    """
    Response with document processing status.

    Attributes:
        document_id: Document ID
        status: Current status
        filename: Original filename
        upload_timestamp: When uploaded
        document_type: Detected document type
        processing_start: When processing started
        processing_end: When processing completed
        processing_time_ms: Time taken to process
        progress_percent: Processing progress percentage
        current_stage: Current processing stage
        error_message: Error message if failed
        extraction_data: Extraction results (if available)
        metadata: Document metadata
    """

    document_id: str = Field(..., description="Document ID")
    status: DocumentStatus = Field(..., description="Current status")
    filename: str = Field(..., description="Original filename")
    upload_timestamp: datetime = Field(
        ..., description="When uploaded"
    )
    document_type: Optional[DocumentType] = Field(
        default=None, description="Detected type"
    )
    processing_start: Optional[datetime] = Field(
        default=None, description="When processing started"
    )
    processing_end: Optional[datetime] = Field(
        default=None, description="When processing completed"
    )
    processing_time_ms: float = Field(
        default=0.0, ge=0, description="Processing time"
    )
    progress_percent: int = Field(
        default=0, ge=0, le=100, description="Progress percentage"
    )
    current_stage: Optional[str] = Field(
        default=None, description="Current processing stage"
    )
    error_message: Optional[str] = Field(
        default=None, description="Error message if failed"
    )
    extraction_data: Optional[dict[str, Any]] = Field(
        default=None, description="Extraction results"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Document metadata"
    )
    page_count: Optional[int] = Field(
        default=None, description="Number of pages in the document"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "document_id": "doc_001",
                "status": "processing",
                "filename": "form_submission.pdf",
                "upload_timestamp": "2025-01-29T16:30:00Z",
                "document_type": "form",
                "processing_start": "2025-01-29T16:30:05Z",
                "processing_end": None,
                "processing_time_ms": 5000.0,
                "progress_percent": 50,
                "current_stage": "council_deliberation",
                "error_message": None,
                "extraction_data": None,
                "metadata": {},
            }
        }
    )


class DocumentBatch(BaseModel):
    """
    Batch of documents for processing.

    Attributes:
        batch_id: Unique batch identifier
        document_ids: Document IDs in batch
        total_documents: Total documents
        batch_created_at: When batch created
        expected_completion: Expected completion time
        priority: Batch processing priority
    """

    batch_id: str = Field(
        ..., description="Unique batch identifier"
    )
    document_ids: list[str] = Field(
        default_factory=list, description="Document IDs"
    )
    total_documents: int = Field(
        ..., ge=0, description="Total documents"
    )
    batch_created_at: datetime = Field(
        default_factory=datetime.utcnow,
        description="When batch created",
    )
    expected_completion: Optional[datetime] = Field(
        default=None, description="Expected completion"
    )
    priority: str = Field(
        default="normal",
        pattern="^(low|normal|high)$",
        description="Processing priority",
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "batch_id": "batch_001",
                "document_ids": ["doc_001", "doc_002"],
                "total_documents": 2,
                "batch_created_at": "2025-01-29T16:30:00Z",
                "expected_completion": "2025-01-29T17:00:00Z",
                "priority": "normal",
            }
        }
    )


class DocumentInfo(BaseModel):
    """
    Detailed information about a document.

    Attributes:
        document_id: Unique document identifier
        filename: Original filename
        file_format: Document format
        file_size_bytes: File size in bytes
        document_type: Type of document
        upload_timestamp: When uploaded
        status: Current status
        pages: Number of pages
        language: Document language
        content_hash: Hash of content
        metadata: Additional metadata
    """

    document_id: str = Field(
        ..., description="Unique document identifier"
    )
    filename: str = Field(..., description="Original filename")
    file_format: DocumentFormat = Field(
        ..., description="Document format"
    )
    file_size_bytes: int = Field(..., ge=0, description="File size")
    document_type: Optional[DocumentType] = Field(
        default=None, description="Document type"
    )
    upload_timestamp: datetime = Field(
        ..., description="When uploaded"
    )
    status: DocumentStatus = Field(..., description="Current status")
    pages: Optional[int] = Field(
        default=None, ge=1, description="Number of pages"
    )
    language: str = Field(default="en", description="Document language")
    content_hash: Optional[str] = Field(
        default=None, description="Content hash"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "document_id": "doc_001",
                "filename": "form_submission.pdf",
                "file_format": "pdf",
                "file_size_bytes": 1024000,
                "document_type": "form",
                "upload_timestamp": "2025-01-29T16:30:00Z",
                "status": "processed",
                "pages": 5,
                "language": "en",
                "content_hash": "abc123def456",
                "metadata": {},
            }
        }
    )


class DocumentDeleteRequest(BaseModel):
    """
    Request to delete a document.

    Attributes:
        document_id: Document to delete
        reason: Reason for deletion
        confirm: Confirmation flag
    """

    document_id: str = Field(..., description="Document to delete")
    reason: Optional[str] = Field(
        default=None, description="Reason for deletion"
    )
    confirm: bool = Field(
        default=False, description="Confirmation flag"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "document_id": "doc_001",
                "reason": "Duplicate submission",
                "confirm": True,
            }
        }
    )


class DocumentDeleteResponse(BaseModel):
    """
    Response to document deletion request.

    Attributes:
        document_id: Deleted document ID
        deleted_at: When deleted
        success: Whether deletion was successful
        message: Deletion message
    """

    document_id: str = Field(..., description="Deleted document ID")
    deleted_at: datetime = Field(
        default_factory=datetime.utcnow,
        description="When deleted",
    )
    success: bool = Field(..., description="Success flag")
    message: str = Field(..., description="Deletion message")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "document_id": "doc_001",
                "deleted_at": "2025-01-29T16:35:00Z",
                "success": True,
                "message": "Document deleted successfully",
            }
        }
    )


class DocumentListResponse(BaseModel):
    """
    Response for listing documents.

    Attributes:
        documents: List of document info
        total_count: Total documents available
        page: Current page
        page_size: Items per page
        filters_applied: Filters that were applied
    """

    documents: list[DocumentInfo] = Field(
        default_factory=list, description="Document list"
    )
    total_count: int = Field(..., ge=0, description="Total documents")
    page: int = Field(..., ge=1, description="Current page")
    page_size: int = Field(..., ge=1, description="Items per page")
    filters_applied: dict[str, Any] = Field(
        default_factory=dict, description="Applied filters"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "documents": [],
                "total_count": 10,
                "page": 1,
                "page_size": 20,
                "filters_applied": {},
            }
        }
    )


class DocumentRetryRequest(BaseModel):
    """
    Request to retry failed document processing.

    Attributes:
        document_id: Document to retry
        reason: Reason for retry
        override_config: Override extraction config
    """

    document_id: str = Field(..., description="Document to retry")
    reason: Optional[str] = Field(
        default=None, description="Reason for retry"
    )
    override_config: dict[str, Any] = Field(
        default_factory=dict, description="Config overrides"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "document_id": "doc_001",
                "reason": "Previous failure due to network timeout",
                "override_config": {},
            }
        }
    )
