"""
Extraction Result Schemas.

Task 2.2.4: Creates schemas for extraction results with field-level confidence,
validation results, and quality metrics using Pydantic v2.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field


class FieldConfidenceLevel(str, Enum):
    """Confidence level for extracted fields."""

    VERY_HIGH = "very_high"  # >= 0.95
    HIGH = "high"  # >= 0.85
    MEDIUM = "medium"  # >= 0.70
    LOW = "low"  # >= 0.50
    VERY_LOW = "very_low"  # < 0.50


class ValidationStatus(str, Enum):
    """Status of field validation."""

    VALID = "valid"
    INVALID = "invalid"
    PARTIAL = "partial"
    UNKNOWN = "unknown"


class QualityTier(str, Enum):
    """Quality tier of extraction result."""

    EXCELLENT = "excellent"  # >= 0.95
    GOOD = "good"  # >= 0.85
    FAIR = "fair"  # >= 0.70
    POOR = "poor"  # < 0.70


class ExtractedField(BaseModel):
    """
    Extracted field with confidence and metadata.

    Attributes:
        name: Field name/key
        value: Extracted value
        confidence: Confidence score (0.0-1.0)
        confidence_level: Categorized confidence level
        raw_text: Raw text from document
        source_location: Location in source document
        validation_status: Validation status
        alternatives: Alternative values and scores
        metadata: Additional field metadata
    """

    name: str = Field(..., description="Field name/key")
    value: Optional[Any] = Field(
        default=None, description="Extracted value"
    )
    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Confidence score (0.0-1.0)"
    )
    confidence_level: FieldConfidenceLevel = Field(
        ..., description="Categorized confidence level"
    )
    raw_text: Optional[str] = Field(
        default=None, description="Raw text from document"
    )
    source_location: Optional[dict[str, Any]] = Field(
        default=None,
        description="Location in source (page, bbox, etc.)",
    )
    validation_status: ValidationStatus = Field(
        default=ValidationStatus.UNKNOWN, description="Validation status"
    )
    alternatives: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Alternative values with scores",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "name": "company_name",
                "value": "Acme Corporation",
                "confidence": 0.95,
                "confidence_level": "very_high",
                "raw_text": "Acme Corporation",
                "source_location": {"page": 1, "bbox": [100, 200, 300, 250]},
                "validation_status": "valid",
                "alternatives": [
                    {"value": "ACME Corp", "confidence": 0.85},
                ],
                "metadata": {"extraction_method": "ocr"},
            }
        }
    )


class ExtractionMetrics(BaseModel):
    """
    Metrics for extraction quality and performance.

    Attributes:
        total_fields: Total fields in schema
        extracted_fields: Fields successfully extracted
        missing_fields: Fields not found
        average_confidence: Average confidence across fields
        high_confidence_fields: Fields with >= 0.85 confidence
        low_confidence_fields: Fields with < 0.70 confidence
        quality_tier: Overall quality tier
        processing_time_ms: Time taken for extraction
    """

    total_fields: int = Field(..., ge=0, description="Total fields")
    extracted_fields: int = Field(
        ..., ge=0, description="Successfully extracted"
    )
    missing_fields: int = Field(
        ..., ge=0, description="Fields not found"
    )
    average_confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Average confidence"
    )
    high_confidence_fields: int = Field(
        default=0, ge=0, description="Fields >= 0.85 confidence"
    )
    low_confidence_fields: int = Field(
        default=0, ge=0, description="Fields < 0.70 confidence"
    )
    quality_tier: QualityTier = Field(
        ..., description="Overall quality tier"
    )
    processing_time_ms: float = Field(
        default=0.0, ge=0, description="Processing time in ms"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "total_fields": 10,
                "extracted_fields": 9,
                "missing_fields": 1,
                "average_confidence": 0.89,
                "high_confidence_fields": 8,
                "low_confidence_fields": 0,
                "quality_tier": "good",
                "processing_time_ms": 2500.0,
            }
        }
    )


class FieldValidationError(BaseModel):
    """
    Validation error for a field.

    Attributes:
        field_name: Name of field with error
        error_type: Type of validation error
        error_message: Human-readable error message
        suggestion: Suggested correction
        severity: Error severity
    """

    field_name: str = Field(..., description="Field with error")
    error_type: str = Field(
        ..., description="Type of validation error"
    )
    error_message: str = Field(
        ..., description="Human-readable error message"
    )
    suggestion: Optional[str] = Field(
        default=None, description="Suggested correction"
    )
    severity: str = Field(
        default="warning", description="Error severity"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "field_name": "email",
                "error_type": "invalid_format",
                "error_message": "Invalid email format",
                "suggestion": "Check email format matches user@domain.com",
                "severity": "error",
            }
        }
    )


class ValidationResult(BaseModel):
    """
    Complete validation result for extraction.

    Attributes:
        is_valid: Overall validation status
        valid_fields: Number of valid fields
        invalid_fields: Number of invalid fields
        validation_errors: List of validation errors
        warnings: List of warnings
    """

    is_valid: bool = Field(..., description="Overall validation status")
    valid_fields: int = Field(..., ge=0, description="Number of valid fields")
    invalid_fields: int = Field(
        ..., ge=0, description="Number of invalid fields"
    )
    validation_errors: list[FieldValidationError] = Field(
        default_factory=list, description="Validation errors"
    )
    warnings: list[str] = Field(
        default_factory=list, description="Warnings"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "is_valid": True,
                "valid_fields": 9,
                "invalid_fields": 0,
                "validation_errors": [],
                "warnings": [
                    "Phone number format is unusual for specified country"
                ],
            }
        }
    )


class ExtractionResult(BaseModel):
    """
    Complete extraction result for a document.

    Attributes:
        extraction_id: Unique extraction identifier
        document_id: Source document ID
        document_type: Type of document extracted
        extracted_at: When extraction completed
        fields: Extracted field values
        metrics: Extraction quality metrics
        validation: Validation results
        confidence: Overall extraction confidence
        quality_tier: Overall quality tier
        requires_review: Whether human review is needed
        review_reason: Why review is needed
        metadata: Additional metadata
    """

    extraction_id: str = Field(
        ..., description="Unique extraction identifier"
    )
    document_id: str = Field(..., description="Source document ID")
    document_type: str = Field(..., description="Type of document")
    extracted_at: datetime = Field(
        default_factory=datetime.utcnow,
        description="When extraction completed",
    )
    fields: list[ExtractedField] = Field(
        default_factory=list, description="Extracted fields"
    )
    metrics: ExtractionMetrics = Field(
        ..., description="Extraction metrics"
    )
    validation: ValidationResult = Field(
        ..., description="Validation results"
    )
    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Overall confidence"
    )
    quality_tier: QualityTier = Field(
        ..., description="Overall quality tier"
    )
    requires_review: bool = Field(
        default=False, description="Whether review is needed"
    )
    review_reason: Optional[str] = Field(
        default=None, description="Why review is needed"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "extraction_id": "ext_001",
                "document_id": "doc_001",
                "document_type": "form",
                "extracted_at": "2025-01-29T16:30:00Z",
                "fields": [],
                "metrics": {
                    "total_fields": 10,
                    "extracted_fields": 9,
                    "missing_fields": 1,
                    "average_confidence": 0.89,
                    "quality_tier": "good",
                },
                "validation": {
                    "is_valid": True,
                    "valid_fields": 9,
                    "invalid_fields": 0,
                },
                "confidence": 0.89,
                "quality_tier": "good",
                "requires_review": False,
            }
        }
    )


class ExtractionComparison(BaseModel):
    """
    Comparison between two extraction results.

    Attributes:
        extraction_id_1: First extraction ID
        extraction_id_2: Second extraction ID
        similarity_score: Similarity between extractions (0.0-1.0)
        matching_fields: Fields with same values
        differing_fields: Fields with different values
        differences: Detailed differences
    """

    extraction_id_1: str = Field(
        ..., description="First extraction ID"
    )
    extraction_id_2: str = Field(
        ..., description="Second extraction ID"
    )
    similarity_score: float = Field(
        ..., ge=0.0, le=1.0, description="Similarity score"
    )
    matching_fields: int = Field(
        ..., ge=0, description="Matching field count"
    )
    differing_fields: int = Field(
        ..., ge=0, description="Differing field count"
    )
    differences: list[dict[str, Any]] = Field(
        default_factory=list, description="Detailed differences"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "extraction_id_1": "ext_001",
                "extraction_id_2": "ext_002",
                "similarity_score": 0.92,
                "matching_fields": 9,
                "differing_fields": 1,
                "differences": [],
            }
        }
    )


class BatchExtractionResult(BaseModel):
    """
    Result of batch extraction processing.

    Attributes:
        batch_id: Unique batch identifier
        total_documents: Total documents in batch
        successful_extractions: Successfully extracted
        failed_extractions: Failed extractions
        average_confidence: Average confidence across batch
        average_quality_tier: Most common quality tier
        extraction_results: Individual extraction results
        batch_errors: Batch-level errors
    """

    batch_id: str = Field(
        ..., description="Unique batch identifier"
    )
    total_documents: int = Field(
        ..., ge=0, description="Total documents"
    )
    successful_extractions: int = Field(
        ..., ge=0, description="Successfully extracted"
    )
    failed_extractions: int = Field(
        ..., ge=0, description="Failed extractions"
    )
    average_confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Average confidence"
    )
    average_quality_tier: QualityTier = Field(
        ..., description="Average quality tier"
    )
    extraction_results: list[ExtractionResult] = Field(
        default_factory=list, description="Individual results"
    )
    batch_errors: list[dict[str, Any]] = Field(
        default_factory=list, description="Batch-level errors"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "batch_id": "batch_001",
                "total_documents": 10,
                "successful_extractions": 9,
                "failed_extractions": 1,
                "average_confidence": 0.88,
                "average_quality_tier": "good",
                "extraction_results": [],
                "batch_errors": [],
            }
        }
    )
