"""Pydantic schemas for API request/response models."""

# Common schemas
from src.models.schemas.common import (
    BatchOperationResult,
    ErrorResponse,
    ErrorSeverity,
    HealthCheck,
    HealthStatus,
    MetadataInfo,
    PaginatedResponse,
    PaginationParams,
    ProcessingStatus,
    SuccessResponse,
)

# Document schemas
from src.models.schemas.document import (
    DocumentBatch,
    DocumentDeleteRequest,
    DocumentDeleteResponse,
    DocumentFormat,
    DocumentInfo,
    DocumentListResponse,
    DocumentRetryRequest,
    DocumentStatus,
    DocumentStatusQuery,
    DocumentStatusResponse,
    DocumentType,
    DocumentUploadRequest,
    DocumentUploadResponse,
)

# Extraction schemas
from src.models.schemas.extraction import (
    BatchExtractionResult,
    ExtractedField,
    ExtractionComparison,
    ExtractionMetrics,
    ExtractionResult,
    ExtractedField,
    FieldConfidenceLevel,
    FieldValidationError,
    QualityTier,
    ValidationResult,
    ValidationStatus,
)

# Council schemas
from src.models.schemas.council import (
    ConflictLevel,
    CouncilDeliberation,
    CouncilSession,
    CouncilStatistics,
    FieldConsensus,
    JudgmentDecision,
    JudgmentRequest,
    MemberExpertise,
    MemberVote,
    VotingStrategy,
)

__all__ = [
    # Common
    "BatchOperationResult",
    "ErrorResponse",
    "ErrorSeverity",
    "HealthCheck",
    "HealthStatus",
    "MetadataInfo",
    "PaginatedResponse",
    "PaginationParams",
    "ProcessingStatus",
    "SuccessResponse",
    # Document
    "DocumentBatch",
    "DocumentDeleteRequest",
    "DocumentDeleteResponse",
    "DocumentFormat",
    "DocumentInfo",
    "DocumentListResponse",
    "DocumentRetryRequest",
    "DocumentStatus",
    "DocumentStatusQuery",
    "DocumentStatusResponse",
    "DocumentType",
    "DocumentUploadRequest",
    "DocumentUploadResponse",
    # Extraction
    "BatchExtractionResult",
    "ExtractedField",
    "ExtractionComparison",
    "ExtractionMetrics",
    "ExtractionResult",
    "FieldConfidenceLevel",
    "FieldValidationError",
    "QualityTier",
    "ValidationResult",
    "ValidationStatus",
    # Council
    "ConflictLevel",
    "CouncilDeliberation",
    "CouncilSession",
    "CouncilStatistics",
    "FieldConsensus",
    "JudgmentDecision",
    "JudgmentRequest",
    "MemberExpertise",
    "MemberVote",
    "VotingStrategy",
]
