"""
Council Session and Voting Schemas.

Task 2.2.5: Creates schemas for council deliberation, member votes,
and consensus mechanisms using Pydantic v2.
"""

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class VotingStrategy(str, Enum):
    """Voting strategy for consensus."""

    CONFIDENCE_WEIGHTED = "confidence_weighted"
    UNANIMOUS = "unanimous"
    EXPERTISE_DELEGATION = "expertise_delegation"
    CASCADING = "cascading"
    SIMPLE_MAJORITY = "simple_majority"


class ConflictLevel(str, Enum):
    """Level of conflict between council members."""

    NONE = "none"  # Full agreement
    MINOR = "minor"  # 2 agree, 1 differs
    MODERATE = "moderate"  # All different
    MAJOR = "major"  # Critical field disagreement


class MemberExpertise(str, Enum):
    """Expertise areas of council members."""

    OCR = "ocr"
    FORM_RECOGNITION = "form_recognition"
    CONTRACT_ANALYSIS = "contract_analysis"
    RECEIPT_PARSING = "receipt_parsing"
    DOCUMENT_CLASSIFICATION = "document_classification"
    GENERAL = "general"


class MemberVote(BaseModel):
    """
    Vote from a single council member.

    Attributes:
        member_id: Unique member identifier
        member_name: Name of council member
        expertise: Member's expertise area
        value: Extracted value
        confidence: Confidence in the value (0.0-1.0)
        reasoning: Explanation for the vote
        raw_output: Raw output from member's processing
        processing_time_ms: Time taken by member
        metadata: Additional metadata
    """

    member_id: str = Field(..., description="Unique member identifier")
    member_name: str = Field(..., description="Name of council member")
    expertise: MemberExpertise = Field(..., description="Member's expertise area")
    value: Any | None = Field(default=None, description="Extracted value")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence score")
    reasoning: str | None = Field(default=None, description="Explanation for vote")
    raw_output: dict[str, Any] | None = Field(default=None, description="Raw output from member")
    processing_time_ms: float = Field(default=0.0, ge=0, description="Processing time in ms")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "member_id": "member_001",
                "member_name": "OCR Member A",
                "expertise": "ocr",
                "value": "Company Name",
                "confidence": 0.95,
                "reasoning": "Clear text in document header",
                "raw_output": {"text": "Company Name", "bbox": [10, 20, 100, 40]},
                "processing_time_ms": 250.0,
                "metadata": {},
            }
        }
    )


class FieldConsensus(BaseModel):
    """
    Consensus result for a single field.

    Attributes:
        field_name: Name of the field
        final_value: Final consensus value
        confidence: Confidence in final value (0.0-1.0)
        source_member: Which member's vote was selected
        all_votes: All votes from council members
        conflict_level: Level of disagreement
        agreement_count: Number of agreeing members
        alternative_values: Other proposed values
        consensus_reason: Explanation of consensus decision
    """

    field_name: str = Field(..., description="Name of field")
    final_value: Any | None = Field(default=None, description="Final consensus value")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence in value")
    source_member: str = Field(..., description="Member whose vote was selected")
    all_votes: list[MemberVote] = Field(..., description="All votes from council")
    conflict_level: ConflictLevel = Field(
        default=ConflictLevel.NONE, description="Level of disagreement"
    )
    agreement_count: int = Field(..., ge=0, description="Number of agreeing members")
    alternative_values: list[dict[str, Any]] = Field(
        default_factory=list, description="Other proposed values"
    )
    consensus_reason: str | None = Field(default=None, description="Explanation of decision")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "field_name": "company_name",
                "final_value": "Company Name",
                "confidence": 0.95,
                "source_member": "member_001",
                "all_votes": [],
                "conflict_level": "none",
                "agreement_count": 3,
                "alternative_values": [],
                "consensus_reason": "All members agreed on value",
            }
        }
    )


class CouncilDeliberation(BaseModel):
    """
    Record of council deliberation process.

    Attributes:
        deliberation_id: Unique deliberation identifier
        field_name: Field being deliberated
        voting_strategy: Strategy used for voting
        votes_by_member: Votes organized by member
        discussion_log: Log of deliberation process
        decision_timestamp: When decision was made
        time_to_consensus_ms: Time taken to reach consensus
    """

    deliberation_id: str = Field(..., description="Unique deliberation identifier")
    field_name: str = Field(..., description="Field being deliberated")
    voting_strategy: VotingStrategy = Field(..., description="Voting strategy used")
    votes_by_member: list[MemberVote] = Field(default_factory=list, description="Votes by member")
    discussion_log: list[dict[str, Any]] = Field(
        default_factory=list, description="Deliberation process log"
    )
    decision_timestamp: datetime = Field(
        default_factory=datetime.utcnow,
        description="When decision was made",
    )
    time_to_consensus_ms: float = Field(default=0.0, ge=0, description="Time to reach consensus")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "deliberation_id": "delibr_001",
                "field_name": "company_name",
                "voting_strategy": "confidence_weighted",
                "votes_by_member": [],
                "discussion_log": [],
                "decision_timestamp": "2025-01-29T16:30:00Z",
                "time_to_consensus_ms": 500.0,
            }
        }
    )


class CouncilSession(BaseModel):
    """
    Complete council session for a document.

    Attributes:
        session_id: Unique session identifier
        document_id: Document being processed
        session_started_at: When session started
        session_ended_at: When session ended
        participating_members: List of participating members
        voting_strategy: Overall voting strategy
        total_fields: Total fields in schema
        fields_with_consensus: Fields with consensus
        disputed_fields: Fields without full agreement
        field_consensuses: Consensus for each field
        overall_confidence: Overall confidence score
        consensus_score: Percentage of fields with agreement
        conflict_level: Overall conflict level
        requires_judge: Whether judge review needed
        requires_human_review: Whether human review needed
        processing_time_ms: Total session time
        metadata: Additional metadata
    """

    session_id: str = Field(..., description="Unique session identifier")
    document_id: str = Field(..., description="Document ID")
    session_started_at: datetime = Field(
        default_factory=datetime.utcnow,
        description="When session started",
    )
    session_ended_at: datetime | None = Field(default=None, description="When session ended")
    participating_members: list[str] = Field(
        default_factory=list, description="Participating members"
    )
    voting_strategy: VotingStrategy = Field(..., description="Voting strategy")
    total_fields: int = Field(..., ge=0, description="Total fields in schema")
    fields_with_consensus: int = Field(..., ge=0, description="Fields with consensus")
    disputed_fields: int = Field(..., ge=0, description="Fields without agreement")
    field_consensuses: list[FieldConsensus] = Field(
        default_factory=list, description="Consensus per field"
    )
    overall_confidence: float = Field(..., ge=0.0, le=1.0, description="Overall confidence")
    consensus_score: float = Field(..., ge=0.0, le=1.0, description="Agreement percentage")
    conflict_level: ConflictLevel = Field(
        default=ConflictLevel.NONE, description="Overall conflict level"
    )
    requires_judge: bool = Field(default=False, description="Judge review needed")
    requires_human_review: bool = Field(default=False, description="Human review needed")
    processing_time_ms: float = Field(default=0.0, ge=0, description="Total processing time")
    # --- Explainability fields ---
    judge_invoked: bool = Field(default=False, description="Whether judge LLM was invoked")
    judge_model: str | None = Field(default=None, description="Judge model name")
    judge_reasoning: str | None = Field(default=None, description="Judge reasoning text")
    judge_confidence: float | None = Field(default=None, description="Judge confidence score")
    resolution_method: str | None = Field(
        default=None,
        description="Conflict resolution method used "
        "(majority_vote, judge_decision, human_review, not_applicable)",
    )
    conflict_details: list[dict[str, Any]] = Field(
        default_factory=list, description="Per-field conflict details"
    )
    unified_extraction: dict[str, Any] = Field(
        default_factory=dict, description="Final unified extraction result"
    )
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "session_id": "sess_001",
                "document_id": "doc_001",
                "session_started_at": "2025-01-29T16:30:00Z",
                "session_ended_at": "2025-01-29T16:30:05Z",
                "participating_members": [
                    "member_001",
                    "member_002",
                    "member_003",
                ],
                "voting_strategy": "confidence_weighted",
                "total_fields": 10,
                "fields_with_consensus": 9,
                "disputed_fields": 1,
                "field_consensuses": [],
                "overall_confidence": 0.90,
                "consensus_score": 0.90,
                "conflict_level": "minor",
                "requires_judge": False,
                "requires_human_review": False,
                "processing_time_ms": 5000.0,
            }
        }
    )


class JudgmentRequest(BaseModel):
    """
    Request for judge to arbitrate council conflicts.

    Attributes:
        request_id: Unique request identifier
        session_id: Associated council session
        disputed_fields: Fields needing judgment
        conflict_summary: Summary of conflicts
        created_at: When request created
        assigned_to: Judge assigned to case
    """

    request_id: str = Field(..., description="Unique request identifier")
    session_id: str = Field(..., description="Associated council session")
    disputed_fields: list[str] = Field(default_factory=list, description="Fields needing judgment")
    conflict_summary: str = Field(..., description="Summary of conflicts")
    created_at: datetime = Field(
        default_factory=datetime.utcnow,
        description="When request created",
    )
    assigned_to: str | None = Field(default=None, description="Judge assigned")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "request_id": "judge_req_001",
                "session_id": "sess_001",
                "disputed_fields": ["field_1", "field_2"],
                "conflict_summary": "Members disagree on extraction method",
                "created_at": "2025-01-29T16:30:00Z",
                "assigned_to": None,
            }
        }
    )


class JudgmentDecision(BaseModel):
    """
    Judge's decision on disputed fields.

    Attributes:
        judgment_id: Unique judgment identifier
        request_id: Associated judgment request
        field_decisions: Decisions per field
        reasoning: Overall reasoning
        decided_at: When decision made
        decided_by: Judge who made decision
        confidence: Confidence in decisions
    """

    judgment_id: str = Field(..., description="Unique judgment identifier")
    request_id: str = Field(..., description="Associated judgment request")
    field_decisions: list[dict[str, Any]] = Field(
        default_factory=list, description="Decisions per field"
    )
    reasoning: str | None = Field(default=None, description="Overall reasoning")
    decided_at: datetime = Field(
        default_factory=datetime.utcnow,
        description="When decision made",
    )
    decided_by: str | None = Field(default=None, description="Judge name")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence in decisions")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "judgment_id": "judgment_001",
                "request_id": "judge_req_001",
                "field_decisions": [
                    {
                        "field": "field_1",
                        "decided_value": "value",
                        "reasoning": "Clear evidence",
                    }
                ],
                "reasoning": "Based on document evidence",
                "decided_at": "2025-01-29T16:35:00Z",
                "decided_by": "judge_001",
                "confidence": 0.95,
            }
        }
    )


class CouncilStatistics(BaseModel):
    """
    Statistics about council performance.

    Attributes:
        total_sessions: Total sessions processed
        average_consensus_score: Average consensus percentage
        average_confidence: Average confidence
        member_agreement_matrix: Agreement between members
        most_disputed_fields: Fields most often disputed
        judge_interventions: Number of judge interventions
        average_session_time_ms: Average processing time
    """

    total_sessions: int = Field(..., ge=0, description="Total sessions")
    average_consensus_score: float = Field(..., ge=0.0, le=1.0, description="Average consensus")
    average_confidence: float = Field(..., ge=0.0, le=1.0, description="Average confidence")
    member_agreement_matrix: dict[str, dict[str, float]] = Field(
        default_factory=dict, description="Member agreement matrix"
    )
    most_disputed_fields: list[str] = Field(
        default_factory=list, description="Most disputed fields"
    )
    judge_interventions: int = Field(default=0, ge=0, description="Judge interventions")
    average_session_time_ms: float = Field(default=0.0, ge=0, description="Average session time")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "total_sessions": 100,
                "average_consensus_score": 0.88,
                "average_confidence": 0.86,
                "member_agreement_matrix": {},
                "most_disputed_fields": [
                    "field_1",
                    "field_2",
                ],
                "judge_interventions": 5,
                "average_session_time_ms": 5000.0,
            }
        }
    )
