"""
Common Schemas for API Requests and Responses.

Task 2.2.1: Creates common reusable schemas for pagination, health checks,
and error responses using Pydantic v2.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Generic, Optional, TypeVar

from pydantic import BaseModel, ConfigDict, Field


class ErrorSeverity(str, Enum):
    """Severity level of an error."""

    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class HealthStatus(str, Enum):
    """Health status of the service."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class ProcessingStatus(str, Enum):
    """Status of document processing."""

    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ErrorResponse(BaseModel):
    """
    Error response schema.

    Represents an error that occurred during processing.

    Attributes:
        error_id: Unique identifier for the error
        message: Human-readable error message
        error_code: Machine-readable error code
        severity: Severity level of the error
        timestamp: When the error occurred
        request_id: Associated request ID for tracing
        details: Additional error details
        suggestion: Suggested action to resolve the error
    """

    error_id: str = Field(
        ..., description="Unique identifier for the error"
    )
    message: str = Field(
        ..., description="Human-readable error message"
    )
    error_code: str = Field(
        ..., description="Machine-readable error code"
    )
    severity: ErrorSeverity = Field(
        default=ErrorSeverity.ERROR, description="Severity level"
    )
    timestamp: datetime = Field(
        default_factory=datetime.utcnow,
        description="When the error occurred",
    )
    request_id: Optional[str] = Field(
        default=None, description="Associated request ID"
    )
    details: dict[str, Any] = Field(
        default_factory=dict, description="Additional error details"
    )
    suggestion: Optional[str] = Field(
        default=None, description="Suggested action to resolve"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "error_id": "err_001",
                "message": "Invalid document format",
                "error_code": "INVALID_FORMAT",
                "severity": "error",
                "timestamp": "2025-01-29T16:30:00Z",
                "request_id": "req_12345",
                "details": {"file_type": "txt", "expected": ["pdf", "jpg"]},
                "suggestion": "Please upload a PDF or image file",
            }
        }
    )


class PaginationParams(BaseModel):
    """
    Pagination parameters for list requests.

    Attributes:
        page: Page number (1-indexed)
        page_size: Items per page
        sort_by: Field to sort by
        sort_order: Sort order (asc/desc)
    """

    page: int = Field(
        default=1, ge=1, description="Page number (1-indexed)"
    )
    page_size: int = Field(
        default=20, ge=1, le=100, description="Items per page"
    )
    sort_by: Optional[str] = Field(
        default=None, description="Field to sort by"
    )
    sort_order: str = Field(
        default="asc", pattern="^(asc|desc)$", description="Sort order"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "page": 1,
                "page_size": 20,
                "sort_by": "created_at",
                "sort_order": "desc",
            }
        }
    )


T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    """
    Paginated response wrapper.

    Attributes:
        items: List of items on current page
        total: Total number of items
        page: Current page number
        page_size: Items per page
        total_pages: Total number of pages
        has_more: Whether more pages exist
    """

    items: list[T] = Field(..., description="Items on current page")
    total: int = Field(..., ge=0, description="Total number of items")
    page: int = Field(..., ge=1, description="Current page number")
    page_size: int = Field(..., ge=1, description="Items per page")
    total_pages: int = Field(..., ge=0, description="Total number of pages")
    has_more: bool = Field(..., description="Whether more pages exist")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "items": [],
                "total": 100,
                "page": 1,
                "page_size": 20,
                "total_pages": 5,
                "has_more": True,
            }
        }
    )


class HealthCheck(BaseModel):
    """
    Health check response schema.

    Attributes:
        status: Overall health status
        timestamp: When check was performed
        version: API version
        uptime_seconds: Seconds since service started
        services: Health status of individual services
        dependencies: Health of external dependencies
    """

    status: HealthStatus = Field(..., description="Overall health status")
    timestamp: datetime = Field(
        default_factory=datetime.utcnow,
        description="When check was performed",
    )
    version: str = Field(..., description="API version")
    uptime_seconds: int = Field(..., ge=0, description="Seconds since start")
    services: dict[str, str] = Field(
        default_factory=dict, description="Service health statuses"
    )
    dependencies: dict[str, bool] = Field(
        default_factory=dict, description="Dependency availability"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "status": "healthy",
                "timestamp": "2025-01-29T16:30:00Z",
                "version": "1.0.0",
                "uptime_seconds": 86400,
                "services": {
                    "ocr": "healthy",
                    "council": "healthy",
                    "extraction": "healthy",
                },
                "dependencies": {
                    "database": True,
                    "cache": True,
                    "ocr_service": True,
                },
            }
        }
    )


class MetadataInfo(BaseModel):
    """
    Metadata information attached to responses.

    Attributes:
        request_id: Unique request identifier
        timestamp: When request was processed
        processing_time_ms: Time taken to process
        api_version: API version used
        server_region: Region where processed
    """

    request_id: str = Field(..., description="Unique request identifier")
    timestamp: datetime = Field(
        default_factory=datetime.utcnow,
        description="When request was processed",
    )
    processing_time_ms: float = Field(
        default=0.0, ge=0, description="Processing time in milliseconds"
    )
    api_version: str = Field(default="1.0.0", description="API version")
    server_region: Optional[str] = Field(
        default=None, description="Region where processed"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "request_id": "req_12345",
                "timestamp": "2025-01-29T16:30:00Z",
                "processing_time_ms": 1250.5,
                "api_version": "1.0.0",
                "server_region": "us-east-1",
            }
        }
    )


class BatchOperationResult(BaseModel):
    """
    Result of a batch operation.

    Attributes:
        batch_id: Unique batch identifier
        total_items: Total items in batch
        successful: Number of successful items
        failed: Number of failed items
        results: Individual result details
        errors: Any batch-level errors
    """

    batch_id: str = Field(..., description="Unique batch identifier")
    total_items: int = Field(..., ge=0, description="Total items in batch")
    successful: int = Field(..., ge=0, description="Successful items")
    failed: int = Field(..., ge=0, description="Failed items")
    results: list[dict[str, Any]] = Field(
        default_factory=list, description="Individual result details"
    )
    errors: list[ErrorResponse] = Field(
        default_factory=list, description="Batch-level errors"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "batch_id": "batch_123",
                "total_items": 10,
                "successful": 8,
                "failed": 2,
                "results": [],
                "errors": [],
            }
        }
    )


class SuccessResponse(BaseModel):
    """
    Generic success response wrapper.

    Attributes:
        success: Whether operation was successful
        message: Optional success message
        data: Response data
        metadata: Request metadata
    """

    success: bool = Field(default=True, description="Success flag")
    message: Optional[str] = Field(
        default=None, description="Success message"
    )
    data: Optional[dict[str, Any]] = Field(
        default=None, description="Response data"
    )
    metadata: Optional[MetadataInfo] = Field(
        default=None, description="Request metadata"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "success": True,
                "message": "Operation completed successfully",
                "data": {},
                "metadata": {
                    "request_id": "req_12345",
                    "timestamp": "2025-01-29T16:30:00Z",
                    "processing_time_ms": 100.5,
                },
            }
        }
    )
