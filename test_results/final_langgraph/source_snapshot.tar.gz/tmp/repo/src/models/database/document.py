"""
Document model for storing document metadata and processing status.

This module defines the Document model which stores:
- File information (filename, path, size, mime_type, checksum)
- Document classification (type, confidence)
- Metadata (page_count, language, custom metadata)
- Processing status and timestamps
- Council session references
"""

import enum
import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any

from sqlalchemy import (
    BigInteger,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.models.database.base import Base

if TYPE_CHECKING:
    from src.models.database.council_session import CouncilSession
    from src.models.database.extraction import Extraction


class ProcessingStatus(str, enum.Enum):
    """Processing status for documents."""

    PENDING = "pending"
    PREPROCESSING = "preprocessing"
    EXTRACTING = "extracting"
    COUNCIL_DELIBERATING = "council_deliberating"
    VALIDATING = "validating"
    CORRECTING = "correcting"
    HUMAN_REVIEW = "human_review"
    INDEXING = "indexing"
    COMPLETED = "completed"
    FAILED = "failed"


class DocumentType(str, enum.Enum):
    """Document type classification."""

    INVOICE = "invoice"
    RECEIPT = "receipt"
    CONTRACT = "contract"
    FORM = "form"
    REPORT = "report"
    LETTER = "letter"
    ID_DOCUMENT = "id_document"
    FINANCIAL = "financial"
    MEDICAL = "medical"
    LEGAL = "legal"
    TECHNICAL = "technical"
    OTHER = "other"
    UNKNOWN = "unknown"


class Document(Base):
    """
    Document model for storing document metadata and processing information.

    Attributes:
        id: Unique identifier (UUID)
        filename: Original filename
        storage_path: Path in object storage (S3/MinIO)
        file_size: File size in bytes
        mime_type: MIME type of the file
        checksum: SHA-256 checksum of the file

        document_type: Classified document type
        type_confidence: Confidence of type classification

        page_count: Number of pages
        language: Detected language code
        custom_metadata: Additional metadata (JSON)

        status: Current processing status
        status_message: Human-readable status message
        progress_percent: Processing progress (0-100)
        processing_started_at: When processing started
        processing_completed_at: When processing completed
        error_message: Error details if failed

        council_session_id: Reference to council session
        consensus_score: Final consensus score from council

        created_at: Record creation timestamp
        updated_at: Last update timestamp
    """

    __tablename__ = "documents"

    # File information
    filename: Mapped[str] = mapped_column(
        String(512),
        nullable=False,
        index=True,
    )
    storage_path: Mapped[str] = mapped_column(
        String(1024),
        nullable=False,
        unique=True,
    )
    file_size: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
    )
    mime_type: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
    )
    checksum: Mapped[str] = mapped_column(
        String(64),  # SHA-256 hex digest
        nullable=False,
        unique=True,
        index=True,
    )

    # Document classification
    document_type: Mapped[DocumentType] = mapped_column(
        Enum(DocumentType, values_callable=lambda x: [e.value for e in x], create_type=False),
        default=DocumentType.UNKNOWN,
        nullable=False,
        index=True,
    )
    type_confidence: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
    )

    # Document metadata
    page_count: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
    )
    language: Mapped[str | None] = mapped_column(
        String(10),  # ISO language code
        nullable=True,
    )
    custom_metadata: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB,
        nullable=True,
        default=dict,
    )

    # Processing status
    status: Mapped[ProcessingStatus] = mapped_column(
        Enum(ProcessingStatus, values_callable=lambda x: [e.value for e in x], create_type=False),
        default=ProcessingStatus.PENDING,
        nullable=False,
        index=True,
    )
    status_message: Mapped[str | None] = mapped_column(
        String(512),
        nullable=True,
    )
    progress_percent: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )
    processing_started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    processing_completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    error_message: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    # Council integration
    council_session_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("council_sessions.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    consensus_score: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
    )

    # Relationships
    council_session: Mapped["CouncilSession | None"] = relationship(
        "CouncilSession",
        lazy="selectin",
        foreign_keys=[council_session_id],
        viewonly=True,
    )
    extractions: Mapped[list["Extraction"]] = relationship(
        "Extraction",
        back_populates="document",
        lazy="selectin",
        cascade="all, delete-orphan",
    )

    def start_processing(self) -> None:
        """Mark document as started processing."""
        self.status = ProcessingStatus.PREPROCESSING
        self.processing_started_at = datetime.utcnow()
        self.progress_percent = 5

    def update_status(
        self,
        status: ProcessingStatus,
        message: str | None = None,
        progress: int | None = None,
    ) -> None:
        """Update processing status."""
        self.status = status
        if message:
            self.status_message = message
        if progress is not None:
            self.progress_percent = max(0, min(100, progress))

    def complete(self, consensus_score: float | None = None) -> None:
        """Mark document as completed."""
        self.status = ProcessingStatus.COMPLETED
        self.processing_completed_at = datetime.utcnow()
        self.progress_percent = 100
        if consensus_score is not None:
            self.consensus_score = consensus_score

    def fail(self, error_message: str) -> None:
        """Mark document as failed."""
        self.status = ProcessingStatus.FAILED
        self.error_message = error_message
        self.processing_completed_at = datetime.utcnow()

    def flag_for_human_review(self, reason: str) -> None:
        """Flag document for human review."""
        self.status = ProcessingStatus.HUMAN_REVIEW
        self.status_message = reason

    @property
    def is_processing(self) -> bool:
        """Check if document is currently being processed."""
        return self.status not in [
            ProcessingStatus.PENDING,
            ProcessingStatus.COMPLETED,
            ProcessingStatus.FAILED,
            ProcessingStatus.HUMAN_REVIEW,
        ]

    @property
    def processing_duration_seconds(self) -> float | None:
        """Calculate processing duration in seconds."""
        if self.processing_started_at is None:
            return None
        end_time = self.processing_completed_at or datetime.utcnow()
        return (end_time - self.processing_started_at).total_seconds()
