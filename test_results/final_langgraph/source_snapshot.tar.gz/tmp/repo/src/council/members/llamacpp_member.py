"""llama.cpp Council Member implementation.

Provides efficient local inference for vision-language models using
llama-cpp-python with GGUF quantized models from HuggingFace.

Supports:
- Apple Silicon (Metal) acceleration
- NVIDIA CUDA acceleration
- CPU fallback
- Multimodal (vision + text) models via llava-style chat handlers

This is the preferred local inference backend due to:
- Smaller model sizes (~4-8GB vs ~14GB for full weights)
- Broader hardware support (Metal, CUDA, CPU, ROCm, Vulkan)
- Lower memory usage via quantization (Q4_K_M, Q5_K_M, Q8_0)
- No PyTorch dependency for inference
"""

import asyncio
import base64
import json
import time
from pathlib import Path
from typing import Any

from src.core.logging import get_logger
from src.council.members.base import (
    CouncilMember,
    ExtractionResult,
    FieldExtraction,
    MemberCapability,
)

logger = get_logger(__name__)

# Default GGUF model repos on HuggingFace
DEFAULT_GGUF_MODELS = {
    "qwen2-vl": {
        "repo_id": "Qwen/Qwen2.5-VL-7B-Instruct-GGUF",
        "filename": "qwen2.5-vl-7b-instruct-q4_k_m.gguf",
        "mmproj_filename": "qwen2.5-vl-7b-instruct-mmproj-f16.gguf",
        "chat_format": "qwen",
    },
    "olmocr": {
        "repo_id": "bartowski/allenai_olmOCR-2-7B-1025-GGUF",
        "filename": "allenai_olmOCR-2-7B-1025-Q4_K_M.gguf",
        "mmproj_filename": None,
        "chat_format": "qwen",
    },
}


class LlamaCppMember(CouncilMember):
    """Council member using llama.cpp for local GGUF model inference.

    Uses llama-cpp-python to run quantized GGUF models efficiently
    on any hardware (Metal, CUDA, CPU).
    """

    def __init__(
        self,
        name: str,
        model_path: str | Path,
        mmproj_path: str | Path | None = None,
        n_ctx: int = 4096,
        n_gpu_layers: int = -1,
        n_threads: int | None = None,
        chat_format: str | None = None,
        capabilities: list[MemberCapability] | None = None,
        confidence_threshold: float = 0.6,
        verbose: bool = False,
    ):
        """Initialize llama.cpp council member.

        Args:
            name: Unique member name
            model_path: Path to GGUF model file
            mmproj_path: Path to multimodal projector GGUF (for vision models)
            n_ctx: Context window size
            n_gpu_layers: Number of layers to offload to GPU (-1 = all)
            n_threads: Number of CPU threads (None = auto)
            chat_format: Chat template format (e.g., "qwen", "chatml")
            capabilities: List of member capabilities
            confidence_threshold: Minimum confidence to report
            verbose: Enable verbose llama.cpp output
        """
        if capabilities is None:
            capabilities = [
                MemberCapability.TEXT_EXTRACTION,
                MemberCapability.TABLE_EXTRACTION,
                MemberCapability.FORM_UNDERSTANDING,
                MemberCapability.LAYOUT_ANALYSIS,
                MemberCapability.LOCAL_PROCESSING,
            ]
            if mmproj_path:
                capabilities.append(MemberCapability.IMAGE_REASONING)

        super().__init__(
            name=name,
            model_version=Path(model_path).stem,
            capabilities=capabilities,
            confidence_threshold=confidence_threshold,
        )

        self._model_path = Path(model_path)
        self._mmproj_path = Path(mmproj_path) if mmproj_path else None
        self._n_ctx = n_ctx
        self._n_gpu_layers = n_gpu_layers
        self._n_threads = n_threads
        self._chat_format = chat_format
        self._verbose = verbose
        self._llm = None

    async def initialize(self) -> None:
        """Initialize the llama.cpp model."""
        if self._initialized:
            return

        logger.info(
            "Initializing llama.cpp member",
            name=self._name,
            model=str(self._model_path),
            gpu_layers=self._n_gpu_layers,
        )

        try:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._load_model)
            self._initialized = True
            logger.info("llama.cpp member initialized", name=self._name)

        except ImportError:
            logger.error(
                "llama-cpp-python not installed. "
                "Install with: uv sync --extra metal (or --extra gpu / --extra cpu)"
            )
            raise
        except Exception as e:
            logger.error("Failed to initialize llama.cpp member", error=str(e))
            raise

    def _load_model(self) -> None:
        """Load the GGUF model synchronously."""
        from llama_cpp import Llama

        kwargs: dict[str, Any] = {
            "model_path": str(self._model_path),
            "n_ctx": self._n_ctx,
            "n_gpu_layers": self._n_gpu_layers,
            "verbose": self._verbose,
        }

        if self._n_threads is not None:
            kwargs["n_threads"] = self._n_threads

        if self._chat_format:
            kwargs["chat_format"] = self._chat_format

        # Enable multimodal support if projector path is provided
        if self._mmproj_path and self._mmproj_path.exists():
            kwargs["chat_handler"] = self._create_chat_handler()

        self._llm = Llama(**kwargs)

    def _create_chat_handler(self) -> Any:
        """Create a multimodal chat handler for vision models."""
        from llama_cpp.llama_chat_format import Llava16ChatHandler

        return Llava16ChatHandler(
            clip_model_path=str(self._mmproj_path),
            verbose=self._verbose,
        )

    async def shutdown(self) -> None:
        """Release model resources."""
        if self._llm:
            del self._llm
            self._llm = None

        self._initialized = False
        logger.info("llama.cpp member shutdown", name=self._name)

    async def extract(
        self,
        image_data: bytes,
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> ExtractionResult:
        """Extract fields from a document image using llama.cpp.

        Args:
            image_data: Document image as bytes
            document_type: Type hint for extraction
            target_fields: Specific fields to extract
            options: Additional options

        Returns:
            ExtractionResult with extracted fields
        """
        if not self._initialized:
            await self.initialize()

        options = options or {}
        start_time = time.time()

        try:
            prompt = self._build_extraction_prompt(document_type, target_fields)
            messages = self._build_messages(image_data, prompt)

            # Run inference in executor to avoid blocking the event loop
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self._llm.create_chat_completion(
                    messages=messages,
                    max_tokens=self._n_ctx // 2,
                    temperature=0.0,
                ),
            )

            response_text = response["choices"][0]["message"]["content"]
            fields = self._parse_response(response_text, document_type)
            fields = self._filter_by_confidence(fields)

            elapsed_ms = int((time.time() - start_time) * 1000)

            return ExtractionResult(
                member_name=self._name,
                model_version=self._model_version,
                fields=fields,
                processing_time_ms=elapsed_ms,
                page_count=1,
                raw_response={"text": response_text},
            )

        except Exception as e:
            elapsed_ms = int((time.time() - start_time) * 1000)
            logger.error("llama.cpp extraction failed", error=str(e), name=self._name)

            return ExtractionResult(
                member_name=self._name,
                model_version=self._model_version,
                fields=[],
                processing_time_ms=elapsed_ms,
                page_count=0,
                status="error",
                error_message=str(e),
            )

    async def extract_batch(
        self,
        images: list[bytes],
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> list[ExtractionResult]:
        """Extract from multiple images sequentially (llama.cpp is single-threaded)."""
        results = []
        for img in images:
            result = await self.extract(img, document_type, target_fields, options)
            results.append(result)
        return results

    def _build_messages(self, image_data: bytes, prompt: str) -> list[dict[str, Any]]:
        """Build chat messages, including image if multimodal."""
        if self._mmproj_path and self._mmproj_path.exists():
            image_b64 = base64.b64encode(image_data).decode("utf-8")
            return [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{image_b64}",
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ]
        else:
            return [{"role": "user", "content": prompt}]

    def _build_extraction_prompt(
        self,
        document_type: str | None,
        target_fields: list[str] | None,
    ) -> str:
        """Build extraction prompt."""
        prompt = (
            "Analyze this document and extract all relevant information.\n"
            "Return your response as a JSON object:\n"
            "{\n"
            '    "fields": [\n'
            '        {"name": "field_name", "value": "extracted_value", '
            '"confidence": 0.95}\n'
            "    ],\n"
            '    "document_type": "detected_type",\n'
            '    "summary": "brief summary"\n'
            "}\n"
        )

        if document_type:
            prompt += f"\nThis document is a {document_type}."

        if target_fields:
            prompt += f"\nFocus on extracting: {', '.join(target_fields)}"

        prompt += (
            "\n\nGuidelines:\n"
            "1. Be precise with values\n"
            "2. Include currency symbols and formatting for numbers\n"
            "3. Preserve original date formats\n"
            "4. Confidence should reflect certainty (0.0-1.0)\n"
            "5. Return only JSON, no additional text."
        )

        return prompt

    def _parse_response(
        self,
        response: str,
        document_type: str | None,
    ) -> list[FieldExtraction]:
        """Parse model response into field extractions."""
        fields = []

        try:
            # Handle markdown code blocks
            if "```json" in response:
                json_str = response.split("```json")[1].split("```")[0]
            elif "```" in response:
                json_str = response.split("```")[1].split("```")[0]
            else:
                json_str = response

            data = json.loads(json_str.strip())

            for field_data in data.get("fields", []):
                fields.append(
                    FieldExtraction(
                        field_name=field_data.get("name", "unknown"),
                        value=field_data.get("value"),
                        confidence=field_data.get("confidence", 0.8),
                        extraction_method=f"llamacpp_{self._name}",
                    )
                )

            if data.get("document_type"):
                fields.append(
                    FieldExtraction(
                        field_name="detected_document_type",
                        value=data["document_type"],
                        confidence=0.9,
                        extraction_method=f"llamacpp_{self._name}",
                    )
                )

        except json.JSONDecodeError:
            logger.warning("Failed to parse JSON from llama.cpp, using raw text")
            fields.append(
                FieldExtraction(
                    field_name="raw_extraction",
                    value=response,
                    confidence=0.7,
                    extraction_method=f"llamacpp_{self._name}_text",
                )
            )

        return fields
