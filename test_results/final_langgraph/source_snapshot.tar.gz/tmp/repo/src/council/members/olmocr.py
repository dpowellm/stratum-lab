"""olmOCR-2-7B Council Member implementation.

olmOCR is the "Efficiency Expert" in the council - a purpose-built OCR
model fine-tuned from Qwen2.5-VL-7B-Instruct for document extraction.

Strengths:
- State-of-the-art OCR accuracy (82.4 on olmOCR-Bench)
- Efficient inference via llama.cpp (qwen2vl architecture)
- Strong structured extraction
- Document understanding

Weaknesses:
- Requires GPU for optimal performance
- Higher resource requirements than PaddleOCR
"""

import asyncio
import base64
import json
import time
from typing import Any

from src.core.logging import get_logger
from src.council.members.base import (
    CouncilMember,
    ExtractionResult,
    FieldExtraction,
    MemberCapability,
)

logger = get_logger(__name__)


class OlmOCRMember(CouncilMember):
    """olmOCR-2-7B council member - Efficiency Expert.

    Uses olmOCR for efficient document extraction.
    Can run locally with llama.cpp (GGUF) or via vLLM.
    """

    def __init__(
        self,
        model_name: str = "allenai/olmOCR-2-7B-1025",
        gguf_path: str | None = None,
        vllm_url: str | None = None,
        max_tokens: int = 4096,
        n_gpu_layers: int = -1,
        temperature: float = 0.0,
        confidence_threshold: float = 0.6,
    ):
        """Initialize olmOCR member.

        Initialization priority:
        1. GGUF path (llama.cpp) - preferred, most efficient
        2. vLLM URL - for dedicated inference servers

        Args:
            model_name: Model identifier
            gguf_path: Path to GGUF model file (for llama.cpp inference)
            vllm_url: URL for vLLM server (if local)
            max_tokens: Maximum tokens in response
            n_gpu_layers: GPU layers for llama.cpp (-1 = all)
            temperature: Sampling temperature
            confidence_threshold: Minimum confidence threshold
        """
        super().__init__(
            name="olmocr",
            model_version="olmocr-2-7b",
            capabilities=[
                MemberCapability.TEXT_EXTRACTION,
                MemberCapability.TABLE_EXTRACTION,
                MemberCapability.FORM_UNDERSTANDING,
                MemberCapability.LAYOUT_ANALYSIS,
                MemberCapability.MULTILINGUAL,
                MemberCapability.BATCH_PROCESSING,
            ],
            confidence_threshold=confidence_threshold,
        )

        self._model_name = model_name
        self._gguf_path = gguf_path
        self._vllm_url = vllm_url
        self._max_tokens = max_tokens
        self._n_gpu_layers = n_gpu_layers
        self._temperature = temperature
        self._client = None
        self._llamacpp = None  # llama.cpp Llama instance

    async def initialize(self) -> None:
        """Initialize olmOCR client.

        Initialization priority:
        1. GGUF path -> llama.cpp (most efficient, broadest hardware support)
        2. vLLM URL -> dedicated inference server
        """
        if self._initialized:
            return

        logger.info(
            "Initializing olmOCR",
            model=self._model_name,
            backend="gguf" if self._gguf_path else "vllm",
        )

        try:
            if self._gguf_path:
                # Preferred: Use llama.cpp with GGUF model
                await self._load_llamacpp_model()
            elif self._vllm_url:
                # Initialize vLLM client
                import httpx

                self._client = httpx.AsyncClient(
                    base_url=self._vllm_url,
                    timeout=120.0,
                )
            else:
                raise RuntimeError(
                    "olmOCR requires either a GGUF path or vLLM URL. No API fallback is available."
                )

            self._initialized = True
            logger.info("olmOCR initialized successfully")

        except ImportError as e:
            logger.error("Required package not installed", error=str(e))
            raise RuntimeError(f"Required package not installed: {e}") from e
        except Exception as e:
            logger.error("Failed to initialize olmOCR", error=str(e))
            raise

    async def _load_llamacpp_model(self) -> None:
        """Load model locally using llama.cpp with GGUF."""
        from llama_cpp import Llama

        logger.info(
            "Loading olmOCR via llama.cpp",
            gguf_path=self._gguf_path,
            n_gpu_layers=self._n_gpu_layers,
        )

        loop = asyncio.get_running_loop()
        self._llamacpp = await loop.run_in_executor(
            None,
            lambda: Llama(
                model_path=self._gguf_path,
                n_ctx=self._max_tokens,
                n_gpu_layers=self._n_gpu_layers,
                verbose=False,
            ),
        )

        logger.info("olmOCR loaded via llama.cpp")

    async def shutdown(self) -> None:
        """Shutdown olmOCR client."""
        if self._llamacpp:
            del self._llamacpp
            self._llamacpp = None

        if self._client:
            if hasattr(self._client, "aclose"):
                await self._client.aclose()
            self._client = None

        self._initialized = False
        logger.info("olmOCR shutdown complete")

    async def extract(
        self,
        image_data: bytes,
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> ExtractionResult:
        """Extract text and fields from a document image.

        Args:
            image_data: Document image as bytes
            document_type: Type hint for extraction
            target_fields: Specific fields to extract
            options: Additional options
                - detailed_extraction: bool - Include detailed analysis

        Returns:
            ExtractionResult with extracted fields
        """
        if not self._initialized:
            await self.initialize()

        options = options or {}
        start_time = time.time()

        try:
            # Encode image to base64
            image_b64 = base64.b64encode(image_data).decode("utf-8")

            # Build extraction prompt
            prompt = self._build_extraction_prompt(
                document_type,
                target_fields,
                options.get("detailed_extraction", False),
            )

            # Call model
            response = await self._call_model(image_b64, prompt)

            # Parse response
            fields = self._parse_response(response, document_type)

            # Filter by confidence
            fields = self._filter_by_confidence(fields)

            elapsed_ms = int((time.time() - start_time) * 1000)

            return ExtractionResult(
                member_name=self._name,
                model_version=self._model_version,
                fields=fields,
                processing_time_ms=elapsed_ms,
                page_count=1,
                raw_response={"text": response},
            )

        except Exception as e:
            elapsed_ms = int((time.time() - start_time) * 1000)
            logger.error("olmOCR extraction failed", error=str(e))

            return ExtractionResult(
                member_name=self._name,
                model_version=self._model_version,
                fields=[],
                processing_time_ms=elapsed_ms,
                page_count=0,
                status="error",
                error_message=str(e),
            )

    async def extract_batch(
        self,
        images: list[bytes],
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> list[ExtractionResult]:
        """Extract from multiple images."""
        # Process in parallel with concurrency limit
        semaphore = asyncio.Semaphore(3)  # Max 3 concurrent

        async def extract_with_limit(img: bytes) -> ExtractionResult:
            async with semaphore:
                return await self.extract(img, document_type, target_fields, options)

        tasks = [extract_with_limit(img) for img in images]
        return await asyncio.gather(*tasks)

    def _build_extraction_prompt(
        self,
        document_type: str | None,
        target_fields: list[str] | None,
        detailed: bool,
    ) -> str:
        """Build the extraction prompt."""
        base_prompt = """Analyze this document image and extract all relevant information.
Return your response as a JSON object with the following structure:
{
    "fields": [
        {
            "name": "field_name",
            "value": "extracted_value",
            "confidence": 0.95
        }
    ],
    "document_type": "detected_type",
    "summary": "brief summary"
}
"""

        if document_type:
            base_prompt += f"\nThis document appears to be a {document_type}."

        if target_fields:
            fields_str = ", ".join(target_fields)
            base_prompt += f"\nPlease focus on extracting these fields: {fields_str}"

        if detailed:
            base_prompt += (
                "\nProvide detailed extraction including all visible text and layout information."
            )

        base_prompt += "\nEnsure confidence scores reflect your certainty in each extraction."

        return base_prompt

    async def _call_model(self, image_b64: str, prompt: str) -> str:
        """Call the olmOCR model."""
        if self._llamacpp:
            return await self._call_llamacpp(image_b64, prompt)
        elif self._vllm_url:
            return await self._call_vllm(image_b64, prompt)
        else:
            raise RuntimeError("olmOCR is not initialized. Call initialize() first.")

    async def _call_llamacpp(self, image_b64: str, prompt: str) -> str:
        """Call llama.cpp model for inference."""
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/png;base64,{image_b64}",
                        },
                    },
                    {"type": "text", "text": prompt},
                ],
            }
        ]

        loop = asyncio.get_running_loop()
        response = await loop.run_in_executor(
            None,
            lambda: self._llamacpp.create_chat_completion(
                messages=messages,
                max_tokens=self._max_tokens // 2,
                temperature=self._temperature if self._temperature > 0 else 0.0,
            ),
        )

        return response["choices"][0]["message"]["content"]

    async def _call_vllm(self, image_b64: str, prompt: str) -> str:
        """Call vLLM server."""
        payload = {
            "model": self._model_name,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{image_b64}"},
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
        }

        response = await self._client.post(
            "/v1/chat/completions",
            json=payload,
        )
        response.raise_for_status()

        data = response.json()
        return data["choices"][0]["message"]["content"]

    def _parse_response(
        self,
        response: str,
        document_type: str | None,
    ) -> list[FieldExtraction]:
        """Parse model response into field extractions."""
        fields = []

        try:
            # Try to parse as JSON
            # Handle potential markdown code blocks
            if "```json" in response:
                json_str = response.split("```json")[1].split("```")[0]
            elif "```" in response:
                json_str = response.split("```")[1].split("```")[0]
            else:
                json_str = response

            data = json.loads(json_str.strip())

            for field_data in data.get("fields", []):
                fields.append(
                    FieldExtraction(
                        field_name=field_data.get("name", "unknown"),
                        value=field_data.get("value"),
                        confidence=field_data.get("confidence", 0.8),
                        extraction_method="olmocr",
                    )
                )

            # Add detected document type
            if data.get("document_type"):
                fields.append(
                    FieldExtraction(
                        field_name="detected_document_type",
                        value=data["document_type"],
                        confidence=0.9,
                        extraction_method="olmocr",
                    )
                )

        except json.JSONDecodeError:
            # Fall back to text parsing
            logger.warning("Failed to parse JSON response, using text extraction")
            fields.append(
                FieldExtraction(
                    field_name="raw_extraction",
                    value=response,
                    confidence=0.7,
                    extraction_method="olmocr_text",
                )
            )

        return fields
