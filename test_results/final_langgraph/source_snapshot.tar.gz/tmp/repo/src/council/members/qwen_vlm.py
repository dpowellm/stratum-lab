"""Qwen VLM Council Member implementation.

Qwen2-VL is the "Reasoning Expert" in the council - a powerful
vision-language model with strong reasoning and understanding.

Strengths:
- Excellent visual reasoning
- Strong multi-modal understanding
- Good at complex layouts
- Chart and diagram analysis

Weaknesses:
- Slower inference
- Higher resource requirements
- More expensive (if using API)
"""

import asyncio
import base64
import io
import json
import time
from typing import Any

from PIL import Image

from src.core.logging import get_logger
from src.council.members.base import (
    CouncilMember,
    ExtractionResult,
    FieldExtraction,
    MemberCapability,
)

logger = get_logger(__name__)


class QwenVLMMember(CouncilMember):
    """Qwen2-VL council member - Reasoning Expert.

    Uses Qwen2-VL for advanced visual understanding and reasoning.
    Can run locally with vLLM or via API.
    """

    def __init__(
        self,
        model_name: str = "Qwen/Qwen2-VL-7B-Instruct",
        gguf_path: str | None = None,
        mmproj_path: str | None = None,
        vllm_url: str | None = None,
        api_key: str | None = None,
        api_base_url: str | None = None,
        max_tokens: int = 4096,
        n_gpu_layers: int = -1,
        temperature: float = 0.0,
        confidence_threshold: float = 0.6,
    ):
        """Initialize Qwen VLM member.

        Initialization priority:
        1. GGUF path (llama.cpp) - preferred, most efficient
        2. vLLM URL - for dedicated inference servers
        3. API key + base URL - for external APIs
        4. Local transformers - fallback, requires most memory

        Args:
            model_name: Model identifier
            gguf_path: Path to GGUF model file (for llama.cpp inference)
            mmproj_path: Path to multimodal projector GGUF (for llama.cpp vision)
            vllm_url: URL for vLLM server (if local)
            api_key: API key for external API
            api_base_url: Base URL for API
            max_tokens: Maximum tokens in response
            n_gpu_layers: GPU layers for llama.cpp (-1 = all)
            temperature: Sampling temperature
            confidence_threshold: Minimum confidence threshold
        """
        super().__init__(
            name="qwen_vlm",
            model_version="qwen2-vl-7b",
            capabilities=[
                MemberCapability.TEXT_EXTRACTION,
                MemberCapability.TABLE_EXTRACTION,
                MemberCapability.FORM_UNDERSTANDING,
                MemberCapability.LAYOUT_ANALYSIS,
                MemberCapability.CHART_UNDERSTANDING,
                MemberCapability.DIAGRAM_ANALYSIS,
                MemberCapability.IMAGE_REASONING,
                MemberCapability.MULTILINGUAL,
                MemberCapability.HANDWRITING,
            ],
            confidence_threshold=confidence_threshold,
        )

        self._model_name = model_name
        self._gguf_path = gguf_path
        self._mmproj_path = mmproj_path
        self._vllm_url = vllm_url
        self._api_key = api_key
        self._api_base_url = api_base_url
        self._max_tokens = max_tokens
        self._n_gpu_layers = n_gpu_layers
        self._temperature = temperature
        self._client = None
        self._processor = None
        self._model = None
        self._llamacpp = None  # llama.cpp Llama instance

    async def initialize(self) -> None:
        """Initialize Qwen VLM client.

        Initialization priority:
        1. GGUF path → llama.cpp (most efficient, broadest hardware support)
        2. vLLM URL → dedicated inference server
        3. API key → external API
        4. Local transformers → fallback (most memory intensive)
        """
        if self._initialized:
            return

        logger.info(
            "Initializing Qwen VLM",
            model=self._model_name,
            backend="gguf"
            if self._gguf_path
            else ("vllm" if self._vllm_url else ("api" if self._api_key else "transformers")),
        )

        try:
            if self._gguf_path:
                # Preferred: Use llama.cpp with GGUF model
                await self._load_llamacpp_model()
            elif self._vllm_url:
                # Initialize vLLM client
                import httpx

                self._client = httpx.AsyncClient(
                    base_url=self._vllm_url,
                    timeout=180.0,  # Longer timeout for VLM
                )
            elif self._api_key and self._api_base_url:
                # Use OpenAI-compatible client
                from openai import AsyncOpenAI

                self._client = AsyncOpenAI(
                    api_key=self._api_key,
                    base_url=self._api_base_url,
                )
            else:
                # Fallback: Load model locally with transformers
                await self._load_local_model()

            self._initialized = True
            logger.info("Qwen VLM initialized successfully")

        except ImportError as e:
            logger.error("Required package not installed", error=str(e))
            raise RuntimeError(f"Required package not installed: {e}") from e
        except Exception as e:
            logger.error("Failed to initialize Qwen VLM", error=str(e))
            raise

    async def _load_llamacpp_model(self) -> None:
        """Load model locally using llama.cpp with GGUF."""
        from llama_cpp import Llama

        logger.info(
            "Loading Qwen VLM via llama.cpp",
            gguf_path=self._gguf_path,
            n_gpu_layers=self._n_gpu_layers,
        )

        kwargs = {
            "model_path": self._gguf_path,
            "n_ctx": self._max_tokens,
            "n_gpu_layers": self._n_gpu_layers,
            "verbose": False,
        }

        # Add multimodal projector if available
        if self._mmproj_path:
            from llama_cpp.llama_chat_format import Llava16ChatHandler

            kwargs["chat_handler"] = Llava16ChatHandler(
                clip_model_path=self._mmproj_path,
                verbose=False,
            )

        loop = asyncio.get_running_loop()
        self._llamacpp = await loop.run_in_executor(
            None,
            lambda: Llama(**kwargs),
        )

        logger.info("Qwen VLM loaded via llama.cpp")

    async def _load_local_model(self) -> None:
        """Load model locally using transformers (fallback).

        Model loading is CPU-heavy so it runs in a thread executor.
        """
        loop = asyncio.get_running_loop()
        self._processor, self._model = await loop.run_in_executor(
            None, self._load_transformers_model
        )

    def _load_transformers_model(self):
        """Load transformers model synchronously (called from thread executor)."""
        import torch
        from transformers import AutoProcessor, Qwen2VLForConditionalGeneration

        logger.info("Loading Qwen VLM model locally")

        device = "cuda" if torch.cuda.is_available() else "cpu"

        processor = AutoProcessor.from_pretrained(self._model_name)
        model = Qwen2VLForConditionalGeneration.from_pretrained(
            self._model_name,
            torch_dtype=torch.float16 if device == "cuda" else torch.float32,
            device_map="auto",
        )

        logger.info(f"Model loaded on {device}")
        return processor, model

    async def shutdown(self) -> None:
        """Shutdown Qwen VLM client."""
        if self._llamacpp:
            del self._llamacpp
            self._llamacpp = None

        if self._client:
            if hasattr(self._client, "aclose"):
                await self._client.aclose()
            self._client = None

        if self._model:
            del self._model
            self._model = None

        if self._processor:
            del self._processor
            self._processor = None

        self._initialized = False
        logger.info("Qwen VLM shutdown complete")

    async def extract(
        self,
        image_data: bytes,
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> ExtractionResult:
        """Extract text and fields from a document image.

        Args:
            image_data: Document image as bytes
            document_type: Type hint for extraction
            target_fields: Specific fields to extract
            options: Additional options
                - analyze_charts: bool - Analyze charts/graphs
                - analyze_diagrams: bool - Analyze diagrams
                - detailed_reasoning: bool - Include reasoning steps

        Returns:
            ExtractionResult with extracted fields
        """
        if not self._initialized:
            await self.initialize()

        options = options or {}
        start_time = time.time()

        try:
            # Build extraction prompt
            prompt = self._build_extraction_prompt(
                document_type,
                target_fields,
                options,
            )

            # Call model based on configuration
            if self._llamacpp:
                response = await self._call_llamacpp(image_data, prompt)
            elif self._model:
                response = await self._call_local_model(image_data, prompt)
            elif self._vllm_url:
                image_b64 = base64.b64encode(image_data).decode("utf-8")
                response = await self._call_vllm(image_b64, prompt)
            else:
                image_b64 = base64.b64encode(image_data).decode("utf-8")
                response = await self._call_api(image_b64, prompt)

            # Parse response
            fields = self._parse_response(response, document_type)

            # Filter by confidence
            fields = self._filter_by_confidence(fields)

            elapsed_ms = int((time.time() - start_time) * 1000)

            return ExtractionResult(
                member_name=self._name,
                model_version=self._model_version,
                fields=fields,
                processing_time_ms=elapsed_ms,
                page_count=1,
                raw_response={"text": response},
            )

        except Exception as e:
            elapsed_ms = int((time.time() - start_time) * 1000)
            logger.error("Qwen VLM extraction failed", error=str(e))

            return ExtractionResult(
                member_name=self._name,
                model_version=self._model_version,
                fields=[],
                processing_time_ms=elapsed_ms,
                page_count=0,
                status="error",
                error_message=str(e),
            )

    async def extract_batch(
        self,
        images: list[bytes],
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> list[ExtractionResult]:
        """Extract from multiple images."""
        # Process sequentially for local model, parallel for API
        if self._model:
            results = []
            for img in images:
                result = await self.extract(img, document_type, target_fields, options)
                results.append(result)
            return results
        else:
            semaphore = asyncio.Semaphore(2)  # Lower concurrency for VLM

            async def extract_with_limit(img: bytes) -> ExtractionResult:
                async with semaphore:
                    return await self.extract(img, document_type, target_fields, options)

            tasks = [extract_with_limit(img) for img in images]
            return await asyncio.gather(*tasks)

    def _build_extraction_prompt(
        self,
        document_type: str | None,
        target_fields: list[str] | None,
        options: dict[str, Any],
    ) -> str:
        """Build the extraction prompt."""
        base_prompt = """You are an expert document analyst. Analyze this document image carefully and extract all relevant information.

Please provide your response as a JSON object with this structure:
{
    "fields": [
        {
            "name": "field_name",
            "value": "extracted_value",
            "confidence": 0.95,
            "reasoning": "brief explanation"
        }
    ],
    "document_type": "detected_type",
    "layout_analysis": {
        "structure": "description of document structure",
        "key_regions": ["list of important regions"]
    },
    "summary": "comprehensive summary of document content"
}
"""

        if document_type:
            base_prompt += f"\nDocument Type: This appears to be a {document_type}."

        if target_fields:
            fields_str = ", ".join(target_fields)
            base_prompt += f"\n\nPriority Fields: Please focus on extracting: {fields_str}"

        if options.get("analyze_charts"):
            base_prompt += "\n\nChart Analysis: If there are any charts or graphs, describe the data trends and key values."

        if options.get("analyze_diagrams"):
            base_prompt += "\n\nDiagram Analysis: If there are any diagrams or flowcharts, explain the relationships and process flow."

        if options.get("detailed_reasoning"):
            base_prompt += "\n\nProvide detailed reasoning for each extraction explaining how you determined the value."

        base_prompt += """

Important Guidelines:
1. Be precise with values - extract exactly what you see
2. For numbers, include currency symbols and formatting
3. For dates, preserve the original format
4. Confidence should reflect your certainty (0.0-1.0)
5. If a field is unclear, still extract with lower confidence

Return only the JSON object, no additional text."""

        return base_prompt

    async def _call_llamacpp(self, image_data: bytes, prompt: str) -> str:
        """Call llama.cpp model for inference."""
        image_b64 = base64.b64encode(image_data).decode("utf-8")

        # Build multimodal messages if projector is available
        if self._mmproj_path:
            messages = [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{image_b64}",
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ]
        else:
            messages = [{"role": "user", "content": prompt}]

        loop = asyncio.get_running_loop()
        response = await loop.run_in_executor(
            None,
            lambda: self._llamacpp.create_chat_completion(
                messages=messages,
                max_tokens=self._max_tokens // 2,
                temperature=self._temperature if self._temperature > 0 else 0.0,
            ),
        )

        return response["choices"][0]["message"]["content"]

    async def _call_local_model(self, image_data: bytes, prompt: str) -> str:
        """Call locally loaded model via transformers (fallback).

        Inference is CPU/GPU-heavy so it runs in a thread executor.
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._run_local_inference, image_data, prompt)

    def _run_local_inference(self, image_data: bytes, prompt: str) -> str:
        """Run transformers inference synchronously (called from thread executor)."""
        import torch

        image = Image.open(io.BytesIO(image_data))

        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": prompt},
                ],
            }
        ]

        text = self._processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )

        inputs = self._processor(
            text=[text],
            images=[image],
            padding=True,
            return_tensors="pt",
        )

        inputs = {k: v.to(self._model.device) for k, v in inputs.items()}

        with torch.no_grad():
            output_ids = self._model.generate(
                **inputs,
                max_new_tokens=self._max_tokens,
                temperature=self._temperature if self._temperature > 0 else None,
                do_sample=self._temperature > 0,
            )

        output_text = self._processor.batch_decode(
            output_ids[:, inputs["input_ids"].shape[1] :],
            skip_special_tokens=True,
        )[0]

        return output_text

    async def _call_vllm(self, image_b64: str, prompt: str) -> str:
        """Call vLLM server."""
        payload = {
            "model": self._model_name,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{image_b64}"},
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
        }

        response = await self._client.post(
            "/v1/chat/completions",
            json=payload,
        )
        response.raise_for_status()

        data = response.json()
        return data["choices"][0]["message"]["content"]

    async def _call_api(self, image_b64: str, prompt: str) -> str:
        """Call external API."""
        response = await self._client.chat.completions.create(
            model=self._model_name,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{image_b64}"},
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
            max_tokens=self._max_tokens,
            temperature=self._temperature,
        )

        return response.choices[0].message.content

    def _parse_response(
        self,
        response: str,
        document_type: str | None,
    ) -> list[FieldExtraction]:
        """Parse model response into field extractions."""
        fields = []

        try:
            # Try to parse as JSON
            if "```json" in response:
                json_str = response.split("```json")[1].split("```")[0]
            elif "```" in response:
                json_str = response.split("```")[1].split("```")[0]
            else:
                json_str = response

            data = json.loads(json_str.strip())

            # Extract fields
            for field_data in data.get("fields", []):
                fields.append(
                    FieldExtraction(
                        field_name=field_data.get("name", "unknown"),
                        value=field_data.get("value"),
                        confidence=field_data.get("confidence", 0.8),
                        extraction_method="qwen_vlm",
                        raw_text=field_data.get("reasoning"),
                    )
                )

            # Add layout analysis if present
            if data.get("layout_analysis"):
                fields.append(
                    FieldExtraction(
                        field_name="layout_analysis",
                        value=data["layout_analysis"],
                        confidence=0.9,
                        extraction_method="qwen_vlm_analysis",
                    )
                )

            # Add document type detection
            if data.get("document_type"):
                fields.append(
                    FieldExtraction(
                        field_name="detected_document_type",
                        value=data["document_type"],
                        confidence=0.9,
                        extraction_method="qwen_vlm",
                    )
                )

            # Add summary
            if data.get("summary"):
                fields.append(
                    FieldExtraction(
                        field_name="document_summary",
                        value=data["summary"],
                        confidence=0.85,
                        extraction_method="qwen_vlm_analysis",
                    )
                )

        except json.JSONDecodeError:
            # Fall back to text parsing
            logger.warning("Failed to parse JSON response, using text extraction")
            fields.append(
                FieldExtraction(
                    field_name="raw_extraction",
                    value=response,
                    confidence=0.7,
                    extraction_method="qwen_vlm_text",
                )
            )

        return fields

    async def analyze_chart(
        self,
        image_data: bytes,
        chart_type: str | None = None,
    ) -> dict[str, Any]:
        """Analyze a chart or graph image.

        Args:
            image_data: Chart image as bytes
            chart_type: Hint about chart type (bar, line, pie, etc.)

        Returns:
            Chart analysis with data points and trends
        """
        if not self._initialized:
            await self.initialize()

        f"""Analyze this {"chart" if not chart_type else chart_type + " chart"} and extract:
1. Chart title and axis labels
2. All data points and values
3. Key trends and patterns
4. Any notable observations

Return as JSON:
{{
    "chart_type": "detected type",
    "title": "chart title",
    "x_axis": {{"label": "label", "values": [...]}},
    "y_axis": {{"label": "label", "range": [min, max]}},
    "data_series": [...],
    "trends": ["list of trends"],
    "insights": "key insights"
}}"""

        result = await self.extract(
            image_data,
            document_type="chart",
            options={"analyze_charts": True},
        )

        if result.status == "error":
            return {"error": result.error_message}

        # Extract chart-specific data
        for field in result.fields:
            if field.field_name == "raw_extraction":
                try:
                    return json.loads(field.value)
                except json.JSONDecodeError:
                    return {"raw_analysis": field.value}

        return {"fields": [f.to_dict() for f in result.fields]}
