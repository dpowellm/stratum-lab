"""Expertise routing for council member field assignment.

Routes specific field types to expert members with higher weight,
based on content analysis and member capabilities.
"""

from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)

# Field type to expert member mapping
# Each entry: field_keywords -> [(primary_expert, secondary_expert)]
_EXPERTISE_MAP: dict[str, list[str]] = {
    "table": ["paddle_ocr", "olmocr"],
    "line_items": ["paddle_ocr", "olmocr"],
    "chart": ["qwen", "colpali"],
    "diagram": ["qwen", "colpali"],
    "graph": ["qwen", "colpali"],
    "form": ["olmocr", "paddle_ocr"],
    "handwrit": ["qwen"],
    "signature": ["qwen", "colpali"],
    "layout": ["colpali", "qwen"],
    "visual": ["colpali", "qwen"],
    "amount": ["paddle_ocr", "olmocr"],
    "total": ["paddle_ocr", "olmocr"],
    "number": ["paddle_ocr", "olmocr"],
    "date": ["paddle_ocr", "olmocr"],
    "name": ["olmocr", "paddle_ocr"],
    "address": ["olmocr", "paddle_ocr"],
}


class ExpertiseRouter:
    """Routes fields to expert council members based on content analysis."""

    def __init__(
        self,
        expertise_map: dict[str, list[str]] | None = None,
    ):
        """Initialize with optional custom expertise map.

        Args:
            expertise_map: Custom field_keyword -> [expert_members] mapping.
        """
        self.expertise_map = expertise_map or _EXPERTISE_MAP

    def route_fields(
        self,
        fields: list[str],
        content_analysis: dict[str, Any] | None = None,
    ) -> dict[str, list[str]]:
        """Route fields to expert members.

        Args:
            fields: List of field names to route.
            content_analysis: Optional content analysis results
                (has_tables, has_charts, etc.).

        Returns:
            Mapping of field_name -> [expert_member_names].
            Each member still extracts all fields, but consensus engine
            trusts experts more on their assigned fields.
        """
        routing: dict[str, list[str]] = {}

        for field_name in fields:
            experts = self._find_experts(field_name, content_analysis)
            if experts:
                routing[field_name] = experts

        logger.debug(
            "Field expertise routing",
            total_fields=len(fields),
            routed_fields=len(routing),
        )
        return routing

    def _find_experts(
        self,
        field_name: str,
        content_analysis: dict[str, Any] | None = None,
    ) -> list[str]:
        """Find expert members for a given field.

        Args:
            field_name: The field to find experts for.
            content_analysis: Optional content features.

        Returns:
            List of expert member names (primary first).
        """
        field_lower = field_name.lower()
        experts: list[str] = []

        # Match field name against expertise map
        for keyword, member_experts in self.expertise_map.items():
            if keyword in field_lower:
                for expert in member_experts:
                    if expert not in experts:
                        experts.append(expert)

        # Boost based on content analysis
        if content_analysis:
            if content_analysis.get("has_tables") and "paddle_ocr" not in experts:
                experts.append("paddle_ocr")
            if content_analysis.get("has_charts") and "qwen" not in experts:
                experts.append("qwen")
            if content_analysis.get("has_handwriting") and "qwen" not in experts:
                experts.insert(0, "qwen")
            if content_analysis.get("has_forms") and "olmocr" not in experts:
                experts.append("olmocr")

        return experts

    def get_member_specialties(self) -> dict[str, list[str]]:
        """Get what each member specializes in.

        Returns:
            Mapping of member_name -> [field_keywords].
        """
        specialties: dict[str, list[str]] = {}
        for keyword, members in self.expertise_map.items():
            for member in members:
                if member not in specialties:
                    specialties[member] = []
                specialties[member].append(keyword)
        return specialties
