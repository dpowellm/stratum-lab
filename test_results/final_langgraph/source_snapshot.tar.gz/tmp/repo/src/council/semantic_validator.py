"""Semantic validation for extracted field values.

Validates that extracted values are realistic and well-formed:
- Amounts must be positive and below configurable maximum
- Dates must be valid calendar dates in reasonable range
- Identifiers must be alphanumeric 3-20 chars
- Names must be non-empty 2-100 chars
"""

import re
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class SemanticCheckResult:
    """Result of semantic validation on a single field."""

    field_name: str
    is_valid: bool
    confidence_penalty: float
    reason: str


class SemanticValidator:
    """Validates that extracted values are semantically reasonable."""

    def __init__(
        self,
        max_amount: float = 1_000_000_000.0,
        min_date_year: int = 1900,
        max_date_year: int = 2100,
    ):
        """Initialize with configurable limits.

        Args:
            max_amount: Maximum acceptable monetary amount.
            min_date_year: Earliest acceptable year.
            max_date_year: Latest acceptable year.
        """
        self.max_amount = max_amount
        self.min_date_year = min_date_year
        self.max_date_year = max_date_year

    def validate_value(
        self,
        field_name: str,
        value: Any,
        document_type: str | None = None,
    ) -> SemanticCheckResult:
        """Validate a single field value.

        Args:
            field_name: Name of the field.
            value: Extracted value.
            document_type: Optional document type for context.

        Returns:
            SemanticCheckResult with validity and penalty.
        """
        if value is None or (isinstance(value, str) and not value.strip()):
            # Empty value — check if it's a required field type
            if self._is_required_field(field_name):
                return SemanticCheckResult(
                    field_name=field_name,
                    is_valid=False,
                    confidence_penalty=0.3,
                    reason=f"Required field '{field_name}' is empty",
                )
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=True,
                confidence_penalty=0.0,
                reason="",
            )

        # Route to type-specific validation
        field_lower = field_name.lower()

        if self._is_amount_field(field_lower):
            return self._validate_amount(field_name, value)

        if self._is_date_field(field_lower):
            return self._validate_date(field_name, value)

        if self._is_identifier_field(field_lower):
            return self._validate_identifier(field_name, value)

        if self._is_name_field(field_lower):
            return self._validate_name(field_name, value)

        return SemanticCheckResult(
            field_name=field_name,
            is_valid=True,
            confidence_penalty=0.0,
            reason="",
        )

    def validate_fields(
        self,
        fields: dict[str, Any],
        document_type: str | None = None,
    ) -> list[SemanticCheckResult]:
        """Validate all fields in an extraction result.

        Args:
            fields: Extracted field values.
            document_type: Document type for context.

        Returns:
            List of validation results (only invalid ones).
        """
        results: list[SemanticCheckResult] = []
        for field_name, value in fields.items():
            result = self.validate_value(field_name, value, document_type)
            if not result.is_valid:
                results.append(result)
        return results

    def _is_amount_field(self, field_lower: str) -> bool:
        return any(
            kw in field_lower
            for kw in [
                "amount",
                "total",
                "subtotal",
                "price",
                "cost",
                "fee",
                "balance",
                "credit",
                "debit",
                "tax",
                "value",
            ]
        )

    def _is_date_field(self, field_lower: str) -> bool:
        return any(kw in field_lower for kw in ["date", "expir", "issued", "birth", "effective"])

    def _is_identifier_field(self, field_lower: str) -> bool:
        return any(
            kw in field_lower
            for kw in [
                "number",
                "id",
                "code",
                "reference",
                "account",
                "card_last_four",
            ]
        )

    def _is_name_field(self, field_lower: str) -> bool:
        return any(
            kw in field_lower
            for kw in [
                "name",
                "holder",
                "vendor",
                "merchant",
                "customer",
                "party",
                "authority",
            ]
        )

    def _is_required_field(self, field_name: str) -> bool:
        field_lower = field_name.lower()
        return self._is_name_field(field_lower) or self._is_identifier_field(field_lower)

    def _validate_amount(self, field_name: str, value: Any) -> SemanticCheckResult:
        """Validate a monetary amount."""
        num = self._try_parse_number(value)
        if num is None:
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.2,
                reason=f"Amount field '{field_name}' is not a valid number: {value}",
            )

        if num < 0:
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.3,
                reason=f"Amount field '{field_name}' is negative: {num}",
            )

        if num > self.max_amount:
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.2,
                reason=f"Amount field '{field_name}' exceeds maximum: {num}",
            )

        return SemanticCheckResult(
            field_name=field_name,
            is_valid=True,
            confidence_penalty=0.0,
            reason="",
        )

    def _validate_date(self, field_name: str, value: Any) -> SemanticCheckResult:
        """Validate a date value."""
        date_val = self._try_parse_date(value)
        if date_val is None:
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.2,
                reason=f"Date field '{field_name}' is not a valid date: {value}",
            )

        if date_val.year < self.min_date_year:
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.2,
                reason=f"Date field '{field_name}' year too early: {date_val.year}",
            )

        if date_val.year > self.max_date_year:
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.2,
                reason=f"Date field '{field_name}' year too late: {date_val.year}",
            )

        return SemanticCheckResult(
            field_name=field_name,
            is_valid=True,
            confidence_penalty=0.0,
            reason="",
        )

    def _validate_identifier(self, field_name: str, value: Any) -> SemanticCheckResult:
        """Validate an identifier field."""
        s = str(value).strip()

        if len(s) < 1:
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.3,
                reason=f"Identifier field '{field_name}' is empty",
            )

        if len(s) > 50:
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.15,
                reason=f"Identifier field '{field_name}' is too long: {len(s)} chars",
            )

        # Allow alphanumeric, hyphens, slashes, dots
        if not re.match(r"^[\w\-./# ]+$", s):
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.1,
                reason=f"Identifier field '{field_name}' has unexpected characters",
            )

        return SemanticCheckResult(
            field_name=field_name,
            is_valid=True,
            confidence_penalty=0.0,
            reason="",
        )

    def _validate_name(self, field_name: str, value: Any) -> SemanticCheckResult:
        """Validate a name field."""
        s = str(value).strip()

        if len(s) < 2:
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.3,
                reason=f"Name field '{field_name}' is too short: '{s}'",
            )

        if len(s) > 200:
            return SemanticCheckResult(
                field_name=field_name,
                is_valid=False,
                confidence_penalty=0.1,
                reason=f"Name field '{field_name}' is too long: {len(s)} chars",
            )

        return SemanticCheckResult(
            field_name=field_name,
            is_valid=True,
            confidence_penalty=0.0,
            reason="",
        )

    def _try_parse_number(self, value: Any) -> float | None:
        if isinstance(value, (int, float)):
            return float(value)
        s = str(value).strip()
        s = re.sub(r"[,$€£¥]", "", s)
        try:
            return float(s)
        except (ValueError, TypeError):
            return None

    def _try_parse_date(self, value: Any) -> datetime | None:
        if isinstance(value, datetime):
            return value
        s = str(value).strip()
        for fmt in [
            "%Y-%m-%d",
            "%m/%d/%Y",
            "%d/%m/%Y",
            "%m-%d-%Y",
            "%B %d, %Y",
            "%b %d, %Y",
            "%d %B %Y",
            "%d %b %Y",
        ]:
            try:
                return datetime.strptime(s, fmt)
            except ValueError:
                continue
        return None
