"""
Council Voting Mechanisms.

Implements multiple voting strategies for consensus decision-making:
- Confidence-weighted majority: Each vote weighted by confidence
- Unanimous: All members must agree
- Expertise delegation: Weight towards specialized models
- Cascading confidence: Progressive voting based on thresholds
"""

from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger
from src.council.consensus import (
    ConflictLevel,
    FieldConsensus,
    MemberVote,
)

logger = get_logger(__name__)


class VotingStrategy(StrEnum):
    """Available voting strategies."""

    CONFIDENCE_WEIGHTED = "confidence_weighted"
    UNANIMOUS = "unanimous"
    EXPERTISE_DELEGATION = "expertise_delegation"
    CASCADING = "cascading"


@dataclass
class VotingResult:
    """Result of a voting round."""

    field_name: str
    final_value: Any
    confidence: float
    source_member: str
    agreement_count: int
    total_votes: int
    conflict_level: ConflictLevel
    alternative_values: list[dict[str, Any]]
    voting_strategy: VotingStrategy
    reasoning: str = ""


class VotingEngine:
    """
    Implements multiple voting strategies for council consensus.

    Each strategy balances speed, accuracy, and consensus quality.
    """

    def __init__(
        self,
        expertise_weights: dict[str, dict[str, float]] | None = None,
        min_confidence: float = 0.60,
    ):
        """
        Initialize voting engine.

        Args:
            expertise_weights: Model expertise weights per capability
            min_confidence: Minimum confidence to count a vote
        """
        self.expertise_weights = expertise_weights or {}
        self.min_confidence = min_confidence

    def confidence_weighted_vote(
        self,
        field_name: str,
        member_votes: dict[str, MemberVote],
        expertise_bonuses: dict[str, float] | None = None,
    ) -> VotingResult:
        """
        Vote using confidence-weighted majority.

        Each vote weighted by the member's confidence score.
        Optionally apply expertise bonuses based on field type.

        Args:
            field_name: Name of the field being voted on
            member_votes: Dict mapping member names to their votes
            expertise_bonuses: Optional expertise bonuses per member

        Returns:
            VotingResult with winner and confidence
        """
        if not member_votes:
            return VotingResult(
                field_name=field_name,
                final_value=None,
                confidence=0.0,
                source_member="",
                agreement_count=0,
                total_votes=0,
                conflict_level=ConflictLevel.MAJOR,
                alternative_values=[],
                voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED,
                reasoning="No votes received",
            )

        votes = list(member_votes.values())
        expertise_bonuses = expertise_bonuses or {}

        # Filter votes by minimum confidence
        valid_votes = [v for v in votes if v.confidence >= self.min_confidence]
        if not valid_votes:
            valid_votes = votes

        # Group votes by value
        value_groups: dict[str, list[MemberVote]] = {}
        for vote in valid_votes:
            value_key = str(vote.value)
            if value_key not in value_groups:
                value_groups[value_key] = []
            value_groups[value_key].append(vote)

        # Calculate weighted score for each value
        best_value = None
        best_score = 0.0
        best_vote = valid_votes[0]
        score_details = {}

        for value_key, group_votes in value_groups.items():
            score = 0.0
            for vote in group_votes:
                base_confidence = vote.confidence
                bonus = expertise_bonuses.get(vote.member_name, 0.0)
                weighted_confidence = base_confidence * (1 + bonus)
                score += weighted_confidence

            score_details[value_key] = {
                "score": score,
                "group_size": len(group_votes),
                "avg_confidence": score / len(group_votes),
            }

            if score > best_score:
                best_score = score
                best_value = group_votes[0].value
                best_vote = max(group_votes, key=lambda v: v.confidence)

        # Determine conflict level
        unique_values = len(value_groups)
        if unique_values == 1:
            conflict_level = ConflictLevel.NONE
            agreement_count = len(valid_votes)
            reasoning = f"Unanimous: all {len(valid_votes)} members agree"
        elif unique_values == 2 and len(valid_votes) >= 2:
            max_group_size = max(len(g) for g in value_groups.values())
            if max_group_size >= 2:
                conflict_level = ConflictLevel.MINOR
                reasoning = f"Minor conflict: {max_group_size} members agree, {len(valid_votes) - max_group_size} differ"
            else:
                conflict_level = ConflictLevel.MODERATE
                reasoning = f"Split decision: {len(valid_votes)} members voting"
            agreement_count = max_group_size
        else:
            conflict_level = ConflictLevel.MODERATE
            agreement_count = max(len(g) for g in value_groups.values())
            reasoning = f"Moderate conflict: {unique_values} different values, {agreement_count} members agree"

        # Build alternative values
        alternatives = []
        for vote in valid_votes:
            if vote.value != best_value:
                alternatives.append(
                    {
                        "value": vote.value,
                        "confidence": vote.confidence,
                        "source": vote.member_name,
                    }
                )

        return VotingResult(
            field_name=field_name,
            final_value=best_value,
            confidence=best_vote.confidence,
            source_member=best_vote.member_name,
            agreement_count=agreement_count,
            total_votes=len(valid_votes),
            conflict_level=conflict_level,
            alternative_values=alternatives,
            voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED,
            reasoning=reasoning,
        )

    def unanimous_vote(
        self,
        field_name: str,
        member_votes: dict[str, MemberVote],
        participating_members: list[str],
    ) -> VotingResult:
        """
        Vote requiring unanimous agreement.

        All members must agree for the vote to pass.
        Used for critical fields like amounts, dates, IDs.

        Args:
            field_name: Field name
            member_votes: All votes
            participating_members: List of member names that participated

        Returns:
            VotingResult
        """
        votes = list(member_votes.values())
        valid_votes = [v for v in votes if v.confidence >= self.min_confidence]

        if not valid_votes:
            return VotingResult(
                field_name=field_name,
                final_value=None,
                confidence=0.0,
                source_member="",
                agreement_count=0,
                total_votes=0,
                conflict_level=ConflictLevel.MAJOR,
                alternative_values=[],
                voting_strategy=VotingStrategy.UNANIMOUS,
                reasoning="No votes met confidence threshold",
            )

        # Check if all values are the same
        first_value = str(valid_votes[0].value)
        all_agree = all(str(v.value) == first_value for v in valid_votes)

        if all_agree and len(valid_votes) == len(participating_members):
            # Unanimous agreement
            avg_confidence = sum(v.confidence for v in valid_votes) / len(valid_votes)
            return VotingResult(
                field_name=field_name,
                final_value=valid_votes[0].value,
                confidence=avg_confidence,
                source_member="unanimous",
                agreement_count=len(valid_votes),
                total_votes=len(valid_votes),
                conflict_level=ConflictLevel.NONE,
                alternative_values=[],
                voting_strategy=VotingStrategy.UNANIMOUS,
                reasoning=f"Unanimous: all {len(valid_votes)} members agree",
            )
        else:
            # No unanimous agreement
            best_vote = max(valid_votes, key=lambda v: v.confidence)
            alternatives = [
                {"value": v.value, "confidence": v.confidence, "source": v.member_name}
                for v in valid_votes
                if v.value != best_vote.value
            ]

            reason = (
                f"Not unanimous: {len(valid_votes)} votes for {len({str(v.value) for v in valid_votes})} "
                f"different values"
            )

            return VotingResult(
                field_name=field_name,
                final_value=best_vote.value,
                confidence=best_vote.confidence,
                source_member=best_vote.member_name,
                agreement_count=1,
                total_votes=len(valid_votes),
                conflict_level=ConflictLevel.MAJOR,
                alternative_values=alternatives,
                voting_strategy=VotingStrategy.UNANIMOUS,
                reasoning=reason,
            )

    def expertise_delegation_vote(
        self,
        field_name: str,
        member_votes: dict[str, MemberVote],
        content_type: str,
    ) -> VotingResult:
        """
        Vote delegating to expertise.

        Weights votes based on each model's expertise for the content type.

        Args:
            field_name: Field name
            member_votes: All votes
            content_type: Type of content (table, chart, text, date, etc.)

        Returns:
            VotingResult favoring the expert
        """
        votes = list(member_votes.values())

        if not votes:
            return VotingResult(
                field_name=field_name,
                final_value=None,
                confidence=0.0,
                source_member="",
                agreement_count=0,
                total_votes=0,
                conflict_level=ConflictLevel.MAJOR,
                alternative_values=[],
                voting_strategy=VotingStrategy.EXPERTISE_DELEGATION,
                reasoning="No votes received",
            )

        # Apply expertise weights
        weighted_votes: list[tuple[MemberVote, float]] = []
        for vote in votes:
            base_weight = vote.confidence
            expertise_bonus = self._get_expertise_bonus(vote.member_name, content_type)
            weighted_score = base_weight * (1 + expertise_bonus)
            weighted_votes.append((vote, weighted_score))

        # Sort by weighted score
        weighted_votes.sort(key=lambda x: x[1], reverse=True)
        best_vote, best_score = weighted_votes[0]

        # Determine conflict level based on score margin
        if len(weighted_votes) > 1:
            second_score = weighted_votes[1][1]
            score_margin = best_score / second_score if second_score > 0 else float("inf")

            if score_margin > 1.2:  # 20% margin
                conflict_level = ConflictLevel.NONE
                reasoning = f"Expert consensus: {best_vote.member_name} has clear expertise advantage for {content_type}"
            else:
                conflict_level = ConflictLevel.MINOR
                reasoning = f"Expertise delegation: {best_vote.member_name} leads for {content_type} but close call"
        else:
            conflict_level = ConflictLevel.NONE
            reasoning = f"Expert decision: only {best_vote.member_name} voted"

        alternatives = [
            {"value": v.value, "confidence": v.confidence, "source": v.member_name}
            for v, _ in weighted_votes[1:]
        ]

        return VotingResult(
            field_name=field_name,
            final_value=best_vote.value,
            confidence=best_vote.confidence,
            source_member=best_vote.member_name,
            agreement_count=1,
            total_votes=len(votes),
            conflict_level=conflict_level,
            alternative_values=alternatives,
            voting_strategy=VotingStrategy.EXPERTISE_DELEGATION,
            reasoning=reasoning,
        )

    def cascading_confidence_vote(
        self,
        field_name: str,
        member_votes: dict[str, MemberVote],
        threshold_95: float = 0.95,
        threshold_80: float = 0.80,
    ) -> VotingResult:
        """
        Vote using cascading confidence thresholds.

        1. If any member has >= 95% confidence: accept without council
        2. If any member has 80-95% confidence: add second opinion
        3. Otherwise: full council deliberation

        Args:
            field_name: Field name
            member_votes: All votes
            threshold_95: High confidence threshold
            threshold_80: Medium confidence threshold

        Returns:
            VotingResult
        """
        votes = list(member_votes.values())

        if not votes:
            return VotingResult(
                field_name=field_name,
                final_value=None,
                confidence=0.0,
                source_member="",
                agreement_count=0,
                total_votes=0,
                conflict_level=ConflictLevel.MAJOR,
                alternative_values=[],
                voting_strategy=VotingStrategy.CASCADING,
                reasoning="No votes received",
            )

        # Sort by confidence descending
        sorted_votes = sorted(votes, key=lambda v: v.confidence, reverse=True)

        # Check high confidence threshold
        high_conf_votes = [v for v in sorted_votes if v.confidence >= threshold_95]
        if high_conf_votes:
            best_vote = high_conf_votes[0]
            return VotingResult(
                field_name=field_name,
                final_value=best_vote.value,
                confidence=best_vote.confidence,
                source_member=best_vote.member_name,
                agreement_count=len(high_conf_votes),
                total_votes=len(votes),
                conflict_level=ConflictLevel.NONE,
                alternative_values=[],
                voting_strategy=VotingStrategy.CASCADING,
                reasoning=f"High confidence (>95%): {best_vote.member_name} decides alone",
            )

        # Check medium confidence threshold
        medium_conf_votes = [v for v in sorted_votes if threshold_80 <= v.confidence < threshold_95]
        if medium_conf_votes:
            best_vote = medium_conf_votes[0]
            alternatives = [
                {"value": v.value, "confidence": v.confidence, "source": v.member_name}
                for v in sorted_votes
                if v.value != best_vote.value and v.confidence >= threshold_80
            ]
            return VotingResult(
                field_name=field_name,
                final_value=best_vote.value,
                confidence=best_vote.confidence,
                source_member=best_vote.member_name,
                agreement_count=len(medium_conf_votes),
                total_votes=len(votes),
                conflict_level=ConflictLevel.MINOR,
                alternative_values=alternatives,
                voting_strategy=VotingStrategy.CASCADING,
                reasoning=f"Medium confidence (80-95%): {best_vote.member_name} leads with validation",
            )

        # Full council deliberation for low confidence
        return self.confidence_weighted_vote(field_name, member_votes)

    def _get_expertise_bonus(self, member_name: str, content_type: str) -> float:
        """Get expertise bonus for a member on content type."""
        member_weights = self.expertise_weights.get(member_name, {})
        return member_weights.get(content_type, 0.0)

    def to_field_consensus(self, result: VotingResult) -> FieldConsensus:
        """Convert VotingResult to FieldConsensus for consensus engine."""
        return FieldConsensus(
            field_name=result.field_name,
            final_value=result.final_value,
            confidence=result.confidence,
            source_member=result.source_member,
            all_votes=[],  # Would be populated by consensus engine
            conflict_level=result.conflict_level,
            agreement_count=result.agreement_count,
            alternative_values=result.alternative_values,
        )
