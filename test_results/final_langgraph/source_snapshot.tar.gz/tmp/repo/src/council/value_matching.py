"""Semantic value normalization and matching for consensus voting.

Handles currency, dates, text, dicts, lists, and fuzzy text matching
so that semantically equivalent values are grouped together.
"""

import json
import re
from datetime import datetime
from difflib import SequenceMatcher
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


def value_distance(a: Any, b: Any, _field_name: str = "") -> float:
    """Calculate semantic distance between two values (0.0 = identical, 1.0 = maximum).

    Uses type-aware comparison:
    - Numeric: relative difference
    - Dates: days difference normalized to years
    - Text: 1 - SequenceMatcher ratio
    """
    if a is None or b is None:
        return 1.0 if (a is None) != (b is None) else 0.0

    # Try numeric comparison
    def _try_numeric(val: Any) -> float | None:
        if isinstance(val, (int, float)):
            return float(val)
        s = str(val).strip().replace(",", "").replace("$", "").replace("€", "").replace("£", "")
        try:
            return float(s)
        except (ValueError, TypeError):
            return None

    num_a = _try_numeric(a)
    num_b = _try_numeric(b)
    if num_a is not None and num_b is not None:
        denom = max(abs(num_a), abs(num_b))
        if denom == 0:
            return 0.0
        return min(1.0, abs(num_a - num_b) / denom)

    # Try date comparison
    def _try_date(val: Any) -> datetime | None:
        if isinstance(val, datetime):
            return val
        s = str(val).strip()
        for fmt in ["%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y", "%m-%d-%Y", "%B %d, %Y"]:
            try:
                return datetime.strptime(s, fmt)
            except ValueError:
                continue
        return None

    date_a = _try_date(a)
    date_b = _try_date(b)
    if date_a is not None and date_b is not None:
        days_diff = abs((date_a - date_b).days)
        return min(1.0, days_diff / 365.0)

    # Text comparison
    str_a = str(a).strip().lower()
    str_b = str(b).strip().lower()
    if str_a and str_b:
        return 1.0 - SequenceMatcher(None, str_a, str_b).ratio()
    return 1.0 if str_a != str_b else 0.0


class ValueMatcher:
    """Normalizes and groups extracted values for consensus voting."""

    def __init__(self, fuzzy_threshold: float = 0.85):
        self.fuzzy_threshold = fuzzy_threshold

    def group_key(self, value: Any, field_type: str | None = None) -> str:
        """Generate a grouping key for a value.

        Semantically equivalent values produce the same key.
        """
        normalized = self.normalize_value(value, field_type)
        if isinstance(normalized, float):
            return f"num:{normalized}"
        if isinstance(normalized, dict):
            return f"dict:{json.dumps(normalized, sort_keys=True)}"
        if isinstance(normalized, list):
            return f"list:{json.dumps(normalized, sort_keys=True)}"
        return f"str:{normalized}"

    def normalize_value(self, value: Any, _field_type: str | None = None) -> Any:
        """Normalize a value for comparison.

        Rules:
        - Currency strings -> float (strips $, commas)
        - Date strings -> ISO format string (YYYY-MM-DD)
        - Dicts -> sorted by keys
        - Lists -> sorted content
        - Text -> lowercase, stripped
        """
        if value is None:
            return ""

        if isinstance(value, dict):
            return {k: self.normalize_value(v) for k, v in sorted(value.items())}

        if isinstance(value, list):
            return sorted([self.normalize_value(v) for v in value], key=str)

        if isinstance(value, (int, float)):
            return float(value)

        s = str(value).strip()

        # Try currency normalization
        currency_val = self._try_parse_currency(s)
        if currency_val is not None:
            return currency_val

        # Try date normalization
        date_val = self._try_parse_date(s)
        if date_val is not None:
            return date_val

        # Default: lowercase text
        return s.lower()

    def values_match(self, a: Any, b: Any, field_type: str | None = None) -> bool:
        """Check if two values are semantically equivalent."""
        key_a = self.group_key(a, field_type)
        key_b = self.group_key(b, field_type)

        if key_a == key_b:
            return True

        # Fuzzy text matching fallback (only for plain string values)
        if isinstance(a, (dict, list)) or isinstance(b, (dict, list)):
            return False

        str_a = str(a).strip().lower()
        str_b = str(b).strip().lower()
        if str_a and str_b:
            ratio = SequenceMatcher(None, str_a, str_b).ratio()
            return ratio >= self.fuzzy_threshold

        return False

    def _try_parse_currency(self, s: str) -> float | None:
        """Try to parse a string as a currency value."""
        # Match patterns like $1,234.56, 1234.56, $1234
        match = re.match(r"^\$?\s*([\d,]+\.?\d*)$", s.replace(" ", ""))
        if match:
            try:
                return float(match.group(1).replace(",", ""))
            except ValueError:
                return None
        return None

    def _try_parse_date(self, s: str) -> str | None:
        """Try to parse a string as a date, returning ISO format."""
        date_formats = [
            "%m/%d/%Y",
            "%m-%d-%Y",
            "%m.%d.%Y",
            "%d/%m/%Y",
            "%d-%m-%Y",
            "%Y-%m-%d",
            "%Y/%m/%d",
            "%B %d, %Y",
            "%B %d %Y",
            "%b %d, %Y",
            "%b %d %Y",
            "%d %B %Y",
            "%d %b %Y",
        ]
        for fmt in date_formats:
            try:
                dt = datetime.strptime(s.strip(), fmt)
                return dt.strftime("%Y-%m-%d")
            except ValueError:
                continue
        return None
