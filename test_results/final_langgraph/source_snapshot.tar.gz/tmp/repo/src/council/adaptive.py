"""
Adaptive Council Configuration.

Task 2.1.1: Creates system that automatically adjusts council configuration
based on document characteristics and historical performance.
"""

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger
from src.council.consensus import VotingStrategy

logger = get_logger(__name__)


class DocumentComplexity(StrEnum):
    """Document complexity levels."""

    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"


@dataclass
class ComplexityResult:
    """Result of complexity scoring."""

    score: float  # 0.0 to 1.0
    level: DocumentComplexity
    factors: dict[str, float] = field(default_factory=dict)


@dataclass
class CouncilConfiguration:
    """Configuration for council processing."""

    member_count: int
    voting_strategy: VotingStrategy
    confidence_threshold: float
    member_weights: dict[str, float] = field(default_factory=dict)
    selected_members: list[str] = field(default_factory=list)
    use_judge: bool = False
    max_retries: int = 2


class ComplexityScorer:
    """
    Scores document complexity based on features.

    Features considered:
    - Page count
    - Presence of tables, charts, forms
    - Handwriting detection
    - Language complexity
    - Text density
    """

    def __init__(self):
        """Initialize the complexity scorer."""
        self.weights = {
            "page_count": 0.15,
            "has_tables": 0.20,
            "has_charts": 0.15,
            "has_handwriting": 0.20,
            "has_forms": 0.10,
            "text_density": 0.10,
            "language": 0.10,
        }

    def score(self, features: dict[str, Any]) -> ComplexityResult:
        """
        Calculate complexity score for a document.

        Args:
            features: Document features dictionary

        Returns:
            ComplexityResult with score and level
        """
        factors = {}
        total_score = 0.0

        # Page count factor
        page_count = features.get("page_count", 1)
        if page_count <= 1:
            page_factor = 0.0
        elif page_count <= 5:
            page_factor = 0.2
        elif page_count <= 20:
            page_factor = 0.5
        else:
            page_factor = min(1.0, page_count / 100)
        factors["page_count"] = page_factor
        total_score += page_factor * self.weights["page_count"]

        # Table presence
        has_tables = features.get("has_tables", False)
        table_factor = 1.0 if has_tables else 0.0
        factors["has_tables"] = table_factor
        total_score += table_factor * self.weights["has_tables"]

        # Chart presence
        has_charts = features.get("has_charts", False)
        chart_factor = 1.0 if has_charts else 0.0
        factors["has_charts"] = chart_factor
        total_score += chart_factor * self.weights["has_charts"]

        # Handwriting presence
        has_handwriting = features.get("has_handwriting", False)
        handwriting_factor = 1.0 if has_handwriting else 0.0
        factors["has_handwriting"] = handwriting_factor
        total_score += handwriting_factor * self.weights["has_handwriting"]

        # Forms presence
        has_forms = features.get("has_forms", False)
        forms_factor = 1.0 if has_forms else 0.0
        factors["has_forms"] = forms_factor
        total_score += forms_factor * self.weights["has_forms"]

        # Text density
        text_density = features.get("text_density", "medium")
        density_map = {"low": 0.0, "medium": 0.3, "high": 0.7}
        density_factor = density_map.get(text_density, 0.3)
        factors["text_density"] = density_factor
        total_score += density_factor * self.weights["text_density"]

        # Language complexity
        language = features.get("language", "en")
        if language == "mixed":
            lang_factor = 1.0
        elif language in ("en", "es", "fr", "de"):
            lang_factor = 0.0
        else:
            lang_factor = 0.3
        factors["language"] = lang_factor
        total_score += lang_factor * self.weights["language"]

        # Normalize score to 0-1
        total_score = min(1.0, max(0.0, total_score))

        # Determine complexity level
        if total_score < 0.3:
            level = DocumentComplexity.SIMPLE
        elif total_score < 0.7:
            level = DocumentComplexity.MODERATE
        else:
            level = DocumentComplexity.COMPLEX

        return ComplexityResult(
            score=total_score,
            level=level,
            factors=factors,
        )


class AdaptiveCouncilConfig:
    """
    Adaptive Council Configuration Manager.

    Automatically adjusts council configuration based on:
    - Document complexity
    - Historical performance
    - Resource availability
    """

    def __init__(
        self,
        fast_path_confidence_threshold: float = 0.95,
        full_council_confidence_threshold: float = 0.85,
        min_council_size: int = 2,
        max_council_size: int = 3,
        learning_system: Any | None = None,
    ):
        """
        Initialize adaptive configuration.

        Args:
            fast_path_confidence_threshold: Threshold for fast path (2 members)
            full_council_confidence_threshold: Threshold for full council
            min_council_size: Minimum council members
            max_council_size: Maximum council members
            learning_system: Optional CouncilLearningSystem for feedback weights
        """
        self.fast_path_threshold = fast_path_confidence_threshold
        self.full_council_threshold = full_council_confidence_threshold
        self.min_council_size = min_council_size
        self.max_council_size = max_council_size
        self.complexity_scorer = ComplexityScorer()
        self.learning_system = learning_system

        # Default member weights
        self.base_weights = {
            "paddle_ocr": 1.0,
            "olmocr": 1.0,
            "qwen": 1.0,
            "colpali": 1.0,
        }

        # Historical performance by document type
        self.historical_weights: dict[str, dict[str, float]] = {}

        # Member capabilities
        self.member_capabilities = {
            "paddle_ocr": ["tables", "forms", "multilingual", "fast"],
            "olmocr": ["long_documents", "semantic", "multipage"],
            "qwen": ["charts", "complex_layouts", "visual_qa", "diagrams"],
            "colpali": ["visual_documents", "complex_layouts", "forms", "mixed_content"],
        }

    def update_historical_weights(
        self,
        history: dict[str, dict[str, float]],
    ) -> None:
        """
        Update weights from historical performance data.

        Args:
            history: Performance history {model: {doc_type: accuracy}}
        """
        self.historical_weights = history
        logger.info(
            "Updated historical weights",
            models=list(history.keys()),
        )

    def get_configuration(
        self,
        doc_features: dict[str, Any],
    ) -> CouncilConfiguration:
        """
        Get council configuration for a document.

        Args:
            doc_features: Document features

        Returns:
            CouncilConfiguration optimized for the document
        """
        # Score document complexity
        complexity = self.complexity_scorer.score(doc_features)

        # Determine base configuration from complexity
        if complexity.level == DocumentComplexity.SIMPLE:
            member_count = self.min_council_size
            voting_strategy = VotingStrategy.CASCADING
            confidence_threshold = self.fast_path_threshold
            use_judge = False
        elif complexity.level == DocumentComplexity.MODERATE:
            member_count = self.min_council_size
            voting_strategy = VotingStrategy.CONFIDENCE_WEIGHTED
            confidence_threshold = self.full_council_threshold
            use_judge = False
        else:  # COMPLEX
            member_count = self.max_council_size
            voting_strategy = VotingStrategy.CONFIDENCE_WEIGHTED
            confidence_threshold = self.full_council_threshold
            use_judge = True

        # Adjust for specific features
        if doc_features.get("has_tables"):
            # Ensure PaddleOCR is included for tables
            pass

        if doc_features.get("has_charts"):
            # Ensure Qwen is included for charts
            member_count = max(member_count, 3)

        # Calculate member weights
        doc_type = doc_features.get("document_type", "unknown")
        member_weights = self._calculate_weights(doc_type, doc_features)

        # Select members based on weights
        selected_members = self._select_members(member_weights, member_count)

        # Check for expected confidence override
        expected_confidence = doc_features.get("expected_confidence")
        if expected_confidence and expected_confidence >= self.fast_path_threshold:
            member_count = min(member_count, 2)

        logger.debug(
            "Generated council configuration",
            complexity=complexity.level.value,
            member_count=member_count,
            strategy=voting_strategy.value,
        )

        return CouncilConfiguration(
            member_count=member_count,
            voting_strategy=voting_strategy,
            confidence_threshold=confidence_threshold,
            member_weights=member_weights,
            selected_members=selected_members,
            use_judge=use_judge,
            max_retries=2 if complexity.level == DocumentComplexity.COMPLEX else 1,
        )

    def _calculate_weights(
        self,
        doc_type: str,
        features: dict[str, Any],
    ) -> dict[str, float]:
        """Calculate member weights for a document.

        Combines base weights, historical performance, learning feedback,
        and capability bonuses.
        """
        weights = dict(self.base_weights)

        # Apply historical performance
        if doc_type in self._get_historical_doc_types():
            for model, perf in self.historical_weights.items():
                if doc_type in perf:
                    weights[model] = weights.get(model, 1.0) * (0.5 + perf[doc_type])

        # Apply learning system feedback weights
        if self.learning_system is not None:
            learned = self.learning_system.get_adjusted_weights(doc_type)
            for model, learned_weight in learned.items():
                if model in weights:
                    weights[model] *= learned_weight

        # Apply capability-driven bonuses based on content features
        if features.get("has_tables"):
            weights["paddle_ocr"] = weights.get("paddle_ocr", 1.0) * 1.4
            weights["olmocr"] = weights.get("olmocr", 1.0) * 1.1

        if features.get("has_charts"):
            weights["qwen"] = weights.get("qwen", 1.0) * 1.5
            weights["colpali"] = weights.get("colpali", 1.0) * 1.3

        if features.get("has_forms"):
            weights["olmocr"] = weights.get("olmocr", 1.0) * 1.3
            weights["paddle_ocr"] = weights.get("paddle_ocr", 1.0) * 1.1

        if features.get("has_handwriting"):
            weights["qwen"] = weights.get("qwen", 1.0) * 1.5

        if features.get("page_count", 1) > 10:
            weights["olmocr"] = weights.get("olmocr", 1.0) * 1.1

        if features.get("has_mixed_content") or features.get("is_scanned"):
            weights["colpali"] = weights.get("colpali", 1.0) * 1.2

        # Normalize weights
        total = sum(weights.values())
        if total > 0:
            weights = {k: v / total for k, v in weights.items()}

        return weights

    def _get_historical_doc_types(self) -> set[str]:
        """Get all document types with historical data."""
        doc_types = set()
        for model_history in self.historical_weights.values():
            doc_types.update(model_history.keys())
        return doc_types

    def _select_members(
        self,
        weights: dict[str, float],
        count: int,
    ) -> list[str]:
        """Select top members by weight."""
        sorted_members = sorted(
            weights.items(),
            key=lambda x: x[1],
            reverse=True,
        )
        return [m[0] for m in sorted_members[:count]]

    def get_fast_path_config(self) -> CouncilConfiguration:
        """Get configuration for fast path processing."""
        return CouncilConfiguration(
            member_count=1,
            voting_strategy=VotingStrategy.CASCADING,
            confidence_threshold=self.fast_path_threshold,
            member_weights={"paddle_ocr": 1.0},
            selected_members=["paddle_ocr"],
            use_judge=False,
            max_retries=1,
        )


# Singleton instance
_adaptive_config: AdaptiveCouncilConfig | None = None


def get_adaptive_config() -> AdaptiveCouncilConfig:
    """Get or create the adaptive config singleton."""
    global _adaptive_config
    if _adaptive_config is None:
        _adaptive_config = AdaptiveCouncilConfig()
    return _adaptive_config
