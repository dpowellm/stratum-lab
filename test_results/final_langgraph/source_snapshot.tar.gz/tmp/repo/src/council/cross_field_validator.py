"""Cross-field validation for extracted document data.

Validates consistency between related fields:
- Totals match sum of components (subtotal + tax == total)
- Date ordering (invoice_date <= due_date)
- Line items sum matches total
- Referential integrity
"""

import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class IssueSeverity(StrEnum):
    """Severity of a cross-field validation issue."""

    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class IssueAction(StrEnum):
    """Suggested action for a validation issue."""

    DOWNGRADE_CONFIDENCE = "downgrade_confidence"
    FLAG_REVIEW = "flag_review"
    REJECT = "reject"


@dataclass
class CrossFieldIssue:
    """A single cross-field validation issue."""

    fields: list[str]
    description: str
    severity: IssueSeverity
    action: IssueAction
    confidence_penalty: float = 0.0
    expected_value: Any = None
    actual_value: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)


def _parse_numeric(value: Any) -> float | None:
    """Try to parse a value as a number."""
    if isinstance(value, (int, float)):
        return float(value)
    if value is None:
        return None
    s = str(value).strip()
    s = re.sub(r"[,$€£¥]", "", s)
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def _parse_date(value: Any) -> datetime | None:
    """Try to parse a value as a date."""
    if isinstance(value, datetime):
        return value
    if value is None:
        return None
    s = str(value).strip()
    for fmt in ["%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y", "%m-%d-%Y", "%B %d, %Y", "%b %d, %Y"]:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


class CrossFieldValidator:
    """Validates consistency between related extracted fields."""

    def __init__(self, tolerance: float = 0.01):
        """Initialize with numeric tolerance for sum checks.

        Args:
            tolerance: Relative tolerance for numeric comparisons (default 1%).
        """
        self.tolerance = tolerance

    def validate_field_consistency(
        self,
        fields: dict[str, Any],
        document_type: str | None = None,
    ) -> list[CrossFieldIssue]:
        """Validate consistency between extracted fields.

        Args:
            fields: Extracted field values (field_name -> value).
            document_type: Document type for type-specific rules.

        Returns:
            List of validation issues found.
        """
        issues: list[CrossFieldIssue] = []

        # Run general date ordering rules
        issues.extend(self._check_date_ordering(fields))

        # Run document-type-specific rules
        if document_type in ("invoice", "receipt", "financial"):
            issues.extend(self._check_totals_sum(fields))
            issues.extend(self._check_line_items_total(fields))

        # Line item quantity * price = amount validation
        issues.extend(self._check_line_item_math(fields))

        # Percentage fields must be in [0, 100]
        issues.extend(self._check_percentage_bounds(fields))

        # Currency consistency across amount fields
        issues.extend(self._check_currency_consistency(fields))

        logger.debug(
            "Cross-field validation complete",
            document_type=document_type,
            issue_count=len(issues),
        )
        return issues

    def _check_totals_sum(self, fields: dict[str, Any]) -> list[CrossFieldIssue]:
        """Check that subtotal + tax == total (within tolerance)."""
        issues: list[CrossFieldIssue] = []

        # Try invoice format: subtotal + tax_amount = total_amount
        subtotal = _parse_numeric(fields.get("subtotal"))
        tax = _parse_numeric(fields.get("tax_amount") or fields.get("tax"))
        total = _parse_numeric(fields.get("total_amount") or fields.get("total"))

        if subtotal is not None and tax is not None and total is not None:
            expected = subtotal + tax
            if total > 0 and abs(expected - total) / total > self.tolerance:
                issues.append(
                    CrossFieldIssue(
                        fields=["subtotal", "tax_amount", "total_amount"],
                        description=(
                            f"Total mismatch: subtotal ({subtotal}) + tax ({tax}) "
                            f"= {expected}, but total = {total}"
                        ),
                        severity=IssueSeverity.ERROR,
                        action=IssueAction.FLAG_REVIEW,
                        confidence_penalty=0.2,
                        expected_value=expected,
                        actual_value=total,
                    )
                )

        # Check opening_balance + credits - debits = closing_balance
        opening = _parse_numeric(fields.get("opening_balance"))
        credits = _parse_numeric(fields.get("total_credits"))
        debits = _parse_numeric(fields.get("total_debits"))
        closing = _parse_numeric(fields.get("closing_balance"))

        if all(v is not None for v in [opening, credits, debits, closing]):
            expected_closing = opening + credits - debits  # type: ignore[operator]
            if closing > 0 and abs(expected_closing - closing) / abs(closing) > self.tolerance:  # type: ignore[operator]
                issues.append(
                    CrossFieldIssue(
                        fields=[
                            "opening_balance",
                            "total_credits",
                            "total_debits",
                            "closing_balance",
                        ],
                        description=(
                            f"Balance mismatch: opening ({opening}) + credits ({credits}) "
                            f"- debits ({debits}) = {expected_closing}, "
                            f"but closing = {closing}"
                        ),
                        severity=IssueSeverity.ERROR,
                        action=IssueAction.FLAG_REVIEW,
                        confidence_penalty=0.2,
                        expected_value=expected_closing,
                        actual_value=closing,
                    )
                )

        return issues

    def _check_date_ordering(self, fields: dict[str, Any]) -> list[CrossFieldIssue]:
        """Check that dates are in logical order."""
        issues: list[CrossFieldIssue] = []

        # Define date ordering rules: (earlier_field, later_field)
        ordering_rules = [
            ("invoice_date", "due_date"),
            ("contract_date", "effective_date"),
            ("effective_date", "expiration_date"),
            ("issue_date", "expiration_date"),
            ("date_of_birth", "issue_date"),
            ("opening_date", "closing_date"),
            ("statement_date", "due_date"),
        ]

        for earlier_field, later_field in ordering_rules:
            earlier_val = fields.get(earlier_field)
            later_val = fields.get(later_field)

            if earlier_val is None or later_val is None:
                continue

            earlier_date = _parse_date(earlier_val)
            later_date = _parse_date(later_val)

            if earlier_date is not None and later_date is not None:
                if earlier_date > later_date:
                    issues.append(
                        CrossFieldIssue(
                            fields=[earlier_field, later_field],
                            description=(
                                f"Date ordering: {earlier_field} ({earlier_val}) "
                                f"is after {later_field} ({later_val})"
                            ),
                            severity=IssueSeverity.WARNING,
                            action=IssueAction.DOWNGRADE_CONFIDENCE,
                            confidence_penalty=0.15,
                        )
                    )

        return issues

    def _check_line_item_math(self, fields: dict[str, Any]) -> list[CrossFieldIssue]:
        """Check that line item quantity * unit_price = amount for each item."""
        issues: list[CrossFieldIssue] = []

        line_items = fields.get("line_items")
        if not isinstance(line_items, list):
            return issues

        for idx, item in enumerate(line_items):
            if not isinstance(item, dict):
                continue

            qty = _parse_numeric(item.get("quantity") or item.get("qty"))
            unit_price = _parse_numeric(item.get("unit_price") or item.get("price"))
            amount = _parse_numeric(item.get("amount") or item.get("total") or item.get("line_total"))

            if qty is not None and unit_price is not None and amount is not None:
                expected = qty * unit_price
                if amount > 0 and abs(expected - amount) / amount > self.tolerance:
                    issues.append(
                        CrossFieldIssue(
                            fields=[f"line_items[{idx}].quantity", f"line_items[{idx}].amount"],
                            description=(
                                f"Line item {idx}: qty ({qty}) x price ({unit_price}) "
                                f"= {expected:.2f}, but amount = {amount}"
                            ),
                            severity=IssueSeverity.WARNING,
                            action=IssueAction.DOWNGRADE_CONFIDENCE,
                            confidence_penalty=0.1,
                            expected_value=expected,
                            actual_value=amount,
                        )
                    )

        return issues

    def _check_percentage_bounds(self, fields: dict[str, Any]) -> list[CrossFieldIssue]:
        """Check that percentage fields are within [0, 100]."""
        issues: list[CrossFieldIssue] = []

        pct_field_patterns = ["rate", "percentage", "pct", "tax_rate", "discount_rate"]
        for field_name, value in fields.items():
            if not any(p in field_name.lower() for p in pct_field_patterns):
                continue

            num = _parse_numeric(value)
            if num is not None and (num < 0 or num > 100):
                issues.append(
                    CrossFieldIssue(
                        fields=[field_name],
                        description=f"Percentage field '{field_name}' = {num}, expected [0, 100]",
                        severity=IssueSeverity.WARNING,
                        action=IssueAction.DOWNGRADE_CONFIDENCE,
                        confidence_penalty=0.15,
                        expected_value="0-100",
                        actual_value=num,
                    )
                )

        return issues

    def _check_currency_consistency(self, fields: dict[str, Any]) -> list[CrossFieldIssue]:
        """Check that all amount fields use the same currency symbol."""
        issues: list[CrossFieldIssue] = []

        amount_fields = ["subtotal", "total", "total_amount", "tax", "tax_amount", "discount"]
        currencies_found: dict[str, list[str]] = {}

        for field_name in amount_fields:
            value = fields.get(field_name)
            if value is None:
                continue
            text = str(value).strip()
            for symbol in ["$", "€", "£", "¥", "CHF", "CAD", "AUD"]:
                if symbol in text:
                    currencies_found.setdefault(symbol, []).append(field_name)
                    break

        if len(currencies_found) > 1:
            all_fields = []
            for field_list in currencies_found.values():
                all_fields.extend(field_list)
            issues.append(
                CrossFieldIssue(
                    fields=all_fields,
                    description=(
                        f"Mixed currencies detected: {list(currencies_found.keys())} "
                        f"across {all_fields}"
                    ),
                    severity=IssueSeverity.WARNING,
                    action=IssueAction.FLAG_REVIEW,
                    confidence_penalty=0.1,
                )
            )

        return issues

    def _check_line_items_total(self, fields: dict[str, Any]) -> list[CrossFieldIssue]:
        """Check that line items sum matches subtotal or total."""
        issues: list[CrossFieldIssue] = []

        line_items = fields.get("line_items")
        if not isinstance(line_items, list) or not line_items:
            return issues

        # Sum up line item amounts
        item_sum = 0.0
        valid_items = 0
        for item in line_items:
            amount = None
            if isinstance(item, dict):
                amount = _parse_numeric(
                    item.get("amount") or item.get("total") or item.get("price")
                )
            if amount is not None:
                item_sum += amount
                valid_items += 1

        if valid_items == 0:
            return issues

        # Compare against subtotal or total
        subtotal = _parse_numeric(fields.get("subtotal"))
        total = _parse_numeric(fields.get("total_amount") or fields.get("total"))

        compare_to = subtotal if subtotal is not None else total
        compare_field = "subtotal" if subtotal is not None else "total_amount"

        if compare_to is not None and compare_to > 0:
            if abs(item_sum - compare_to) / compare_to > self.tolerance:
                issues.append(
                    CrossFieldIssue(
                        fields=["line_items", compare_field],
                        description=(
                            f"Line items sum ({item_sum:.2f}) doesn't match "
                            f"{compare_field} ({compare_to})"
                        ),
                        severity=IssueSeverity.WARNING,
                        action=IssueAction.DOWNGRADE_CONFIDENCE,
                        confidence_penalty=0.1,
                        expected_value=compare_to,
                        actual_value=item_sum,
                    )
                )

        return issues
