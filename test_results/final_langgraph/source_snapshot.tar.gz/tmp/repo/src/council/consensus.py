"""
Council Consensus Engine.

Aggregates outputs from multiple OCR council members and determines
the final extraction through voting and consensus mechanisms.
"""

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from src.core.logging import CouncilLogger, get_logger
from src.services.evals.calibration import CalibrationTracker
from src.services.ocr.base import Capability, OCRResult

logger = get_logger(__name__)


class VotingStrategy(StrEnum):
    """Voting strategy for consensus."""

    CONFIDENCE_WEIGHTED = "confidence_weighted"
    UNANIMOUS = "unanimous"
    EXPERTISE_DELEGATION = "expertise_delegation"
    CASCADING = "cascading"


class ConflictLevel(StrEnum):
    """Level of conflict between council members."""

    NONE = "none"
    MINOR = "minor"  # 2 agree, 1 differs
    MODERATE = "moderate"  # All 3 different
    MAJOR = "major"  # Critical field with disagreement


@dataclass
class MemberVote:
    """Vote from a single council member."""

    member_name: str
    value: Any
    confidence: float
    raw_output: Any = None
    processing_time_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class FieldConsensus:
    """Consensus result for a single field."""

    field_name: str
    final_value: Any
    confidence: float
    source_member: str
    all_votes: list[MemberVote]
    conflict_level: ConflictLevel = ConflictLevel.NONE
    agreement_count: int = 0
    alternative_values: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class ConsensusResult:
    """Complete consensus result from the council."""

    session_id: str
    fields: list[FieldConsensus]
    overall_confidence: float
    consensus_score: float  # Percentage of fields with full agreement
    agreed_fields: int
    disputed_fields: int
    total_fields: int
    voting_strategy: VotingStrategy
    participating_members: list[str]
    conflict_level: ConflictLevel = ConflictLevel.NONE
    requires_judge: bool = False
    requires_human_review: bool = False
    processing_time_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "session_id": self.session_id,
            "overall_confidence": self.overall_confidence,
            "consensus_score": self.consensus_score,
            "agreed_fields": self.agreed_fields,
            "disputed_fields": self.disputed_fields,
            "total_fields": self.total_fields,
            "voting_strategy": self.voting_strategy.value,
            "participating_members": self.participating_members,
            "conflict_level": self.conflict_level.value,
            "requires_judge": self.requires_judge,
            "requires_human_review": self.requires_human_review,
            "fields": [
                {
                    "field_name": f.field_name,
                    "final_value": f.final_value,
                    "confidence": f.confidence,
                    "source_member": f.source_member,
                    "conflict_level": f.conflict_level.value,
                    "agreement_count": f.agreement_count,
                }
                for f in self.fields
            ],
        }


class ConsensusEngine:
    """
    Council Consensus Engine.

    Aggregates outputs from multiple OCR models and determines
    the final extraction through configurable voting mechanisms.
    """

    def __init__(
        self,
        consensus_threshold: float = 0.85,
        unanimous_threshold: float = 0.95,
        min_confidence: float = 0.60,
        expertise_weights: dict[str, dict[str, float]] | None = None,
        calibrator: CalibrationTracker | None = None,
        field_weights: dict[str, float] | None = None,
        learning_weights: dict[str, float] | None = None,
        expertise_routing: dict[str, list[str]] | None = None,
    ):
        """
        Initialize the consensus engine.

        Args:
            consensus_threshold: Minimum consensus score to accept without judge
            unanimous_threshold: Threshold for unanimous consensus
            min_confidence: Minimum confidence to consider a vote
            expertise_weights: Model expertise weights per capability
            calibrator: Optional CalibrationTracker for Platt scaling
            field_weights: Optional per-field criticality weights
            learning_weights: Optional per-model learned weights from feedback
            expertise_routing: Optional field→member routing from ExpertiseRouter
        """
        self.consensus_threshold = consensus_threshold
        self.unanimous_threshold = unanimous_threshold
        self.min_confidence = min_confidence
        self.expertise_weights = expertise_weights or self._default_expertise_weights()
        self.calibrator = calibrator
        self.field_weights = field_weights
        self.learning_weights = learning_weights
        self.expertise_routing = expertise_routing

    def _default_expertise_weights(self) -> dict[str, dict[str, float]]:
        """Get default expertise weights for each model."""
        return {
            "paddle_ocr": {
                Capability.TABLES.value: 0.50,
                Capability.MULTILINGUAL.value: 0.60,
                Capability.FAST_EXTRACTION.value: 0.70,
                Capability.FORMS.value: 0.55,
            },
            "olmocr": {
                Capability.TOKEN_EFFICIENCY.value: 0.65,
                Capability.LONG_DOCUMENTS.value: 0.60,
                Capability.MULTIPAGE.value: 0.55,
                Capability.SEMANTIC_UNDERSTANDING.value: 0.60,
            },
            "qwen": {
                Capability.CHARTS.value: 0.70,
                Capability.COMPLEX_LAYOUTS.value: 0.60,
                Capability.DIAGRAMS.value: 0.65,
                Capability.VISUAL_QA.value: 0.70,
            },
            "colpali": {
                Capability.COMPLEX_LAYOUTS.value: 0.70,
                Capability.VISUAL_QA.value: 0.65,
                Capability.CHARTS.value: 0.55,
                Capability.DIAGRAMS.value: 0.60,
                Capability.FORMS.value: 0.60,
            },
        }

    def calculate_consensus(
        self,
        session_id: str,
        member_results: dict[str, OCRResult],
        extracted_fields: dict[str, dict[str, MemberVote]],
        voting_strategy: VotingStrategy = VotingStrategy.CONFIDENCE_WEIGHTED,
        critical_fields: list[str] | None = None,
        council_logger: CouncilLogger | None = None,
    ) -> ConsensusResult:
        """
        Calculate consensus from council member results.

        Args:
            session_id: Unique session identifier
            member_results: OCR results from each member
            extracted_fields: Extracted field values from each member
                Format: {field_name: {member_name: MemberVote}}
            voting_strategy: Strategy for reaching consensus
            critical_fields: Fields requiring unanimous agreement
            council_logger: Optional logger for council decisions

        Returns:
            ConsensusResult with final values and confidence scores
        """
        critical_fields = critical_fields or []
        participating_members = list(member_results.keys())

        field_consensuses: list[FieldConsensus] = []
        agreed_count = 0
        disputed_count = 0
        total_confidence = 0.0
        max_conflict = ConflictLevel.NONE
        requires_judge = False
        requires_human = False

        for field_name, member_votes in extracted_fields.items():
            # Get field consensus based on voting strategy
            is_critical = field_name in critical_fields

            if is_critical:
                field_consensus = self._unanimous_vote(
                    field_name, member_votes, participating_members
                )
            elif voting_strategy == VotingStrategy.CONFIDENCE_WEIGHTED:
                field_consensus = self._confidence_weighted_vote(field_name, member_votes)
            elif voting_strategy == VotingStrategy.EXPERTISE_DELEGATION:
                field_consensus = self._expertise_delegation_vote(field_name, member_votes)
            elif voting_strategy == VotingStrategy.CASCADING:
                field_consensus = self._cascading_vote(field_name, member_votes)
            else:
                field_consensus = self._confidence_weighted_vote(field_name, member_votes)

            field_consensuses.append(field_consensus)
            total_confidence += field_consensus.confidence

            # Track agreement
            if field_consensus.conflict_level == ConflictLevel.NONE:
                agreed_count += 1
            else:
                disputed_count += 1

            # Track max conflict level
            if self._conflict_level_value(
                field_consensus.conflict_level
            ) > self._conflict_level_value(max_conflict):
                max_conflict = field_consensus.conflict_level

            # Determine if escalation needed
            if field_consensus.conflict_level == ConflictLevel.MODERATE:
                requires_judge = True
            elif field_consensus.conflict_level == ConflictLevel.MAJOR:
                requires_human = True

            # Log conflict if present
            if council_logger and field_consensus.conflict_level != ConflictLevel.NONE:
                council_logger.log_conflict(
                    field_name=field_name,
                    conflict_level=field_consensus.conflict_level.value,
                    member_values={v.member_name: v.value for v in field_consensus.all_votes},
                )

        total_fields = len(field_consensuses)
        consensus_score = agreed_count / total_fields if total_fields > 0 else 0.0

        # Use field criticality weights for overall confidence if available
        if self.field_weights and total_fields > 0:
            weighted_sum = 0.0
            weight_total = 0.0
            for fc in field_consensuses:
                w = self.field_weights.get(fc.field_name, 1.0)
                weighted_sum += fc.confidence * w
                weight_total += w
            overall_confidence = weighted_sum / weight_total if weight_total > 0 else 0.0
        else:
            overall_confidence = total_confidence / total_fields if total_fields > 0 else 0.0

        # Check if consensus meets threshold
        if consensus_score < self.consensus_threshold and not requires_human:
            requires_judge = True

        result = ConsensusResult(
            session_id=session_id,
            fields=field_consensuses,
            overall_confidence=overall_confidence,
            consensus_score=consensus_score,
            agreed_fields=agreed_count,
            disputed_fields=disputed_count,
            total_fields=total_fields,
            voting_strategy=voting_strategy,
            participating_members=participating_members,
            conflict_level=max_conflict,
            requires_judge=requires_judge,
            requires_human_review=requires_human,
        )

        # Log consensus result
        if council_logger:
            council_logger.log_consensus_result(
                consensus_score=consensus_score,
                agreed_fields=agreed_count,
                disputed_fields=disputed_count,
                total_fields=total_fields,
            )

        return result

    def _confidence_weighted_vote(
        self,
        field_name: str,
        member_votes: dict[str, MemberVote],
    ) -> FieldConsensus:
        """
        Vote using confidence-weighted majority.

        Each vote is weighted by the member's confidence score.
        """
        if not member_votes:
            return FieldConsensus(
                field_name=field_name,
                final_value=None,
                confidence=0.0,
                source_member="",
                all_votes=[],
                conflict_level=ConflictLevel.MAJOR,
            )

        votes = list(member_votes.values())

        # Apply calibration to get effective confidence
        calibrated_confs: dict[str, float] = {}
        for v in votes:
            calibrated_confs[v.member_name] = self._calibrate_vote_confidence(v)

        # Filter votes above minimum confidence (using calibrated scores)
        valid_votes = [v for v in votes if calibrated_confs[v.member_name] >= self.min_confidence]
        if not valid_votes:
            valid_votes = votes  # Use all if none meet threshold

        # Group by value
        from src.council.value_matching import ValueMatcher

        value_groups: dict[str, list[MemberVote]] = {}
        for vote in valid_votes:
            value_key = ValueMatcher().group_key(vote.value)
            if value_key not in value_groups:
                value_groups[value_key] = []
            value_groups[value_key].append(vote)

        # Calculate weighted score for each value (using calibrated confidence)
        best_value = None
        best_score = 0.0
        best_vote = valid_votes[0]

        for _value_key, group_votes in value_groups.items():
            score = sum(calibrated_confs[v.member_name] for v in group_votes)
            if score > best_score:
                best_score = score
                best_value = group_votes[0].value
                best_vote = max(group_votes, key=lambda v: calibrated_confs[v.member_name])

        # Determine conflict level
        unique_values = len(value_groups)
        if unique_values == 1:
            conflict_level = ConflictLevel.NONE
            agreement_count = len(valid_votes)
        elif unique_values == 2 and len(valid_votes) >= 2:
            # Check if it's 2-1 split
            max_group_size = max(len(g) for g in value_groups.values())
            conflict_level = ConflictLevel.MINOR if max_group_size >= 2 else ConflictLevel.MODERATE
            agreement_count = max_group_size
        else:
            conflict_level = ConflictLevel.MODERATE
            agreement_count = 1

        # Build alternative values
        alternatives = []
        for vote in valid_votes:
            if vote.value != best_value:
                alternatives.append(
                    {
                        "value": vote.value,
                        "confidence": vote.confidence,
                        "source": vote.member_name,
                    }
                )

        # Apply value divergence penalty
        from src.council.value_matching import value_distance

        max_distance = 0.0
        for vote in valid_votes:
            if vote.value != best_value:
                dist = value_distance(best_value, vote.value, field_name)
                max_distance = max(max_distance, dist)

        # Agreement-weighted confidence: boost when members agree, penalize splits
        agreement_ratio = agreement_count / len(valid_votes) if valid_votes else 0.0
        bonus = 1.0 + (agreement_ratio - 0.5) * 0.3
        base_conf = calibrated_confs[best_vote.member_name]
        weighted_confidence = min(1.0, base_conf * bonus)

        # Divergence penalty: large value disagreements reduce confidence
        if max_distance > 0.1:
            divergence_penalty = max(0.5, 1.0 - max_distance * 0.5)
            weighted_confidence *= divergence_penalty

        return FieldConsensus(
            field_name=field_name,
            final_value=best_value,
            confidence=weighted_confidence,
            source_member=best_vote.member_name,
            all_votes=votes,
            conflict_level=conflict_level,
            agreement_count=agreement_count,
            alternative_values=alternatives,
        )

    def _unanimous_vote(
        self,
        field_name: str,
        member_votes: dict[str, MemberVote],
        participating_members: list[str],
    ) -> FieldConsensus:
        """
        Vote requiring unanimous agreement.

        All members must agree for the vote to pass.
        """
        votes = list(member_votes.values())

        # Apply calibration
        calibrated_confs: dict[str, float] = {}
        for v in votes:
            calibrated_confs[v.member_name] = self._calibrate_vote_confidence(v)

        valid_votes = [v for v in votes if calibrated_confs[v.member_name] >= self.min_confidence]

        if not valid_votes:
            return FieldConsensus(
                field_name=field_name,
                final_value=None,
                confidence=0.0,
                source_member="",
                all_votes=votes,
                conflict_level=ConflictLevel.MAJOR,
            )

        # Check if all values are the same
        from src.council.value_matching import ValueMatcher

        matcher = ValueMatcher()
        first_key = matcher.group_key(valid_votes[0].value)
        all_agree = all(matcher.group_key(v.value) == first_key for v in valid_votes)

        if all_agree and len(valid_votes) == len(participating_members):
            # Unanimous agreement - use calibrated confidences
            avg_confidence = sum(calibrated_confs[v.member_name] for v in valid_votes) / len(
                valid_votes
            )
            return FieldConsensus(
                field_name=field_name,
                final_value=valid_votes[0].value,
                confidence=avg_confidence,
                source_member="unanimous",
                all_votes=votes,
                conflict_level=ConflictLevel.NONE,
                agreement_count=len(valid_votes),
            )
        else:
            # No unanimous agreement - mark as major conflict for critical fields
            best_vote = max(valid_votes, key=lambda v: calibrated_confs[v.member_name])
            return FieldConsensus(
                field_name=field_name,
                final_value=best_vote.value,
                confidence=best_vote.confidence,
                source_member=best_vote.member_name,
                all_votes=votes,
                conflict_level=ConflictLevel.MAJOR,
                agreement_count=1,
                alternative_values=[
                    {"value": v.value, "confidence": v.confidence, "source": v.member_name}
                    for v in valid_votes
                    if v.value != best_vote.value
                ],
            )

    def _expertise_delegation_vote(
        self,
        field_name: str,
        member_votes: dict[str, MemberVote],
    ) -> FieldConsensus:
        """
        Vote giving weight to model expertise.

        Applies expertise bonus based on field type/content.
        """
        votes = list(member_votes.values())

        if not votes:
            return FieldConsensus(
                field_name=field_name,
                final_value=None,
                confidence=0.0,
                source_member="",
                all_votes=[],
                conflict_level=ConflictLevel.MAJOR,
            )

        # Detect content type from field name (simplified)
        content_type = self._detect_content_type(field_name)

        # Apply expertise weights with calibration and routing
        weighted_votes: list[tuple[MemberVote, float]] = []
        for vote in votes:
            base_weight = self._calibrate_vote_confidence(vote)
            expertise_bonus = self._get_expertise_bonus(vote.member_name, content_type)
            routing_bonus = self._get_expertise_routing_bonus(vote.member_name, field_name)
            weighted_score = base_weight * (1 + expertise_bonus + routing_bonus)
            weighted_votes.append((vote, weighted_score))

        # Sort by weighted score
        weighted_votes.sort(key=lambda x: x[1], reverse=True)
        best_vote, best_score = weighted_votes[0]

        # Determine conflict level based on score difference
        if len(weighted_votes) > 1:
            second_score = weighted_votes[1][1]
            if best_score > second_score * 1.2:  # 20% margin
                conflict_level = ConflictLevel.NONE
            else:
                conflict_level = ConflictLevel.MINOR
        else:
            conflict_level = ConflictLevel.NONE

        return FieldConsensus(
            field_name=field_name,
            final_value=best_vote.value,
            confidence=best_vote.confidence,
            source_member=best_vote.member_name,
            all_votes=votes,
            conflict_level=conflict_level,
            agreement_count=1,
            alternative_values=[
                {"value": v.value, "confidence": v.confidence, "source": v.member_name}
                for v, _ in weighted_votes[1:]
            ],
        )

    def _cascading_vote(
        self,
        field_name: str,
        member_votes: dict[str, MemberVote],
    ) -> FieldConsensus:
        """Vote using cascading strategy.

        Consults members in priority order (paddle → olmocr → qwen → colpali).
        Accumulates votes and checks for consensus at each step.
        Stops early if confidence >= unanimous_threshold AND agreement >= 2.
        Falls through to full confidence-weighted vote if no early consensus.
        """
        priority_order = ["paddle_ocr", "olmocr", "qwen", "colpali"]
        accumulated: dict[str, MemberVote] = {}

        for member_name in priority_order:
            # Find the vote for this member (flexible name matching)
            vote = member_votes.get(member_name)
            if vote is None:
                # Try partial match
                for k, v in member_votes.items():
                    if member_name in k or k in member_name:
                        vote = v
                        break
            if vote is None:
                continue

            accumulated[vote.member_name] = vote

            # Check if we have enough agreement to stop early
            if len(accumulated) >= 2:
                interim = self._confidence_weighted_vote(field_name, accumulated)
                if interim.confidence >= self.unanimous_threshold and interim.agreement_count >= 2:
                    return interim

        # No early stop — use full council vote
        return self._confidence_weighted_vote(field_name, member_votes)

    def _detect_content_type(self, field_name: str) -> str:
        """Detect content type from field name."""
        field_lower = field_name.lower()
        if any(kw in field_lower for kw in ["table", "grid", "matrix"]):
            return Capability.TABLES.value
        if any(kw in field_lower for kw in ["chart", "graph", "plot"]):
            return Capability.CHARTS.value
        if any(kw in field_lower for kw in ["amount", "total", "price", "currency"]):
            return "financial"
        if any(kw in field_lower for kw in ["date", "time"]):
            return "date"
        return "text"

    def _get_expertise_bonus(self, member_name: str, content_type: str) -> float:
        """Get expertise bonus for a member on a content type."""
        member_weights = self.expertise_weights.get(member_name, {})
        return member_weights.get(content_type, 0.0)

    def _calibrate_vote_confidence(self, vote: MemberVote) -> float:
        """Calibrate a vote's confidence using Platt scaling and learning weights.

        Applies calibrator (if available) then multiplies by learning weight
        for the member (if available).
        """
        conf = vote.confidence
        if self.calibrator:
            conf = self.calibrator.calibrate(conf, vote.member_name)
        if self.learning_weights and vote.member_name in self.learning_weights:
            conf = conf * self.learning_weights[vote.member_name]
        return min(1.0, max(0.0, conf))

    def _get_expertise_routing_bonus(self, member_name: str, field_name: str) -> float:
        """Get expertise routing bonus for a member on a specific field."""
        if not self.expertise_routing:
            return 0.0
        expert_members = self.expertise_routing.get(field_name, [])
        if member_name in expert_members:
            return 0.3  # 30% boost for designated experts
        return 0.0

    def _conflict_level_value(self, level: ConflictLevel) -> int:
        """Get numeric value for conflict level comparison."""
        mapping = {
            ConflictLevel.NONE: 0,
            ConflictLevel.MINOR: 1,
            ConflictLevel.MODERATE: 2,
            ConflictLevel.MAJOR: 3,
        }
        return mapping.get(level, 0)


# Singleton instance
_consensus_engine: ConsensusEngine | None = None


def get_consensus_engine(
    calibrator: CalibrationTracker | None = None,
    field_weights: dict[str, float] | None = None,
    learning_weights: dict[str, float] | None = None,
    expertise_routing: dict[str, list[str]] | None = None,
) -> ConsensusEngine:
    """Get or create the consensus engine singleton."""
    global _consensus_engine
    if _consensus_engine is None:
        from src.config.settings import get_settings

        settings = get_settings()
        _consensus_engine = ConsensusEngine(
            consensus_threshold=settings.council.consensus_threshold,
            unanimous_threshold=settings.council.unanimous_threshold,
            min_confidence=settings.council.min_confidence,
            calibrator=calibrator,
            field_weights=field_weights,
            learning_weights=learning_weights,
            expertise_routing=expertise_routing,
        )
    return _consensus_engine
