"""
Council Learning System.

Task 2.1.2: Creates feedback loop that improves council performance
from corrections and outcomes.

Phase 3.1: Persistence support — when a session_factory is provided,
corrections, events, and weight history are persisted to the database.
The public sync methods (``record_correction``, ``record_event``,
``get_adjusted_weights``) remain unchanged for backward compatibility.
Async variants (``arecord_correction``, ``arecord_event``,
``aget_adjusted_weights``) persist to the database when a session_factory
is configured.
"""

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any

from sqlalchemy import Integer as SAInteger, case, func, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from src.core.logging import get_logger
from src.models.database.learning import (
    LearningCorrection as LearningCorrectionModel,
    LearningEvent as LearningEventModel,
    WeightHistory as WeightHistoryModel,
)

logger = get_logger(__name__)


@dataclass
class CorrectionPattern:
    """Pattern representing a correction made to extraction."""

    document_type: str
    field_name: str
    original_value: Any
    corrected_value: Any
    source_model: str
    correction_source: str  # "human", "judge", "auto"
    timestamp: datetime
    confidence: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class LearningEvent:
    """Event recording model performance."""

    model_name: str
    document_type: str
    field_name: str
    was_correct: bool
    confidence: float
    timestamp: datetime
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ModelPerformance:
    """Performance metrics for a model."""

    model_name: str
    document_type: str
    accuracy: float
    avg_confidence: float
    total_extractions: int
    correct_extractions: int
    weaknesses: list[str] = field(default_factory=list)
    strengths: list[str] = field(default_factory=list)


@dataclass
class SuccessPattern:
    """Pattern representing successful extraction."""

    document_type: str
    layout: str
    winning_model: str
    consensus_score: float
    timestamp: datetime = field(default_factory=datetime.utcnow)
    features: dict[str, Any] = field(default_factory=dict)


class CouncilLearningSystem:
    """
    Learning system that improves council performance over time.

    Features:
    - Tracks correction patterns
    - Identifies model-specific weaknesses
    - Adjusts expertise weights
    - Stores successful patterns

    When constructed with a ``session_factory``, the async methods
    (``arecord_correction``, ``arecord_event``, ``aget_adjusted_weights``,
    ``load_from_db``) persist data to the database. The sync methods
    always work in-memory only and are fully backward-compatible.
    """

    def __init__(
        self,
        learning_window_days: int = 30,
        min_samples_for_adjustment: int = 10,
        weight_adjustment_rate: float = 0.1,
        session_factory: async_sessionmaker[AsyncSession] | None = None,
    ):
        """
        Initialize the learning system.

        Args:
            learning_window_days: Days to consider for learning
            min_samples_for_adjustment: Minimum samples before adjusting weights
            weight_adjustment_rate: How quickly to adjust weights
            session_factory: Optional async session factory for DB persistence.
                When provided, the async method variants also persist to the
                database. When None, behaviour is unchanged (in-memory only).
        """
        self.learning_window_days = learning_window_days
        self.min_samples = min_samples_for_adjustment
        self.adjustment_rate = weight_adjustment_rate
        self._session_factory = session_factory

        # Storage for patterns and events
        self.corrections: list[CorrectionPattern] = []
        self.events: list[LearningEvent] = []
        self.success_patterns: list[SuccessPattern] = []

        # Aggregated statistics
        self._model_stats: dict[str, dict[str, dict[str, Any]]] = defaultdict(
            lambda: defaultdict(lambda: {"correct": 0, "total": 0, "confidence_sum": 0.0})
        )

        # Computed weights
        self._adjusted_weights: dict[str, dict[str, float]] = {}

        # Identified weaknesses per model
        self._weaknesses: dict[str, list[str]] = defaultdict(list)

    # ------------------------------------------------------------------
    # Sync public API (backward-compatible, in-memory only)
    # ------------------------------------------------------------------

    def record_correction(self, correction: CorrectionPattern) -> None:
        """
        Record a correction made to extraction (in-memory only).

        Args:
            correction: The correction pattern to record
        """
        self._record_correction_in_memory(correction)

        logger.debug(
            "Recorded correction",
            model=correction.source_model,
            field=correction.field_name,
            doc_type=correction.document_type,
        )

    def record_event(self, event: LearningEvent) -> None:
        """
        Record a learning event (in-memory only).

        Args:
            event: The learning event to record
        """
        self._record_event_in_memory(event)

    def get_adjusted_weights(
        self,
        document_type: str,
        field_name: str | None = None,
    ) -> dict[str, float]:
        """
        Get adjusted weights for a document type (in-memory only).

        Args:
            document_type: Type of document
            field_name: Optional specific field

        Returns:
            Dictionary of model weights
        """
        return self._compute_weights(document_type, field_name)

    # ------------------------------------------------------------------
    # Async public API (in-memory + DB persistence)
    # ------------------------------------------------------------------

    async def arecord_correction(self, correction: CorrectionPattern) -> None:
        """
        Record a correction — in-memory and (optionally) to the database.

        Args:
            correction: The correction pattern to record
        """
        self._record_correction_in_memory(correction)

        if self._session_factory is not None:
            await self._persist_correction(correction)

        logger.debug(
            "Recorded correction (persisted)",
            model=correction.source_model,
            field=correction.field_name,
            doc_type=correction.document_type,
        )

    async def arecord_event(self, event: LearningEvent) -> None:
        """
        Record a learning event — in-memory and (optionally) to the database.

        Args:
            event: The learning event to record
        """
        self._record_event_in_memory(event)

        if self._session_factory is not None:
            await self._persist_event(event)

            # Persist weight history if threshold is met
            stats = self._model_stats[event.model_name][event.document_type]
            if stats["total"] >= self.min_samples:
                await self._persist_weight_update(event.model_name, event.document_type)

    async def aget_adjusted_weights(
        self,
        document_type: str,
        field_name: str | None = None,
    ) -> dict[str, float]:
        """
        Get adjusted weights — queries DB when in-memory data is empty.

        Args:
            document_type: Type of document
            field_name: Optional specific field

        Returns:
            Dictionary of model weights
        """
        # If in-memory stats are empty, try loading from DB
        has_in_memory_stats = any(
            document_type in doc_types for doc_types in self._model_stats.values()
        )
        if not has_in_memory_stats and self._session_factory is not None:
            await self._load_stats_from_db(document_type)

        return self._compute_weights(document_type, field_name)

    async def load_from_db(self) -> None:
        """
        Load all persisted corrections and events from the database
        into the in-memory lists.

        Call this after creating a new ``CouncilLearningSystem`` instance
        to restore state from a previous run.
        """
        if self._session_factory is None:
            return

        cutoff = datetime.utcnow() - timedelta(days=self.learning_window_days)

        async with self._session_factory() as session:
            # Load corrections
            stmt = (
                select(LearningCorrectionModel)
                .where(LearningCorrectionModel.is_deleted == False)  # noqa: E712
                .where(LearningCorrectionModel.created_at >= cutoff)
                .order_by(LearningCorrectionModel.created_at)
            )
            result = await session.execute(stmt)
            for row in result.scalars().all():
                self.corrections.append(
                    CorrectionPattern(
                        document_type=row.document_type,
                        field_name=row.field_name,
                        original_value=row.original_value,
                        corrected_value=row.corrected_value,
                        source_model=row.source_model,
                        correction_source=row.correction_source,
                        timestamp=row.created_at,
                        confidence=row.confidence,
                    )
                )

            # Load events
            stmt = (
                select(LearningEventModel)
                .where(LearningEventModel.is_deleted == False)  # noqa: E712
                .where(LearningEventModel.created_at >= cutoff)
                .order_by(LearningEventModel.created_at)
            )
            result = await session.execute(stmt)
            for row in result.scalars().all():
                event = LearningEvent(
                    model_name=row.model_name,
                    document_type=row.document_type,
                    field_name=row.field_name,
                    was_correct=row.was_correct,
                    confidence=row.confidence,
                    timestamp=row.created_at,
                )
                self.events.append(event)

                # Rebuild in-memory stats
                stats = self._model_stats[event.model_name][event.document_type]
                stats["total"] += 1
                stats["confidence_sum"] += event.confidence
                if event.was_correct:
                    stats["correct"] += 1

        logger.info(
            "Loaded learning data from database",
            corrections=len(self.corrections),
            events=len(self.events),
        )

    # ------------------------------------------------------------------
    # Remaining sync public API (unchanged)
    # ------------------------------------------------------------------

    def store_successful_pattern(self, pattern: dict[str, Any]) -> None:
        """
        Store a successful extraction pattern.

        Args:
            pattern: Pattern dictionary with document info
        """
        success = SuccessPattern(
            document_type=pattern.get("document_type", "unknown"),
            layout=pattern.get("layout", "unknown"),
            winning_model=pattern.get("winning_model", "unknown"),
            consensus_score=pattern.get("consensus_score", 0.0),
            features=pattern,
        )
        self.success_patterns.append(success)

        logger.debug(
            "Stored successful pattern",
            doc_type=success.document_type,
            layout=success.layout,
            model=success.winning_model,
        )

    def get_patterns_for_model(self, model_name: str) -> list[CorrectionPattern]:
        """
        Get correction patterns for a specific model.

        Args:
            model_name: Name of the model

        Returns:
            List of correction patterns
        """
        cutoff = datetime.utcnow() - timedelta(days=self.learning_window_days)
        return [
            c for c in self.corrections if c.source_model == model_name and c.timestamp >= cutoff
        ]

    def identify_weaknesses(self, model_name: str) -> list[str]:
        """
        Identify weaknesses for a model based on corrections.

        Args:
            model_name: Name of the model

        Returns:
            List of field names that are weaknesses
        """
        # Count corrections by field
        field_corrections: dict[str, int] = defaultdict(int)
        cutoff = datetime.utcnow() - timedelta(days=self.learning_window_days)

        for correction in self.corrections:
            if (
                correction.source_model == model_name
                and correction.timestamp >= cutoff
                and correction.original_value != correction.corrected_value
            ):
                field_corrections[correction.field_name] += 1

        # Fields with 3+ corrections are weaknesses
        weaknesses = [field for field, count in field_corrections.items() if count >= 3]

        # Also include tracked weaknesses
        weaknesses.extend(self._weaknesses.get(model_name, []))

        return list(set(weaknesses))

    def get_model_performance(
        self,
        model_name: str,
        document_type: str,
    ) -> ModelPerformance:
        """
        Get performance metrics for a model on a document type.

        Args:
            model_name: Name of the model
            document_type: Type of document

        Returns:
            ModelPerformance with metrics
        """
        stats = self._model_stats[model_name].get(document_type, {})

        total = stats.get("total", 0)
        correct = stats.get("correct", 0)
        confidence_sum = stats.get("confidence_sum", 0.0)

        accuracy = correct / total if total > 0 else 0.0
        avg_confidence = confidence_sum / total if total > 0 else 0.0

        # Get weaknesses for this document type
        weaknesses = self._weaknesses.get(model_name, [])

        return ModelPerformance(
            model_name=model_name,
            document_type=document_type,
            accuracy=accuracy,
            avg_confidence=avg_confidence,
            total_extractions=total,
            correct_extractions=correct,
            weaknesses=weaknesses,
        )

    def get_similar_patterns(
        self,
        document_type: str,
        layout: str,
    ) -> list[SuccessPattern]:
        """
        Get similar successful patterns.

        Args:
            document_type: Type of document
            layout: Layout type

        Returns:
            List of matching success patterns
        """
        cutoff = datetime.utcnow() - timedelta(days=self.learning_window_days)
        return [
            p
            for p in self.success_patterns
            if (p.document_type == document_type and p.layout == layout and p.timestamp >= cutoff)
        ]

    def get_best_model_for_type(self, document_type: str) -> str:
        """
        Get the best performing model for a document type.

        Args:
            document_type: Type of document

        Returns:
            Name of the best model
        """
        best_model = "paddle_ocr"
        best_accuracy = 0.0

        for model_name in ["paddle_ocr", "olmocr", "qwen", "colpali"]:
            perf = self.get_model_performance(model_name, document_type)
            if perf.accuracy > best_accuracy:
                best_accuracy = perf.accuracy
                best_model = model_name

        return best_model

    def export_statistics(self) -> dict[str, Any]:
        """Export learning statistics for analysis."""
        return {
            "total_corrections": len(self.corrections),
            "total_events": len(self.events),
            "success_patterns": len(self.success_patterns),
            "model_stats": dict(self._model_stats),
            "weaknesses": dict(self._weaknesses),
            "adjusted_weights": self._adjusted_weights,
        }

    def clear_old_data(self, days: int | None = None) -> int:
        """
        Clear data older than specified days.

        Args:
            days: Days to keep (default: learning_window_days)

        Returns:
            Number of records cleared
        """
        days = days or self.learning_window_days
        cutoff = datetime.utcnow() - timedelta(days=days)
        cleared = 0

        # Clear corrections
        old_count = len(self.corrections)
        self.corrections = [c for c in self.corrections if c.timestamp >= cutoff]
        cleared += old_count - len(self.corrections)

        # Clear events
        old_count = len(self.events)
        self.events = [e for e in self.events if e.timestamp >= cutoff]
        cleared += old_count - len(self.events)

        # Clear patterns
        old_count = len(self.success_patterns)
        self.success_patterns = [p for p in self.success_patterns if p.timestamp >= cutoff]
        cleared += old_count - len(self.success_patterns)

        logger.info("Cleared old learning data", records_cleared=cleared)
        return cleared

    # ------------------------------------------------------------------
    # Private in-memory helpers
    # ------------------------------------------------------------------

    def _record_correction_in_memory(self, correction: CorrectionPattern) -> None:
        """Record a correction in-memory and update weakness tracking."""
        self.corrections.append(correction)

        if correction.original_value != correction.corrected_value:
            self._track_weakness(
                correction.source_model,
                correction.document_type,
                correction.field_name,
            )

    def _record_event_in_memory(self, event: LearningEvent) -> None:
        """Record a learning event in-memory and update stats."""
        self.events.append(event)

        stats = self._model_stats[event.model_name][event.document_type]
        stats["total"] += 1
        stats["confidence_sum"] += event.confidence

        if event.was_correct:
            stats["correct"] += 1
        else:
            self._track_weakness(
                event.model_name,
                event.document_type,
                event.field_name,
            )

        # Recalculate weights if we have enough samples
        if stats["total"] >= self.min_samples:
            self._update_weights(event.model_name, event.document_type)

    def _compute_weights(
        self,
        document_type: str,
        field_name: str | None = None,
    ) -> dict[str, float]:
        """Compute adjusted weights from in-memory stats."""
        weights = {
            "paddle_ocr": 1.0,
            "olmocr": 1.0,
            "qwen": 1.0,
            "colpali": 1.0,
        }

        for model_name in weights:
            stats = self._model_stats[model_name].get(document_type)
            if stats and stats["total"] >= self.min_samples:
                accuracy = stats["correct"] / stats["total"]
                weights[model_name] *= 0.5 + accuracy

        if field_name:
            for model_name in weights:
                if field_name in self._weaknesses.get(model_name, []):
                    weights[model_name] *= 0.8

        total = sum(weights.values())
        if total > 0:
            weights = {k: v / total for k, v in weights.items()}

        return weights

    def _track_weakness(
        self,
        model_name: str,
        document_type: str,
        field_name: str,
    ) -> None:
        """Track a weakness for a model."""
        key = f"{document_type}:{field_name}"
        if key not in self._weaknesses[model_name]:
            self._weaknesses[model_name].append(key)
            logger.debug(
                "Tracked weakness",
                model=model_name,
                doc_type=document_type,
                field=field_name,
            )

    def _update_weights(
        self,
        model_name: str,
        document_type: str,
    ) -> None:
        """Update weights based on accumulated statistics."""
        stats = self._model_stats[model_name][document_type]

        if stats["total"] < self.min_samples:
            return

        accuracy = stats["correct"] / stats["total"]
        avg_confidence = stats["confidence_sum"] / stats["total"]

        new_weight = accuracy * (0.5 + avg_confidence * 0.5)

        key = f"{document_type}:{model_name}"
        if key in self._adjusted_weights:
            current = self._adjusted_weights.get(key, 1.0)
            self._adjusted_weights[key] = (
                current * (1 - self.adjustment_rate) + new_weight * self.adjustment_rate
            )
        else:
            self._adjusted_weights[key] = new_weight

    # ------------------------------------------------------------------
    # Private async persistence helpers
    # ------------------------------------------------------------------

    async def _persist_correction(self, correction: CorrectionPattern) -> None:
        """Persist a single correction to the database."""
        async with self._session_factory() as session:  # type: ignore[union-attr]
            row = LearningCorrectionModel(
                document_type=correction.document_type,
                field_name=correction.field_name,
                original_value=correction.original_value,
                corrected_value=correction.corrected_value,
                source_model=correction.source_model,
                correction_source=correction.correction_source,
                confidence=correction.confidence,
            )
            session.add(row)
            await session.commit()

    async def _persist_event(self, event: LearningEvent) -> None:
        """Persist a single learning event to the database."""
        async with self._session_factory() as session:  # type: ignore[union-attr]
            row = LearningEventModel(
                model_name=event.model_name,
                document_type=event.document_type,
                field_name=event.field_name,
                was_correct=event.was_correct,
                confidence=event.confidence,
            )
            session.add(row)
            await session.commit()

    async def _persist_weight_update(
        self,
        model_name: str,
        document_type: str,
    ) -> None:
        """Persist the current weight for a model/document_type pair."""
        stats = self._model_stats[model_name][document_type]
        if stats["total"] < self.min_samples:
            return

        accuracy = stats["correct"] / stats["total"]
        key = f"{document_type}:{model_name}"
        weight = self._adjusted_weights.get(key, 0.0)

        async with self._session_factory() as session:  # type: ignore[union-attr]
            row = WeightHistoryModel(
                model_name=model_name,
                document_type=document_type,
                weight=weight,
                accuracy=accuracy,
                sample_count=stats["total"],
            )
            session.add(row)
            await session.commit()

    async def _load_stats_from_db(self, document_type: str) -> None:
        """
        Load aggregated event statistics from the database for a document type.

        Populates ``_model_stats`` so that ``aget_adjusted_weights`` can
        use persisted data when the in-memory cache is empty.
        """
        async with self._session_factory() as session:  # type: ignore[union-attr]
            # Use a CASE expression to safely cast boolean to integer
            # for cross-database compatibility (PostgreSQL and SQLite).
            correct_expr = func.sum(
                case(
                    (LearningEventModel.was_correct == True, 1),  # noqa: E712
                    else_=0,
                ).cast(SAInteger)
            ).label("correct")

            stmt = (
                select(
                    LearningEventModel.model_name,
                    func.count().label("total"),
                    correct_expr,
                    func.sum(LearningEventModel.confidence).label("confidence_sum"),
                )
                .where(LearningEventModel.document_type == document_type)
                .where(LearningEventModel.is_deleted == False)  # noqa: E712
                .group_by(LearningEventModel.model_name)
            )
            result = await session.execute(stmt)
            rows = result.all()

            for row in rows:
                model_name = row.model_name
                self._model_stats[model_name][document_type] = {
                    "correct": int(row.correct or 0),
                    "total": int(row.total or 0),
                    "confidence_sum": float(row.confidence_sum or 0.0),
                }


# Singleton instance
_learning_system: CouncilLearningSystem | None = None


def get_learning_system() -> CouncilLearningSystem:
    """Get or create the learning system singleton."""
    global _learning_system
    if _learning_system is None:
        _learning_system = CouncilLearningSystem()
    return _learning_system
