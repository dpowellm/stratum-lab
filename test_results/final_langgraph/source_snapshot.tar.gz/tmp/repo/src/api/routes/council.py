"""Council session and deliberation endpoints."""

from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Path,
    Query,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy import Integer, case, func, literal, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.logging import get_logger
from src.models.database.base import get_session
from src.models.database.council_session import (
    ConflictLevel as DBConflictLevel,
    CouncilSession as DBCouncilSession,
    MemberVote as DBMemberVote,
    VotingStrategy as DBVotingStrategy,
)
from src.models.schemas.council import (
    ConflictLevel,
    CouncilSession,
    CouncilStatistics,
    FieldConsensus,
    VotingStrategy,
)

logger = get_logger(__name__)

router = APIRouter(prefix="/council", tags=["Council"])

# ---------------------------------------------------------------------------
# Legacy member name migration: deepseek_ocr → olmocr
# ---------------------------------------------------------------------------

_MEMBER_NAME_ALIASES: dict[str, str] = {"deepseek_ocr": "olmocr"}


def _normalize_member_name(name: str) -> str:
    """Map legacy member names to their current equivalents."""
    return _MEMBER_NAME_ALIASES.get(name, name)


# ---------------------------------------------------------------------------
# Mapping helpers between DB enums and schema enums
# ---------------------------------------------------------------------------

_DB_VOTING_STRATEGY_TO_SCHEMA: dict[DBVotingStrategy, VotingStrategy] = {
    DBVotingStrategy.CONFIDENCE_WEIGHTED: VotingStrategy.CONFIDENCE_WEIGHTED,
    DBVotingStrategy.UNANIMOUS: VotingStrategy.UNANIMOUS,
    DBVotingStrategy.EXPERTISE_DELEGATION: VotingStrategy.EXPERTISE_DELEGATION,
    DBVotingStrategy.CASCADING: VotingStrategy.CASCADING,
}

_DB_CONFLICT_LEVEL_TO_SCHEMA: dict[DBConflictLevel, ConflictLevel] = {
    DBConflictLevel.NONE: ConflictLevel.NONE,
    DBConflictLevel.MINOR: ConflictLevel.MINOR,
    DBConflictLevel.MODERATE: ConflictLevel.MODERATE,
    DBConflictLevel.MAJOR: ConflictLevel.MAJOR,
}

_SCHEMA_CONFLICT_LEVEL_TO_DB: dict[ConflictLevel, DBConflictLevel] = {
    v: k for k, v in _DB_CONFLICT_LEVEL_TO_SCHEMA.items()
}


def _period_to_timedelta(period: str) -> timedelta | None:
    """Convert a period string (7d, 30d, 90d, all) to a timedelta."""
    mapping = {
        "7d": timedelta(days=7),
        "30d": timedelta(days=30),
        "90d": timedelta(days=90),
    }
    return mapping.get(period)


def _build_field_consensuses(
    db_session: DBCouncilSession,
) -> list[FieldConsensus]:
    """Build per-field consensus data from member votes and unified extraction."""
    unified = db_session.unified_extraction or {}
    votes = db_session.member_votes or []

    if not unified or not votes:
        return []

    from src.models.schemas.council import MemberExpertise, MemberVote as MemberVoteSchema

    consensuses: list[FieldConsensus] = []

    for field_name, final_value in unified.items():
        member_votes: list[MemberVoteSchema] = []
        values_seen: list[str] = []

        best_confidence = 0.0
        best_member = ""

        for vote in votes:
            extracted = vote.extracted_fields or {}
            field_confs = vote.field_confidences or {}

            if field_name not in extracted:
                continue

            field_data = extracted[field_name]
            # extracted_fields stores {field: {value, confidence}} or {field: value}
            if isinstance(field_data, dict):
                value = field_data.get("value", field_data)
                conf = field_data.get("confidence", field_confs.get(field_name, 0.0))
            else:
                value = field_data
                conf = field_confs.get(field_name, vote.overall_confidence)

            conf = float(conf)
            member_votes.append(
                MemberVoteSchema(
                    member_id=str(vote.id),
                    member_name=_normalize_member_name(vote.member_name),
                    expertise=MemberExpertise.GENERAL,
                    value=value,
                    confidence=min(max(conf, 0.0), 1.0),
                    processing_time_ms=vote.processing_time_ms,
                )
            )
            values_seen.append(str(value))

            if conf > best_confidence:
                best_confidence = conf
                best_member = _normalize_member_name(vote.member_name)

        # Determine agreement
        unique_values = set(values_seen)
        agreement_count = max(values_seen.count(v) for v in unique_values) if values_seen else 0

        if len(unique_values) <= 1:
            conflict = ConflictLevel.NONE
        elif agreement_count >= 2:
            conflict = ConflictLevel.MINOR
        else:
            conflict = ConflictLevel.MODERATE

        consensuses.append(
            FieldConsensus(
                field_name=field_name,
                final_value=final_value,
                confidence=min(max(best_confidence, 0.0), 1.0),
                source_member=best_member or "unknown",
                all_votes=member_votes,
                conflict_level=conflict,
                agreement_count=agreement_count,
            )
        )

    return consensuses


def _db_session_to_schema(db_session: DBCouncilSession) -> CouncilSession:
    """Convert a DB CouncilSession record to the API schema."""
    return CouncilSession(
        session_id=str(db_session.id),
        document_id=str(db_session.document_id),
        session_started_at=db_session.created_at,
        session_ended_at=db_session.updated_at,
        participating_members=[
            _normalize_member_name(m) for m in (db_session.participating_members or [])
        ],
        voting_strategy=_DB_VOTING_STRATEGY_TO_SCHEMA.get(
            db_session.voting_strategy,
            VotingStrategy.CONFIDENCE_WEIGHTED,
        ),
        total_fields=db_session.total_fields,
        fields_with_consensus=db_session.agreed_fields,
        disputed_fields=db_session.disputed_fields,
        field_consensuses=_build_field_consensuses(db_session),
        overall_confidence=db_session.final_confidence or 0.0,
        consensus_score=db_session.consensus_score or 0.0,
        conflict_level=_DB_CONFLICT_LEVEL_TO_SCHEMA.get(
            db_session.conflict_level,
            ConflictLevel.NONE,
        ),
        requires_judge=db_session.judge_invoked,
        requires_human_review=db_session.human_review_required,
        processing_time_ms=db_session.total_processing_time_ms or 0.0,
        judge_invoked=db_session.judge_invoked,
        judge_model=db_session.judge_model,
        judge_reasoning=db_session.judge_reasoning,
        judge_confidence=db_session.judge_confidence,
        resolution_method=(
            db_session.resolution_method.value if db_session.resolution_method else None
        ),
        conflict_details=db_session.conflict_details or [],
        unified_extraction=db_session.unified_extraction or {},
    )


# ---------------------------------------------------------------------------
# Pydantic models used only at the route layer
# ---------------------------------------------------------------------------


class SessionFilter(BaseModel):
    """Filters for council session queries."""

    status: str | None = Field(
        default=None,
        description="Filter by session status",
    )
    min_consensus_score: float | None = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Minimum consensus score",
    )
    max_consensus_score: float | None = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Maximum consensus score",
    )
    conflict_level: ConflictLevel | None = Field(
        default=None,
        description="Filter by conflict level",
    )


class CouncilSessionListResponse(BaseModel):
    """Response for listing council sessions."""

    sessions: list[CouncilSession] = Field(default_factory=list, description="List of sessions")
    total_count: int = Field(..., ge=0, description="Total sessions")
    page: int = Field(..., ge=1, description="Current page")
    page_size: int = Field(..., ge=1, description="Items per page")
    filters_applied: dict[str, Any] = Field(default_factory=dict, description="Applied filters")

    model_config = {
        "json_schema_extra": {
            "example": {
                "sessions": [],
                "total_count": 100,
                "page": 1,
                "page_size": 20,
                "filters_applied": {},
            }
        }
    }


class StatisticsDetail(BaseModel):
    """Detailed statistics entry."""

    metric: str = Field(..., description="Metric name")
    value: Any = Field(..., description="Metric value")
    unit: str | None = Field(default=None, description="Unit of measurement")
    timestamp: datetime = Field(..., description="When measured")


class DetailedCouncilStatistics(BaseModel):
    """Detailed council performance statistics."""

    statistics: CouncilStatistics = Field(..., description="Base statistics")
    period_start: datetime = Field(..., description="Period start time")
    period_end: datetime = Field(..., description="Period end time")
    additional_metrics: list[StatisticsDetail] = Field(
        default_factory=list, description="Additional metrics"
    )
    trending: dict[str, Any] = Field(default_factory=dict, description="Trend analysis")

    model_config = {
        "json_schema_extra": {
            "example": {
                "statistics": {
                    "total_sessions": 100,
                    "average_consensus_score": 0.88,
                    "average_confidence": 0.86,
                    "member_agreement_matrix": {},
                    "most_disputed_fields": ["field_1"],
                    "judge_interventions": 5,
                    "average_session_time_ms": 5000.0,
                },
                "period_start": "2025-01-01T00:00:00Z",
                "period_end": "2025-01-29T16:30:00Z",
                "additional_metrics": [],
                "trending": {},
            }
        }
    }


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/sessions/{session_id}",
    response_model=CouncilSession,
    status_code=status.HTTP_200_OK,
    summary="Get council session",
    description="Retrieve a specific council deliberation session.",
    responses={
        200: {"description": "Session found"},
        404: {"description": "Session not found"},
        503: {"description": "Service unavailable"},
    },
)
async def get_council_session(
    session_id: str = Path(..., description="Session ID"),
    _include_votes: bool = Query(
        default=True,
        description="Include member votes",
    ),
    _include_deliberation: bool = Query(
        default=True,
        description="Include deliberation details",
    ),
    db: AsyncSession = Depends(get_session),
) -> CouncilSession:
    """
    Get a specific council session.

    Retrieves detailed information about a council deliberation session
    including member votes and consensus results.

    Args:
        session_id: ID of the council session
        _include_votes: Include member votes in response (reserved for future use)
        _include_deliberation: Include deliberation details (reserved for future use)
        db: Async database session (injected)

    Returns:
        CouncilSession with full details

    Raises:
        HTTPException: If session not found
    """
    try:
        logger.info(
            "Retrieving council session",
            session_id=session_id,
        )

        try:
            session_uuid = UUID(session_id)
        except ValueError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Council session not found: {session_id}",
            ) from e

        stmt = select(DBCouncilSession).where(
            DBCouncilSession.id == session_uuid,
            DBCouncilSession.is_deleted.is_(False),
        )
        result = await db.execute(stmt)
        db_session = result.scalar_one_or_none()

        if db_session is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Council session not found: {session_id}",
            )

        return _db_session_to_schema(db_session)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Error retrieving council session",
            session_id=session_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to retrieve council session",
        ) from e


@router.get(
    "/sessions",
    response_model=CouncilSessionListResponse,
    status_code=status.HTTP_200_OK,
    summary="List council sessions",
    description="List council deliberation sessions with filtering.",
    responses={
        200: {"description": "Sessions retrieved"},
        400: {"description": "Invalid filter parameters"},
        503: {"description": "Service unavailable"},
    },
)
async def list_council_sessions(
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=100, description="Items per page"),
    session_status: str | None = Query(
        None, alias="status", description="Filter by session status"
    ),
    min_consensus: float | None = Query(
        None,
        ge=0.0,
        le=1.0,
        description="Minimum consensus score",
    ),
    max_consensus: float | None = Query(
        None,
        ge=0.0,
        le=1.0,
        description="Maximum consensus score",
    ),
    conflict_level: ConflictLevel | None = Query(None, description="Filter by conflict level"),
    db: AsyncSession = Depends(get_session),
) -> CouncilSessionListResponse:
    """
    List council sessions with filtering and pagination.

    Args:
        page: Page number
        page_size: Items per page
        session_status: Filter by session status
        min_consensus: Minimum consensus score filter
        max_consensus: Maximum consensus score filter
        conflict_level: Filter by conflict level
        db: Async database session (injected)

    Returns:
        CouncilSessionListResponse with paginated sessions

    Raises:
        HTTPException: If query parameters are invalid
    """
    try:
        if (
            min_consensus is not None
            and max_consensus is not None
            and min_consensus > max_consensus
        ):
            raise ValueError("min_consensus cannot be greater than max_consensus")

        logger.info(
            "Listing council sessions",
            page=page,
            page_size=page_size,
        )

        # -- Build base filter condition --
        base_filter = DBCouncilSession.is_deleted.is_(False)

        # -- Apply optional filters --
        filters = [base_filter]

        if min_consensus is not None:
            filters.append(DBCouncilSession.consensus_score >= min_consensus)
        if max_consensus is not None:
            filters.append(DBCouncilSession.consensus_score <= max_consensus)
        if conflict_level is not None:
            db_conflict = _SCHEMA_CONFLICT_LEVEL_TO_DB.get(conflict_level)
            if db_conflict is not None:
                filters.append(DBCouncilSession.conflict_level == db_conflict)

        # -- Count total matching rows --
        count_stmt = select(func.count(DBCouncilSession.id)).where(*filters)
        total_count_result = await db.execute(count_stmt)
        total_count: int = total_count_result.scalar_one()

        # -- Fetch the page --
        offset = (page - 1) * page_size
        data_stmt = (
            select(DBCouncilSession)
            .where(*filters)
            .order_by(DBCouncilSession.created_at.desc())
            .offset(offset)
            .limit(page_size)
        )
        data_result = await db.execute(data_stmt)
        db_sessions = data_result.scalars().all()

        sessions = [_db_session_to_schema(s) for s in db_sessions]

        return CouncilSessionListResponse(
            sessions=sessions,
            total_count=total_count,
            page=page,
            page_size=page_size,
            filters_applied={
                k: v
                for k, v in {
                    "status": session_status,
                    "min_consensus": min_consensus,
                    "max_consensus": max_consensus,
                    "conflict_level": (conflict_level.value if conflict_level else None),
                }.items()
                if v is not None
            },
        )

    except ValueError as e:
        logger.warning(
            "Invalid filter parameters",
            error=str(e),
        )
        raise HTTPException(
            status_code=400,
            detail=f"Invalid filter parameters: {e!s}",
        ) from e
    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Error listing council sessions",
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to list council sessions",
        ) from e


@router.get(
    "/stats",
    response_model=DetailedCouncilStatistics,
    status_code=status.HTTP_200_OK,
    summary="Get council statistics",
    description="Retrieve council performance statistics and metrics.",
    responses={
        200: {"description": "Statistics retrieved"},
        503: {"description": "Service unavailable"},
    },
)
async def get_council_stats(
    period: str | None = Query(
        "30d",
        description="Time period (7d, 30d, 90d, all)",
    ),
    db: AsyncSession = Depends(get_session),
) -> DetailedCouncilStatistics:
    """
    Get council performance statistics.

    Retrieves aggregate statistics about council deliberation performance,
    consensus rates, member agreement, and conflict resolution metrics.

    Args:
        period: Time period for statistics
        db: Async database session (injected)

    Returns:
        DetailedCouncilStatistics with performance metrics

    Raises:
        HTTPException: If period is invalid or service unavailable
    """
    try:
        valid_periods = ["7d", "30d", "90d", "all"]
        if period not in valid_periods:
            raise ValueError(f"Invalid period. Must be one of: {', '.join(valid_periods)}")

        logger.info(
            "Retrieving council statistics",
            period=period,
        )

        now = datetime.now(tz=UTC)
        delta = _period_to_timedelta(period)  # type: ignore[arg-type]
        period_start = now - delta if delta is not None else datetime(2000, 1, 1, tzinfo=UTC)

        # -- Build base filter --
        filters = [DBCouncilSession.is_deleted.is_(False)]
        if delta is not None:
            filters.append(DBCouncilSession.created_at >= period_start)

        # -- Aggregate query --
        agg_stmt = select(
            func.count(DBCouncilSession.id).label("total_sessions"),
            func.coalesce(func.avg(DBCouncilSession.consensus_score), 0.0).label("avg_consensus"),
            func.coalesce(func.avg(DBCouncilSession.final_confidence), 0.0).label("avg_confidence"),
            func.coalesce(func.avg(DBCouncilSession.total_processing_time_ms), 0.0).label(
                "avg_time_ms"
            ),
            func.coalesce(
                func.sum(func.cast(DBCouncilSession.judge_invoked, Integer)),
                0,
            ).label("judge_interventions"),
        ).where(*filters)

        agg_result = await db.execute(agg_stmt)
        row = agg_result.one()

        total_sessions: int = row.total_sessions  # type: ignore[attr-defined]
        avg_consensus: float = float(row.avg_consensus)  # type: ignore[attr-defined]
        avg_confidence: float = float(row.avg_confidence)  # type: ignore[attr-defined]
        avg_time_ms: float = float(row.avg_time_ms)  # type: ignore[attr-defined]
        judge_interventions: int = int(row.judge_interventions)  # type: ignore[attr-defined]

        return DetailedCouncilStatistics(
            statistics=CouncilStatistics(
                total_sessions=total_sessions,
                average_consensus_score=avg_consensus,
                average_confidence=avg_confidence,
                average_session_time_ms=avg_time_ms,
                judge_interventions=judge_interventions,
            ),
            period_start=period_start,
            period_end=now,
            additional_metrics=[],
            trending={},
        )

    except ValueError as e:
        logger.warning(
            "Invalid statistics request",
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid period: {e!s}",
        ) from e
    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Error retrieving council statistics",
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to retrieve statistics",
        ) from e


# ---------------------------------------------------------------------------
# Member performance endpoint
# ---------------------------------------------------------------------------


class MemberPerformanceEntry(BaseModel):
    """Performance metrics for a single council member."""

    member_name: str = Field(..., description="Council member name")
    avg_confidence: float = Field(..., description="Average confidence score")
    avg_processing_time_ms: float = Field(..., description="Average processing time (ms)")
    total_votes: int = Field(..., description="Total number of votes cast")
    accuracy: float = Field(0.0, description="Fraction of votes matching final consensus value")


@router.get(
    "/members/performance",
    response_model=list[MemberPerformanceEntry],
    status_code=status.HTTP_200_OK,
    summary="Get member performance",
    description="Aggregate performance metrics per council member.",
    responses={
        200: {"description": "Member performance data"},
        503: {"description": "Service unavailable"},
    },
)
async def get_member_performance(
    period: str = Query(
        "30d",
        description="Time period (7d, 30d, 90d, all)",
    ),
    db: AsyncSession = Depends(get_session),
) -> list[MemberPerformanceEntry]:
    """Get per-member performance metrics."""
    try:
        valid_periods = ["7d", "30d", "90d", "all"]
        if period not in valid_periods:
            raise ValueError(f"Invalid period. Must be one of: {', '.join(valid_periods)}")

        delta = _period_to_timedelta(period)
        now = datetime.now(tz=UTC)

        filters = [DBCouncilSession.is_deleted.is_(False)]
        if delta is not None:
            filters.append(DBCouncilSession.created_at >= now - delta)

        normalized_name = case(
            (DBMemberVote.member_name == "deepseek_ocr", literal("olmocr")),
            else_=DBMemberVote.member_name,
        ).label("member_name")
        stmt = (
            select(
                normalized_name,
                func.avg(DBMemberVote.overall_confidence).label("avg_confidence"),
                func.avg(DBMemberVote.processing_time_ms).label("avg_processing_time_ms"),
                func.count(DBMemberVote.id).label("total_votes"),
            )
            .join(DBCouncilSession, DBMemberVote.council_session_id == DBCouncilSession.id)
            .where(*filters)
            .group_by(normalized_name)
            .order_by(func.count(DBMemberVote.id).desc())
        )

        result = await db.execute(stmt)
        rows = result.all()

        return [
            MemberPerformanceEntry(
                member_name=row.member_name,
                avg_confidence=round(float(row.avg_confidence), 4),
                avg_processing_time_ms=round(float(row.avg_processing_time_ms), 2),
                total_votes=int(row.total_votes),
                accuracy=0.0,  # accuracy requires comparing per-field to unified — left as 0
            )
            for row in rows
        ]

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error fetching member performance", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to retrieve member performance",
        ) from e


# ---------------------------------------------------------------------------
# Field difficulty endpoint
# ---------------------------------------------------------------------------


def _aggregate_field_difficulty(rows: list) -> dict[str, dict[str, Any]]:
    """Aggregate per-field difficulty stats from conflict_details rows."""
    field_stats: dict[str, dict[str, Any]] = {}
    for row in rows:
        details = row.conflict_details
        confidence = row.final_confidence or 0.0
        if not isinstance(details, list):
            continue
        for entry in details:
            if not isinstance(entry, dict):
                continue
            fname = entry.get("field_name", entry.get("field", ""))
            if not fname:
                continue
            if fname not in field_stats:
                field_stats[fname] = {"total": 0, "conflicts": 0, "confidence_sum": 0.0}
            field_stats[fname]["total"] += 1
            field_stats[fname]["confidence_sum"] += confidence
            votes = entry.get("votes", [])
            unique_values = {str(v.get("value", "")) for v in votes if isinstance(v, dict)}
            if len(unique_values) > 1:
                field_stats[fname]["conflicts"] += 1
    return field_stats


class FieldDifficultyEntry(BaseModel):
    """Difficulty metrics for a single extracted field."""

    field_name: str = Field(..., description="Field name")
    total_sessions: int = Field(..., description="Sessions where field appeared")
    conflict_count: int = Field(..., description="Sessions where field had conflict")
    conflict_rate: float = Field(..., description="Fraction of sessions with conflict")
    avg_confidence: float = Field(..., description="Average confidence across sessions")


@router.get(
    "/fields/difficulty",
    response_model=list[FieldDifficultyEntry],
    status_code=status.HTTP_200_OK,
    summary="Get field difficulty",
    description="Aggregate difficulty metrics per extracted field.",
    responses={
        200: {"description": "Field difficulty data"},
        503: {"description": "Service unavailable"},
    },
)
async def get_field_difficulty(
    period: str = Query(
        "30d",
        description="Time period (7d, 30d, 90d, all)",
    ),
    db: AsyncSession = Depends(get_session),
) -> list[FieldDifficultyEntry]:
    """Get per-field difficulty metrics from conflict_details JSON."""
    try:
        valid_periods = ["7d", "30d", "90d", "all"]
        if period not in valid_periods:
            raise ValueError(f"Invalid period. Must be one of: {', '.join(valid_periods)}")

        delta = _period_to_timedelta(period)
        now = datetime.now(tz=UTC)

        filters = [
            DBCouncilSession.is_deleted.is_(False),
            DBCouncilSession.conflict_details.isnot(None),
        ]
        if delta is not None:
            filters.append(DBCouncilSession.created_at >= now - delta)

        stmt = select(DBCouncilSession.conflict_details, DBCouncilSession.final_confidence).where(
            *filters
        )

        result = await db.execute(stmt)
        rows = result.all()

        field_stats = _aggregate_field_difficulty(rows)

        entries = [
            FieldDifficultyEntry(
                field_name=fname,
                total_sessions=s["total"],
                conflict_count=s["conflicts"],
                conflict_rate=round(s["conflicts"] / s["total"], 4) if s["total"] > 0 else 0.0,
                avg_confidence=(
                    round(s["confidence_sum"] / s["total"], 4) if s["total"] > 0 else 0.0
                ),
            )
            for fname, s in field_stats.items()
        ]

        entries.sort(key=lambda e: e.conflict_rate, reverse=True)
        return entries

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error fetching field difficulty", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to retrieve field difficulty",
        ) from e


# ---------------------------------------------------------------------------
# Judge configuration endpoints
# ---------------------------------------------------------------------------


class JudgeConfigResponse(BaseModel):
    """Judge configuration response."""

    provider: str
    model: str
    has_api_key: bool
    enabled: bool
    always_use_judge: bool


class JudgeConfigUpdateRequest(BaseModel):
    """Judge configuration update request."""

    provider: str | None = None
    model: str | None = None
    api_key: str | None = None
    enabled: bool | None = None
    always_use_judge: bool | None = None


class ValidateKeyRequest(BaseModel):
    """API key validation request."""

    provider: str
    api_key: str


class ValidateKeyResponse(BaseModel):
    """API key validation response."""

    valid: bool
    error: str | None = None


@router.get(
    "/judge/config",
    response_model=JudgeConfigResponse,
    summary="Get judge configuration",
)
async def get_judge_config() -> JudgeConfigResponse:
    """Get current judge configuration."""
    from src.services.judge.config import get_judge_config_manager

    mgr = get_judge_config_manager()
    config = mgr.get_config()
    return JudgeConfigResponse(**config.to_dict())


@router.put(
    "/judge/config",
    response_model=JudgeConfigResponse,
    summary="Update judge configuration",
)
async def update_judge_config(
    request: JudgeConfigUpdateRequest,
) -> JudgeConfigResponse:
    """Update judge configuration."""
    from src.services.judge.config import get_judge_config_manager

    mgr = get_judge_config_manager()
    config = mgr.update_config(
        provider=request.provider,
        model=request.model,
        api_key=request.api_key,
        enabled=request.enabled,
        always_use_judge=request.always_use_judge,
    )
    return JudgeConfigResponse(**config.to_dict())


@router.delete(
    "/judge/config/api-key",
    summary="Delete judge API key",
)
async def delete_judge_api_key() -> dict[str, Any]:
    """Clear the stored judge API key."""
    from src.services.judge.config import get_judge_config_manager

    mgr = get_judge_config_manager()
    mgr.clear_api_key()
    return {"success": True, "message": "API key cleared"}


@router.get(
    "/judge/models/{provider}",
    response_model=list[str],
    summary="Get available models for provider",
)
async def get_provider_models(
    provider: str = Path(..., description="Provider name"),
    api_key: str | None = Query(None, description="API key for live model list"),
) -> list[str]:
    """Get available models for a provider."""
    from src.services.judge.config import get_judge_config_manager

    mgr = get_judge_config_manager()
    models = await mgr.fetch_models_from_provider(provider, api_key)
    return models


@router.post(
    "/judge/validate-key",
    response_model=ValidateKeyResponse,
    summary="Validate an API key",
)
async def validate_api_key(request: ValidateKeyRequest) -> ValidateKeyResponse:
    """Validate an API key by making a lightweight API call."""
    try:
        from src.services.judge.config import get_judge_config_manager

        mgr = get_judge_config_manager()
        models = await mgr.fetch_models_from_provider(request.provider, request.api_key)
        if models:
            return ValidateKeyResponse(valid=True)
        return ValidateKeyResponse(valid=False, error="No models returned")
    except Exception as exc:
        return ValidateKeyResponse(valid=False, error=str(exc))
