"""
HITL Review Interface API.

Task 2.3.3: Creates API for human review interface integration.
"""

from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from src.core.logging import get_logger
from src.services.hitl.queue import (
    HITLQueue,
    get_hitl_queue,
)

logger = get_logger(__name__)

router = APIRouter(prefix="/hitl", tags=["HITL Review"])


# Request/Response models
class ReviewItemResponse(BaseModel):
    """Review item response model."""

    id: str
    document_id: str
    confidence: float
    reason: str
    priority: str
    status: str
    extracted_fields: dict[str, Any]
    created_at: str | None = None


class ReviewQueueResponse(BaseModel):
    """Review queue response model."""

    items: list[ReviewItemResponse]
    total: int
    pending: int
    assigned: int


class SubmitCorrectionRequest(BaseModel):
    """Request to submit corrections."""

    corrections: dict[str, Any]
    notes: str = ""


class SubmitCorrectionResponse(BaseModel):
    """Response after submitting corrections."""

    success: bool
    message: str = ""


class SkipReviewRequest(BaseModel):
    """Request to skip a review."""

    reason: str = ""


class AssignReviewerRequest(BaseModel):
    """Request to assign a reviewer."""

    reviewer_id: str


class QueueStatisticsResponse(BaseModel):
    """Queue statistics response."""

    total_items: int
    pending: int
    assigned: int
    completed: int
    avg_wait_time: float


# Helper functions (also usable in tests)
def get_review_queue(queue: HITLQueue) -> dict[str, Any]:
    """
    Get the review queue.

    Args:
        queue: HITL queue instance

    Returns:
        Dictionary with queue items
    """
    pending = queue.get_prioritized()
    stats = queue.get_statistics()

    return {
        "items": [item.to_dict() for item in pending],
        "total": stats["total_items"],
        "pending": stats["pending"],
        "assigned": stats["assigned"],
    }


def get_document_for_review(
    queue: HITLQueue,
    item_id: str,
) -> dict[str, Any] | None:
    """
    Get a specific document for review.

    Args:
        queue: HITL queue instance
        item_id: Review item ID

    Returns:
        Document data for review or None
    """
    return queue.get_item_for_api(item_id)


def submit_corrections(
    queue: HITLQueue,
    item_id: str,
    reviewer_id: str,
    corrections: dict[str, Any],
    notes: str = "",
) -> dict[str, Any]:
    """
    Submit corrections for a review item.

    Args:
        queue: HITL queue instance
        item_id: Review item ID
        reviewer_id: Reviewer ID
        corrections: Corrected values
        notes: Reviewer notes

    Returns:
        Result dictionary
    """
    success = queue.submit_review(
        item_id=item_id,
        reviewer_id=reviewer_id,
        corrections=corrections,
        notes=notes,
    )

    return {
        "success": success,
        "message": "Review submitted successfully" if success else "Failed to submit review",
    }


def skip_review(
    queue: HITLQueue,
    item_id: str,
    reviewer_id: str,
    reason: str = "",
) -> dict[str, Any]:
    """
    Skip a review item.

    Args:
        queue: HITL queue instance
        item_id: Review item ID
        reviewer_id: Reviewer ID
        reason: Skip reason

    Returns:
        Result dictionary
    """
    success = queue.skip_item(
        item_id=item_id,
        reviewer_id=reviewer_id,
        reason=reason,
    )

    return {
        "success": success,
        "message": "Review skipped" if success else "Failed to skip review",
    }


# API Endpoints
@router.get("/queue", response_model=ReviewQueueResponse)
async def api_get_review_queue(
    priority: str | None = Query(None, description="Filter by priority"),
    limit: int = Query(50, ge=1, le=100),
) -> ReviewQueueResponse:
    """Get the review queue."""
    queue = get_hitl_queue()
    result = get_review_queue(queue)

    # Filter by priority if specified
    if priority:
        result["items"] = [
            item for item in result["items"] if item.get("priority", "").lower() == priority.lower()
        ]

    # Apply limit
    result["items"] = result["items"][:limit]

    return ReviewQueueResponse(**result)


@router.get("/queue/{item_id}", response_model=ReviewItemResponse)
async def api_get_review_item(item_id: str) -> ReviewItemResponse:
    """Get a specific review item."""
    queue = get_hitl_queue()
    item = get_document_for_review(queue, item_id)

    if not item:
        raise HTTPException(status_code=404, detail="Review item not found")

    return ReviewItemResponse(**item)


@router.post("/queue/{item_id}/assign")
async def api_assign_reviewer(
    item_id: str,
    request: AssignReviewerRequest,
) -> dict[str, Any]:
    """Assign a reviewer to an item."""
    queue = get_hitl_queue()
    assignment = queue.assign_reviewer(item_id, request.reviewer_id)

    if not assignment:
        raise HTTPException(
            status_code=400,
            detail="Could not assign reviewer",
        )

    return {
        "success": True,
        "assignment": {
            "item_id": item_id,
            "reviewer_id": request.reviewer_id,
            "assigned_at": assignment.assigned_at.isoformat(),
        },
    }


@router.post("/queue/{item_id}/submit", response_model=SubmitCorrectionResponse)
async def api_submit_corrections(
    item_id: str,
    request: SubmitCorrectionRequest,
    reviewer_id: str = Query(..., description="Reviewer ID"),
) -> SubmitCorrectionResponse:
    """Submit corrections for a review item."""
    queue = get_hitl_queue()
    result = submit_corrections(
        queue=queue,
        item_id=item_id,
        reviewer_id=reviewer_id,
        corrections=request.corrections,
        notes=request.notes,
    )

    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])

    # Feed corrections to quality evaluator
    try:
        from src.services.evals.quality import get_quality_evaluator

        evaluator = get_quality_evaluator()
        for field_name, corrected_value in request.corrections.items():
            evaluator.record_correction(
                field_name=field_name,
                original_value=None,
                corrected_value=corrected_value,
                model_name="council_consensus",
                document_type="unknown",
            )
    except Exception:
        logger.debug("Non-critical eval recording failed")  # Non-critical eval recording

    return SubmitCorrectionResponse(**result)


@router.post("/queue/{item_id}/skip", response_model=SubmitCorrectionResponse)
async def api_skip_review(
    item_id: str,
    request: SkipReviewRequest,
    reviewer_id: str = Query(..., description="Reviewer ID"),
) -> SubmitCorrectionResponse:
    """Skip a review item."""
    queue = get_hitl_queue()
    result = skip_review(
        queue=queue,
        item_id=item_id,
        reviewer_id=reviewer_id,
        reason=request.reason,
    )

    return SubmitCorrectionResponse(**result)


@router.get("/statistics", response_model=QueueStatisticsResponse)
async def api_get_statistics() -> QueueStatisticsResponse:
    """Get queue statistics."""
    queue = get_hitl_queue()
    stats = queue.get_statistics()

    return QueueStatisticsResponse(
        total_items=stats["total_items"],
        pending=stats["pending"],
        assigned=stats["assigned"],
        completed=stats["completed"],
        avg_wait_time=stats["avg_wait_time"],
    )


@router.get("/reviewer/{reviewer_id}/items")
async def api_get_reviewer_items(reviewer_id: str) -> dict[str, Any]:
    """Get items assigned to a specific reviewer."""
    queue = get_hitl_queue()
    items = queue.get_reviewer_items(reviewer_id)

    return {
        "reviewer_id": reviewer_id,
        "items": [item.to_dict() for item in items],
        "count": len(items),
    }


@router.post("/cleanup")
async def api_cleanup_expired() -> dict[str, Any]:
    """Clean up expired assignments."""
    queue = get_hitl_queue()
    expired_count = queue.cleanup_expired()

    return {
        "success": True,
        "expired_cleaned": expired_count,
    }
