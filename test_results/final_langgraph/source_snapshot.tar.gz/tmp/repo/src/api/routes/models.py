"""Model status and download endpoints."""

import asyncio

from fastapi import APIRouter, HTTPException, status

from src.core.logging import get_logger
from src.services.models.downloader import download_single_model
from src.services.models.status import ModelInfo, get_model_status_service

logger = get_logger(__name__)

router = APIRouter(prefix="/models", tags=["Models"])

# Strong references to background download tasks to prevent GC
_background_tasks: set[asyncio.Task[bool]] = set()


@router.get(
    "/status",
    response_model=list[ModelInfo],
    summary="Get all model statuses",
    description="Returns the download/readiness status of all council models.",
)
async def get_models_status() -> list[ModelInfo]:
    """Return status of all tracked models."""
    svc = get_model_status_service()
    return svc.get_all_status()


@router.post(
    "/download/{model_key}",
    response_model=ModelInfo,
    summary="Trigger model download",
    description="Manually trigger download of a specific model.",
    responses={
        404: {"description": "Unknown model key"},
    },
)
async def trigger_download(model_key: str) -> ModelInfo:
    """Trigger download of a specific model in the background."""
    svc = get_model_status_service()
    try:
        model = svc.get_status(model_key)
    except KeyError as err:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Unknown model key: {model_key}",
        ) from err

    # Launch download in background — store ref to prevent GC
    task = asyncio.create_task(download_single_model(svc, model_key))
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)
    return model
