"""Document management endpoints."""

import asyncio
import hashlib
import uuid
from datetime import datetime
from typing import Any

from fastapi import (
    APIRouter,
    Body,
    Depends,
    File,
    HTTPException,
    Path,
    Query,
    UploadFile,
    status,
)
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.logging import get_logger
from src.models.database.base import get_session
from src.models.database.document import DocumentType as DBDocumentType, ProcessingStatus
from src.models.schemas.document import (
    DocumentDeleteResponse,
    DocumentFormat,
    DocumentInfo,
    DocumentListResponse,
    DocumentStatus,
    DocumentStatusResponse,
    DocumentUploadResponse,
)
from src.models.schemas.region import RegionExportRequest
from src.services.document.pipeline import process_document_background
from src.services.document.repository import DocumentRepository

# Track background processing tasks to prevent GC collection
_background_tasks: set[asyncio.Task] = set()  # type: ignore[type-arg]

logger = get_logger(__name__)

router = APIRouter(prefix="/documents", tags=["Documents"])


# Constants
MAX_FILE_SIZE = 300 * 1024 * 1024  # 300MB
ALLOWED_MIME_TYPES = {
    # Documents
    "application/pdf": "pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "application/msword": "doc",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
    "application/vnd.ms-excel": "xls",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
    "application/vnd.ms-powerpoint": "ppt",
    "text/plain": "txt",
    "text/csv": "csv",
    "text/html": "html",
    "application/rtf": "rtf",
    # Images
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/tiff": "tiff",
    "image/webp": "webp",
    "image/gif": "gif",
    "image/bmp": "bmp",
    "image/svg+xml": "svg",
    "image/heic": "heic",
    "image/heif": "heif",
}

# Magic bytes for file validation (only validated when content-type is known)
_MAGIC_BYTES = {
    "application/pdf": b"%PDF",
    "image/png": b"\x89PNG",
    "image/jpeg": b"\xff\xd8",
    "image/gif": b"GIF",
    "image/bmp": b"BM",
}


def _calculate_checksum(content: bytes) -> str:
    """Calculate SHA-256 checksum of content."""
    return hashlib.sha256(content).hexdigest()


def _validate_file(file: UploadFile, content: bytes) -> tuple[bool, str]:
    """Validate uploaded file."""
    if len(content) > MAX_FILE_SIZE:
        return (
            False,
            f"File size exceeds maximum allowed ({MAX_FILE_SIZE // 1024 // 1024}MB)",
        )

    content_type = file.content_type or "application/octet-stream"
    if content_type not in ALLOWED_MIME_TYPES:
        return False, f"File type '{content_type}' is not supported"

    # Validate magic bytes for known formats
    expected_magic = _MAGIC_BYTES.get(content_type)
    if expected_magic and not content.startswith(expected_magic):
        fmt = ALLOWED_MIME_TYPES.get(content_type, content_type)
        return False, f"Invalid {fmt.upper()} file"

    return True, "Valid"


def _map_db_status_to_schema(db_status: ProcessingStatus) -> DocumentStatus:
    """Map database ProcessingStatus to schema DocumentStatus."""
    mapping = {
        ProcessingStatus.PENDING: DocumentStatus.PENDING,
        ProcessingStatus.PREPROCESSING: DocumentStatus.PROCESSING,
        ProcessingStatus.EXTRACTING: DocumentStatus.PROCESSING,
        ProcessingStatus.COUNCIL_DELIBERATING: DocumentStatus.PROCESSING,
        ProcessingStatus.VALIDATING: DocumentStatus.PROCESSING,
        ProcessingStatus.CORRECTING: DocumentStatus.PROCESSING,
        ProcessingStatus.INDEXING: DocumentStatus.PROCESSING,
        ProcessingStatus.HUMAN_REVIEW: DocumentStatus.PROCESSING,
        ProcessingStatus.COMPLETED: DocumentStatus.PROCESSED,
        ProcessingStatus.FAILED: DocumentStatus.FAILED,
    }
    return mapping.get(db_status, DocumentStatus.PENDING)


@router.post(
    "/upload",
    response_model=DocumentUploadResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Upload document for extraction",
    responses={
        202: {"description": "Document accepted for processing"},
        400: {"description": "Invalid file format or size"},
        409: {"description": "Duplicate document"},
    },
)
async def upload_document(
    file: UploadFile = File(..., description="Document file to upload"),
    session: AsyncSession = Depends(get_session),
) -> DocumentUploadResponse:
    """Upload a document for processing."""
    try:
        content = await file.read()

        # Run input guard validation
        from src.services.guardrails.input_guard import get_input_guard

        guard = get_input_guard()
        content_type = file.content_type or "application/octet-stream"
        guard_result = guard.validate_input(
            filename=file.filename or "unknown",
            content=content,
            content_type=content_type,
        )
        if not guard_result.passed:
            failed_checks = [c.message for c in guard_result.checks if not c.passed]
            message = "; ".join(failed_checks) if failed_checks else "Input validation failed"
            logger.warning(
                "Document upload validation failed",
                filename=file.filename,
                error=message,
                pii_entities=len(guard_result.pii_entities),
            )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=message,
            )

        checksum = _calculate_checksum(content)
        repo = DocumentRepository(session)

        # Check for duplicate
        existing = await repo.get_by_checksum(checksum)
        if existing:
            logger.warning(
                "Duplicate document upload attempted",
                filename=file.filename,
                existing_id=str(existing.id),
            )
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Document already exists with ID: {existing.id}",
            )

        # Generate storage path and upload to storage service
        doc_id = uuid.uuid4()
        content_type = file.content_type or "application/octet-stream"
        storage_path = f"documents/{doc_id}/{file.filename or 'unknown'}"

        try:
            from src.services.storage.local import LocalStorageService

            storage = LocalStorageService()
            # Ensure the default bucket directory exists
            await storage.create_bucket("documents")
            await storage.upload(
                key=storage_path,
                content=content,
                content_type=content_type,
            )
        except Exception as storage_err:
            logger.warning(
                "Storage upload failed, proceeding with DB record",
                error=str(storage_err),
            )

        try:
            doc = await repo.create(
                filename=file.filename or "unknown",
                storage_path=storage_path,
                file_size=len(content),
                mime_type=content_type,
                checksum=checksum,
            )
        except Exception as db_err:
            # Handle race condition: unique constraint on checksum
            error_msg = str(db_err).lower()
            if "unique" in error_msg or "duplicate" in error_msg:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Document with this content already exists (checksum: {checksum[:12]}...)",
                ) from db_err
            raise

        logger.info(
            "Document uploaded successfully",
            document_id=str(doc.id),
            filename=file.filename,
            file_size=len(content),
        )

        # Dispatch background processing (ingestion → council → extraction)
        task = asyncio.create_task(
            process_document_background(
                document_id=str(doc.id),
                storage_path=storage_path,
                filename=file.filename or "unknown",
            )
        )
        _background_tasks.add(task)
        task.add_done_callback(_background_tasks.discard)

        return DocumentUploadResponse(
            document_id=str(doc.id),
            filename=file.filename or "unknown",
            upload_timestamp=doc.created_at or datetime.utcnow(),
            status=DocumentStatus.PENDING,
            size_bytes=len(content),
            file_format=DocumentFormat(ALLOWED_MIME_TYPES.get(content_type, "pdf")),
            content_hash=checksum,
            extraction_id=None,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Error uploading document",
            filename=file.filename,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to upload document",
        ) from e


@router.get(
    "/{document_id}",
    response_model=DocumentStatusResponse,
    status_code=status.HTTP_200_OK,
    summary="Get document status",
    responses={
        200: {"description": "Document found"},
        404: {"description": "Document not found"},
    },
)
async def get_document_status(
    document_id: str = Path(..., description="Document ID"),
    session: AsyncSession = Depends(get_session),
) -> DocumentStatusResponse:
    """Get the current status of a document."""
    try:
        repo = DocumentRepository(session)
        doc = await repo.get_by_id(uuid.UUID(document_id))

        if doc is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        return DocumentStatusResponse(
            document_id=str(doc.id),
            status=_map_db_status_to_schema(doc.status),
            filename=doc.filename,
            upload_timestamp=doc.created_at or datetime.utcnow(),
            document_type=None,
            processing_start=doc.processing_started_at,
            processing_end=doc.processing_completed_at,
            progress_percent=doc.progress_percent,
            current_stage=doc.status.value,
            error_message=doc.error_message,
            page_count=doc.page_count,
        )

    except HTTPException:
        raise
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document not found: {document_id}",
        ) from None
    except Exception as e:
        logger.error(
            "Error retrieving document status",
            document_id=document_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to retrieve document status",
        ) from e


@router.get(
    "/{document_id}/download",
    status_code=status.HTTP_200_OK,
    summary="Download extracted data",
    responses={
        200: {"description": "Extracted data"},
        404: {"description": "Document not found"},
        400: {"description": "Document processing not complete"},
    },
)
async def download_extracted_data(
    document_id: str = Path(..., description="Document ID"),
    format: str = Query("json", description="Export format"),
    session: AsyncSession = Depends(get_session),
) -> dict[str, Any]:
    """Download extracted data for a document."""
    try:
        repo = DocumentRepository(session)
        doc = await repo.get_by_id(uuid.UUID(document_id))

        if doc is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        if doc.status != ProcessingStatus.COMPLETED:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Document processing not completed. Current status: {doc.status.value}",
            )

        extraction = await repo.get_latest_extraction(doc.id)

        return {
            "document_id": str(doc.id),
            "format": format,
            "extraction_data": extraction.extracted_data if extraction else {},
            "metadata": {},
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Error downloading extracted data",
            document_id=document_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to download extracted data",
        ) from e


@router.get(
    "",
    response_model=DocumentListResponse,
    status_code=status.HTTP_200_OK,
    summary="List documents",
    responses={
        200: {"description": "Documents retrieved"},
    },
)
async def list_documents(
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=100, description="Items per page"),
    status_filter: str | None = Query(None, alias="status", description="Filter by status"),
    document_type: str | None = Query(None, description="Filter by document type"),
    session: AsyncSession = Depends(get_session),
) -> DocumentListResponse:
    """List documents with pagination and filtering."""
    try:
        repo = DocumentRepository(session)

        # Map schema status to DB status for filtering
        db_status = None
        if status_filter:
            schema_to_db = {
                "pending": ProcessingStatus.PENDING,
                "processing": ProcessingStatus.EXTRACTING,
                "processed": ProcessingStatus.COMPLETED,
                "failed": ProcessingStatus.FAILED,
            }
            db_status = schema_to_db.get(status_filter)

        db_doc_type = None
        if document_type:
            import contextlib

            with contextlib.suppress(ValueError):
                db_doc_type = DBDocumentType(document_type)

        docs, total_count = await repo.list_documents(
            page=page,
            page_size=page_size,
            status=db_status,
            document_type=db_doc_type,
        )

        docs_info = [
            DocumentInfo(
                document_id=str(d.id),
                filename=d.filename,
                file_format=DocumentFormat(ALLOWED_MIME_TYPES.get(d.mime_type, "pdf")),
                file_size_bytes=d.file_size,
                document_type=None,
                upload_timestamp=d.created_at or datetime.utcnow(),
                status=_map_db_status_to_schema(d.status),
                content_hash=d.checksum,
            )
            for d in docs
        ]

        return DocumentListResponse(
            documents=docs_info,
            total_count=total_count,
            page=page,
            page_size=page_size,
            filters_applied={
                "status": status_filter,
                "document_type": document_type,
            },
        )

    except Exception as e:
        logger.error("Error listing documents", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to list documents",
        ) from e


def _export_as_format(
    format_val: str,
    document_id: str,
    doc_id: uuid.UUID,
    filename: str | None,
    title: str,
    extraction_data: dict[str, Any],
) -> Response:
    """Dispatch export to the appropriate format generator.

    Returns a Response for json, pdf, docx, markdown, html, csv, excel.
    Raises HTTPException for unsupported formats.
    """
    if format_val == "json":
        import json

        content = json.dumps(
            {"document_id": str(doc_id), "filename": filename, **extraction_data},
            indent=2,
            default=str,
        )
        return Response(
            content=content,
            media_type="application/json",
            headers={"Content-Disposition": f'attachment; filename="{title}.json"'},
        )

    if format_val == "pdf":
        from src.services.generation.pdf import get_pdf_generator

        gen = get_pdf_generator()
        pdf_doc = gen.generate(title=title, extraction_data=extraction_data)
        return Response(
            content=pdf_doc.content_bytes or b"",
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{title}.pdf"'},
        )

    if format_val == "docx":
        from src.services.generation.docx import get_docx_generator

        gen = get_docx_generator()
        docx_doc = gen.generate(title=title, extraction_data=extraction_data)
        return Response(
            content=docx_doc.content_bytes or b"",
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f'attachment; filename="{title}.docx"'},
        )

    if format_val == "markdown":
        from src.services.generation.markdown import get_markdown_generator

        gen = get_markdown_generator()
        md_doc = gen.generate(title=title, extraction_data=extraction_data)
        return Response(
            content=md_doc.content.encode("utf-8"),
            media_type="text/markdown",
            headers={"Content-Disposition": f'attachment; filename="{title}.md"'},
        )

    return _export_as_tabular_format(format_val, document_id, extraction_data)


def _export_as_tabular_format(
    format_val: str,
    document_id: str,
    extraction_data: dict[str, Any],
) -> Response:
    """Handle html, csv, and excel export formats.

    Raises HTTPException for unsupported formats.
    """
    if format_val == "html":
        from src.services.generation.html import get_html_generator

        generator = get_html_generator()
        html_content = generator.generate(extraction_data, title=f"Document {document_id}")
        return Response(content=html_content, media_type="text/html")

    if format_val == "csv":
        from src.services.generation.tabular import get_csv_generator

        generator = get_csv_generator()
        tables = extraction_data.get("tables", [])
        if tables:
            csv_content = generator.generate_from_tables(tables)
        else:
            csv_content = generator.generate_from_fields(
                extraction_data.get("extracted_fields", extraction_data)
            )
        return Response(
            content=csv_content,
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename=document_{document_id}.csv"},
        )

    if format_val == "excel":
        from src.services.generation.tabular import get_excel_generator

        generator = get_excel_generator()
        tables = extraction_data.get("tables", [])
        excel_bytes = generator.generate(extraction_data, tables=tables)
        return Response(
            content=excel_bytes,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename=document_{document_id}.xlsx"},
        )

    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=(
            f"Unsupported format: {format_val}. Use json, pdf, docx, markdown, html, csv, or excel."
        ),
    )


@router.get(
    "/{document_id}/export",
    status_code=status.HTTP_200_OK,
    summary="Export document extraction",
    responses={
        200: {"description": "Exported content"},
        404: {"description": "Document not found"},
        400: {"description": "Document not processed or invalid format"},
    },
)
async def export_document(
    document_id: str = Path(..., description="Document ID"),
    format: str = Query(
        "json", description="Export format: json, pdf, docx, markdown, html, csv, excel"
    ),
    session: AsyncSession = Depends(get_session),
) -> Response:
    """Export extracted data in various formats."""
    try:
        repo = DocumentRepository(session)
        doc = await repo.get_by_id(uuid.UUID(document_id))

        if doc is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        if doc.status != ProcessingStatus.COMPLETED:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Document not processed. Current status: {doc.status.value}",
            )

        extraction = await repo.get_latest_extraction(doc.id)
        extraction_data = extraction.extracted_data if extraction else {}

        title = doc.filename or "Extraction Report"

        return _export_as_format(
            format_val=format,
            document_id=document_id,
            doc_id=doc.id,
            filename=doc.filename,
            title=title,
            extraction_data=extraction_data,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error exporting document", document_id=document_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to export document",
        ) from e


@router.post(
    "/{document_id}/blog",
    status_code=status.HTTP_200_OK,
    summary="Generate blog from document",
    responses={
        200: {"description": "Blog generated"},
        404: {"description": "Document not found"},
        400: {"description": "Document not processed"},
    },
)
async def generate_blog(
    document_id: str = Path(..., description="Document ID"),
    instructions: str = Body("Write a professional summary of this document.", embed=True),
    session: AsyncSession = Depends(get_session),
) -> dict[str, Any]:
    """Generate a blog post from extracted document content."""
    try:
        repo = DocumentRepository(session)
        doc = await repo.get_by_id(uuid.UUID(document_id))

        if doc is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        if doc.status != ProcessingStatus.COMPLETED:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Document not processed. Current status: {doc.status.value}",
            )

        extraction = await repo.get_latest_extraction(doc.id)
        extraction_data = extraction.extracted_data if extraction else {}

        from src.services.generation.blog import BlogGenerator

        gen = BlogGenerator()
        blog = gen.generate(
            title=doc.filename or "Document Blog",
            extraction_data=extraction_data,
            instructions=instructions,
        )

        return {
            "document_id": str(doc.id),
            "title": blog.title,
            "content": blog.content,
            "word_count": blog.word_count,
            "created_at": blog.created_at.isoformat(),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error generating blog", document_id=document_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to generate blog",
        ) from e


@router.post(
    "/{document_id}/process",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Trigger document processing",
    responses={
        202: {"description": "Processing started"},
        404: {"description": "Document not found"},
        409: {"description": "Document already processed or processing"},
    },
)
async def trigger_processing(
    document_id: str = Path(..., description="Document ID"),
    session: AsyncSession = Depends(get_session),
) -> dict[str, str]:
    """Manually trigger processing for a document."""
    try:
        repo = DocumentRepository(session)
        doc = await repo.get_by_id(uuid.UUID(document_id))

        if doc is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        if doc.status == ProcessingStatus.COMPLETED:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Document already processed",
            )

        if doc.is_processing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Document is already being processed (status: {doc.status.value})",
            )

        task = asyncio.create_task(
            process_document_background(
                document_id=str(doc.id),
                storage_path=doc.storage_path,
                filename=doc.filename,
            )
        )
        _background_tasks.add(task)
        task.add_done_callback(_background_tasks.discard)

        return {
            "document_id": document_id,
            "status": "processing_started",
            "message": "Document processing has been triggered",
        }

    except HTTPException:
        raise
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document not found: {document_id}",
        ) from None
    except Exception as e:
        logger.error(
            "Error triggering document processing",
            document_id=document_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to trigger processing",
        ) from e


@router.post(
    "/{document_id}/reprocess",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Re-process a document",
    responses={
        202: {"description": "Re-processing started"},
        404: {"description": "Document not found"},
        409: {"description": "Document is currently processing"},
    },
)
async def reprocess_document(
    document_id: str = Path(..., description="Document ID"),
    session: AsyncSession = Depends(get_session),
) -> dict[str, str]:
    """Re-process an already-processed (or failed) document.

    Resets the document status and re-runs the extraction pipeline,
    which will overwrite the existing extraction data with fresh results.
    """
    try:
        repo = DocumentRepository(session)
        doc = await repo.get_by_id(uuid.UUID(document_id))

        if doc is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        if doc.is_processing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Document is currently processing (status: {doc.status.value})",
            )

        # Reset status so the pipeline can run again
        doc.status = ProcessingStatus.PENDING
        doc.error_message = None
        doc.progress_percent = 0
        doc.processing_started_at = None
        doc.processing_completed_at = None

        # Mark existing extraction as non-latest so a new one takes its place
        existing_extraction = await repo.get_latest_extraction(doc.id)
        if existing_extraction:
            existing_extraction.is_latest = False

        await session.commit()

        task = asyncio.create_task(
            process_document_background(
                document_id=str(doc.id),
                storage_path=doc.storage_path,
                filename=doc.filename,
            )
        )
        _background_tasks.add(task)
        task.add_done_callback(_background_tasks.discard)

        return {
            "document_id": document_id,
            "status": "reprocessing_started",
            "message": "Document re-processing has been triggered",
        }

    except HTTPException:
        raise
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document not found: {document_id}",
        ) from None
    except Exception as e:
        logger.error(
            "Error re-processing document",
            document_id=document_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to re-process document",
        ) from e


@router.get(
    "/{document_id}/file",
    status_code=status.HTTP_200_OK,
    summary="Download original file",
    responses={
        200: {"description": "File content"},
        404: {"description": "Document or file not found"},
    },
)
async def download_original_file(
    document_id: str = Path(..., description="Document ID"),
    session: AsyncSession = Depends(get_session),
) -> Response:
    """Download the original uploaded file from storage."""
    try:
        repo = DocumentRepository(session)
        doc = await repo.get_by_id(uuid.UUID(document_id))

        if doc is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        from src.services.storage.local import LocalStorageService

        storage = LocalStorageService()
        result = await storage.download(doc.storage_path)

        return Response(
            content=result.content,
            media_type=doc.mime_type or "application/octet-stream",
            headers={
                "Content-Disposition": f'inline; filename="{doc.filename}"',
                "Content-Length": str(len(result.content)),
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Error downloading file",
            document_id=document_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="File not found in storage",
        ) from e


def _layout_has_text(layout: Any) -> bool:
    """Check whether a DocumentLayout contains meaningful text content."""
    for page in layout.pages:
        for block in page.blocks:
            if block.block_type == "table":
                return True
            if not hasattr(block, "lines"):
                continue
            for line in block.lines:
                text = "".join(span.text for span in line.spans).strip()
                if text:
                    return True
    return False


def _extract_tables_from_db(extracted_data: dict) -> list:
    """Extract TableBlock objects from DB extraction data (council results).

    Looks for 'line_items' or 'tables' keys in the extracted data.
    """
    from src.services.layout.models import TableBlock as LayoutTableBlock

    table_blocks = []

    # Check for line_items (common in invoice extractions)
    line_items = extracted_data.get("line_items")
    if isinstance(line_items, dict):
        line_items = line_items.get("value", line_items)
    if isinstance(line_items, list) and line_items:
        first = line_items[0]
        if isinstance(first, dict):
            headers = list(first.keys())
            rows = [[str(item.get(h, "")) for h in headers] for item in line_items]
            table_blocks.append(
                LayoutTableBlock(headers=headers, rows=rows, bbox=(0, 0, 0, 0))
            )

    # Check for explicit tables key
    tables = extracted_data.get("tables")
    if isinstance(tables, list):
        for tbl in tables:
            if isinstance(tbl, dict) and "headers" in tbl and "rows" in tbl:
                table_blocks.append(
                    LayoutTableBlock(
                        headers=tbl["headers"],
                        rows=tbl["rows"],
                        bbox=(0, 0, 0, 0),
                    )
                )

    return table_blocks


async def _init_council_members() -> list[Any]:
    """Lazily initialize available council members for region OCR."""
    import importlib

    members: list[Any] = []
    member_configs = [
        ("paddle_ocr", "src.council.members.paddle_ocr", "PaddleOCRMember"),
        ("olmocr", "src.council.members.olmocr", "OlmOCRMember"),
        ("qwen_vlm", "src.council.members.qwen_vlm", "QwenVLMMember"),
        ("colpali", "src.council.members.colpali_vlm", "ColPaliVLMMember"),
    ]
    for name, module_path, class_name in member_configs:
        try:
            mod = importlib.import_module(module_path)
            cls = getattr(mod, class_name)
            member = cls()
            await member.initialize()
            members.append(member)
            logger.info("Council member initialized for region OCR", member=name)
        except Exception as exc:
            logger.debug("Could not initialize council member", member=name, error=str(exc))
    return members


async def _enhance_layout_with_council(
    layout: Any,
    file_bytes: bytes,
    regions: list[Any],
    extractor: Any,
) -> Any:
    """Enhance empty layout pages with council OCR extraction.

    When PyMuPDF text extraction yields no text (e.g. scanned PDFs), this
    crops each region as an image and runs it through the LLM council
    orchestrator. The council members (PaddleOCR, olmOCR, Qwen VLM,
    ColPali VLM) each perform OCR independently, then vote on the text via
    the consensus engine.

    Args:
        layout: DocumentLayout from PyMuPDF extraction.
        file_bytes: Raw PDF/document bytes.
        regions: List of RegionSelector dataclass instances.
        extractor: LayoutExtractor instance.

    Returns:
        Enhanced DocumentLayout with council-extracted text blocks.
    """
    from src.services.layout.models import (
        DocumentLayout,
        PageLayout,
        TextBlock,
        TextLine,
        TextSpan,
    )

    try:
        from src.council.orchestrator import CouncilOrchestrator
    except ImportError:
        logger.warning("Council module not available, skipping council OCR enhancement")
        return layout

    members = await _init_council_members()
    if not members:
        logger.warning("No council members available for region OCR, falling back to pytesseract")
        return layout

    orchestrator = CouncilOrchestrator(council_members=members)

    enhanced_pages: list[PageLayout] = []
    for page_layout, region in zip(layout.pages, regions, strict=False):
        # Check if this page already has text (native PDF region)
        has_text = any(
            any("".join(s.text for s in line.spans).strip() for line in block.lines)
            for block in page_layout.blocks
        )
        if has_text:
            enhanced_pages.append(page_layout)
            continue

        # Empty text — crop as image and run through council
        try:
            image_bytes = extractor.crop_region_as_image(file_bytes, region, dpi=300, fmt="png")
        except Exception as exc:
            logger.warning("Failed to crop region for council OCR", error=str(exc))
            enhanced_pages.append(page_layout)
            continue

        try:
            session_id = f"region-{uuid.uuid4().hex[:12]}"
            decision = await orchestrator.deliberate(
                session_id=session_id,
                image_data=image_bytes,
                document_type=None,
                target_fields=None,
            )

            # Convert council extracted_fields into TextBlocks
            blocks: list[TextBlock] = []
            for _field_name, field_data in decision.extracted_fields.items():
                value = field_data.get("value", "")
                if not value or not str(value).strip():
                    continue
                text = str(value)
                span = TextSpan(
                    text=text,
                    font_name="Helvetica",
                    font_size=11.0,
                    color=0,
                    bold=False,
                    italic=False,
                    bbox=(0.0, 0.0, 0.0, 0.0),
                )
                line = TextLine(spans=[span], bbox=(0.0, 0.0, 0.0, 0.0))
                blocks.append(TextBlock(lines=[line], bbox=(0.0, 0.0, 0.0, 0.0), block_type="text"))

            if blocks:
                enhanced_pages.append(
                    PageLayout(
                        page_number=page_layout.page_number,
                        page_width=page_layout.page_width,
                        page_height=page_layout.page_height,
                        blocks=blocks,
                        region=page_layout.region,
                    )
                )
                logger.info(
                    "Council OCR enhanced region",
                    page=page_layout.page_number,
                    blocks=len(blocks),
                    confidence=f"{decision.overall_confidence:.2%}",
                )
            else:
                enhanced_pages.append(page_layout)

        except Exception as exc:
            logger.warning("Council OCR failed for region", error=str(exc))
            enhanced_pages.append(page_layout)

    return DocumentLayout(
        pages=enhanced_pages,
        source_filename=layout.source_filename,
        total_page_count=layout.total_page_count,
    )


def _ocr_cropped_region(image_bytes: bytes, title: str) -> dict[str, Any]:
    """Run OCR on cropped image bytes and return structured extraction data.

    Returns a dict matching the format expected by document generators:
    summary, document_type, sections, tables, diagrams, entities.
    Falls back gracefully if pytesseract is unavailable or OCR fails.
    """
    try:
        import pytesseract
        from PIL import Image as PILImage
    except ImportError:
        logger.debug("pytesseract or PIL not available for OCR")
        return {}

    try:
        import io as _io

        img = PILImage.open(_io.BytesIO(image_bytes))
        raw_text = pytesseract.image_to_string(img).strip()
    except Exception as exc:
        logger.warning("OCR extraction failed", error=str(exc))
        return {}

    if not raw_text:
        return {}

    # Try structured analysis via ContentAnalyzer
    try:
        from src.services.document.content_analyzer import ContentAnalyzer

        analyzer = ContentAnalyzer()
        analyzed = analyzer.analyze(raw_text, filename=title)

        return {
            "summary": analyzed.summary,
            "document_type": analyzed.document_type,
            "sections": [
                {"title": s.title, "content": s.content, "level": s.level}
                for s in analyzed.sections
            ],
            "tables": [
                {"title": t.title, "headers": t.headers, "rows": t.rows} for t in analyzed.tables
            ],
            "diagrams": [
                {
                    "title": d.title,
                    "description": d.description,
                    "ascii_representation": d.ascii_representation,
                }
                for d in analyzed.diagrams
            ],
            "entities": analyzed.entities,
        }
    except Exception as exc:
        logger.warning("ContentAnalyzer failed, using raw text", error=str(exc))
        return {
            "summary": raw_text[:500],
            "document_type": "generic",
            "sections": [{"title": "Extracted Text", "content": raw_text, "level": 1}],
            "tables": [],
            "diagrams": [],
            "entities": {},
        }


def _normalize_extraction_data(data: dict[str, Any]) -> dict[str, Any]:
    """Unwrap extraction data fields from {"value": ..., "confidence": ...} wrappers.

    The DB stores fields as ``{"value": <actual>, "confidence": <float>}`` but
    rendering functions expect flat values (e.g. ``sections`` as a list, not a dict).
    This function normalises the data so renderers always receive the expected types.
    """
    if not data or not isinstance(data, dict):
        return data or {}

    out: dict[str, Any] = {}
    for key, val in data.items():
        if isinstance(val, dict) and "value" in val and "confidence" in val:
            out[key] = val["value"]
        else:
            out[key] = val

    # Enforce expected types for known keys
    for list_key in ("sections", "tables", "diagrams"):
        v = out.get(list_key)
        if v is not None and not isinstance(v, list):
            out[list_key] = []
    entities = out.get("entities")
    if entities is not None and not isinstance(entities, dict):
        out["entities"] = {}

    # Build fallback sections if none exist
    if not out.get("sections"):
        _build_fallback_sections(out)

    return out


def _build_fallback_sections(out: dict[str, Any]) -> None:
    """Populate ``out["sections"]`` from diagrams or document_text if empty."""
    fallback_sections: list[dict[str, Any]] = []
    diagrams_used = False
    for diag in out.get("diagrams") or []:
        if not isinstance(diag, dict):
            continue
        content_parts = [
            p for key in ("description", "ascii_representation") if (p := diag.get(key))
        ]
        if content_parts:
            fallback_sections.append(
                {
                    "title": diag.get("title", "Diagram"),
                    "content": "\n\n".join(content_parts),
                    "level": 2,
                }
            )
            diagrams_used = True
    # Use document_text if still nothing
    if not fallback_sections:
        doc_text = out.get("document_text")
        if isinstance(doc_text, str) and doc_text.strip():
            fallback_sections.append({"title": "Document Content", "content": doc_text, "level": 1})
    if fallback_sections:
        out["sections"] = fallback_sections
    if diagrams_used:
        out["diagrams"] = []


def _safe_list(data: dict[str, Any], key: str) -> list[Any]:
    """Get a list value from data, returning [] for non-list values."""
    val = data.get(key, [])
    return val if isinstance(val, list) else []


def _safe_dict(data: dict[str, Any], key: str) -> dict[str, Any]:
    """Get a dict value from data, returning {} for non-dict values."""
    val = data.get(key, {})
    return val if isinstance(val, dict) else {}


def _md_render_tables(tables: list[Any]) -> list[str]:
    """Render tables as markdown."""
    parts: list[str] = []
    for table in tables:
        if not isinstance(table, dict):
            continue
        tbl_title = table.get("title")
        headers = table.get("headers", [])
        if tbl_title:
            parts.append(f"### {tbl_title}\n")
        if headers:
            parts.append("| " + " | ".join(headers) + " |")
            parts.append("| " + " | ".join("---" for _ in headers) + " |")
            for row in table.get("rows", []):
                parts.append("| " + " | ".join(str(c) for c in row) + " |")
            parts.append("")
    return parts


def _md_render_diagrams(diagrams: list[Any]) -> list[str]:
    """Render diagrams as markdown."""
    parts: list[str] = []
    for diag in diagrams:
        if not isinstance(diag, dict):
            continue
        parts.append(f"### {diag.get('title', 'Diagram')}\n")
        if diag.get("description"):
            parts.append(f"{diag['description']}\n")
        if diag.get("ascii_representation"):
            parts.append(f"```text\n{diag['ascii_representation']}\n```\n")
    return parts


def _md_render_entities(entities: dict[str, Any]) -> list[str]:
    """Render entities as markdown."""
    if not entities:
        return []
    parts: list[str] = ["## Detected Entities\n"]
    for entity_type, values in entities.items():
        if isinstance(values, list):
            parts.append(f"- **{entity_type}**: {', '.join(str(v) for v in values)}")
        else:
            parts.append(f"- **{entity_type}**: {values}")
    parts.append("")
    return parts


def _render_md_sections(
    extraction_data: dict[str, Any],
) -> list[str]:
    """Render extraction data sections, tables, diagrams, and entities as markdown."""
    parts: list[str] = []

    summary = extraction_data.get("summary", "")
    if summary and isinstance(summary, str):
        parts.append("## Summary\n")
        parts.append(f"{summary}\n")

    sections = _safe_list(extraction_data, "sections")
    if sections:
        parts.append("## Extracted Content\n")
        for section in sections:
            if not isinstance(section, dict):
                continue
            heading = "#" * min(section.get("level", 2) + 1, 6)
            if sec_title := section.get("title", ""):
                parts.append(f"{heading} {sec_title}\n")
            if sec_content := section.get("content", ""):
                parts.append(f"{sec_content}\n")

    parts.extend(_md_render_diagrams(_safe_list(extraction_data, "diagrams")))
    parts.extend(_md_render_tables(_safe_list(extraction_data, "tables")))
    parts.extend(_md_render_entities(_safe_dict(extraction_data, "entities")))
    return parts


def _render_blog_content(title: str, img_b64: str, extraction_data: dict[str, Any]) -> str:
    """Build a blog-style markdown document from extraction data."""
    summary = extraction_data.get("summary", "")
    sections = _safe_list(extraction_data, "sections")
    diagrams = _safe_list(extraction_data, "diagrams")
    tables = _safe_list(extraction_data, "tables")
    entities = _safe_dict(extraction_data, "entities")

    parts = [
        f"# {title}\n",
        "## Introduction\n",
        "This document contains extracted content from an image region.\n",
    ]
    if summary:
        parts.append(f"{summary}\n")
    parts.append(f"![Extracted Region](data:image/png;base64,{img_b64})\n")

    if sections:
        parts.append("## Content\n")
        for section in sections:
            if not isinstance(section, dict):
                continue
            if sec_title := section.get("title", ""):
                parts.append(f"### {sec_title}\n")
            if sec_content := section.get("content", ""):
                parts.append(f"{sec_content}\n")

    if diagrams:
        parts.append("## Diagrams\n")
        parts.extend(_md_render_diagrams(diagrams))

    if tables:
        parts.append("## Data Tables\n")
        parts.extend(_md_render_tables(tables))

    if entities:
        parts.append("## Key Information\n")
        parts.extend(_md_render_entities(entities))

    parts.append("## Conclusion\n")
    parts.append("The above content was extracted from the selected image region.\n")
    return "\n".join(parts)


def _export_image_region(
    extractor: Any,
    file_bytes: bytes,
    region: Any,
    body: "RegionExportRequest",
    title: str,
    db_extraction_data: dict[str, Any] | None = None,
) -> Response:
    """Export a cropped image region in the requested format."""
    import base64 as b64mod

    if body.format == "image":
        cropped = extractor.crop_image_region(file_bytes, region, fmt=body.image_format)
        media_type = {
            "png": "image/png",
            "jpg": "image/jpeg",
            "jpeg": "image/jpeg",
            "webp": "image/webp",
        }.get(body.image_format, "image/png")
        return Response(
            content=cropped,
            media_type=media_type,
            headers={"Content-Disposition": f'attachment; filename="region.{body.image_format}"'},
        )

    # For document formats, crop as PNG then build text content.
    # Prefer DB extraction data (from VLM council which understands images
    # semantically) over OCR (pytesseract pixel-level text recognition).
    # OCR on styled infographics / dark backgrounds produces garbled output,
    # while VLM extraction captures structured content accurately.
    cropped_png = extractor.crop_image_region(file_bytes, region, fmt="png")

    if db_extraction_data:
        extraction_data = _normalize_extraction_data(db_extraction_data)
        logger.info("Using DB extraction data for image region export", title=title)
    else:
        extraction_data = _ocr_cropped_region(cropped_png, title)
        extraction_data = _normalize_extraction_data(extraction_data) if extraction_data else {}

    if body.format == "pdf":
        return Response(
            content=_render_pdf_with_image(cropped_png, title, extraction_data),
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{title}_region.pdf"'},
        )

    if body.format == "docx":
        return Response(
            content=_render_docx_with_image(cropped_png, title, extraction_data),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f'attachment; filename="{title}_region.docx"'},
        )

    if body.format in ("markdown", "blog"):
        img_b64 = b64mod.b64encode(cropped_png).decode("ascii")

        if body.format == "blog":
            md_content = _render_blog_content(title, img_b64, extraction_data)
        else:
            md_parts = [
                f"# {title} - Region Export\n",
                f"![Extracted Region](data:image/png;base64,{img_b64})\n",
                *_render_md_sections(extraction_data),
            ]
            md_content = "\n".join(md_parts)

        return Response(
            content=md_content.encode(),
            media_type="text/markdown",
            headers={"Content-Disposition": f'attachment; filename="{title}_region.md"'},
        )

    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=f"Unsupported format for image export: {body.format}",
    )


def _pdf_add_summary(
    story: list[Any],
    data: dict[str, Any],
    styles: Any,
    body_style: Any,
) -> None:
    """Add summary paragraph to PDF story."""
    from reportlab.platypus import Paragraph, Spacer

    summary = data.get("summary", "")
    if summary and isinstance(summary, str):
        story.append(Paragraph("Summary", styles["Heading1"]))
        story.append(Spacer(1, 6))
        story.append(Paragraph(summary, body_style))
        story.append(Spacer(1, 12))


def _pdf_add_content_sections(
    story: list[Any],
    data: dict[str, Any],
    styles: Any,
    heading_style: Any,
    body_style: Any,
) -> None:
    """Add content sections to PDF story."""
    from reportlab.platypus import Paragraph, Spacer

    sections = data.get("sections", [])
    if not isinstance(sections, list):
        sections = []
    if not sections:
        return
    story.append(Paragraph("Extracted Content", styles["Heading1"]))
    story.append(Spacer(1, 6))
    for section in sections:
        if not isinstance(section, dict):
            continue
        sec_title = section.get("title", "")
        sec_content = section.get("content", "")
        if sec_title:
            story.append(Paragraph(sec_title, heading_style))
        if sec_content:
            for chunk in sec_content.split("\n\n"):
                stripped = chunk.strip()
                if stripped:
                    story.append(Paragraph(stripped, body_style))


def _pdf_add_diagrams(
    story: list[Any],
    data: dict[str, Any],
    heading_style: Any,
    body_style: Any,
    mono_style: Any,
) -> None:
    """Add diagrams to PDF story."""
    from reportlab.platypus import Paragraph, Preformatted, Spacer

    diagrams = data.get("diagrams", [])
    if not isinstance(diagrams, list):
        diagrams = []
    for diag in diagrams:
        if not isinstance(diag, dict):
            continue
        diag_title = diag.get("title", "Diagram")
        story.append(Paragraph(diag_title, heading_style))
        if diag.get("description"):
            story.append(Paragraph(diag["description"], body_style))
        if diag.get("ascii_representation"):
            story.append(Preformatted(diag["ascii_representation"], mono_style))
        story.append(Spacer(1, 8))


def _pdf_add_tables(
    story: list[Any],
    data: dict[str, Any],
    styles: Any,
) -> None:
    """Add tables to PDF story."""
    from reportlab.platypus import Paragraph, Spacer, Table, TableStyle

    tables = data.get("tables", [])
    if not isinstance(tables, list):
        tables = []
    for tbl in tables:
        headers = tbl.get("headers", [])
        rows = tbl.get("rows", [])
        if not (headers and rows):
            continue
        tbl_title = tbl.get("title")
        if tbl_title:
            story.append(Paragraph(tbl_title, styles["Heading3"]))
            story.append(Spacer(1, 4))
        t = Table([headers, *rows])
        t.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), "#D0D0D0"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, -1), 9),
                    ("GRID", (0, 0), (-1, -1), 0.5, "#808080"),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ]
            )
        )
        story.append(t)
        story.append(Spacer(1, 8))


def _pdf_add_entities(
    story: list[Any],
    data: dict[str, Any],
    styles: Any,
) -> None:
    """Add entities to PDF story."""
    from reportlab.platypus import Paragraph, Spacer

    entities = data.get("entities", {})
    if not isinstance(entities, dict):
        entities = {}
    if entities:
        story.append(Paragraph("Detected Entities", styles["Heading2"]))
        story.append(Spacer(1, 4))
        for entity_type, values in entities.items():
            text = f"<b>{entity_type}:</b> {', '.join(str(v) for v in values)}"
            story.append(Paragraph(text, styles["BodyText"]))


def _add_pdf_extraction_content(
    story: list[Any], extraction_data: dict[str, Any], styles: Any
) -> None:
    """Append extraction data (summary, sections, diagrams, tables, entities) to reportlab."""
    from reportlab.lib.styles import ParagraphStyle

    heading_style = ParagraphStyle(
        "SectionHeading", parent=styles["Heading2"], fontSize=13, spaceAfter=6
    )
    body_style = ParagraphStyle("SectionBody", parent=styles["BodyText"], fontSize=10, spaceAfter=8)
    mono_style = ParagraphStyle(
        "MonoBody",
        parent=styles["Code"],
        fontSize=8,
        spaceAfter=8,
        fontName="Courier",
    )

    _pdf_add_summary(story, extraction_data, styles, body_style)
    _pdf_add_content_sections(story, extraction_data, styles, heading_style, body_style)
    _pdf_add_diagrams(story, extraction_data, heading_style, body_style, mono_style)
    _pdf_add_tables(story, extraction_data, styles)
    _pdf_add_entities(story, extraction_data, styles)


def _render_pdf_with_image(
    image_bytes: bytes, title: str, extraction_data: dict[str, Any] | None = None
) -> bytes:
    """Create a PDF containing the image and extracted text content."""
    import io as _io

    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import inch
        from reportlab.lib.utils import ImageReader
        from reportlab.platypus import (
            Image as RLImage,
            Paragraph,
            SimpleDocTemplate,
            Spacer,
        )
    except ImportError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PDF generation requires reportlab. Install with: pip install reportlab",
        ) from exc

    buf = _io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title=title)
    styles = getSampleStyleSheet()
    story: list[Any] = []

    title_style = ParagraphStyle("RegionTitle", parent=styles["Title"], fontSize=16, spaceAfter=12)
    story.append(Paragraph(title, title_style))
    story.append(Spacer(1, 12))

    img_reader = ImageReader(_io.BytesIO(image_bytes))
    iw, ih = img_reader.getSize()
    page_w, _ = A4
    scale = min((page_w - 2 * inch) / iw, 1.0)
    story.append(RLImage(_io.BytesIO(image_bytes), width=iw * scale, height=ih * scale))
    story.append(Spacer(1, 18))

    if extraction_data:
        _add_pdf_extraction_content(story, extraction_data, styles)

    doc.build(story)
    return buf.getvalue()


def _add_docx_table(doc: Any, tbl: dict[str, Any]) -> None:
    """Add a single table with headers and rows to a python-docx document."""
    headers = tbl.get("headers", [])
    rows = tbl.get("rows", [])
    if not (headers and rows):
        return
    tbl_title = tbl.get("title")
    if tbl_title:
        doc.add_heading(tbl_title, level=3)
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    for i, header in enumerate(headers):
        table.rows[0].cells[i].text = str(header)
    for row_data in rows:
        row_cells = table.add_row().cells
        for i, cell_val in enumerate(row_data):
            if i < len(row_cells):
                row_cells[i].text = str(cell_val)


def _docx_add_summary(doc: Any, data: dict[str, Any]) -> None:
    """Add summary to DOCX document."""
    summary = data.get("summary", "")
    if summary and isinstance(summary, str):
        doc.add_heading("Summary", level=2)
        doc.add_paragraph(summary)


def _docx_add_content_sections(doc: Any, data: dict[str, Any]) -> None:
    """Add content sections to DOCX document."""
    sections = data.get("sections", [])
    if not isinstance(sections, list):
        sections = []
    if not sections:
        return
    doc.add_heading("Extracted Content", level=2)
    for section in sections:
        if not isinstance(section, dict):
            continue
        sec_title = section.get("title", "")
        sec_content = section.get("content", "")
        if sec_title:
            doc.add_heading(sec_title, level=min(section.get("level", 2) + 1, 4))
        if sec_content:
            doc.add_paragraph(sec_content)


def _docx_add_diagrams(doc: Any, data: dict[str, Any]) -> None:
    """Add diagrams to DOCX document."""
    diagrams = data.get("diagrams", [])
    if not isinstance(diagrams, list):
        diagrams = []
    for diag in diagrams:
        if not isinstance(diag, dict):
            continue
        diag_title = diag.get("title", "Diagram")
        doc.add_heading(diag_title, level=3)
        if diag.get("description"):
            doc.add_paragraph(diag["description"])
        if diag.get("ascii_representation"):
            doc.add_paragraph(diag["ascii_representation"], style="Quote")


def _docx_add_entities(doc: Any, data: dict[str, Any]) -> None:
    """Add entities to DOCX document."""
    entities = data.get("entities", {})
    if not isinstance(entities, dict):
        entities = {}
    if not entities:
        return
    doc.add_heading("Detected Entities", level=2)
    for entity_type, values in entities.items():
        val_str = ", ".join(str(v) for v in values) if isinstance(values, list) else values
        doc.add_paragraph(f"{entity_type}: {val_str}", style="List Bullet")


def _add_docx_extraction_content(doc: Any, extraction_data: dict[str, Any]) -> None:
    """Append extraction data (summary, sections, diagrams, tables, entities) to DOCX."""
    _docx_add_summary(doc, extraction_data)
    _docx_add_content_sections(doc, extraction_data)
    _docx_add_diagrams(doc, extraction_data)
    tables = extraction_data.get("tables", [])
    if isinstance(tables, list):
        for tbl in tables:
            _add_docx_table(doc, tbl)
    _docx_add_entities(doc, extraction_data)


def _render_docx_with_image(
    image_bytes: bytes, title: str, extraction_data: dict[str, Any] | None = None
) -> bytes:
    """Create a DOCX document containing the image and extracted text content."""
    import io as _io

    try:
        from docx import Document as DocxDoc
        from docx.shared import Inches
    except ImportError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=("DOCX generation requires python-docx. Install with: pip install python-docx"),
        ) from exc

    doc = DocxDoc()
    doc.add_heading(title, level=1)
    doc.add_picture(_io.BytesIO(image_bytes), width=Inches(6))

    if extraction_data:
        _add_docx_extraction_content(doc, extraction_data)

    buf = _io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


@router.post(
    "/{document_id}/export/regions",
    status_code=status.HTTP_200_OK,
    summary="Export selected regions",
    responses={
        200: {"description": "Exported region content"},
        404: {"description": "Document not found"},
        400: {"description": "Document not processed or invalid request"},
    },
)
async def export_regions(
    document_id: str = Path(..., description="Document ID"),
    body: RegionExportRequest = Body(...),
    session: AsyncSession = Depends(get_session),
) -> Response:
    """Export selected rectangular regions from a document (PDF or image).

    Supports format-preserving export (PDF, DOCX, Markdown, Blog) using
    extracted layout data, or pixel-perfect image crops.
    """
    try:
        from src.services.layout.extractor import LayoutExtractor, is_image_file
        from src.services.layout.models import RegionSelector
        from src.services.storage.local import LocalStorageService

        repo = DocumentRepository(session)
        doc = await repo.get_by_id(uuid.UUID(document_id))

        if doc is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        if doc.status != ProcessingStatus.COMPLETED:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Document not processed. Current status: {doc.status.value}",
            )

        # Fetch file bytes from storage
        storage = LocalStorageService()
        result = await storage.download(doc.storage_path)
        file_bytes = result.content

        extractor = LayoutExtractor()

        # Convert Pydantic regions to dataclass regions
        regions = [
            RegionSelector(
                page_number=r.page_number,
                x0=r.x0,
                y0=r.y0,
                x1=r.x1,
                y1=r.y1,
                label=r.label,
            )
            for r in body.regions
        ]

        title = doc.filename or "Extracted Region"

        # Detect whether this is an image file
        doc_is_image = is_image_file(doc.filename or "")

        if doc_is_image:
            extraction = await repo.get_latest_extraction(doc.id)
            db_extraction_data = extraction.extracted_data if extraction else {}
            return _export_image_region(
                extractor,
                file_bytes,
                regions[0],
                body,
                title,
                db_extraction_data=db_extraction_data,
            )

        if body.format == "image":
            # Image crop: return first region as image
            image_bytes = extractor.crop_region_as_image(
                file_bytes, regions[0], dpi=body.image_dpi, fmt=body.image_format
            )
            return Response(
                content=image_bytes,
                media_type={
                    "png": "image/png",
                    "jpg": "image/jpeg",
                    "jpeg": "image/jpeg",
                    "webp": "image/webp",
                }.get(body.image_format, "image/png"),
                headers={
                    "Content-Disposition": f'attachment; filename="region.{body.image_format}"'
                },
            )

        # Layout-preserving export: extract layout then generate
        layout = extractor.extract_regions(file_bytes, regions)

        # DB extraction fallback: if no TableBlock was detected by find_tables(),
        # check DB extraction data for structured tables from council VLM
        from src.services.layout.models import TableBlock as LayoutTableBlock

        has_table = any(
            isinstance(b, LayoutTableBlock)
            for p in layout.pages
            for b in p.blocks
        )
        if not has_table:
            extraction = await repo.get_latest_extraction(doc.id)
            if extraction and extraction.extracted_data:
                db_tables = _extract_tables_from_db(extraction.extracted_data)
                if db_tables and layout.pages:
                    layout.pages[-1].blocks.extend(db_tables)

        # If PyMuPDF found no text (scanned PDF), enhance with council OCR
        if body.use_council and not _layout_has_text(layout):
            logger.info(
                "PyMuPDF extracted no text, running council OCR on regions",
                document_id=document_id,
                region_count=len(regions),
            )
            layout = await _enhance_layout_with_council(layout, file_bytes, regions, extractor)

        if body.format == "pdf":
            from src.services.generation.pdf import get_pdf_generator

            gen = get_pdf_generator()
            pdf_doc = gen.generate_from_layout(layout, title=title)
            return Response(
                content=pdf_doc.content_bytes or b"",
                media_type="application/pdf",
                headers={"Content-Disposition": f'attachment; filename="{title}_region.pdf"'},
            )

        if body.format == "docx":
            from src.services.generation.docx import get_docx_generator

            gen = get_docx_generator()
            docx_doc = gen.generate_from_layout(layout, title=title)
            return Response(
                content=docx_doc.content_bytes or b"",
                media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                headers={"Content-Disposition": f'attachment; filename="{title}_region.docx"'},
            )

        if body.format == "markdown":
            from src.services.generation.markdown import get_markdown_generator

            gen = get_markdown_generator()
            md_doc = gen.generate_from_layout(layout, title=title)
            return Response(
                content=md_doc.content.encode("utf-8"),
                media_type="text/markdown",
                headers={"Content-Disposition": f'attachment; filename="{title}_region.md"'},
            )

        if body.format == "blog":
            from src.services.generation.blog import BlogGenerator

            gen = BlogGenerator()
            blog_doc = gen.generate_from_layout(layout, title=title)
            return Response(
                content=blog_doc.content.encode("utf-8"),
                media_type="text/markdown",
                headers={"Content-Disposition": f'attachment; filename="{title}_blog.md"'},
            )

        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported format: {body.format}. Use pdf, docx, markdown, blog, or image.",
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error exporting regions", document_id=document_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Failed to export regions: {type(e).__name__}: {e!s}",
        ) from e


@router.get(
    "/{document_id}/pages/{page_number}/image",
    status_code=status.HTTP_200_OK,
    summary="Render page as image",
    responses={
        200: {"description": "Page image (PNG)"},
        404: {"description": "Document not found"},
    },
)
async def render_page_image(
    document_id: str = Path(..., description="Document ID"),
    page_number: int = Path(..., ge=0, description="0-indexed page number"),
    dpi: int = Query(150, ge=72, le=600, description="Image resolution"),
    session: AsyncSession = Depends(get_session),
) -> Response:
    """Render a single page as a PNG image for dashboard canvas display.

    For image documents, returns the raw image bytes (only page 0 is valid).
    For PDFs, renders the specified page at the requested DPI.
    """
    try:
        from src.services.layout.extractor import LayoutExtractor, is_image_file
        from src.services.storage.local import LocalStorageService

        repo = DocumentRepository(session)
        doc = await repo.get_by_id(uuid.UUID(document_id))

        if doc is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        storage = LocalStorageService()
        result = await storage.download(doc.storage_path)

        extractor = LayoutExtractor()

        if is_image_file(doc.filename or ""):
            if page_number != 0:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Image files only have page 0.",
                )
            image_bytes = extractor.render_image_as_png(result.content)
        else:
            image_bytes = extractor.render_page_as_image(result.content, page_number, dpi=dpi)

        return Response(
            content=image_bytes,
            media_type="image/png",
            headers={"Content-Disposition": f'inline; filename="page_{page_number}.png"'},
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Error rendering page image",
            document_id=document_id,
            page_number=page_number,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Failed to render page image",
        ) from e


@router.delete(
    "/{document_id}",
    response_model=DocumentDeleteResponse,
    status_code=status.HTTP_200_OK,
    summary="Delete document",
    responses={
        200: {"description": "Document deleted"},
        404: {"description": "Document not found"},
    },
)
async def delete_document(
    document_id: str = Path(..., description="Document ID"),
    session: AsyncSession = Depends(get_session),
) -> DocumentDeleteResponse:
    """Delete a document (soft-delete)."""
    try:
        repo = DocumentRepository(session)
        doc = await repo.soft_delete(uuid.UUID(document_id))

        if doc is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        logger.info("Document deleted", document_id=document_id)

        return DocumentDeleteResponse(
            document_id=document_id,
            deleted_at=datetime.utcnow(),
            success=True,
            message="Document deleted successfully",
        )

    except HTTPException:
        raise
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document not found: {document_id}",
        ) from None
    except Exception as e:
        logger.error(
            "Error deleting document",
            document_id=document_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to delete document",
        ) from e
