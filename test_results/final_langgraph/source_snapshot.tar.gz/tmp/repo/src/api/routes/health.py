"""Health check and status endpoints."""

from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from src.config.settings import Settings

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from src.config.settings import get_settings
from src.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(prefix="/health", tags=["Health"])


class HealthResponse(BaseModel):
    """Health check response model."""

    status: str = Field(..., description="Overall health status")
    timestamp: datetime = Field(..., description="Time of health check")
    version: str = Field(..., description="API version")
    environment: str = Field(..., description="Deployment environment")

    model_config = {
        "json_schema_extra": {
            "example": {
                "status": "healthy",
                "timestamp": "2025-01-29T16:30:00Z",
                "version": "1.0.0",
                "environment": "production",
            }
        }
    }


class ComponentStatus(BaseModel):
    """Status of a single component."""

    status: str = Field(..., description="Component status")
    message: str = Field(..., description="Status message")
    last_checked: datetime = Field(..., description="Last check time")
    details: dict[str, Any] = Field(default_factory=dict, description="Additional details")


class DetailedHealthResponse(BaseModel):
    """Detailed health check response with component status."""

    status: str = Field(..., description="Overall health status")
    timestamp: datetime = Field(..., description="Time of health check")
    version: str = Field(..., description="API version")
    environment: str = Field(..., description="Deployment environment")
    components: dict[str, ComponentStatus] = Field(..., description="Component health status")

    model_config = {
        "json_schema_extra": {
            "example": {
                "status": "healthy",
                "timestamp": "2025-01-29T16:30:00Z",
                "version": "1.0.0",
                "environment": "production",
                "components": {
                    "api": {
                        "status": "healthy",
                        "message": "API is running",
                        "last_checked": "2025-01-29T16:30:00Z",
                        "details": {},
                    }
                },
            }
        }
    }


def _get_council_status(settings: "Settings") -> ComponentStatus:
    """Build council component status from model download state."""
    from src.services.models.status import get_model_status_service

    model_svc = get_model_status_service()
    models = model_svc.get_all_status()
    downloaded_count = sum(1 for m in models if m.status.value in ("downloaded", "ready"))
    total = len(models)

    if downloaded_count == total:
        status_str = "healthy"
        message = f"{downloaded_count}/{total} models ready"
    elif downloaded_count > 0:
        status_str = "degraded"
        message = f"{downloaded_count}/{total} models ready"
    else:
        status_str = "degraded"
        message = "No models downloaded"

    return ComponentStatus(
        status=status_str,
        message=message,
        last_checked=datetime.utcnow(),
        details={
            "enabled_members": settings.enabled_council_members,
            "models": {m.key: m.status.value for m in models},
        },
    )


async def check_dependencies() -> dict[str, bool]:
    """
    Check critical dependencies.

    Returns:
        Dictionary of component status checks
    """
    try:
        # Add dependency checks as needed
        checks = {
            "api": True,
        }
        return checks
    except Exception as e:
        logger.error("Dependency check failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Service dependency check failed",
        ) from e


@router.get(
    "",
    response_model=HealthResponse,
    status_code=status.HTTP_200_OK,
    summary="Basic health check",
    description="Returns basic health status of the API.",
    responses={
        200: {"description": "API is healthy"},
        503: {"description": "API is unhealthy"},
    },
)
async def health_check() -> HealthResponse:
    """
    Basic health check endpoint.

    Returns:
        HealthResponse with current status
    """
    settings = get_settings()
    logger.debug("Health check requested")
    return HealthResponse(
        status="healthy",
        timestamp=datetime.utcnow(),
        version=settings.app.version,
        environment=settings.app.env,
    )


@router.get(
    "/ready",
    response_model=DetailedHealthResponse,
    status_code=status.HTTP_200_OK,
    summary="Readiness check",
    description="Returns detailed health status including component checks.",
    responses={
        200: {"description": "API is ready"},
        503: {"description": "API is not ready"},
    },
)
async def readiness_check(
    _deps: dict[str, bool] = Depends(check_dependencies),
) -> DetailedHealthResponse:
    """
    Readiness check with component status.

    Checks critical dependencies and components for readiness.

    Args:
        deps: Dependency check results

    Returns:
        DetailedHealthResponse with component status
    """
    settings = get_settings()
    logger.debug("Readiness check requested")

    # Component health checks
    components = {
        "api": ComponentStatus(
            status="healthy",
            message="API is running",
            last_checked=datetime.utcnow(),
            details={},
        ),
        "council": _get_council_status(settings),
    }

    # Determine overall status
    overall_status = "healthy"
    for component in components.values():
        if component.status != "healthy":
            overall_status = "degraded"
            break

    response = DetailedHealthResponse(
        status=overall_status,
        timestamp=datetime.utcnow(),
        version=settings.app.version,
        environment=settings.app.env,
        components=components,
    )

    # Return 503 if degraded
    if overall_status != "healthy":
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Service is not ready",
        )

    return response


@router.get(
    "/live",
    status_code=status.HTTP_200_OK,
    summary="Liveness check",
    description="Simple liveness probe for Kubernetes.",
    responses={
        200: {"description": "API is alive"},
    },
)
async def liveness_check() -> dict[str, str]:
    """
    Kubernetes liveness probe.

    Returns:
        Dictionary with alive status
    """
    logger.debug("Liveness check requested")
    return {"status": "alive"}
