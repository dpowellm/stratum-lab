"""
Audit Trail API Routes.

Provides endpoints for querying the immutable audit log.
"""

from datetime import UTC, datetime, timedelta
from typing import Any

from fastapi import APIRouter, Depends, Query
from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.middleware.auth import AuthUser, require_permission
from src.core.logging import get_logger
from src.models.database.audit import AuditLog
from src.models.database.base import get_session
from src.services.security.rbac import Permission

logger = get_logger(__name__)

router = APIRouter(prefix="/audit", tags=["Audit"])


@router.get("/logs")
async def list_audit_logs(
    event_type: str | None = Query(None, description="Filter by event type"),
    user_id: str | None = Query(None, description="Filter by user ID"),
    resource_type: str | None = Query(None, description="Filter by resource type"),
    resource_id: str | None = Query(None, description="Filter by resource ID"),
    severity: str | None = Query(None, description="Filter by severity"),
    hours: int = Query(24, ge=1, le=720, description="Lookback period in hours"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    user: AuthUser = Depends(require_permission(Permission.ADMIN_AUDIT)),  # noqa: ARG001
    session: AsyncSession = Depends(get_session),
) -> dict[str, Any]:
    """Query audit logs with filtering and pagination."""
    since = datetime.now(tz=UTC) - timedelta(hours=hours)

    query = select(AuditLog).where(
        AuditLog.created_at >= since,
        AuditLog.is_deleted == False,  # noqa: E712
    )

    if event_type:
        query = query.where(AuditLog.event_type == event_type)
    if user_id:
        query = query.where(AuditLog.user_id == user_id)
    if resource_type:
        query = query.where(AuditLog.resource_type == resource_type)
    if resource_id:
        query = query.where(AuditLog.resource_id == resource_id)
    if severity:
        query = query.where(AuditLog.severity == severity)

    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total = (await session.execute(count_query)).scalar() or 0

    # Paginate
    query = query.order_by(desc(AuditLog.created_at))
    query = query.offset((page - 1) * page_size).limit(page_size)

    result = await session.execute(query)
    logs = result.scalars().all()

    return {
        "logs": [
            {
                "id": str(log.id),
                "event_type": log.event_type,
                "action": log.action,
                "outcome": log.outcome,
                "severity": log.severity,
                "user_id": log.user_id,
                "username": log.username,
                "ip_address": log.ip_address,
                "resource_type": log.resource_type,
                "resource_id": log.resource_id,
                "details": log.details,
                "created_at": log.created_at.isoformat() if log.created_at else None,
            }
            for log in logs
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.get("/summary")
async def audit_summary(
    hours: int = Query(24, ge=1, le=720, description="Lookback period in hours"),
    user: AuthUser = Depends(require_permission(Permission.ADMIN_AUDIT)),  # noqa: ARG001
    session: AsyncSession = Depends(get_session),
) -> dict[str, Any]:
    """Get a summary of audit events over a period."""
    since = datetime.now(tz=UTC) - timedelta(hours=hours)

    # Count by event type
    type_query = (
        select(AuditLog.event_type, func.count().label("count"))
        .where(AuditLog.created_at >= since)
        .group_by(AuditLog.event_type)
    )
    type_result = await session.execute(type_query)
    by_type = {row.event_type: row.count for row in type_result}

    # Count by severity
    sev_query = (
        select(AuditLog.severity, func.count().label("count"))
        .where(AuditLog.created_at >= since)
        .group_by(AuditLog.severity)
    )
    sev_result = await session.execute(sev_query)
    by_severity = {row.severity: row.count for row in sev_result}

    # Count by outcome
    outcome_query = (
        select(AuditLog.outcome, func.count().label("count"))
        .where(AuditLog.created_at >= since)
        .group_by(AuditLog.outcome)
    )
    outcome_result = await session.execute(outcome_query)
    by_outcome = {row.outcome: row.count for row in outcome_result}

    total = sum(by_type.values())

    return {
        "period_hours": hours,
        "total_events": total,
        "by_event_type": by_type,
        "by_severity": by_severity,
        "by_outcome": by_outcome,
    }
