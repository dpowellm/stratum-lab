"""
Authentication API routes.

Provides endpoints for user authentication, token management,
and API key operations.
"""

from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from src.api.middleware.auth import (
    AuthUser,
    create_access_token,
    create_refresh_token,
    decode_token,
    get_current_user,
    register_api_key,
    require_permission,
)
from src.core.logging import get_logger
from src.services.security.rbac import Permission, get_rbac_manager

logger = get_logger(__name__)

router = APIRouter(prefix="/auth", tags=["Authentication"])


class LoginRequest(BaseModel):
    """Login request body."""

    username: str
    password: str


class TokenResponse(BaseModel):
    """Token response."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"  # noqa: S105
    expires_in: int = 3600


class RefreshRequest(BaseModel):
    """Token refresh request."""

    refresh_token: str


class ApiKeyRequest(BaseModel):
    """API key creation request."""

    name: str
    permissions: list[str] | None = None


class ApiKeyResponse(BaseModel):
    """API key creation response."""

    key: str
    name: str
    message: str = "Store this key securely. It cannot be retrieved again."


@router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest):
    """
    Authenticate user and return access + refresh tokens.

    In development mode, accepts any credentials and creates a dev user.
    In production, validates against the RBAC user store.
    """
    from src.config.settings import get_settings

    settings = get_settings()
    rbac = get_rbac_manager()

    # Look up user
    user = rbac.get_user_by_username(request.username)

    if settings.is_development and not user:
        # Dev mode: auto-create user
        user = rbac.create_user(
            username=request.username,
            email=f"{request.username}@dev.local",
            roles=["admin"],
            is_admin=True,
        )
        logger.info("Dev mode: auto-created user", username=request.username)

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is disabled",
        )

    # Update last login
    user.last_login = datetime.now(tz=UTC)

    # Create tokens
    access_token = create_access_token(
        user_id=user.user_id,
        username=user.username,
        roles=list(user.roles),
        is_admin=user.is_admin,
    )
    refresh_token = create_refresh_token(
        user_id=user.user_id,
        username=user.username,
    )

    logger.info("User logged in", username=user.username, user_id=user.user_id)

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(request: RefreshRequest):
    """Refresh an access token using a refresh token."""
    token_data = decode_token(request.refresh_token)

    if token_data.token_type != "refresh":  # noqa: S105
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid token type, expected refresh token",
        )

    access_token = create_access_token(
        user_id=token_data.sub,
        username=token_data.username,
        roles=token_data.roles,
        is_admin=token_data.is_admin,
    )
    new_refresh = create_refresh_token(
        user_id=token_data.sub,
        username=token_data.username,
    )

    return TokenResponse(
        access_token=access_token,
        refresh_token=new_refresh,
    )


@router.get("/me")
async def get_me(user: AuthUser = Depends(get_current_user)):
    """Get current authenticated user info."""
    return {
        "user_id": user.user_id,
        "username": user.username,
        "roles": user.roles,
        "is_admin": user.is_admin,
        "permissions": user.permissions,
    }


@router.post("/api-keys", response_model=ApiKeyResponse)
async def create_api_key(
    request: ApiKeyRequest,
    user: AuthUser = Depends(require_permission(Permission.ADMIN_SECURITY)),
):
    """Create a new API key for service-to-service authentication."""
    import secrets

    key = f"ade_{secrets.token_urlsafe(32)}"
    register_api_key(key, request.name, request.permissions)

    logger.info(
        "API key created",
        key_name=request.name,
        created_by=user.username,
    )

    return ApiKeyResponse(key=key, name=request.name)
