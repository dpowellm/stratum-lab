"""
FastAPI application factory and main entry point.

This module provides the FastAPI application with:
- Application factory pattern
- Lifespan management (startup/shutdown)
- Middleware stack (CORS, GZip, Logging, Request ID)
- Router registration
- OpenAPI documentation
"""

import asyncio
import uuid
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import ORJSONResponse

from src.config.settings import get_settings
from src.core.logging import clear_context, configure_logging, get_logger, set_request_id
from src.models.database.base import close_db, init_db

# Configure logging on module load
configure_logging()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Application lifespan manager.

    Handles startup and shutdown events for the FastAPI application.
    Manages database initialization and cleanup.
    """
    settings = get_settings()
    logger.info(
        "Starting application",
        app_name=settings.app.name,
        version=settings.app.version,
        environment=settings.app.env,
    )

    # Startup
    download_task: asyncio.Task[dict[str, bool]] | None = None
    warmup_task: asyncio.Task[dict[str, bool]] | None = None
    try:
        # Initialize database
        if settings.is_development:
            await init_db()
            logger.info("Database initialized")

        # Check for already-downloaded models and launch background download
        from src.services.models.downloader import download_all_models
        from src.services.models.status import get_model_status_service

        model_svc = get_model_status_service()
        model_svc.check_downloaded()
        download_task = asyncio.create_task(download_all_models(model_svc))
        logger.info("Model download task launched in background")

        # Warm up council members sequentially in the background.
        # This loads models one at a time (not all at once) to avoid OOM.
        from src.council.members.factory import warmup_members

        warmup_task = asyncio.create_task(warmup_members(settings))
        logger.info("Council member warmup task launched in background")

        logger.info("Application startup complete")
        yield
    finally:
        # Shutdown
        logger.info("Shutting down application")
        if download_task and not download_task.done():
            download_task.cancel()
        if warmup_task and not warmup_task.done():
            warmup_task.cancel()
        await close_db()
        logger.info("Application shutdown complete")


def _mount_frontend(app: FastAPI) -> None:
    """
    Mount the React frontend static files if the build exists.

    Serves the built frontend from frontend/dist/, with a catch-all
    fallback to index.html for SPA client-side routing.
    """
    import pathlib

    from fastapi.responses import FileResponse
    from fastapi.staticfiles import StaticFiles

    dist_dir = pathlib.Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"
    if not dist_dir.is_dir():
        logger.info("Frontend build not found, skipping static file mount", path=str(dist_dir))
        return

    index_html = dist_dir / "index.html"
    if not index_html.is_file():
        logger.warning("Frontend dist exists but index.html missing", path=str(dist_dir))
        return

    # Mount static assets (JS, CSS, images)
    assets_dir = dist_dir / "assets"
    if assets_dir.is_dir():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="frontend-assets")

    # Catch-all route for SPA fallback - must be registered last
    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_spa(full_path: str) -> FileResponse:
        """Serve index.html for all non-API routes (SPA fallback)."""
        # Check if this is a static file in dist
        file_path = dist_dir / full_path
        if file_path.is_file() and not full_path.startswith("api/"):
            return FileResponse(str(file_path))
        return FileResponse(str(index_html))

    logger.info("Frontend mounted", dist=str(dist_dir))


def create_app() -> FastAPI:
    """
    Create and configure the FastAPI application.

    Returns:
        FastAPI: Configured application instance
    """
    settings = get_settings()

    app = FastAPI(
        title="Agentic Document Extraction API",
        description="Enterprise-grade document extraction with LLM Council Architecture",
        version=settings.app.version,
        docs_url="/docs" if settings.app.debug else None,
        redoc_url="/redoc" if settings.app.debug else None,
        openapi_url="/openapi.json" if settings.app.debug else None,
        default_response_class=ORJSONResponse,
        lifespan=lifespan,
    )

    # Configure middleware
    configure_middleware(app)

    # Register routes
    register_routes(app)

    # Mount frontend static files (if built)
    _mount_frontend(app)

    return app


def configure_middleware(app: FastAPI) -> None:
    """
    Configure application middleware stack.

    Sets up CORS, compression, rate limiting, request ID tracking, and logging.

    Args:
        app: FastAPI application instance
    """
    settings = get_settings()

    # Rate limiting
    from src.api.middleware.rate_limit import configure_rate_limiter

    configure_rate_limiter(app)

    # CORS middleware — restrict methods/headers, enforce configured origins
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors.origins,
        allow_credentials=settings.cors.allow_credentials,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=[
            "Authorization",
            "Content-Type",
            "X-Request-ID",
            "X-API-Key",
            "Accept",
        ],
        expose_headers=["X-Request-ID"],
    )

    # GZip middleware for response compression
    app.add_middleware(GZipMiddleware, minimum_size=1000)

    # Request ID middleware - adds unique ID to each request
    @app.middleware("http")
    async def request_id_middleware(request: Request, call_next) -> Response:
        """Add request ID to all requests for tracking."""
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        set_request_id(request_id)

        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id

        clear_context()
        return response

    # Logging middleware - logs all requests and responses
    @app.middleware("http")
    async def logging_middleware(request: Request, call_next) -> Response:
        """Log all requests and responses."""
        logger.info(
            "Request started",
            method=request.method,
            path=request.url.path,
            client_host=request.client.host if request.client else None,
        )

        response = await call_next(request)

        logger.info(
            "Request completed",
            method=request.method,
            path=request.url.path,
            status_code=response.status_code,
        )

        return response


def register_routes(app: FastAPI) -> None:
    """
    Register all application routes.

    Includes routers for health checks, documents, extractions, and council.

    Args:
        app: FastAPI application instance
    """
    from src.api.routes.audit import router as audit_router
    from src.api.routes.auth import router as auth_router
    from src.api.routes.council import router as council_router
    from src.api.routes.documents import router as documents_router
    from src.api.routes.extraction import router as extraction_router
    from src.api.routes.guardrails import router as guardrails_router
    from src.api.routes.health import router as health_router
    from src.api.routes.hitl import router as hitl_router
    from src.api.routes.metrics import router as metrics_router
    from src.api.routes.models import router as models_router
    from src.api.routes.qa import router as qa_router

    # Register auth routes (no auth required)
    app.include_router(auth_router, prefix="/api/v1")

    # Register health routes
    app.include_router(health_router, prefix="/api/v1")

    # Register metrics route (Prometheus scraping, no prefix)
    app.include_router(metrics_router)

    # Register audit routes
    app.include_router(audit_router, prefix="/api/v1")

    # Register document routes
    app.include_router(documents_router, prefix="/api/v1")

    # Register extraction routes
    app.include_router(extraction_router, prefix="/api/v1")

    # Register council routes
    app.include_router(council_router, prefix="/api/v1")

    # Register HITL review routes
    app.include_router(hitl_router, prefix="/api/v1")

    # Register Q&A routes
    app.include_router(qa_router, prefix="/api/v1")

    # Register guardrails & evals routes
    app.include_router(guardrails_router, prefix="/api/v1")

    # Register model status routes
    app.include_router(models_router, prefix="/api/v1")

    # Root endpoint -- only when frontend is not built (SPA serves / instead)
    import pathlib

    dist_dir = pathlib.Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"
    if not (dist_dir / "index.html").is_file():

        @app.get(
            "/",
            tags=["Root"],
            summary="API root",
            description="Root endpoint with API information and documentation links.",
        )
        async def root() -> dict:
            """
            Root endpoint with API information.

            Returns:
                Dictionary with API metadata and documentation URLs
            """
            settings = get_settings()
            return {
                "name": "Agentic Document Extraction API",
                "version": settings.app.version,
                "environment": settings.app.env,
                "docs_url": "/docs" if settings.app.debug else None,
                "redoc_url": "/redoc" if settings.app.debug else None,
                "openapi_url": "/openapi.json" if settings.app.debug else None,
            }

    # Health endpoint at root level
    @app.get(
        "/health",
        tags=["Health"],
        summary="Quick health check",
        description="Quick health check endpoint at root level.",
    )
    async def quick_health() -> dict[str, str]:
        """
        Quick health check at root level.

        Returns:
            Dictionary with health status
        """
        return {"status": "healthy"}


# Create application instance
app = create_app()
