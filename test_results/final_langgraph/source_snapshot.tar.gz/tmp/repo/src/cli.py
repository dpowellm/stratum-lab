"""CLI entry point for the Agentic Document Extraction System.

Provides the `agentic-doc` command with subcommands for:
- serve: Run the FastAPI API server
- worker: Run Celery workers
- download-models: Download GGUF quantized models
- info: Show system and hardware information
"""

import argparse
import platform

import uvicorn

from src import __version__


def create_parser() -> argparse.ArgumentParser:
    """Create the CLI argument parser with all subcommands."""
    parser = argparse.ArgumentParser(
        prog="agentic-doc",
        description="Agentic Document Extraction System - LLM Council Architecture",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # serve
    serve_parser = subparsers.add_parser("serve", help="Run the API server")
    serve_parser.add_argument("--host", default="0.0.0.0", help="Bind host")
    serve_parser.add_argument("--port", type=int, default=8000, help="Bind port")
    serve_parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    serve_parser.add_argument("--workers", type=int, default=4, help="Number of workers")

    # worker
    worker_parser = subparsers.add_parser("worker", help="Run a Celery worker")
    worker_parser.add_argument(
        "--queue", default="default", help="Queue name (default, ingestion, council, indexing)"
    )
    worker_parser.add_argument("--concurrency", type=int, default=4, help="Worker concurrency")
    worker_parser.add_argument(
        "--loglevel", default="info", help="Log level (debug, info, warning, error)"
    )

    # download-models
    dl_parser = subparsers.add_parser("download-models", help="Download GGUF quantized models")
    dl_parser.add_argument(
        "--model", default="all", help="Model to download (all, qwen, olmocr, paddle, embedding)"
    )
    dl_parser.add_argument(
        "--quant", default="Q4_K_M", help="Quantization level (Q4_K_M, Q5_K_M, Q8_0, F16)"
    )
    dl_parser.add_argument("--cache-dir", default=None, help="Custom cache directory")

    # info
    subparsers.add_parser("info", help="Show system and hardware information")

    return parser


def run_serve(args: argparse.Namespace) -> None:
    """Run the FastAPI API server."""
    uvicorn.run(
        "src.api.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        workers=args.workers,
    )


def run_worker(args: argparse.Namespace) -> None:
    """Run a Celery worker."""
    from src.workers.celery_app import celery_app

    argv = [
        "worker",
        f"--loglevel={args.loglevel}",
        f"-Q{args.queue}",
        f"--concurrency={args.concurrency}",
    ]
    celery_app.worker_main(argv)


def run_download_models(args: argparse.Namespace) -> None:
    """Download GGUF quantized models."""
    from scripts.download_models import ModelDownloader

    downloader = ModelDownloader(quant=args.quant, cache_dir=args.cache_dir)
    if args.model == "all":
        downloader.download_all()
    else:
        downloader.download_gguf_model(args.model)


def get_system_info() -> dict:
    """Gather system and hardware information."""
    info = {
        "version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
    }

    try:
        import torch

        info["torch"] = torch.__version__
        info["cuda_available"] = torch.cuda.is_available()
        info["mps_available"] = torch.backends.mps.is_available()
        if torch.cuda.is_available():
            info["cuda_device"] = torch.cuda.get_device_name(0)
    except ImportError:
        info["torch"] = "not installed"

    try:
        from llama_cpp import __version__ as lcpp_version

        info["llama_cpp"] = lcpp_version
    except ImportError:
        info["llama_cpp"] = "not installed"

    return info


def run_info(_args: argparse.Namespace) -> None:
    """Display system information."""
    info = get_system_info()
    print("Agentic Document Extraction System")
    print("=" * 40)
    for key, value in info.items():
        print(f"  {key}: {value}")


def main() -> None:
    """CLI main entry point."""
    parser = create_parser()
    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        raise SystemExit(1)

    commands = {
        "serve": run_serve,
        "worker": run_worker,
        "download-models": run_download_models,
        "info": run_info,
    }

    handler = commands.get(args.command)
    if handler:
        handler(args)
    else:
        parser.print_help()
        raise SystemExit(1)


if __name__ == "__main__":
    main()
