"""
Application settings management using Pydantic Settings.

This module provides centralized configuration management with:
- Environment variable support
- Type validation
- Default values
- Production validation
- Cached settings for performance
"""

from functools import lru_cache
from typing import Literal

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppSettings(BaseSettings):
    """Application-level settings."""

    name: str = Field(default="agentic-doc-extraction", description="Application name")
    version: str = Field(default="0.1.0", description="Application version")
    env: Literal["development", "staging", "production"] = Field(
        default="development", description="Environment name"
    )
    debug: bool = Field(default=True, description="Debug mode flag")
    secret_key: SecretStr = Field(
        default=SecretStr("dev-secret-key-change-in-production"),
        description="Secret key for encryption",
    )

    model_config = SettingsConfigDict(env_prefix="APP_")


class ServerSettings(BaseSettings):
    """API server settings."""

    host: str = Field(default="0.0.0.0", description="Server host")  # noqa: S104
    port: int = Field(default=8000, ge=1, le=65535, description="Server port")
    workers: int = Field(default=4, ge=1, description="Number of workers")
    reload: bool = Field(default=True, description="Auto-reload on code changes")

    model_config = SettingsConfigDict(env_prefix="API_")


class DatabaseSettings(BaseSettings):
    """Database connection settings."""

    url: str = Field(
        default="postgresql+asyncpg://postgres:postgres@localhost:5432/agentic_doc",
        description="Database connection URL",
    )
    pool_size: int = Field(default=10, ge=1, description="Connection pool size")
    max_overflow: int = Field(default=20, ge=0, description="Max overflow connections")
    echo: bool = Field(default=False, description="Echo SQL queries")

    model_config = SettingsConfigDict(env_prefix="DATABASE_")


class RedisSettings(BaseSettings):
    """Redis connection settings."""

    url: str = Field(default="redis://localhost:6379/0", description="Redis connection URL")
    max_connections: int = Field(default=20, ge=1, description="Max connections")

    model_config = SettingsConfigDict(env_prefix="REDIS_")


class CelerySettings(BaseSettings):
    """Celery task queue settings."""

    broker_url: str = Field(
        default="amqp://guest:guest@localhost:5672//",
        description="Celery broker URL",
    )
    result_backend: str = Field(
        default="redis://localhost:6379/1", description="Result backend URL"
    )

    model_config = SettingsConfigDict(env_prefix="CELERY_")


class S3Settings(BaseSettings):
    """S3/MinIO storage settings."""

    endpoint_url: str = Field(default="http://localhost:9000", description="S3 endpoint URL")
    access_key: SecretStr = Field(default=SecretStr("minioadmin"), description="Access key")
    secret_key: SecretStr = Field(default=SecretStr("minioadmin"), description="Secret key")
    bucket_name: str = Field(default="documents", description="Default bucket name")
    region: str = Field(default="us-east-1", description="S3 region")

    model_config = SettingsConfigDict(env_prefix="S3_")


class QdrantSettings(BaseSettings):
    """Qdrant vector database settings."""

    host: str = Field(default="localhost", description="Qdrant host")
    port: int = Field(default=6333, ge=1, le=65535, description="Qdrant port")
    collection_name: str = Field(default="documents", description="Collection name")
    vector_size: int = Field(default=1024, ge=1, description="Vector dimension size")
    visual_vector_size: int = Field(
        default=128, ge=1, description="Visual embedding dimension (ColPali)"
    )
    enable_visual_search: bool = Field(default=True, description="Enable ColPali visual search")
    distance: Literal["Cosine", "Euclid", "Dot"] = Field(
        default="Cosine", description="Distance metric"
    )

    model_config = SettingsConfigDict(env_prefix="QDRANT_")


class CouncilSettings(BaseSettings):
    """LLM Council configuration settings."""

    # Council mode: "auto" tries real members first then falls back to mock,
    # "mock" always uses mock members, "gguf"/"api" force those backends.
    council_mode: Literal["auto", "mock", "gguf", "api"] = Field(
        default="auto", description="Council member backend mode"
    )

    # Council member toggles
    paddle_ocr_enabled: bool = Field(default=True, description="Enable PaddleOCR")
    olmocr_enabled: bool = Field(default=True, description="Enable olmOCR")
    qwen_enabled: bool = Field(default=True, description="Enable Qwen VLM")
    colpali_enabled: bool = Field(default=True, description="Enable ColPali VLM")

    # Consensus thresholds
    consensus_threshold: float = Field(
        default=0.85, ge=0.0, le=1.0, description="Consensus threshold"
    )
    unanimous_threshold: float = Field(
        default=0.95, ge=0.0, le=1.0, description="Unanimous consensus threshold"
    )
    min_confidence: float = Field(
        default=0.60, ge=0.0, le=1.0, description="Minimum confidence score"
    )

    # Model paths and keys
    paddle_ocr_model_dir: str | None = Field(
        default=None, description="PaddleOCR custom model directory"
    )
    olmocr_gguf_path: str | None = Field(default=None, description="olmOCR GGUF model file path")
    olmocr_api_key: str | None = Field(default=None, description="olmOCR API key")
    qwen_gguf_path: str | None = Field(default=None, description="Qwen GGUF model file path")
    qwen_vllm_url: str | None = Field(default=None, description="Qwen vLLM server URL")
    olmocr_vllm_url: str | None = Field(default=None, description="olmOCR vLLM server URL")
    colpali_gguf_path: str | None = Field(default=None, description="ColPali GGUF model file path")

    # Expertise weights
    weight_paddle_tables: float = Field(
        default=0.50, ge=0.0, le=1.0, description="PaddleOCR weight for tables"
    )
    weight_paddle_multilingual: float = Field(
        default=0.60, ge=0.0, le=1.0, description="PaddleOCR weight for multilingual"
    )
    weight_olmocr_long_docs: float = Field(
        default=0.60, ge=0.0, le=1.0, description="olmOCR weight for long documents"
    )
    weight_qwen_charts: float = Field(
        default=0.70, ge=0.0, le=1.0, description="Qwen weight for charts"
    )
    weight_qwen_complex_layout: float = Field(
        default=0.60, ge=0.0, le=1.0, description="Qwen weight for complex layouts"
    )
    weight_colpali_visual_docs: float = Field(
        default=0.75, ge=0.0, le=1.0, description="ColPali weight for visual documents"
    )
    weight_colpali_complex_layout: float = Field(
        default=0.70, ge=0.0, le=1.0, description="ColPali weight for complex layouts"
    )

    model_config = SettingsConfigDict(env_prefix="COUNCIL_")


class JudgeSettings(BaseSettings):
    """Judge model settings for conflict resolution."""

    provider: Literal["anthropic", "openai"] = Field(
        default="anthropic", description="Judge model provider"
    )
    anthropic_api_key: SecretStr = Field(default=SecretStr(""), description="Anthropic API key")
    openai_api_key: SecretStr = Field(default=SecretStr(""), description="OpenAI API key")
    model_name: str = Field(default="claude-3-5-sonnet-20241022", description="Judge model name")
    max_tokens: int = Field(default=4096, ge=1, description="Max tokens for response")
    temperature: float = Field(default=0.1, ge=0.0, le=2.0, description="Model temperature")

    model_config = SettingsConfigDict(env_prefix="JUDGE_")


class AgentSettings(BaseSettings):
    """Agent orchestration settings."""

    max_iterations: int = Field(default=10, ge=1, description="Max agent iterations")
    timeout_seconds: int = Field(default=300, ge=1, description="Agent timeout")
    checkpoint_enabled: bool = Field(default=True, description="Enable checkpointing")

    model_config = SettingsConfigDict(env_prefix="AGENT_")


class EmbeddingSettings(BaseSettings):
    """Embedding model settings."""

    model: str = Field(default="BAAI/bge-m3", description="Embedding model name")
    device: Literal["cpu", "cuda"] = Field(default="cpu", description="Device to use")

    model_config = SettingsConfigDict(env_prefix="EMBEDDING_")


class LoggingSettings(BaseSettings):
    """Logging configuration settings."""

    level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = Field(
        default="INFO", description="Log level"
    )
    format: Literal["json", "console"] = Field(default="json", description="Log format")
    file: str | None = Field(default=None, description="Log file path")

    model_config = SettingsConfigDict(env_prefix="LOG_")


class OtelSettings(BaseSettings):
    """OpenTelemetry settings."""

    enabled: bool = Field(default=True, description="Enable OpenTelemetry")
    service_name: str = Field(default="agentic-doc-extraction", description="Service name")
    exporter_endpoint: str = Field(
        default="http://localhost:4317", description="OTLP exporter endpoint"
    )

    model_config = SettingsConfigDict(env_prefix="OTEL_")


class CORSSettings(BaseSettings):
    """CORS configuration settings."""

    origins: list[str] = Field(
        default=[
            "http://localhost:3000",
            "http://localhost:5173",
            "http://localhost:8080",
        ],
        description="Allowed origins",
    )
    allow_credentials: bool = Field(default=True, description="Allow credentials")

    model_config = SettingsConfigDict(env_prefix="CORS_")


class HITLSettings(BaseSettings):
    """Human-in-the-Loop settings."""

    enabled: bool = Field(default=True, description="Enable HITL")
    confidence_threshold: float = Field(
        default=0.85, ge=0.0, le=1.0, description="Confidence threshold for HITL"
    )
    review_queue_max_size: int = Field(default=1000, ge=1, description="Max review queue size")
    auto_escalate_after_hours: int = Field(
        default=24, ge=1, description="Auto-escalate after hours"
    )

    model_config = SettingsConfigDict(env_prefix="HITL_")


class SecuritySettings(BaseSettings):
    """Security configuration settings."""

    jwt_algorithm: str = Field(default="HS256", description="JWT signing algorithm")
    access_token_expire_minutes: int = Field(
        default=60, ge=1, description="Access token expiry in minutes"
    )
    refresh_token_expire_days: int = Field(
        default=7, ge=1, description="Refresh token expiry in days"
    )
    rate_limit_default: str = Field(
        default="200/minute", description="Default rate limit per IP"
    )
    rate_limit_auth: str = Field(
        default="10/minute", description="Rate limit for auth endpoints"
    )
    rate_limit_upload: str = Field(
        default="20/minute", description="Rate limit for upload endpoints"
    )

    model_config = SettingsConfigDict(env_prefix="SECURITY_")


class Settings(BaseSettings):
    """
    Main settings class that combines all configuration categories.

    Usage:
        settings = get_settings()
        print(settings.app.name)
        print(settings.database.url)
    """

    app: AppSettings = Field(default_factory=AppSettings)
    server: ServerSettings = Field(default_factory=ServerSettings)
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    redis: RedisSettings = Field(default_factory=RedisSettings)
    celery: CelerySettings = Field(default_factory=CelerySettings)
    s3: S3Settings = Field(default_factory=S3Settings)
    qdrant: QdrantSettings = Field(default_factory=QdrantSettings)
    council: CouncilSettings = Field(default_factory=CouncilSettings)
    judge: JudgeSettings = Field(default_factory=JudgeSettings)
    agent: AgentSettings = Field(default_factory=AgentSettings)
    embedding: EmbeddingSettings = Field(default_factory=EmbeddingSettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    otel: OtelSettings = Field(default_factory=OtelSettings)
    cors: CORSSettings = Field(default_factory=CORSSettings)
    hitl: HITLSettings = Field(default_factory=HITLSettings)
    security: SecuritySettings = Field(default_factory=SecuritySettings)

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    @model_validator(mode="after")
    def validate_production_settings(self) -> "Settings":
        """Validate settings for production environment."""
        if self.app.env == "production":
            # Ensure debug is disabled
            if self.app.debug:
                raise ValueError("Debug mode must be disabled in production")

            # Ensure secret key is changed
            secret = self.app.secret_key.get_secret_value()
            if "dev-secret" in secret or "change" in secret.lower():
                raise ValueError("Secret key must be changed in production")

            # Ensure at least one council member is enabled
            if not any(
                [
                    self.council.paddle_ocr_enabled,
                    self.council.olmocr_enabled,
                    self.council.qwen_enabled,
                    self.council.colpali_enabled,
                ]
            ):
                raise ValueError("At least one council member must be enabled in production")

            # Ensure judge API key is set
            if (
                self.judge.provider == "anthropic"
                and not self.judge.anthropic_api_key.get_secret_value()
            ):
                raise ValueError("Anthropic API key required in production")
            elif (
                self.judge.provider == "openai" and not self.judge.openai_api_key.get_secret_value()
            ):
                raise ValueError("OpenAI API key required in production")

        return self

    @property
    def is_development(self) -> bool:
        """Check if running in development environment."""
        return self.app.env == "development"

    @property
    def is_production(self) -> bool:
        """Check if running in production environment."""
        return self.app.env == "production"

    @property
    def enabled_council_members(self) -> list[str]:
        """Get list of enabled council members."""
        members = []
        if self.council.paddle_ocr_enabled:
            members.append("paddle_ocr")
        if self.council.olmocr_enabled:
            members.append("olmocr")
        if self.council.qwen_enabled:
            members.append("qwen")
        if self.council.colpali_enabled:
            members.append("colpali")
        return members


@lru_cache
def get_settings() -> Settings:
    """
    Get cached settings instance.

    This function returns a cached Settings instance for performance.
    The cache is invalidated when the process restarts.

    Returns:
        Settings: Application settings instance

    Example:
        settings = get_settings()
        print(settings.database.url)
    """
    return Settings()


def clear_settings_cache() -> None:
    """Clear the settings cache. Useful for testing."""
    get_settings.cache_clear()
