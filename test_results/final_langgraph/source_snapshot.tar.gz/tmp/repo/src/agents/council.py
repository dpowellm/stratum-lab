"""Council Agent for coordinating LLM council extraction.

The Council Agent orchestrates the extraction process across
multiple OCR/VLM models and manages the consensus-building process.
"""

import asyncio
import time
from typing import Any

from src.agents.state import (
    AgentState,
    ConflictResolution,
    CouncilVote,
    ExtractionField,
    ProcessingStage,
)
from src.core.logging import get_logger
from src.council.consensus import (
    ConflictLevel,
    ConsensusEngine,
    MemberVote,
    VotingStrategy,
)

logger = get_logger(__name__)


class CouncilAgent:
    """Council Agent for coordinating extraction across council members."""

    def __init__(
        self,
        consensus_engine: ConsensusEngine | None = None,
    ):
        """Initialize Council Agent.

        Args:
            consensus_engine: Consensus engine instance (creates default if None)
        """
        self._consensus_engine = consensus_engine or ConsensusEngine()
        self._members = {}  # Will be populated with council member instances

    async def extract(self, state: AgentState) -> AgentState:
        """Run extraction across council members.

        Args:
            state: Current agent state

        Returns:
            Updated state with council votes
        """
        start_time = time.time()

        logger.info(
            "Starting council extraction",
            session_id=state.session_id,
            members=state.processing_plan.get("council_members", []),
        )

        state.update_stage(ProcessingStage.COUNCIL_VOTING)

        try:
            # Get council members to use
            member_names = state.processing_plan.get(
                "council_members",
                ["paddle_ocr", "olmocr", "qwen_vlm", "colpali"],
            )

            # Run extraction in parallel across all members
            tasks = []
            for member_name in member_names:
                task = self._extract_with_member(
                    member_name=member_name,
                    state=state,
                )
                tasks.append(task)

            # Wait for all extractions
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Process results and collect votes
            for result in results:
                if isinstance(result, Exception):
                    logger.error(f"Member extraction failed: {result}")
                    state.metrics.errors.append(str(result))
                    continue

                # Add votes to state
                for vote in result:
                    state.council_votes.append(vote)

            elapsed_ms = int((time.time() - start_time) * 1000)
            state.update_stage(ProcessingStage.CONSENSUS_BUILDING, elapsed_ms)

            logger.info(
                "Council voting completed",
                session_id=state.session_id,
                total_votes=len(state.council_votes),
                elapsed_ms=elapsed_ms,
            )

            return state

        except Exception as e:
            logger.error(
                "Council extraction failed",
                session_id=state.session_id,
                error=str(e),
            )
            state.add_error(f"Council extraction failed: {e}")
            return state

    async def build_consensus(self, state: AgentState) -> AgentState:
        """Build consensus from council votes.

        Args:
            state: State with council votes

        Returns:
            Updated state with consensus results
        """
        start_time = time.time()

        logger.info(
            "Building consensus",
            session_id=state.session_id,
            total_votes=len(state.council_votes),
        )

        try:
            # Group votes by field
            votes_by_field: dict[str, dict[str, MemberVote]] = {}

            for vote in state.council_votes:
                if vote.field_name not in votes_by_field:
                    votes_by_field[vote.field_name] = {}

                votes_by_field[vote.field_name][vote.member_name] = MemberVote(
                    member_name=vote.member_name,
                    value=vote.value,
                    confidence=vote.confidence,
                )

            # Calculate consensus
            voting_strategy = VotingStrategy(state.voting_strategy)

            consensus_result = self._consensus_engine.calculate_consensus(
                session_id=state.session_id,
                member_results={},
                extracted_fields=votes_by_field,
                voting_strategy=voting_strategy,
                critical_fields=state.critical_fields,
            )

            # Convert consensus to extracted fields
            for field_consensus in consensus_result.fields:
                state.extracted_fields.append(
                    ExtractionField(
                        name=field_consensus.field_name,
                        value=field_consensus.final_value,
                        confidence=field_consensus.confidence,
                        source=field_consensus.source_member or "consensus",
                        alternatives=[
                            {
                                "value": alt["value"],
                                "member": alt.get("member"),
                                "confidence": alt.get("confidence"),
                            }
                            for alt in field_consensus.alternative_values
                        ],
                    )
                )

                # Record conflict resolutions
                if field_consensus.conflict_level != ConflictLevel.NONE:
                    state.conflict_resolutions.append(
                        ConflictResolution(
                            field_name=field_consensus.field_name,
                            final_value=field_consensus.final_value,
                            resolved_by="consensus"
                            if field_consensus.conflict_level == ConflictLevel.MINOR
                            else "pending",
                            confidence=field_consensus.confidence,
                            reasoning=f"Conflict level: {field_consensus.conflict_level.value}",
                        )
                    )

            state.confidence_score = consensus_result.consensus_score

            # Check if judge is needed
            if consensus_result.requires_judge:
                state.update_stage(ProcessingStage.JUDGE_REVIEWING)
            else:
                state.update_stage(ProcessingStage.VALIDATING)

            elapsed_ms = int((time.time() - start_time) * 1000)

            logger.info(
                "Consensus built",
                session_id=state.session_id,
                consensus_score=consensus_result.consensus_score,
                agreed_fields=consensus_result.agreed_fields,
                disputed_fields=consensus_result.disputed_fields,
                requires_judge=consensus_result.requires_judge,
                elapsed_ms=elapsed_ms,
            )

            return state

        except Exception as e:
            logger.error(
                "Consensus building failed",
                session_id=state.session_id,
                error=str(e),
            )
            state.add_error(f"Consensus building failed: {e}")
            return state

    async def _extract_with_member(
        self,
        member_name: str,
        state: AgentState,
    ) -> list[CouncilVote]:
        """Run extraction with a single council member.

        Args:
            member_name: Name of the council member
            state: Current agent state

        Returns:
            List of votes from this member
        """
        start_time = time.time()
        votes = []

        logger.info(
            f"Extracting with {member_name}",
            session_id=state.session_id,
        )

        try:
            # Get or create member instance
            member = await self._get_member(member_name)

            if not member:
                logger.warning(f"Member {member_name} not available")
                return votes

            # Run extraction
            result = await member.extract(
                image_data=state.raw_image_data,
                document_type=state.document.classification.value if state.document else None,
                target_fields=state.target_fields,
            )

            # Convert to votes
            for field in result.fields:
                votes.append(
                    CouncilVote(
                        member_name=member_name,
                        field_name=field.field_name,
                        value=field.value,
                        confidence=field.confidence,
                        processing_time_ms=result.processing_time_ms,
                    )
                )

            elapsed_ms = int((time.time() - start_time) * 1000)
            state.metrics.total_api_calls += 1

            logger.info(
                f"Extraction completed for {member_name}",
                session_id=state.session_id,
                num_fields=len(votes),
                elapsed_ms=elapsed_ms,
            )

            return votes

        except Exception as e:
            logger.error(
                f"Extraction failed for {member_name}",
                session_id=state.session_id,
                error=str(e),
            )
            return votes

    async def _get_member(self, member_name: str):
        """Get or create a council member instance."""
        if member_name not in self._members:
            # Lazy import and create members
            if member_name == "paddle_ocr":
                from src.council.members.paddle_ocr import PaddleOCRMember

                self._members[member_name] = PaddleOCRMember()

            elif member_name == "olmocr":
                from src.council.members.olmocr import OlmOCRMember

                self._members[member_name] = OlmOCRMember()

            elif member_name == "qwen_vlm":
                from src.council.members.qwen_vlm import QwenVLMMember

                self._members[member_name] = QwenVLMMember()

            elif member_name == "colpali":
                from src.council.members.colpali_vlm import ColPaliVLMMember

                self._members[member_name] = ColPaliVLMMember()

            # Initialize the member
            if member_name in self._members:
                await self._members[member_name].initialize()

        return self._members.get(member_name)


class JudgeAgent:
    """Agent for invoking the judge model on conflicts."""

    def __init__(self, judge_interface=None):
        """Initialize Judge Agent.

        Args:
            judge_interface: Judge interface instance
        """
        self._judge = judge_interface

    async def resolve_conflicts(self, state: AgentState) -> AgentState:
        """Resolve conflicts using the judge model.

        Args:
            state: State with unresolved conflicts

        Returns:
            Updated state with judge decisions
        """
        start_time = time.time()

        logger.info(
            "Invoking judge for conflict resolution",
            session_id=state.session_id,
        )

        try:
            # Get pending conflicts
            pending_conflicts = [
                r for r in state.conflict_resolutions if r.resolved_by == "pending"
            ]

            if not pending_conflicts:
                state.update_stage(ProcessingStage.VALIDATING)
                return state

            # Build conflict contexts
            from src.council.judge import ConflictContext, ConflictLevel

            contexts = []
            for conflict in pending_conflicts:
                # Get votes for this field
                votes = state.get_votes_for_field(conflict.field_name)
                member_votes = {
                    v.member_name: MemberVote(v.member_name, v.value, v.confidence) for v in votes
                }

                contexts.append(
                    ConflictContext(
                        field_name=conflict.field_name,
                        member_votes=member_votes,
                        conflict_level=ConflictLevel.MODERATE,
                        is_critical=conflict.field_name in state.critical_fields,
                        image_data=state.raw_image_data,
                    )
                )

            # Resolve with judge
            if self._judge:
                result = await self._judge.resolve_conflicts(
                    session_id=state.session_id,
                    conflicts=contexts,
                )

                # Update state with judge decisions
                for decision in result.decisions:
                    # Update the conflict resolution
                    for i, conflict in enumerate(state.conflict_resolutions):
                        if conflict.field_name == decision.field_name:
                            state.conflict_resolutions[i] = ConflictResolution(
                                field_name=decision.field_name,
                                final_value=decision.final_value,
                                resolved_by="judge",
                                confidence=decision.confidence,
                                reasoning=decision.reasoning,
                            )

                    # Update the extracted field
                    for field in state.extracted_fields:
                        if field.name == decision.field_name:
                            field.value = decision.final_value
                            field.confidence = decision.confidence
                            field.source = "judge"

                    # Check for human review
                    if decision.requires_human_review:
                        state.human_review_fields.append(decision.field_name)

                if state.human_review_fields:
                    state.mark_for_human_review(
                        "Judge escalated fields for human review",
                        state.human_review_fields,
                    )

            elapsed_ms = int((time.time() - start_time) * 1000)
            state.update_stage(ProcessingStage.VALIDATING, elapsed_ms)

            logger.info(
                "Judge resolution completed",
                session_id=state.session_id,
                elapsed_ms=elapsed_ms,
            )

            return state

        except Exception as e:
            logger.error(
                "Judge resolution failed",
                session_id=state.session_id,
                error=str(e),
            )
            state.add_error(f"Judge resolution failed: {e}")
            return state


# LangGraph node functions
async def council_extraction_node(state: dict[str, Any]) -> dict[str, Any]:
    """LangGraph node for council extraction."""
    from src.agents.state import dict_to_state, state_to_dict

    agent_state = dict_to_state(state)
    agent = CouncilAgent()

    updated_state = await agent.extract(agent_state)

    return state_to_dict(updated_state)


async def consensus_node(state: dict[str, Any]) -> dict[str, Any]:
    """LangGraph node for consensus building."""
    from src.agents.state import dict_to_state, state_to_dict

    agent_state = dict_to_state(state)
    agent = CouncilAgent()

    updated_state = await agent.build_consensus(agent_state)

    return state_to_dict(updated_state)


async def judge_node(state: dict[str, Any]) -> dict[str, Any]:
    """LangGraph node for judge resolution."""
    from src.agents.state import dict_to_state, state_to_dict

    agent_state = dict_to_state(state)
    agent = JudgeAgent()

    updated_state = await agent.resolve_conflicts(agent_state)

    return state_to_dict(updated_state)
