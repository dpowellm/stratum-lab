"""LangGraph agents for document processing.

This module implements the agentic workflow using LangGraph:
- Planning Agent: Analyzes documents and creates extraction plans
- Council Agent: Coordinates LLM council extraction
- Validation Agent: Validates extracted fields
- Correction Agent: Fixes validation errors
- Orchestrator: Manages the workflow graph

The workflow processes documents through these stages:
1. Planning → Document classification and strategy
2. Council Extraction → Multi-model OCR/VLM extraction
3. Consensus → Vote aggregation and conflict detection
4. Judge (if needed) → Conflict resolution
5. Validation → Field validation
6. Correction (if needed) → Error fixing
7. Finalize → Output preparation
"""


# Lazy imports to avoid langgraph dependency when not needed
def __getattr__(name):
    """Lazy import for langgraph-dependent modules."""
    _langgraph_imports = {
        "AgentState",
        "ProcessingStage",
        "DocumentMetadata",
        "DocumentClassification",
        "ExtractionField",
        "CouncilVote",
        "ConflictResolution",
        "ValidationResult",
        "ProcessingMetrics",
        "PlanningAgent",
        "CouncilAgent",
        "JudgeAgent",
        "ValidationAgent",
        "CorrectionAgent",
        "DocumentExtractionOrchestrator",
        "create_orchestrator",
        "process_document",
        "create_extraction_workflow",
    }

    if name in _langgraph_imports:
        if name in {
            "AgentState",
            "ProcessingStage",
            "DocumentMetadata",
            "DocumentClassification",
            "ExtractionField",
            "CouncilVote",
            "ConflictResolution",
            "ValidationResult",
            "ProcessingMetrics",
        }:
            from src.agents import state

            return getattr(state, name)
        elif name == "PlanningAgent":
            from src.agents.planning import PlanningAgent

            return PlanningAgent
        elif name in {"CouncilAgent", "JudgeAgent"}:
            from src.agents import council

            return getattr(council, name)
        elif name == "ValidationAgent":
            from src.agents.validation import ValidationAgent

            return ValidationAgent
        elif name == "CorrectionAgent":
            from src.agents.correction import CorrectionAgent

            return CorrectionAgent
        elif name in {
            "DocumentExtractionOrchestrator",
            "create_orchestrator",
            "process_document",
            "create_extraction_workflow",
        }:
            from src.agents import orchestrator

            return getattr(orchestrator, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # State
    "AgentState",
    "ConflictResolution",
    "CorrectionAgent",
    "CouncilAgent",
    "CouncilVote",
    "DocumentClassification",
    # Orchestrator
    "DocumentExtractionOrchestrator",
    "DocumentMetadata",
    "ExtractionField",
    "JudgeAgent",
    # Agents
    "PlanningAgent",
    "ProcessingMetrics",
    "ProcessingStage",
    "ValidationAgent",
    "ValidationResult",
    "create_extraction_workflow",
    "create_orchestrator",
    "process_document",
]
