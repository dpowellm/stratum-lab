"""Agent Orchestrator using LangGraph.

The orchestrator builds and manages the LangGraph workflow
for document processing, coordinating all agents.
"""

from typing import Any, Literal

from langgraph.graph import END, StateGraph

from src.agents.correction import correction_node
from src.agents.council import (
    consensus_node,
    council_extraction_node,
    judge_node,
)
from src.agents.planning import planning_node
from src.agents.state import (
    ProcessingStage,
)
from src.agents.validation import validation_node
from src.core.logging import get_logger

logger = get_logger(__name__)


# State type for LangGraph
GraphState = dict[str, Any]


def create_extraction_workflow() -> StateGraph:
    """Create the document extraction workflow graph.

    The workflow follows this structure:
    1. Planning → Determines extraction strategy
    2. Council Extraction → Runs OCR/VLM models
    3. Consensus → Builds agreement from votes
    4. Judge (conditional) → Resolves conflicts
    5. Validation → Validates extracted fields
    6. Correction (conditional) → Fixes validation errors
    7. Complete or Human Review

    Returns:
        StateGraph for the extraction workflow
    """
    # Create the graph
    workflow = StateGraph(GraphState)

    # Add nodes
    workflow.add_node("planning", planning_node)
    workflow.add_node("council_extraction", council_extraction_node)
    workflow.add_node("consensus", consensus_node)
    workflow.add_node("judge", judge_node)
    workflow.add_node("validation", validation_node)
    workflow.add_node("correction", correction_node)
    workflow.add_node("finalize", finalize_node)

    # Set entry point
    workflow.set_entry_point("planning")

    # Add edges
    workflow.add_edge("planning", "council_extraction")
    workflow.add_edge("council_extraction", "consensus")

    # Conditional edge after consensus
    workflow.add_conditional_edges(
        "consensus",
        route_after_consensus,
        {
            "judge": "judge",
            "validation": "validation",
            "human_review": "finalize",
        },
    )

    workflow.add_edge("judge", "validation")

    # Conditional edge after validation
    workflow.add_conditional_edges(
        "validation",
        route_after_validation,
        {
            "correction": "correction",
            "complete": "finalize",
            "human_review": "finalize",
        },
    )

    # Conditional edge after correction
    workflow.add_conditional_edges(
        "correction",
        route_after_correction,
        {
            "complete": "finalize",
            "human_review": "finalize",
        },
    )

    workflow.add_edge("finalize", END)

    return workflow


def route_after_consensus(state: GraphState) -> Literal["judge", "validation", "human_review"]:
    """Route after consensus building."""
    stage = state.get("stage", "")

    if stage == ProcessingStage.JUDGE_REVIEWING.value:
        return "judge"
    elif stage == ProcessingStage.HUMAN_REVIEW.value:
        return "human_review"
    else:
        return "validation"


def route_after_validation(state: GraphState) -> Literal["correction", "complete", "human_review"]:
    """Route after validation."""
    if state.get("requires_human_review", False):
        return "human_review"
    elif state.get("requires_correction", False):
        return "correction"
    else:
        return "complete"


def route_after_correction(state: GraphState) -> Literal["complete", "human_review"]:
    """Route after correction."""
    if state.get("requires_human_review", False):
        return "human_review"
    else:
        return "complete"


async def finalize_node(state: GraphState) -> GraphState:
    """Finalize the extraction results.

    Prepares the final output with all extracted fields
    and metadata.
    """
    logger.info(
        "Finalizing extraction",
        session_id=state.get("session_id"),
    )

    # Build final extraction output
    final_extraction = {}

    for field_data in state.get("extracted_fields", []):
        final_extraction[field_data["name"]] = {
            "value": field_data["value"],
            "confidence": field_data["confidence"],
            "source": field_data["source"],
            "validated": field_data.get("validated", False),
            "corrected": field_data.get("corrected", False),
        }

    state["final_extraction"] = final_extraction

    # Calculate overall confidence
    if final_extraction:
        confidences = [f["confidence"] for f in final_extraction.values()]
        state["confidence_score"] = sum(confidences) / len(confidences)
    else:
        state["confidence_score"] = 0.0

    # Mark as completed if not requiring human review
    if not state.get("requires_human_review", False):
        state["stage"] = ProcessingStage.COMPLETED.value

    return state


class DocumentExtractionOrchestrator:
    """Orchestrator for document extraction workflow."""

    def __init__(self):
        """Initialize the orchestrator."""
        self._workflow = create_extraction_workflow()
        self._app = self._workflow.compile()

    async def process_document(
        self,
        document_id: str,
        image_data: bytes,
        filename: str,
        file_type: str,
        file_size: int,
        options: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Process a document through the extraction pipeline.

        Args:
            document_id: Unique document identifier
            image_data: Document image data
            filename: Original filename
            file_type: MIME type
            file_size: File size in bytes
            options: Processing options

        Returns:
            Extraction result
        """
        options = options or {}

        logger.info(
            "Starting document extraction",
            document_id=document_id,
            filename=filename,
            file_type=file_type,
        )

        # Create initial state
        initial_state: GraphState = {
            "session_id": document_id,
            "stage": ProcessingStage.INITIALIZED.value,
            "document": {
                "document_id": document_id,
                "filename": filename,
                "file_type": file_type,
                "file_size": file_size,
                "page_count": 1,
                "classification": "unknown",
                "language": options.get("language", "en"),
                "upload_timestamp": "",
                "checksum": "",
                "storage_path": "",
            },
            "raw_image_data": image_data,
            "extracted_text": "",
            "processing_plan": {},
            "target_fields": options.get("target_fields", []),
            "critical_fields": options.get("critical_fields", []),
            "council_votes": [],
            "voting_strategy": options.get("voting_strategy", "confidence_weighted"),
            "consensus_threshold": options.get("consensus_threshold", 0.85),
            "extracted_fields": [],
            "conflict_resolutions": [],
            "validation_results": [],
            "requires_correction": False,
            "final_extraction": {},
            "confidence_score": 0.0,
            "requires_human_review": False,
            "human_review_reason": "",
            "human_review_fields": [],
            "metrics": {
                "start_time": None,
                "end_time": None,
                "stage_times": {},
                "total_api_calls": 0,
                "total_tokens_used": 0,
                "retries": 0,
                "errors": [],
            },
            "messages": [],
            "error": None,
            "error_stage": None,
        }

        try:
            # Run the workflow
            final_state = await self._app.ainvoke(initial_state)

            return self._format_result(final_state)

        except Exception as e:
            logger.error(
                "Document extraction failed",
                document_id=document_id,
                error=str(e),
            )
            return {
                "document_id": document_id,
                "status": "failed",
                "error": str(e),
                "extraction": {},
                "confidence": 0.0,
            }

    def _format_result(self, state: GraphState) -> dict[str, Any]:
        """Format the final result."""
        return {
            "document_id": state.get("session_id"),
            "status": "completed"
            if state.get("stage") == ProcessingStage.COMPLETED.value
            else "review_required",
            "extraction": state.get("final_extraction", {}),
            "confidence": state.get("confidence_score", 0.0),
            "classification": state.get("document", {}).get("classification", "unknown"),
            "requires_human_review": state.get("requires_human_review", False),
            "human_review_reason": state.get("human_review_reason", ""),
            "human_review_fields": state.get("human_review_fields", []),
            "metrics": state.get("metrics", {}),
            "validation_results": state.get("validation_results", []),
        }

    async def get_workflow_state(self, thread_id: str) -> dict[str, Any] | None:
        """Get the current state of a workflow.

        Args:
            thread_id: Thread/session identifier

        Returns:
            Current workflow state or None
        """
        try:
            state = await self._app.aget_state({"configurable": {"thread_id": thread_id}})
            return state.values if state else None
        except Exception:
            return None


# Factory function for creating orchestrator
def create_orchestrator() -> DocumentExtractionOrchestrator:
    """Create a document extraction orchestrator."""
    return DocumentExtractionOrchestrator()


# Convenience function for direct processing
async def process_document(
    document_id: str,
    image_data: bytes,
    filename: str,
    file_type: str,
    file_size: int,
    options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Process a document through the extraction pipeline.

    Convenience function that creates an orchestrator and processes
    the document in one call.

    Args:
        document_id: Unique document identifier
        image_data: Document image data
        filename: Original filename
        file_type: MIME type
        file_size: File size in bytes
        options: Processing options

    Returns:
        Extraction result
    """
    orchestrator = create_orchestrator()
    return await orchestrator.process_document(
        document_id=document_id,
        image_data=image_data,
        filename=filename,
        file_type=file_type,
        file_size=file_size,
        options=options,
    )
