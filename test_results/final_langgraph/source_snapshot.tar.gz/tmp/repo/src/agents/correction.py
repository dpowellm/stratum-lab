"""Correction Agent for fixing validation errors.

The Correction Agent attempts to fix fields that failed validation:
- Format corrections (normalize dates, currencies, etc.)
- Calculation corrections (recalculate totals)
- Re-extraction for low confidence fields
"""

import re
import time
from datetime import datetime
from typing import Any

from src.agents.state import (
    AgentState,
    ExtractionField,
    ProcessingStage,
)
from src.core.logging import get_logger

logger = get_logger(__name__)


class CorrectionAgent:
    """Correction Agent for fixing validation errors."""

    def __init__(self):
        """Initialize Correction Agent."""
        self._correctors = {
            "format": self._correct_format,
            "business_rule": self._correct_business_rule,
            "required": self._correct_required,
        }

    async def correct(self, state: AgentState) -> AgentState:
        """Apply corrections to invalid fields.

        Args:
            state: State with validation errors

        Returns:
            Updated state with corrections applied
        """
        start_time = time.time()

        logger.info(
            "Starting field correction",
            session_id=state.session_id,
            num_errors=len([r for r in state.validation_results if not r.is_valid]),
        )

        state.update_stage(ProcessingStage.CORRECTING)

        try:
            corrections_made = 0
            remaining_errors = []

            # Process each validation error
            for validation in state.validation_results:
                if validation.is_valid:
                    continue

                # Get the field
                field = state.get_field(validation.field_name)
                if not field:
                    remaining_errors.append(validation)
                    continue

                # Try to correct
                corrector = self._correctors.get(validation.validation_type)
                if corrector:
                    corrected = await corrector(field, validation, state)
                    if corrected:
                        corrections_made += 1
                    else:
                        remaining_errors.append(validation)
                else:
                    remaining_errors.append(validation)

            # Update validation results with remaining errors
            state.validation_results = [
                v for v in state.validation_results if v.is_valid
            ] + remaining_errors

            # Check if all critical errors are resolved
            critical_errors = [e for e in remaining_errors if e.field_name in state.critical_fields]

            if critical_errors:
                state.mark_for_human_review(
                    f"Could not automatically correct {len(critical_errors)} critical fields",
                    [e.field_name for e in critical_errors],
                )
            else:
                state.requires_correction = len(remaining_errors) > 0
                state.update_stage(ProcessingStage.COMPLETED)

            elapsed_ms = int((time.time() - start_time) * 1000)

            logger.info(
                "Correction completed",
                session_id=state.session_id,
                corrections_made=corrections_made,
                remaining_errors=len(remaining_errors),
                elapsed_ms=elapsed_ms,
            )

            return state

        except Exception as e:
            logger.error(
                "Correction failed",
                session_id=state.session_id,
                error=str(e),
            )
            state.add_error(f"Correction failed: {e}")
            return state

    async def _correct_format(
        self,
        field: ExtractionField,
        validation,
        state: AgentState,
    ) -> bool:
        """Correct format errors."""
        original_value = field.value
        corrected = False

        field_lower = field.name.lower()

        # Date format correction
        if "date" in field_lower:
            corrected_value = self._normalize_date(field.value)
            if corrected_value and corrected_value != original_value:
                field.original_value = original_value
                field.value = corrected_value
                field.corrected = True
                corrected = True

        # Currency format correction
        elif any(x in field_lower for x in ["amount", "total", "price", "cost"]):
            corrected_value = self._normalize_currency(field.value)
            if corrected_value and corrected_value != original_value:
                field.original_value = original_value
                field.value = corrected_value
                field.corrected = True
                corrected = True

        # Phone format correction
        elif "phone" in field_lower:
            corrected_value = self._normalize_phone(field.value)
            if corrected_value and corrected_value != original_value:
                field.original_value = original_value
                field.value = corrected_value
                field.corrected = True
                corrected = True

        return corrected

    async def _correct_business_rule(
        self,
        field: ExtractionField,
        validation,
        state: AgentState,
    ) -> bool:
        """Correct business rule errors."""
        # Use suggested correction if available
        if validation.suggested_correction is not None:
            field.original_value = field.value
            field.value = validation.suggested_correction
            field.corrected = True
            return True

        # Try to recalculate totals
        if "total" in field.name.lower():
            return await self._recalculate_total(field, state)

        return False

    async def _correct_required(
        self,
        field: ExtractionField,
        validation,
        state: AgentState,
    ) -> bool:
        """Handle required field errors.

        Required fields that are missing cannot be auto-corrected.
        They need to be re-extracted or flagged for human review.
        """
        # Check if we have alternatives
        if field.alternatives:
            # Use the highest confidence alternative
            best_alt = max(field.alternatives, key=lambda x: x.get("confidence", 0))
            if best_alt.get("value"):
                field.original_value = field.value
                field.value = best_alt["value"]
                field.corrected = True
                return True

        return False

    def _normalize_date(self, value: Any) -> str | None:
        """Normalize date to ISO format."""
        if not value:
            return None

        value_str = str(value).strip()

        # Common date patterns and their formats
        patterns = [
            (r"(\d{4})-(\d{2})-(\d{2})", "%Y-%m-%d"),
            (r"(\d{2})/(\d{2})/(\d{4})", "%m/%d/%Y"),
            (r"(\d{2})-(\d{2})-(\d{4})", "%m-%d-%Y"),
            (r"(\d{1,2})/(\d{1,2})/(\d{4})", "%m/%d/%Y"),
            (r"(\d{1,2})/(\d{1,2})/(\d{2})", "%m/%d/%y"),
        ]

        for pattern, fmt in patterns:
            match = re.match(pattern, value_str)
            if match:
                try:
                    parsed = datetime.strptime(value_str, fmt)
                    return parsed.strftime("%Y-%m-%d")
                except ValueError:
                    continue

        # Try parsing month names
        month_patterns = [
            r"(\w+)\s+(\d{1,2}),?\s+(\d{4})",  # Month DD, YYYY
            r"(\d{1,2})\s+(\w+)\s+(\d{4})",  # DD Month YYYY
        ]

        for pattern in month_patterns:
            match = re.match(pattern, value_str)
            if match:
                try:
                    # Try various date formats with month names
                    for fmt in ["%B %d, %Y", "%B %d %Y", "%d %B %Y", "%b %d, %Y"]:
                        try:
                            parsed = datetime.strptime(value_str, fmt)
                            return parsed.strftime("%Y-%m-%d")
                        except ValueError:
                            continue
                except Exception:
                    logger.debug("Failed to parse date with month names", value=str(value))

        return None

    def _normalize_currency(self, value: Any) -> str | None:
        """Normalize currency format."""
        if not value:
            return None

        value_str = str(value).strip()

        # Extract numeric value
        match = re.search(r"([\d,]+\.?\d*)", value_str)
        if not match:
            return None

        numeric = match.group(1).replace(",", "")

        try:
            amount = float(numeric)

            # Detect currency symbol
            currency_symbols = {
                "$": "USD",
                "€": "EUR",
                "£": "GBP",
                "¥": "JPY",
            }

            symbol = "$"  # Default
            for sym in currency_symbols:
                if sym in value_str:
                    symbol = sym
                    break

            return f"{symbol}{amount:,.2f}"

        except ValueError:
            return None

    def _normalize_phone(self, value: Any) -> str | None:
        """Normalize phone number format."""
        if not value:
            return None

        # Extract digits
        digits = re.sub(r"\D", "", str(value))

        if len(digits) == 10:
            # US format: (XXX) XXX-XXXX
            return f"({digits[:3]}) {digits[3:6]}-{digits[6:]}"

        elif len(digits) == 11 and digits[0] == "1":
            # US with country code
            return f"+1 ({digits[1:4]}) {digits[4:7]}-{digits[7:]}"

        elif len(digits) >= 7:
            # Generic format
            return digits

        return None

    async def _recalculate_total(
        self,
        field: ExtractionField,
        state: AgentState,
    ) -> bool:
        """Recalculate total from line items or subtotals."""
        subtotal = None
        tax = None

        for f in state.extracted_fields:
            if "subtotal" in f.name.lower():
                subtotal = self._parse_amount(f.value)
            elif "tax" in f.name.lower() and "total" not in f.name.lower():
                tax = self._parse_amount(f.value)

        if subtotal is not None:
            calculated_total = subtotal + (tax or 0)
            field.original_value = field.value
            field.value = f"${calculated_total:,.2f}"
            field.corrected = True
            return True

        return False

    def _parse_amount(self, value: Any) -> float | None:
        """Parse amount from string."""
        if value is None:
            return None
        try:
            cleaned = re.sub(r"[$€£¥,]", "", str(value))
            return float(cleaned)
        except (ValueError, TypeError):
            return None


# LangGraph node function
async def correction_node(state: dict[str, Any]) -> dict[str, Any]:
    """LangGraph node for correction."""
    from src.agents.state import dict_to_state, state_to_dict

    agent_state = dict_to_state(state)
    agent = CorrectionAgent()

    updated_state = await agent.correct(agent_state)

    return state_to_dict(updated_state)
