"""
LLM-Based Correction Agent.

Task 2.3.1: Creates correction system that uses LLM to fix extraction errors.
"""

import re
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class CorrectionStrategy(StrEnum):
    """Correction strategies."""

    CONTEXT_AWARE = "context_aware"
    PATTERN_BASED = "pattern_based"
    SEMANTIC = "semantic"
    RULE_BASED = "rule_based"


@dataclass
class CorrectionResult:
    """Result of a correction attempt."""

    success: bool
    corrections: dict[str, Any] = field(default_factory=dict)
    explanation: str = ""
    new_confidence: float = 0.0
    strategy_used: CorrectionStrategy = CorrectionStrategy.CONTEXT_AWARE
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ErrorAnalysis:
    """Analysis of an extraction error."""

    error_type: str
    field_name: str
    original_value: Any
    suggested_correction: Any
    confidence: float
    explanation: str
    pattern_detected: str | None = None


class LLMCorrectionAgent:
    """
    LLM-Based Correction Agent.

    Features:
    - Error analysis
    - Context-aware correction
    - Confidence recalculation
    - Correction explanation
    """

    def __init__(
        self,
        correction_threshold: float = 0.7,
        use_llm: bool = True,
    ):
        """
        Initialize correction agent.

        Args:
            correction_threshold: Minimum confidence for auto-correction
            use_llm: Whether to use LLM for corrections (vs rule-based)
        """
        self.correction_threshold = correction_threshold
        self.use_llm = use_llm

        # Correction patterns
        self._patterns = {
            "currency": {
                "pattern": r"^\$?\d{1,3}(,\d{3})*(\.\d{2})?$",
                "fixes": [
                    (r"(\d+),(\d{2})$", r"\1.\2"),  # Fix comma decimal
                    (r"^\$?(\d+)(\d{3})$", r"$\1,\2"),  # Add missing comma
                ],
            },
            "date": {
                "pattern": r"^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}$",
                "fixes": [
                    (r"(\d+)\.(\d+)\.(\d+)", r"\1/\2/\3"),  # Dot to slash
                ],
            },
            "phone": {
                "pattern": r"^[\d\s\-\(\)]+$",
                "fixes": [
                    (r"[^\d]", ""),  # Remove non-digits
                ],
            },
        }

    async def analyze_error(
        self,
        error_context: dict[str, Any],
    ) -> ErrorAnalysis:
        """
        Analyze an extraction error.

        Args:
            error_context: Context about the error

        Returns:
            ErrorAnalysis with error type and suggested correction
        """
        field_name = error_context.get("field_name", "")
        extracted_value = error_context.get("extracted_value", "")
        expected_format = error_context.get("expected_format", "")
        raw_text = error_context.get("raw_text", "")

        # Determine error type
        error_type = self._detect_error_type(field_name, extracted_value, expected_format)

        # Generate suggested correction
        suggested = await self._suggest_correction(error_type, extracted_value, raw_text)

        # Calculate confidence in suggestion
        confidence = self._calculate_suggestion_confidence(extracted_value, suggested, raw_text)

        explanation = self._generate_explanation(error_type, extracted_value, suggested)

        return ErrorAnalysis(
            error_type=error_type,
            field_name=field_name,
            original_value=extracted_value,
            suggested_correction=suggested,
            confidence=confidence,
            explanation=explanation,
        )

    async def correct(
        self,
        extraction: dict[str, Any],
        validation_errors: list[dict],
    ) -> CorrectionResult:
        """
        Correct extraction errors.

        Args:
            extraction: Original extraction
            validation_errors: List of validation errors

        Returns:
            CorrectionResult with corrections
        """
        corrections = {}
        explanations = []
        overall_confidence = 0.0
        success_count = 0

        for error in validation_errors:
            field_name = error.get("field", "")
            original_value = extraction.get(field_name)

            # Analyze and correct
            error_context = {
                "field_name": field_name,
                "extracted_value": original_value,
                "error_message": error.get("error", ""),
            }

            analysis = await self.analyze_error(error_context)

            if analysis.confidence >= self.correction_threshold:
                corrections[field_name] = analysis.suggested_correction
                explanations.append(analysis.explanation)
                overall_confidence += analysis.confidence
                success_count += 1

        # Calculate final confidence
        final_confidence = overall_confidence / success_count if success_count > 0 else 0.0

        return CorrectionResult(
            success=len(corrections) > 0,
            corrections=corrections,
            explanation="; ".join(explanations),
            new_confidence=final_confidence,
            strategy_used=CorrectionStrategy.CONTEXT_AWARE,
        )

    async def correct_field(
        self,
        field_context: dict[str, Any],
    ) -> CorrectionResult:
        """
        Correct a single field.

        Args:
            field_context: Context about the field

        Returns:
            CorrectionResult for the field
        """
        analysis = await self.analyze_error(field_context)

        if analysis.confidence >= self.correction_threshold:
            return CorrectionResult(
                success=True,
                corrections={analysis.field_name: analysis.suggested_correction},
                explanation=analysis.explanation,
                new_confidence=analysis.confidence,
            )

        return CorrectionResult(
            success=False,
            explanation="Confidence too low for auto-correction",
            new_confidence=field_context.get("confidence", 0.0),
        )

    def _detect_error_type(
        self,
        field_name: str,
        value: Any,
        expected_format: str,
    ) -> str:
        """Detect the type of error."""
        field_lower = field_name.lower()
        value_str = str(value)

        # Format errors
        if expected_format == "currency" or "amount" in field_lower or "total" in field_lower:
            if not re.match(self._patterns["currency"]["pattern"], value_str):
                return "currency_format"

        if expected_format == "date" or "date" in field_lower:
            if not re.match(self._patterns["date"]["pattern"], value_str):
                return "date_format"

        if expected_format == "phone" or "phone" in field_lower:
            digits = re.sub(r"\D", "", value_str)
            if not (7 <= len(digits) <= 15):
                return "phone_format"

        # Value errors
        if not value or value_str.strip() == "":
            return "missing_value"

        if "?" in value_str or "unclear" in value_str.lower():
            return "unclear_value"

        return "unknown_error"

    async def _suggest_correction(
        self,
        error_type: str,
        original_value: Any,
        raw_text: str,
    ) -> Any:
        """Generate suggested correction."""
        value_str = str(original_value)

        # Apply pattern-based fixes
        if error_type == "currency_format":
            # Try to extract valid currency from raw text
            match = re.search(r"\$?\d{1,3}(?:,\d{3})*(?:\.\d{2})?", raw_text)
            if match:
                return match.group()

            # Apply fixes
            for pattern, replacement in self._patterns["currency"]["fixes"]:
                corrected = re.sub(pattern, replacement, value_str)
                if corrected != value_str:
                    return corrected

        if error_type == "date_format":
            # Try to extract valid date from raw text
            match = re.search(r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}", raw_text)
            if match:
                return match.group()

            # Try common format conversions
            for pattern, replacement in self._patterns["date"]["fixes"]:
                corrected = re.sub(pattern, replacement, value_str)
                if corrected != value_str:
                    return corrected

        if error_type == "phone_format":
            # Extract digits
            digits = re.sub(r"\D", "", value_str)
            if 10 <= len(digits) <= 11:
                return f"({digits[:3]}) {digits[3:6]}-{digits[6:10]}"

        if error_type == "missing_value":
            # Try to find value in raw text
            if raw_text:
                # Simple heuristic - look for numbers near field-like text
                numbers = re.findall(r"\d+\.?\d*", raw_text)
                if numbers:
                    return numbers[0]

        return original_value

    def _calculate_suggestion_confidence(
        self,
        original: Any,
        suggested: Any,
        raw_text: str,
    ) -> float:
        """Calculate confidence in the suggestion."""
        if original == suggested:
            return 0.3  # No change

        suggested_str = str(suggested)

        # Higher confidence if suggestion matches raw text
        if suggested_str in raw_text:
            return 0.9

        # Check if suggestion looks valid
        # Currency check
        if re.match(r"^\$?\d{1,3}(,\d{3})*(\.\d{2})?$", suggested_str):
            return 0.8

        # Date check
        if re.match(r"^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}$", suggested_str):
            return 0.8

        return 0.6

    def _generate_explanation(
        self,
        error_type: str,
        original: Any,
        suggested: Any,
    ) -> str:
        """Generate explanation for the correction."""
        if original == suggested:
            return "No correction needed"

        explanations = {
            "currency_format": f"Corrected currency format from '{original}' to '{suggested}'",
            "date_format": f"Corrected date format from '{original}' to '{suggested}'",
            "phone_format": f"Standardized phone format from '{original}' to '{suggested}'",
            "missing_value": f"Extracted value '{suggested}' from context",
            "unclear_value": f"Resolved unclear value to '{suggested}'",
        }

        return explanations.get(
            error_type,
            f"Corrected '{original}' to '{suggested}'",
        )


# Singleton instance
_correction_agent: LLMCorrectionAgent | None = None


def get_correction_agent() -> LLMCorrectionAgent:
    """Get or create the correction agent singleton."""
    global _correction_agent
    if _correction_agent is None:
        _correction_agent = LLMCorrectionAgent()
    return _correction_agent
