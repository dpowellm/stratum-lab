"""Unified storage service with factory pattern.

This module provides a unified storage service interface that works with
S3, MinIO, and local storage backends. It includes:
- Factory pattern for storage initialization
- Async upload/download operations
- Presigned URL generation
- Metadata management
- File listing and operations
"""

from functools import lru_cache
from typing import BinaryIO

from src.config.settings import get_settings
from src.services.storage.base import (
    StorageServiceInterface,
)
from src.services.storage.local import LocalStorageService
from src.services.storage.s3 import S3StorageService


class StorageService:
    """Unified storage service factory and facade.

    Provides a consistent interface for S3/MinIO and local storage.
    Automatically selects backend based on configuration.

    Example:
        storage = StorageService()
        # Upload
        metadata = await storage.upload_file(
            file_data=b"content",
            key="documents/doc1.pdf",
            metadata={"doc_id": "123"}
        )

        # Download
        obj = await storage.download_file(key="documents/doc1.pdf")
        print(obj.content)

        # Get presigned URL
        presigned = await storage.get_presigned_url(
            key="documents/doc1.pdf",
            expiry=3600
        )
    """

    def __init__(self):
        """Initialize storage service with configured backend."""
        self._backend = self._create_backend()

    @staticmethod
    def _create_backend() -> StorageServiceInterface:
        """Create and configure the appropriate storage backend.

        Returns:
            Configured storage service instance (S3 or Local)
        """
        settings = get_settings()

        # Use S3/MinIO if endpoint is configured, otherwise use local storage
        if settings.s3.endpoint_url and settings.s3.endpoint_url != "":
            return S3StorageService(
                endpoint_url=settings.s3.endpoint_url,
                access_key=settings.s3.access_key.get_secret_value(),
                secret_key=settings.s3.secret_key.get_secret_value(),
                region=settings.s3.region,
                default_bucket=settings.s3.bucket_name,
                use_ssl=settings.s3.endpoint_url.startswith("https"),
            )
        else:
            return LocalStorageService(
                base_path="./storage",
                default_bucket="documents",
            )

    @property
    def backend(self) -> StorageServiceInterface:
        """Get the underlying storage backend."""
        return self._backend

    async def upload_file(
        self,
        file_data: bytes | BinaryIO,
        key: str,
        metadata: dict[str, str] | None = None,
        content_type: str = "application/octet-stream",
        bucket: str | None = None,
    ) -> str:
        """Upload a file to storage.

        Args:
            file_data: File content as bytes or file-like object
            key: Storage key/path for the file
            metadata: Optional custom metadata to store with file
            content_type: MIME type of the file
            bucket: Optional bucket override

        Returns:
            Storage key/path of uploaded file

        Raises:
            UploadError: If upload fails
            BucketNotFoundError: If bucket doesn't exist
        """
        meta = await self._backend.upload(
            key=key,
            content=file_data,
            bucket=bucket,
            content_type=content_type,
            metadata=metadata,
        )
        return meta.key

    async def download_file(
        self,
        key: str,
        bucket: str | None = None,
    ) -> bytes:
        """Download a file from storage.

        Args:
            key: Storage key/path of the file
            bucket: Optional bucket override

        Returns:
            File content as bytes

        Raises:
            ObjectNotFoundError: If file doesn't exist
            DownloadError: If download fails
        """
        obj = await self._backend.download(key=key, bucket=bucket)
        return obj.content

    async def get_presigned_url(
        self,
        key: str,
        expiry: int = 3600,
        bucket: str | None = None,
        method: str = "GET",
    ) -> str:
        """Generate a presigned URL for direct file access.

        Allows temporary direct access to files without AWS credentials.
        Useful for serving files via HTTP or uploading directly from browser.

        Args:
            key: Storage key/path of the file
            expiry: URL expiration time in seconds (default: 1 hour)
            bucket: Optional bucket override
            method: HTTP method - "GET" or "PUT"

        Returns:
            Presigned URL string that expires after specified time

        Raises:
            StorageError: If URL generation fails
            ObjectNotFoundError: If file doesn't exist
        """
        presigned = await self._backend.generate_presigned_url(
            key=key,
            bucket=bucket,
            method=method,
            expires_in=expiry,
        )
        return presigned.url

    async def delete_file(
        self,
        key: str,
        bucket: str | None = None,
    ) -> bool:
        """Delete a file from storage.

        Args:
            key: Storage key/path to delete
            bucket: Optional bucket override

        Returns:
            True if deletion successful

        Raises:
            ObjectNotFoundError: If file doesn't exist
            StorageError: If deletion fails
        """
        return await self._backend.delete(key=key, bucket=bucket)

    async def list_files(
        self,
        prefix: str = "",
        bucket: str | None = None,
        max_keys: int = 1000,
    ) -> list[str]:
        """List files with optional prefix filtering.

        Useful for finding all documents of a certain type or in a folder.

        Args:
            prefix: Filter files by prefix (e.g., "documents/2024/")
            bucket: Optional bucket override
            max_keys: Maximum number of keys to return

        Returns:
            List of file keys matching the prefix

        Raises:
            BucketNotFoundError: If bucket doesn't exist
            StorageError: If listing fails
        """
        result = await self._backend.list_objects(
            prefix=prefix,
            bucket=bucket,
            max_keys=max_keys,
        )
        return [obj.key for obj in result.objects]

    async def file_exists(
        self,
        key: str,
        bucket: str | None = None,
    ) -> bool:
        """Check if a file exists in storage.

        Args:
            key: Storage key/path to check
            bucket: Optional bucket override

        Returns:
            True if file exists, False otherwise

        Raises:
            StorageError: If check fails
        """
        return await self._backend.exists(key=key, bucket=bucket)

    async def get_file_metadata(
        self,
        key: str,
        bucket: str | None = None,
    ) -> dict:
        """Get file metadata without downloading content.

        Args:
            key: Storage key/path of the file
            bucket: Optional bucket override

        Returns:
            Dictionary with file metadata (size, type, modified time, etc.)

        Raises:
            ObjectNotFoundError: If file doesn't exist
            StorageError: If metadata retrieval fails
        """
        metadata = await self._backend.get_metadata(key=key, bucket=bucket)
        return metadata.to_dict()

    async def copy_file(
        self,
        source_key: str,
        dest_key: str,
        source_bucket: str | None = None,
        dest_bucket: str | None = None,
    ) -> str:
        """Copy a file within storage.

        Args:
            source_key: Source file key/path
            dest_key: Destination file key/path
            source_bucket: Optional source bucket override
            dest_bucket: Optional destination bucket override

        Returns:
            Key of the copied file

        Raises:
            ObjectNotFoundError: If source doesn't exist
            StorageError: If copy fails
        """
        metadata = await self._backend.copy(
            source_key=source_key,
            dest_key=dest_key,
            source_bucket=source_bucket,
            dest_bucket=dest_bucket,
        )
        return metadata.key

    async def move_file(
        self,
        source_key: str,
        dest_key: str,
        source_bucket: str | None = None,
        dest_bucket: str | None = None,
    ) -> str:
        """Move a file within storage (copy then delete).

        Args:
            source_key: Source file key/path
            dest_key: Destination file key/path
            source_bucket: Optional source bucket override
            dest_bucket: Optional destination bucket override

        Returns:
            Key of the moved file

        Raises:
            ObjectNotFoundError: If source doesn't exist
            StorageError: If move fails
        """
        metadata = await self._backend.move(
            source_key=source_key,
            dest_key=dest_key,
            source_bucket=source_bucket,
            dest_bucket=dest_bucket,
        )
        return metadata.key


@lru_cache(maxsize=1)
def get_storage_service() -> StorageService:
    """Get singleton storage service instance.

    Returns a cached instance for performance. Use this in async code
    to access the storage service consistently.

    Returns:
        StorageService instance

    Example:
        storage = get_storage_service()
        await storage.upload_file(...)
    """
    return StorageService()
