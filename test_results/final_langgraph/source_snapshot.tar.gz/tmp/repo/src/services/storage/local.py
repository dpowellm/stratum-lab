"""Local filesystem storage service for development and testing."""

import hashlib
import json
import os
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import BinaryIO, AsyncIterator
import asyncio
import aiofiles
import aiofiles.os

from src.services.storage.base import (
    StorageServiceInterface,
    StorageType,
    StorageMetadata,
    StorageObject,
    PresignedURL,
    ListResult,
    StorageError,
    ObjectNotFoundError,
    BucketNotFoundError,
    UploadError,
    DownloadError,
)


class LocalStorageService(StorageServiceInterface):
    """Local filesystem storage service.

    Useful for development and testing without S3/MinIO.
    """

    def __init__(
        self,
        base_path: str | Path = "./storage",
        default_bucket: str = "documents",
    ):
        """Initialize local storage service.

        Args:
            base_path: Base directory for storage
            default_bucket: Default bucket name
        """
        self._base_path = Path(base_path)
        self._default_bucket = default_bucket
        self._base_path.mkdir(parents=True, exist_ok=True)

    @property
    def storage_type(self) -> StorageType:
        """Get the storage type."""
        return StorageType.LOCAL

    def _get_bucket(self, bucket: str | None) -> str:
        """Get bucket name, using default if not specified."""
        return bucket or self._default_bucket

    def _get_bucket_path(self, bucket: str) -> Path:
        """Get the filesystem path for a bucket."""
        return self._base_path / bucket

    def _get_object_path(self, bucket: str, key: str) -> Path:
        """Get the filesystem path for an object."""
        return self._get_bucket_path(bucket) / key

    def _get_metadata_path(self, bucket: str, key: str) -> Path:
        """Get the filesystem path for object metadata."""
        obj_path = self._get_object_path(bucket, key)
        return obj_path.parent / f".{obj_path.name}.metadata.json"

    async def _save_metadata(
        self,
        bucket: str,
        key: str,
        metadata: dict,
    ) -> None:
        """Save object metadata to a sidecar file."""
        metadata_path = self._get_metadata_path(bucket, key)
        metadata_path.parent.mkdir(parents=True, exist_ok=True)

        async with aiofiles.open(metadata_path, "w") as f:
            await f.write(json.dumps(metadata, default=str))

    async def _load_metadata(self, bucket: str, key: str) -> dict:
        """Load object metadata from sidecar file."""
        metadata_path = self._get_metadata_path(bucket, key)

        if metadata_path.exists():
            async with aiofiles.open(metadata_path, "r") as f:
                return json.loads(await f.read())

        return {}

    async def upload(
        self,
        key: str,
        content: bytes | BinaryIO,
        bucket: str | None = None,
        content_type: str = "application/octet-stream",
        metadata: dict[str, str] | None = None,
    ) -> StorageMetadata:
        """Upload an object to local storage."""
        bucket_name = self._get_bucket(bucket)
        bucket_path = self._get_bucket_path(bucket_name)

        if not bucket_path.exists():
            raise BucketNotFoundError(f"Bucket '{bucket_name}' not found")

        object_path = self._get_object_path(bucket_name, key)

        # Convert content to bytes
        if isinstance(content, bytes):
            content_bytes = content
        else:
            content_bytes = content.read()

        size = len(content_bytes)
        checksum = hashlib.sha256(content_bytes).hexdigest()

        try:
            # Create parent directories
            object_path.parent.mkdir(parents=True, exist_ok=True)

            # Write file
            async with aiofiles.open(object_path, "wb") as f:
                await f.write(content_bytes)

            now = datetime.utcnow()

            # Save metadata
            await self._save_metadata(
                bucket_name,
                key,
                {
                    "content_type": content_type,
                    "custom_metadata": metadata or {},
                    "checksum": checksum,
                    "uploaded_at": now.isoformat(),
                },
            )

            return StorageMetadata(
                key=key,
                bucket=bucket_name,
                size=size,
                content_type=content_type,
                etag=checksum[:32],
                last_modified=now,
                checksum=checksum,
                custom_metadata=metadata or {},
            )

        except Exception as e:
            raise UploadError(f"Upload failed: {e}")

    async def download(
        self,
        key: str,
        bucket: str | None = None,
    ) -> StorageObject:
        """Download an object from local storage."""
        bucket_name = self._get_bucket(bucket)
        object_path = self._get_object_path(bucket_name, key)

        if not object_path.exists():
            raise ObjectNotFoundError(f"Object '{key}' not found in bucket '{bucket_name}'")

        try:
            async with aiofiles.open(object_path, "rb") as f:
                content = await f.read()

            stat = object_path.stat()
            saved_metadata = await self._load_metadata(bucket_name, key)

            metadata = StorageMetadata(
                key=key,
                bucket=bucket_name,
                size=stat.st_size,
                content_type=saved_metadata.get("content_type", "application/octet-stream"),
                etag=saved_metadata.get("checksum", "")[:32],
                last_modified=datetime.fromtimestamp(stat.st_mtime),
                checksum=saved_metadata.get("checksum"),
                custom_metadata=saved_metadata.get("custom_metadata", {}),
            )

            return StorageObject(content=content, metadata=metadata)

        except ObjectNotFoundError:
            raise
        except Exception as e:
            raise DownloadError(f"Download failed: {e}")

    async def download_stream(
        self,
        key: str,
        bucket: str | None = None,
        chunk_size: int = 8192,
    ) -> AsyncIterator[bytes]:
        """Download an object as a stream."""
        bucket_name = self._get_bucket(bucket)
        object_path = self._get_object_path(bucket_name, key)

        if not object_path.exists():
            raise ObjectNotFoundError(f"Object '{key}' not found")

        try:
            async with aiofiles.open(object_path, "rb") as f:
                while True:
                    chunk = await f.read(chunk_size)
                    if not chunk:
                        break
                    yield chunk

        except ObjectNotFoundError:
            raise
        except Exception as e:
            raise DownloadError(f"Download stream failed: {e}")

    async def delete(
        self,
        key: str,
        bucket: str | None = None,
    ) -> bool:
        """Delete an object from local storage."""
        bucket_name = self._get_bucket(bucket)
        object_path = self._get_object_path(bucket_name, key)
        metadata_path = self._get_metadata_path(bucket_name, key)

        if not object_path.exists():
            raise ObjectNotFoundError(f"Object '{key}' not found")

        try:
            await aiofiles.os.remove(object_path)

            if metadata_path.exists():
                await aiofiles.os.remove(metadata_path)

            return True

        except Exception as e:
            raise StorageError(f"Delete failed: {e}")

    async def delete_many(
        self,
        keys: list[str],
        bucket: str | None = None,
    ) -> dict[str, bool]:
        """Delete multiple objects."""
        results = {}

        for key in keys:
            try:
                await self.delete(key, bucket)
                results[key] = True
            except ObjectNotFoundError:
                results[key] = False
            except Exception:
                results[key] = False

        return results

    async def exists(
        self,
        key: str,
        bucket: str | None = None,
    ) -> bool:
        """Check if an object exists."""
        bucket_name = self._get_bucket(bucket)
        object_path = self._get_object_path(bucket_name, key)
        return object_path.exists()

    async def get_metadata(
        self,
        key: str,
        bucket: str | None = None,
    ) -> StorageMetadata:
        """Get object metadata without downloading content."""
        bucket_name = self._get_bucket(bucket)
        object_path = self._get_object_path(bucket_name, key)

        if not object_path.exists():
            raise ObjectNotFoundError(f"Object '{key}' not found")

        stat = object_path.stat()
        saved_metadata = await self._load_metadata(bucket_name, key)

        return StorageMetadata(
            key=key,
            bucket=bucket_name,
            size=stat.st_size,
            content_type=saved_metadata.get("content_type", "application/octet-stream"),
            etag=saved_metadata.get("checksum", "")[:32],
            last_modified=datetime.fromtimestamp(stat.st_mtime),
            checksum=saved_metadata.get("checksum"),
            custom_metadata=saved_metadata.get("custom_metadata", {}),
        )

    async def list_objects(
        self,
        prefix: str | None = None,
        bucket: str | None = None,
        max_keys: int = 1000,
        continuation_token: str | None = None,
    ) -> ListResult:
        """List objects in local storage."""
        bucket_name = self._get_bucket(bucket)
        bucket_path = self._get_bucket_path(bucket_name)

        if not bucket_path.exists():
            raise BucketNotFoundError(f"Bucket '{bucket_name}' not found")

        objects = []

        # Find all files recursively
        for file_path in bucket_path.rglob("*"):
            # Skip metadata files and directories
            if file_path.is_dir() or file_path.name.startswith("."):
                continue

            # Calculate relative key
            key = str(file_path.relative_to(bucket_path))

            # Apply prefix filter
            if prefix and not key.startswith(prefix):
                continue

            stat = file_path.stat()
            saved_metadata = await self._load_metadata(bucket_name, key)

            objects.append(
                StorageMetadata(
                    key=key,
                    bucket=bucket_name,
                    size=stat.st_size,
                    content_type=saved_metadata.get("content_type", "application/octet-stream"),
                    etag=saved_metadata.get("checksum", "")[:32],
                    last_modified=datetime.fromtimestamp(stat.st_mtime),
                )
            )

        # Sort by key
        objects.sort(key=lambda x: x.key)

        # Apply pagination
        start_index = 0
        if continuation_token:
            try:
                start_index = int(continuation_token)
            except ValueError:
                pass

        end_index = start_index + max_keys
        paginated = objects[start_index:end_index]

        next_token = None
        if end_index < len(objects):
            next_token = str(end_index)

        return ListResult(
            objects=paginated,
            prefix=prefix,
            continuation_token=next_token,
            is_truncated=next_token is not None,
        )

    async def generate_presigned_url(
        self,
        key: str,
        bucket: str | None = None,
        method: str = "GET",
        expires_in: int = 3600,
        content_type: str | None = None,
    ) -> PresignedURL:
        """Generate a presigned URL (local file path for local storage)."""
        bucket_name = self._get_bucket(bucket)
        object_path = self._get_object_path(bucket_name, key)

        # For local storage, return the file path as URL
        url = f"file://{object_path.absolute()}"

        headers = {}
        if content_type and method.upper() == "PUT":
            headers["Content-Type"] = content_type

        return PresignedURL(
            url=url,
            method=method.upper(),
            expires_at=datetime.utcnow() + timedelta(seconds=expires_in),
            headers=headers,
        )

    async def copy(
        self,
        source_key: str,
        dest_key: str,
        source_bucket: str | None = None,
        dest_bucket: str | None = None,
    ) -> StorageMetadata:
        """Copy an object within local storage."""
        src_bucket = self._get_bucket(source_bucket)
        dst_bucket = self._get_bucket(dest_bucket)

        src_path = self._get_object_path(src_bucket, source_key)
        dst_path = self._get_object_path(dst_bucket, dest_key)

        if not src_path.exists():
            raise ObjectNotFoundError(f"Source object '{source_key}' not found")

        try:
            # Create parent directories
            dst_path.parent.mkdir(parents=True, exist_ok=True)

            # Copy file
            shutil.copy2(src_path, dst_path)

            # Copy metadata
            src_metadata_path = self._get_metadata_path(src_bucket, source_key)
            dst_metadata_path = self._get_metadata_path(dst_bucket, dest_key)

            if src_metadata_path.exists():
                shutil.copy2(src_metadata_path, dst_metadata_path)

            return await self.get_metadata(dest_key, dst_bucket)

        except ObjectNotFoundError:
            raise
        except Exception as e:
            raise StorageError(f"Copy failed: {e}")

    async def move(
        self,
        source_key: str,
        dest_key: str,
        source_bucket: str | None = None,
        dest_bucket: str | None = None,
    ) -> StorageMetadata:
        """Move an object within local storage."""
        metadata = await self.copy(source_key, dest_key, source_bucket, dest_bucket)
        await self.delete(source_key, source_bucket)
        return metadata

    async def create_bucket(
        self,
        bucket: str,
        region: str | None = None,
    ) -> bool:
        """Create a new bucket (directory)."""
        bucket_path = self._get_bucket_path(bucket)

        try:
            bucket_path.mkdir(parents=True, exist_ok=True)
            return True
        except Exception as e:
            raise StorageError(f"Create bucket failed: {e}")

    async def bucket_exists(self, bucket: str) -> bool:
        """Check if a bucket exists."""
        bucket_path = self._get_bucket_path(bucket)
        return bucket_path.exists() and bucket_path.is_dir()

    async def list_buckets(self) -> list[str]:
        """List all buckets."""
        buckets = []

        for path in self._base_path.iterdir():
            if path.is_dir() and not path.name.startswith("."):
                buckets.append(path.name)

        return sorted(buckets)
