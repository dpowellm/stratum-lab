"""Storage services for document management."""

from functools import lru_cache

from src.services.storage.base import (
    StorageServiceInterface,
    StorageObject,
    StorageMetadata,
    PresignedURL,
)
from src.services.storage.s3 import S3StorageService
from src.services.storage.local import LocalStorageService


@lru_cache(maxsize=1)
def get_storage_service() -> StorageServiceInterface:
    """Get singleton storage service instance based on configuration.

    Returns a cached LocalStorageService for development or
    S3StorageService for production based on settings.
    """
    from src.config.settings import get_settings

    settings = get_settings()
    storage_type = getattr(settings, "storage_type", "local")

    if storage_type == "s3":
        return S3StorageService()
    return LocalStorageService()


__all__ = [
    "StorageServiceInterface",
    "StorageObject",
    "StorageMetadata",
    "PresignedURL",
    "S3StorageService",
    "LocalStorageService",
    "get_storage_service",
]
