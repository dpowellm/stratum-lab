"""Base storage service interface."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import BinaryIO, AsyncIterator
from pathlib import Path


class StorageType(str, Enum):
    """Supported storage types."""

    S3 = "s3"
    MINIO = "minio"
    LOCAL = "local"
    GCS = "gcs"  # Future support


@dataclass
class StorageMetadata:
    """Metadata for a stored object."""

    key: str
    bucket: str
    size: int
    content_type: str
    etag: str | None = None
    last_modified: datetime | None = None
    checksum: str | None = None
    custom_metadata: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "key": self.key,
            "bucket": self.bucket,
            "size": self.size,
            "content_type": self.content_type,
            "etag": self.etag,
            "last_modified": self.last_modified.isoformat() if self.last_modified else None,
            "checksum": self.checksum,
            "custom_metadata": self.custom_metadata,
        }


@dataclass
class StorageObject:
    """A stored object with content and metadata."""

    content: bytes
    metadata: StorageMetadata

    @property
    def key(self) -> str:
        """Get the object key."""
        return self.metadata.key

    @property
    def size(self) -> int:
        """Get the object size."""
        return self.metadata.size

    @property
    def content_type(self) -> str:
        """Get the content type."""
        return self.metadata.content_type


@dataclass
class PresignedURL:
    """A presigned URL for direct access."""

    url: str
    method: str  # GET, PUT
    expires_at: datetime
    headers: dict[str, str] = field(default_factory=dict)

    @property
    def is_expired(self) -> bool:
        """Check if the URL has expired."""
        return datetime.utcnow() > self.expires_at

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "url": self.url,
            "method": self.method,
            "expires_at": self.expires_at.isoformat(),
            "headers": self.headers,
            "is_expired": self.is_expired,
        }


@dataclass
class ListResult:
    """Result of listing objects."""

    objects: list[StorageMetadata]
    prefix: str | None
    continuation_token: str | None = None
    is_truncated: bool = False

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "objects": [obj.to_dict() for obj in self.objects],
            "prefix": self.prefix,
            "continuation_token": self.continuation_token,
            "is_truncated": self.is_truncated,
            "count": len(self.objects),
        }


class StorageError(Exception):
    """Base storage error."""
    pass


class ObjectNotFoundError(StorageError):
    """Object not found in storage."""
    pass


class BucketNotFoundError(StorageError):
    """Bucket not found."""
    pass


class UploadError(StorageError):
    """Error during upload."""
    pass


class DownloadError(StorageError):
    """Error during download."""
    pass


class StorageServiceInterface(ABC):
    """Abstract interface for storage services.

    Supports S3-compatible storage (AWS S3, MinIO, etc.)
    """

    @property
    @abstractmethod
    def storage_type(self) -> StorageType:
        """Get the storage type."""
        pass

    @abstractmethod
    async def upload(
        self,
        key: str,
        content: bytes | BinaryIO,
        bucket: str | None = None,
        content_type: str = "application/octet-stream",
        metadata: dict[str, str] | None = None,
    ) -> StorageMetadata:
        """Upload an object to storage.

        Args:
            key: Object key/path
            content: File content as bytes or file-like object
            bucket: Target bucket (uses default if not specified)
            content_type: MIME type of the content
            metadata: Custom metadata to attach

        Returns:
            StorageMetadata for the uploaded object

        Raises:
            UploadError: If upload fails
        """
        pass

    @abstractmethod
    async def download(
        self,
        key: str,
        bucket: str | None = None,
    ) -> StorageObject:
        """Download an object from storage.

        Args:
            key: Object key/path
            bucket: Source bucket (uses default if not specified)

        Returns:
            StorageObject with content and metadata

        Raises:
            ObjectNotFoundError: If object doesn't exist
            DownloadError: If download fails
        """
        pass

    @abstractmethod
    async def download_stream(
        self,
        key: str,
        bucket: str | None = None,
        chunk_size: int = 8192,
    ) -> AsyncIterator[bytes]:
        """Download an object as a stream.

        Args:
            key: Object key/path
            bucket: Source bucket
            chunk_size: Size of each chunk

        Yields:
            Chunks of bytes

        Raises:
            ObjectNotFoundError: If object doesn't exist
        """
        pass

    @abstractmethod
    async def delete(
        self,
        key: str,
        bucket: str | None = None,
    ) -> bool:
        """Delete an object from storage.

        Args:
            key: Object key/path
            bucket: Source bucket

        Returns:
            True if deleted successfully

        Raises:
            ObjectNotFoundError: If object doesn't exist
        """
        pass

    @abstractmethod
    async def delete_many(
        self,
        keys: list[str],
        bucket: str | None = None,
    ) -> dict[str, bool]:
        """Delete multiple objects.

        Args:
            keys: List of object keys
            bucket: Source bucket

        Returns:
            Dict mapping key to deletion success
        """
        pass

    @abstractmethod
    async def exists(
        self,
        key: str,
        bucket: str | None = None,
    ) -> bool:
        """Check if an object exists.

        Args:
            key: Object key/path
            bucket: Source bucket

        Returns:
            True if object exists
        """
        pass

    @abstractmethod
    async def get_metadata(
        self,
        key: str,
        bucket: str | None = None,
    ) -> StorageMetadata:
        """Get object metadata without downloading content.

        Args:
            key: Object key/path
            bucket: Source bucket

        Returns:
            StorageMetadata

        Raises:
            ObjectNotFoundError: If object doesn't exist
        """
        pass

    @abstractmethod
    async def list_objects(
        self,
        prefix: str | None = None,
        bucket: str | None = None,
        max_keys: int = 1000,
        continuation_token: str | None = None,
    ) -> ListResult:
        """List objects in storage.

        Args:
            prefix: Filter by key prefix
            bucket: Source bucket
            max_keys: Maximum number of keys to return
            continuation_token: Token for pagination

        Returns:
            ListResult with objects and pagination info
        """
        pass

    @abstractmethod
    async def generate_presigned_url(
        self,
        key: str,
        bucket: str | None = None,
        method: str = "GET",
        expires_in: int = 3600,
        content_type: str | None = None,
    ) -> PresignedURL:
        """Generate a presigned URL for direct access.

        Args:
            key: Object key/path
            bucket: Source bucket
            method: HTTP method (GET for download, PUT for upload)
            expires_in: URL validity in seconds
            content_type: Content-Type for PUT requests

        Returns:
            PresignedURL with URL and expiration
        """
        pass

    @abstractmethod
    async def copy(
        self,
        source_key: str,
        dest_key: str,
        source_bucket: str | None = None,
        dest_bucket: str | None = None,
    ) -> StorageMetadata:
        """Copy an object within storage.

        Args:
            source_key: Source object key
            dest_key: Destination object key
            source_bucket: Source bucket
            dest_bucket: Destination bucket

        Returns:
            StorageMetadata for the new object
        """
        pass

    @abstractmethod
    async def move(
        self,
        source_key: str,
        dest_key: str,
        source_bucket: str | None = None,
        dest_bucket: str | None = None,
    ) -> StorageMetadata:
        """Move an object within storage.

        Args:
            source_key: Source object key
            dest_key: Destination object key
            source_bucket: Source bucket
            dest_bucket: Destination bucket

        Returns:
            StorageMetadata for the moved object
        """
        pass

    # Bucket operations

    @abstractmethod
    async def create_bucket(
        self,
        bucket: str,
        region: str | None = None,
    ) -> bool:
        """Create a new bucket.

        Args:
            bucket: Bucket name
            region: AWS region (for S3)

        Returns:
            True if created successfully
        """
        pass

    @abstractmethod
    async def bucket_exists(self, bucket: str) -> bool:
        """Check if a bucket exists.

        Args:
            bucket: Bucket name

        Returns:
            True if bucket exists
        """
        pass

    @abstractmethod
    async def list_buckets(self) -> list[str]:
        """List all buckets.

        Returns:
            List of bucket names
        """
        pass

    # Utility methods

    def generate_key(
        self,
        document_id: str,
        filename: str,
        prefix: str = "documents",
    ) -> str:
        """Generate a storage key for a document.

        Args:
            document_id: Document UUID
            filename: Original filename
            prefix: Key prefix

        Returns:
            Storage key in format: prefix/document_id/filename
        """
        # Sanitize filename
        safe_filename = Path(filename).name
        return f"{prefix}/{document_id}/{safe_filename}"

    def parse_key(self, key: str) -> dict[str, str]:
        """Parse a storage key into components.

        Args:
            key: Storage key

        Returns:
            Dict with prefix, document_id, filename
        """
        parts = key.split("/")
        if len(parts) >= 3:
            return {
                "prefix": parts[0],
                "document_id": parts[1],
                "filename": "/".join(parts[2:]),
            }
        return {"key": key}
