"""Layout extraction from PDF documents using PyMuPDF, and image cropping via PIL."""

from __future__ import annotations

import io
from pathlib import Path
from typing import Any

from src.core.logging import get_logger
from src.services.layout.models import (
    DocumentLayout,
    PageLayout,
    RegionSelector,
    TableBlock,
    TextBlock,
    TextLine,
    TextSpan,
)

logger = get_logger(__name__)

_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tiff", ".tif"}


def is_image_file(filename: str) -> bool:
    """Check whether a filename has an image extension.

    Args:
        filename: Name or path of the file.

    Returns:
        True if the file extension is a supported image format.
    """
    return Path(filename).suffix.lower() in _IMAGE_EXTENSIONS


# PyMuPDF flags bitmask
_FLAG_ITALIC = 1 << 1
_FLAG_BOLD = 1 << 4


class LayoutExtractor:
    """Extracts structured layout data from PDF pages using PyMuPDF.

    Supports both full-page extraction and clipped region extraction,
    as well as rendering pages/regions as images.
    """

    def extract_regions(self, file_bytes: bytes, regions: list[RegionSelector]) -> DocumentLayout:
        """Extract layout data from specific rectangular regions.

        Args:
            file_bytes: PDF file content.
            regions: List of regions to extract.

        Returns:
            DocumentLayout with text blocks for each region.
        """
        import fitz

        doc = fitz.open(stream=file_bytes, filetype="pdf")
        try:
            layout = DocumentLayout(
                source_filename="",
                total_page_count=doc.page_count,
            )

            for region in regions:
                if region.page_number < 0 or region.page_number >= doc.page_count:
                    logger.warning(
                        "Region page number out of range",
                        page_number=region.page_number,
                        total_pages=doc.page_count,
                    )
                    continue

                page = doc[region.page_number]
                rect = region.to_fitz_rect(page.rect.width, page.rect.height)
                clip = fitz.Rect(*rect)
                raw = page.get_text("dict", clip=clip)

                text_blocks = self._parse_blocks(raw.get("blocks", []))
                table_blocks = self._extract_tables(page, clip=clip)
                text_blocks = self._filter_text_blocks_outside_tables(
                    text_blocks, table_blocks
                )
                blocks: list[TextBlock | TableBlock] = self._merge_blocks_by_position(
                    text_blocks, table_blocks
                )
                page_layout = PageLayout(
                    page_number=region.page_number,
                    page_width=page.rect.width,
                    page_height=page.rect.height,
                    blocks=blocks,
                    region=region,
                )
                layout.pages.append(page_layout)

            return layout
        finally:
            doc.close()

    def extract_full_pages(
        self, file_bytes: bytes, page_numbers: list[int] | None = None
    ) -> DocumentLayout:
        """Extract layout data from full pages.

        Args:
            file_bytes: PDF file content.
            page_numbers: Specific pages to extract (0-indexed). None = all pages.

        Returns:
            DocumentLayout with text blocks for each page.
        """
        import fitz

        doc = fitz.open(stream=file_bytes, filetype="pdf")
        try:
            layout = DocumentLayout(
                source_filename="",
                total_page_count=doc.page_count,
            )

            pages_to_extract = page_numbers if page_numbers is not None else range(doc.page_count)

            for page_num in pages_to_extract:
                if page_num < 0 or page_num >= doc.page_count:
                    continue

                page = doc[page_num]
                raw = page.get_text("dict")
                text_blocks = self._parse_blocks(raw.get("blocks", []))
                table_blocks = self._extract_tables(page)
                text_blocks = self._filter_text_blocks_outside_tables(
                    text_blocks, table_blocks
                )
                blocks: list[TextBlock | TableBlock] = self._merge_blocks_by_position(
                    text_blocks, table_blocks
                )

                page_layout = PageLayout(
                    page_number=page_num,
                    page_width=page.rect.width,
                    page_height=page.rect.height,
                    blocks=blocks,
                )
                layout.pages.append(page_layout)

            return layout
        finally:
            doc.close()

    def crop_region_as_image(
        self,
        file_bytes: bytes,
        region: RegionSelector,
        dpi: int = 300,
        fmt: str = "png",
    ) -> bytes:
        """Crop a region from a PDF page as a raster image.

        Args:
            file_bytes: PDF file content.
            region: Region to crop.
            dpi: Resolution in dots per inch.
            fmt: Image format (png, jpg, webp).

        Returns:
            Image bytes in the specified format.
        """
        import fitz

        doc = fitz.open(stream=file_bytes, filetype="pdf")
        try:
            page = doc[region.page_number]
            rect = region.to_fitz_rect(page.rect.width, page.rect.height)
            clip = fitz.Rect(*rect)
            pixmap = page.get_pixmap(dpi=dpi, clip=clip)
            return pixmap.tobytes(output=fmt)
        finally:
            doc.close()

    def crop_multiple_regions(
        self,
        file_bytes: bytes,
        regions: list[RegionSelector],
        dpi: int = 300,
        fmt: str = "png",
    ) -> list[bytes]:
        """Crop multiple regions as images.

        Args:
            file_bytes: PDF file content.
            regions: Regions to crop.
            dpi: Resolution in dots per inch.
            fmt: Image format.

        Returns:
            List of image bytes, one per region.
        """
        import fitz

        doc = fitz.open(stream=file_bytes, filetype="pdf")
        try:
            results = []
            for region in regions:
                if region.page_number < 0 or region.page_number >= doc.page_count:
                    results.append(b"")
                    continue
                page = doc[region.page_number]
                rect = region.to_fitz_rect(page.rect.width, page.rect.height)
                clip = fitz.Rect(*rect)
                pixmap = page.get_pixmap(dpi=dpi, clip=clip)
                results.append(pixmap.tobytes(output=fmt))
            return results
        finally:
            doc.close()

    def render_page_as_image(self, file_bytes: bytes, page_number: int, dpi: int = 150) -> bytes:
        """Render a full page as a PNG image.

        Args:
            file_bytes: PDF file content.
            page_number: 0-indexed page number.
            dpi: Resolution.

        Returns:
            PNG image bytes.
        """
        import fitz

        doc = fitz.open(stream=file_bytes, filetype="pdf")
        try:
            page = doc[page_number]
            pixmap = page.get_pixmap(dpi=dpi)
            return pixmap.tobytes(output="png")
        finally:
            doc.close()

    def crop_image_region(
        self,
        file_bytes: bytes,
        region: RegionSelector,
        fmt: str = "png",
    ) -> bytes:
        """Crop a region from an image file using normalized coordinates.

        Args:
            file_bytes: Image file content (PNG, JPEG, etc.).
            region: Region to crop (normalized 0.0-1.0 coordinates).
            fmt: Output image format (png, jpeg, webp).

        Returns:
            Cropped image bytes in the specified format.
        """
        from PIL import Image

        img = Image.open(io.BytesIO(file_bytes))
        img = img.convert("RGB")
        w, h = img.size
        box = (
            int(region.x0 * w),
            int(region.y0 * h),
            int(region.x1 * w),
            int(region.y1 * h),
        )
        cropped = img.crop(box)
        buf = io.BytesIO()
        cropped.save(buf, format=fmt.upper())
        return buf.getvalue()

    def crop_multiple_image_regions(
        self,
        file_bytes: bytes,
        regions: list[RegionSelector],
        fmt: str = "png",
    ) -> list[bytes]:
        """Crop multiple regions from an image file.

        All regions are treated as page_number=0 (images are single-page).

        Args:
            file_bytes: Image file content.
            regions: Regions to crop.
            fmt: Output image format.

        Returns:
            List of cropped image bytes.
        """
        from PIL import Image

        img = Image.open(io.BytesIO(file_bytes))
        img = img.convert("RGB")
        w, h = img.size

        results: list[bytes] = []
        for region in regions:
            box = (
                int(region.x0 * w),
                int(region.y0 * h),
                int(region.x1 * w),
                int(region.y1 * h),
            )
            cropped = img.crop(box)
            buf = io.BytesIO()
            cropped.save(buf, format=fmt.upper())
            results.append(buf.getvalue())
        return results

    def render_image_as_png(self, file_bytes: bytes) -> bytes:
        """Convert any supported image to PNG format.

        Args:
            file_bytes: Image file content (PNG, JPEG, BMP, etc.).

        Returns:
            PNG image bytes.
        """
        from PIL import Image

        img = Image.open(io.BytesIO(file_bytes))
        img = img.convert("RGB")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()

    def get_page_count(self, file_bytes: bytes) -> int:
        """Get the number of pages in a PDF.

        Args:
            file_bytes: PDF file content.

        Returns:
            Number of pages.
        """
        import fitz

        doc = fitz.open(stream=file_bytes, filetype="pdf")
        try:
            return doc.page_count
        finally:
            doc.close()

    def _extract_tables(self, page: Any, clip: Any = None) -> list[TableBlock]:
        """Extract tables from a PDF page using PyMuPDF's find_tables().

        Args:
            page: A fitz Page object.
            clip: Optional fitz.Rect to restrict table detection area.

        Returns:
            List of TableBlock objects for detected tables.
        """
        table_blocks: list[TableBlock] = []
        try:
            kwargs: dict[str, Any] = {}
            if clip is not None:
                kwargs["clip"] = clip
            tables = page.find_tables(**kwargs)
            for table in tables:
                raw = table.extract()
                if not raw or len(raw) < 1:
                    continue
                # First row is headers, rest are data
                headers = [str(cell) if cell is not None else "" for cell in raw[0]]
                rows = [
                    [str(cell) if cell is not None else "" for cell in row]
                    for row in raw[1:]
                ]
                bbox = tuple(table.bbox) if hasattr(table, "bbox") else (0, 0, 0, 0)
                table_blocks.append(
                    TableBlock(headers=headers, rows=rows, bbox=bbox)
                )
        except Exception as exc:
            logger.debug("Table detection failed or unavailable", error=str(exc))
        return table_blocks

    @staticmethod
    def _filter_text_blocks_outside_tables(
        text_blocks: list[TextBlock],
        table_blocks: list[TableBlock],
    ) -> list[TextBlock]:
        """Remove text blocks whose center overlaps a detected table bbox.

        Args:
            text_blocks: Text blocks from _parse_blocks().
            table_blocks: Table blocks from _extract_tables().

        Returns:
            Filtered list of text blocks.
        """
        if not table_blocks:
            return text_blocks

        filtered: list[TextBlock] = []
        for tb in text_blocks:
            cx = (tb.bbox[0] + tb.bbox[2]) / 2
            cy = (tb.bbox[1] + tb.bbox[3]) / 2
            overlaps = False
            for tbl in table_blocks:
                if (
                    tbl.bbox[0] <= cx <= tbl.bbox[2]
                    and tbl.bbox[1] <= cy <= tbl.bbox[3]
                ):
                    overlaps = True
                    break
            if not overlaps:
                filtered.append(tb)
        return filtered

    @staticmethod
    def _merge_blocks_by_position(
        text_blocks: list[TextBlock],
        table_blocks: list[TableBlock],
    ) -> list[TextBlock | TableBlock]:
        """Merge text and table blocks sorted by vertical position (y0).

        Args:
            text_blocks: Filtered text blocks.
            table_blocks: Detected table blocks.

        Returns:
            Combined list sorted by y-coordinate of bbox.
        """
        all_blocks: list[TextBlock | TableBlock] = list(text_blocks) + list(table_blocks)
        all_blocks.sort(key=lambda b: b.bbox[1])
        return all_blocks

    def _parse_blocks(self, raw_blocks: list[dict]) -> list[TextBlock]:
        """Parse PyMuPDF text dict blocks into our data structures.

        Args:
            raw_blocks: List of block dicts from page.get_text("dict")["blocks"].

        Returns:
            List of TextBlock objects.
        """
        blocks = []
        for block in raw_blocks:
            block_type = "image" if block.get("type") == 1 else "text"
            block_bbox = tuple(block.get("bbox", (0, 0, 0, 0)))

            if block_type == "image":
                # Image blocks have no text lines
                blocks.append(
                    TextBlock(
                        lines=[],
                        bbox=block_bbox,
                        block_type="image",
                    )
                )
                continue

            lines = []
            for line in block.get("lines", []):
                line_bbox = tuple(line.get("bbox", (0, 0, 0, 0)))
                spans = []
                for span in line.get("spans", []):
                    flags = span.get("flags", 0)
                    bold = bool(flags & _FLAG_BOLD)
                    italic = bool(flags & _FLAG_ITALIC)

                    # Also detect from font name as fallback
                    font_name = span.get("font", "")
                    if not bold and "bold" in font_name.lower():
                        bold = True
                    if not italic and (
                        "italic" in font_name.lower() or "oblique" in font_name.lower()
                    ):
                        italic = True

                    spans.append(
                        TextSpan(
                            text=span.get("text", ""),
                            font_name=font_name,
                            font_size=span.get("size", 12.0),
                            color=span.get("color", 0),
                            bold=bold,
                            italic=italic,
                            bbox=tuple(span.get("bbox", (0, 0, 0, 0))),
                        )
                    )

                if spans:
                    lines.append(TextLine(spans=spans, bbox=line_bbox))

            if lines:
                blocks.append(
                    TextBlock(
                        lines=lines,
                        bbox=block_bbox,
                        block_type="text",
                    )
                )

        return blocks
