"""Vector store service for RAG.

Provides integration with Qdrant vector database for
storing and searching document embeddings.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class VectorRecord:
    """A record to store in the vector database."""

    id: str
    vector: list[float]
    payload: dict[str, Any] = field(default_factory=dict)

    @property
    def dimension(self) -> int:
        return len(self.vector)


@dataclass
class SearchResult:
    """Result from a vector search."""

    id: str
    score: float
    payload: dict[str, Any]
    vector: list[float] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "score": self.score,
            "payload": self.payload,
        }


class VectorStoreInterface(ABC):
    """Abstract interface for vector stores."""

    @abstractmethod
    async def create_collection(
        self,
        name: str,
        dimension: int,
        distance: str = "cosine",
    ) -> bool:
        """Create a collection."""
        pass

    @abstractmethod
    async def delete_collection(self, name: str) -> bool:
        """Delete a collection."""
        pass

    @abstractmethod
    async def collection_exists(self, name: str) -> bool:
        """Check if collection exists."""
        pass

    @abstractmethod
    async def upsert(
        self,
        collection: str,
        records: list[VectorRecord],
    ) -> int:
        """Upsert records into collection."""
        pass

    @abstractmethod
    async def search(
        self,
        collection: str,
        query_vector: list[float],
        limit: int = 10,
        filter: dict[str, Any] | None = None,
        include_vectors: bool = False,
    ) -> list[SearchResult]:
        """Search for similar vectors."""
        pass

    @abstractmethod
    async def delete(
        self,
        collection: str,
        ids: list[str],
    ) -> int:
        """Delete records by ID."""
        pass

    @abstractmethod
    async def delete_by_filter(
        self,
        collection: str,
        filter: dict[str, Any],
    ) -> int:
        """Delete records by filter."""
        pass

    @abstractmethod
    async def get(
        self,
        collection: str,
        ids: list[str],
        include_vectors: bool = False,
    ) -> list[VectorRecord]:
        """Get records by ID."""
        pass

    @abstractmethod
    async def count(
        self,
        collection: str,
        filter: dict[str, Any] | None = None,
    ) -> int:
        """Count records in collection."""
        pass


class QdrantVectorStore(VectorStoreInterface):
    """Qdrant vector store implementation."""

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6333,
        api_key: str | None = None,
        https: bool = False,
        prefer_grpc: bool = False,
    ):
        """Initialize Qdrant client.

        Args:
            host: Qdrant host
            port: Qdrant port
            api_key: API key for authentication
            https: Use HTTPS
            prefer_grpc: Prefer gRPC over HTTP
        """
        self._host = host
        self._port = port
        self._api_key = api_key
        self._https = https
        self._prefer_grpc = prefer_grpc
        self._client = None

    async def _ensure_client(self) -> None:
        """Ensure client is initialized."""
        if self._client is None:
            from qdrant_client.async_qdrant_client import AsyncQdrantClient

            self._client = AsyncQdrantClient(
                host=self._host,
                port=self._port,
                api_key=self._api_key,
                https=self._https,
                prefer_grpc=self._prefer_grpc,
            )

    async def close(self) -> None:
        """Close the client connection."""
        if self._client:
            await self._client.close()
            self._client = None

    async def create_collection(
        self,
        name: str,
        dimension: int,
        distance: str = "cosine",
    ) -> bool:
        """Create a collection in Qdrant."""
        await self._ensure_client()

        from qdrant_client.models import Distance, VectorParams

        distance_map = {
            "cosine": Distance.COSINE,
            "euclidean": Distance.EUCLID,
            "dot": Distance.DOT,
        }

        try:
            await self._client.create_collection(
                collection_name=name,
                vectors_config=VectorParams(
                    size=dimension,
                    distance=distance_map.get(distance, Distance.COSINE),
                ),
            )

            logger.info(f"Created collection '{name}' with dimension {dimension}")
            return True

        except Exception:
            logger.error("Failed to create collection", name=name, exc_info=True)
            return False

    async def delete_collection(self, name: str) -> bool:
        """Delete a collection."""
        await self._ensure_client()

        try:
            await self._client.delete_collection(collection_name=name)
            logger.info(f"Deleted collection '{name}'")
            return True
        except Exception:
            logger.error("Failed to delete collection", name=name, exc_info=True)
            return False

    async def collection_exists(self, name: str) -> bool:
        """Check if collection exists."""
        await self._ensure_client()

        try:
            collections = await self._client.get_collections()
            return any(c.name == name for c in collections.collections)
        except Exception:
            return False

    async def upsert(
        self,
        collection: str,
        records: list[VectorRecord],
    ) -> int:
        """Upsert records into collection."""
        await self._ensure_client()

        from qdrant_client.models import PointStruct

        points = [
            PointStruct(
                id=record.id,
                vector=record.vector,
                payload=record.payload,
            )
            for record in records
        ]

        try:
            await self._client.upsert(
                collection_name=collection,
                points=points,
            )

            logger.info(f"Upserted {len(records)} records to '{collection}'")
            return len(records)

        except Exception:
            logger.error(
                "Failed to upsert records",
                collection=collection,
                record_count=len(records),
                exc_info=True,
            )
            raise

    async def search(
        self,
        collection: str,
        query_vector: list[float],
        limit: int = 10,
        filter: dict[str, Any] | None = None,
        include_vectors: bool = False,
    ) -> list[SearchResult]:
        """Search for similar vectors."""
        await self._ensure_client()

        try:
            # Build filter
            qdrant_filter = None
            if filter:
                from qdrant_client.models import FieldCondition, Filter, MatchValue

                conditions = []
                for key, value in filter.items():
                    if isinstance(value, list):
                        # Match any of the values
                        for v in value:
                            conditions.append(FieldCondition(key=key, match=MatchValue(value=v)))
                    else:
                        conditions.append(FieldCondition(key=key, match=MatchValue(value=value)))

                if conditions:
                    qdrant_filter = Filter(must=conditions)

            results = await self._client.search(
                collection_name=collection,
                query_vector=query_vector,
                limit=limit,
                query_filter=qdrant_filter,
                with_vectors=include_vectors,
            )

            return [
                SearchResult(
                    id=str(r.id),
                    score=r.score,
                    payload=r.payload or {},
                    vector=r.vector if include_vectors else None,
                )
                for r in results
            ]

        except Exception:
            logger.error(
                "Vector search failed",
                collection=collection,
                limit=limit,
                exc_info=True,
            )
            return []

    async def delete(
        self,
        collection: str,
        ids: list[str],
    ) -> int:
        """Delete records by ID."""
        await self._ensure_client()

        try:
            await self._client.delete(
                collection_name=collection,
                points_selector=ids,
            )

            logger.info(f"Deleted {len(ids)} records from '{collection}'")
            return len(ids)

        except Exception:
            logger.error(
                "Failed to delete records",
                collection=collection,
                id_count=len(ids),
                exc_info=True,
            )
            return 0

    async def delete_by_filter(
        self,
        collection: str,
        filter: dict[str, Any],
    ) -> int:
        """Delete records by filter."""
        await self._ensure_client()

        from qdrant_client.models import FieldCondition, Filter, MatchValue

        try:
            conditions = []
            for key, value in filter.items():
                conditions.append(FieldCondition(key=key, match=MatchValue(value=value)))

            qdrant_filter = Filter(must=conditions)

            await self._client.delete(
                collection_name=collection,
                points_selector=qdrant_filter,
            )

            logger.info(f"Deleted records by filter from '{collection}'")
            return -1  # Unknown count

        except Exception:
            logger.error(
                "Failed to delete by filter",
                collection=collection,
                exc_info=True,
            )
            return 0

    async def get(
        self,
        collection: str,
        ids: list[str],
        include_vectors: bool = False,
    ) -> list[VectorRecord]:
        """Get records by ID."""
        await self._ensure_client()

        try:
            results = await self._client.retrieve(
                collection_name=collection,
                ids=ids,
                with_vectors=include_vectors,
            )

            return [
                VectorRecord(
                    id=str(r.id),
                    vector=r.vector if include_vectors else [],
                    payload=r.payload or {},
                )
                for r in results
            ]

        except Exception:
            logger.error(
                "Failed to get records",
                collection=collection,
                id_count=len(ids),
                exc_info=True,
            )
            return []

    async def count(
        self,
        collection: str,
        filter: dict[str, Any] | None = None,
    ) -> int:
        """Count records in collection."""
        await self._ensure_client()

        try:
            collection_info = await self._client.get_collection(collection_name=collection)
            return collection_info.points_count

        except Exception:
            logger.error(
                "Failed to count records",
                collection=collection,
                exc_info=True,
            )
            return 0

    async def create_multi_vector_collection(
        self,
        name: str,
        vector_configs: dict[str, tuple[int, str]],
    ) -> bool:
        """Create a collection with named vectors for multi-modal search.

        Args:
            name: Collection name.
            vector_configs: Mapping of vector_name -> (dimension, distance).
                Example: {"text": (1024, "cosine"), "visual": (128, "cosine")}

        Returns:
            True if collection was created successfully.
        """
        await self._ensure_client()

        from qdrant_client.models import Distance, VectorParams

        distance_map = {
            "cosine": Distance.COSINE,
            "euclidean": Distance.EUCLID,
            "dot": Distance.DOT,
        }

        try:
            vectors_config = {
                vec_name: VectorParams(
                    size=dim,
                    distance=distance_map.get(dist, Distance.COSINE),
                )
                for vec_name, (dim, dist) in vector_configs.items()
            }

            await self._client.create_collection(
                collection_name=name,
                vectors_config=vectors_config,
            )

            logger.info(
                "Created multi-vector collection",
                name=name,
                vectors=list(vector_configs.keys()),
            )
            return True

        except Exception:
            logger.error(
                "Failed to create multi-vector collection",
                name=name,
                exc_info=True,
            )
            return False

    async def upsert_multi_vector(
        self,
        collection: str,
        records: list[dict[str, Any]],
    ) -> int:
        """Upsert records with named vectors.

        Args:
            collection: Collection name.
            records: List of dicts with "id", "vectors" (name->vec), "payload".

        Returns:
            Number of records upserted.
        """
        await self._ensure_client()

        from qdrant_client.models import PointStruct

        points = [
            PointStruct(
                id=record["id"],
                vector=record["vectors"],
                payload=record.get("payload", {}),
            )
            for record in records
        ]

        try:
            await self._client.upsert(
                collection_name=collection,
                points=points,
            )
            logger.info(
                "Upserted multi-vector records",
                collection=collection,
                count=len(records),
            )
            return len(records)
        except Exception:
            logger.error(
                "Failed to upsert multi-vector records",
                collection=collection,
                exc_info=True,
            )
            raise

    async def search_named_vector(
        self,
        collection: str,
        vector_name: str,
        query_vector: list[float],
        limit: int = 10,
        filter: dict[str, Any] | None = None,
    ) -> list[SearchResult]:
        """Search using a specific named vector.

        Args:
            collection: Collection name.
            vector_name: Name of the vector to search (e.g., "text", "visual").
            query_vector: Query embedding.
            limit: Max results.
            filter: Optional metadata filter.

        Returns:
            Search results.
        """
        await self._ensure_client()

        try:
            qdrant_filter = None
            if filter:
                from qdrant_client.models import FieldCondition, Filter, MatchValue

                conditions = [
                    FieldCondition(key=key, match=MatchValue(value=value))
                    for key, value in filter.items()
                ]
                qdrant_filter = Filter(must=conditions)

            results = await self._client.search(
                collection_name=collection,
                query_vector=(vector_name, query_vector),
                limit=limit,
                query_filter=qdrant_filter,
            )

            return [
                SearchResult(
                    id=str(r.id),
                    score=r.score,
                    payload=r.payload or {},
                )
                for r in results
            ]

        except Exception:
            logger.error(
                "Named vector search failed",
                collection=collection,
                vector_name=vector_name,
                exc_info=True,
            )
            return []

    async def hybrid_search(
        self,
        collection: str,
        dense_vector: list[float],
        sparse_vector: dict[int, float] | None = None,
        limit: int = 10,
        filter: dict[str, Any] | None = None,
        alpha: float = 0.5,
    ) -> list[SearchResult]:
        """Perform hybrid search combining dense and sparse vectors.

        Args:
            collection: Collection name
            dense_vector: Dense embedding vector
            sparse_vector: Sparse vector (term frequencies)
            limit: Number of results
            filter: Metadata filter
            alpha: Weight for dense vs sparse (0=sparse, 1=dense)

        Returns:
            List of search results
        """
        # For now, just do dense search
        # Hybrid search requires Qdrant named vectors
        return await self.search(
            collection=collection,
            query_vector=dense_vector,
            limit=limit,
            filter=filter,
        )

    async def search_multi_modal(
        self,
        collection: str,
        text_vector: list[float] | None = None,
        visual_vector: list[float] | None = None,
        limit: int = 10,
        filter: dict[str, Any] | None = None,
        text_weight: float = 0.7,
    ) -> list[SearchResult]:
        """Search using both text and visual vectors with score fusion.

        Args:
            collection: Collection name.
            text_vector: Text embedding query vector.
            visual_vector: Visual embedding query vector.
            limit: Max results.
            filter: Optional metadata filter.
            text_weight: Weight for text results (1-text_weight for visual).

        Returns:
            Fused search results.
        """
        text_results: list[SearchResult] = []
        visual_results: list[SearchResult] = []

        if text_vector:
            text_results = await self.search_named_vector(
                collection, "text", text_vector, limit=limit * 2, filter=filter
            )
        if visual_vector:
            visual_results = await self.search_named_vector(
                collection, "visual", visual_vector, limit=limit * 2, filter=filter
            )

        if not text_results and not visual_results:
            return []

        # Reciprocal rank fusion
        return self._reciprocal_rank_fusion(text_results, visual_results, text_weight, limit)

    def _reciprocal_rank_fusion(
        self,
        results_a: list[SearchResult],
        results_b: list[SearchResult],
        weight_a: float,
        limit: int,
        k: int = 60,
    ) -> list[SearchResult]:
        """Combine two result lists using reciprocal rank fusion.

        Score = weight_a * 1/(k+rank_a) + weight_b * 1/(k+rank_b)
        """
        weight_b = 1.0 - weight_a
        scores: dict[str, float] = {}
        payloads: dict[str, dict[str, Any]] = {}

        for rank, r in enumerate(results_a):
            scores[r.id] = scores.get(r.id, 0.0) + weight_a / (k + rank + 1)
            payloads[r.id] = r.payload

        for rank, r in enumerate(results_b):
            scores[r.id] = scores.get(r.id, 0.0) + weight_b / (k + rank + 1)
            if r.id not in payloads:
                payloads[r.id] = r.payload

        # Sort by fused score
        sorted_ids = sorted(scores, key=lambda x: scores[x], reverse=True)[:limit]
        return [
            SearchResult(id=rid, score=scores[rid], payload=payloads[rid]) for rid in sorted_ids
        ]
