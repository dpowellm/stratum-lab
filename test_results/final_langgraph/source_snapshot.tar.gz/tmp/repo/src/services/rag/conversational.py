"""
Conversational Q&A Service.

Task 3.1.4: Implements multi-turn Q&A with conversation memory.
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class MessageRole(StrEnum):
    """Role in conversation."""

    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


@dataclass
class Message:
    """A conversation message."""

    role: MessageRole
    content: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "role": self.role.value,
            "content": self.content,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }


@dataclass
class Citation:
    """Source citation for answer."""

    document_id: str
    content: str
    page_number: int | None = None
    relevance_score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "document_id": self.document_id,
            "content": self.content,
            "page_number": self.page_number,
            "relevance_score": self.relevance_score,
            "metadata": self.metadata,
        }


@dataclass
class QAResponse:
    """Response from Q&A system."""

    answer: str
    citations: list[Citation]
    confidence: float
    follow_up_questions: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    processing_time_ms: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "answer": self.answer,
            "citations": [c.to_dict() for c in self.citations],
            "confidence": self.confidence,
            "follow_up_questions": self.follow_up_questions,
            "metadata": self.metadata,
            "processing_time_ms": self.processing_time_ms,
        }


@dataclass
class ConversationContext:
    """Context for a conversation session."""

    conversation_id: str
    messages: list[Message] = field(default_factory=list)
    document_ids: list[str] = field(default_factory=list)
    entities: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    @property
    def turn_count(self) -> int:
        """Get number of conversation turns."""
        return len([m for m in self.messages if m.role == MessageRole.USER])

    def add_message(
        self,
        role: MessageRole,
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Add a message to the conversation."""
        self.messages.append(
            Message(
                role=role,
                content=content,
                metadata=metadata or {},
            )
        )
        self.updated_at = datetime.utcnow()

    def get_history_text(
        self,
        max_turns: int | None = None,
    ) -> str:
        """Get conversation history as text."""
        messages = self.messages
        if max_turns:
            # Get last N turns (2 messages per turn: user + assistant)
            messages = messages[-(max_turns * 2) :]

        lines = []
        for msg in messages:
            prefix = "User" if msg.role == MessageRole.USER else "Assistant"
            lines.append(f"{prefix}: {msg.content}")

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "conversation_id": self.conversation_id,
            "messages": [m.to_dict() for m in self.messages],
            "document_ids": self.document_ids,
            "entities": self.entities,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "turn_count": self.turn_count,
        }


class ConversationalQA:
    """
    Conversational Q&A Service.

    Features:
    - Multi-turn conversations
    - Context maintenance
    - Entity tracking
    - Follow-up question generation
    """

    def __init__(
        self,
        max_history_turns: int = 10,
        min_confidence: float = 0.3,
    ):
        """
        Initialize conversational Q&A.

        Args:
            max_history_turns: Maximum conversation turns to keep
            min_confidence: Minimum confidence threshold
        """
        self.max_history_turns = max_history_turns
        self.min_confidence = min_confidence
        self._conversations: dict[str, ConversationContext] = {}
        self._retriever = None  # Would be injected

    def create_conversation(
        self,
        document_ids: list[str] | None = None,
    ) -> ConversationContext:
        """
        Create a new conversation.

        Args:
            document_ids: Documents to include in context

        Returns:
            New conversation context
        """
        conversation_id = str(uuid.uuid4())
        context = ConversationContext(
            conversation_id=conversation_id,
            document_ids=document_ids or [],
        )
        self._conversations[conversation_id] = context

        logger.info(
            "Conversation created",
            conversation_id=conversation_id,
            documents=len(context.document_ids),
        )

        return context

    def get_conversation(
        self,
        conversation_id: str,
    ) -> ConversationContext | None:
        """Get a conversation by ID."""
        return self._conversations.get(conversation_id)

    def ask(
        self,
        conversation_id: str,
        question: str,
    ) -> QAResponse:
        """
        Ask a question in a conversation.

        Args:
            conversation_id: Conversation ID
            question: User question

        Returns:
            Q&A response
        """
        start_time = datetime.utcnow()

        context = self._conversations.get(conversation_id)
        if not context:
            # Create new conversation
            context = self.create_conversation()
            conversation_id = context.conversation_id

        # Add user message
        context.add_message(MessageRole.USER, question)

        # Rewrite query with context
        rewritten_query = self._rewrite_query(question, context)

        # Retrieve relevant passages
        citations = self._retrieve_passages(rewritten_query, context.document_ids)

        # Generate answer
        answer, confidence = self._generate_answer(question, citations, context)

        # Extract entities for context
        self._extract_entities(question, answer, context)

        # Generate follow-up questions
        follow_ups = self._generate_follow_ups(question, answer, context)

        # Add assistant message
        context.add_message(
            MessageRole.ASSISTANT,
            answer,
            metadata={"confidence": confidence},
        )

        # Calculate processing time
        processing_time_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)

        return QAResponse(
            answer=answer,
            citations=citations,
            confidence=confidence,
            follow_up_questions=follow_ups,
            processing_time_ms=processing_time_ms,
        )

    def _rewrite_query(
        self,
        question: str,
        context: ConversationContext,
    ) -> str:
        """
        Rewrite query with conversation context.

        Handles:
        - Pronoun resolution (it, they, this)
        - Implicit references
        - Follow-up questions
        """
        # Get recent messages
        context.get_history_text(max_turns=3)

        # Simple pronoun resolution
        pronouns = ["it", "they", "this", "that", "them", "these"]
        question_lower = question.lower()

        # Check if question contains pronouns that need resolution
        has_pronouns = any(
            f" {p} " in f" {question_lower} "
            or question_lower.startswith(f"{p} ")
            or question_lower.endswith(f" {p}")
            for p in pronouns
        )

        if has_pronouns and context.entities:
            # Try to resolve pronouns using tracked entities
            for entity_type, entity_value in context.entities.items():
                if entity_type in ["subject", "topic"]:
                    for p in pronouns:
                        question = question.replace(f" {p} ", f" {entity_value} ")

        return question

    def _retrieve_passages(
        self,
        query: str,
        document_ids: list[str],
    ) -> list[Citation]:
        """Retrieve relevant passages for the query."""
        # Simulated retrieval
        # In production, would use actual retriever
        citations = []

        # Simulate finding relevant passages
        if document_ids:
            for i, doc_id in enumerate(document_ids[:3]):
                citations.append(
                    Citation(
                        document_id=doc_id,
                        content=f"Relevant passage from document {doc_id} for query: {query[:50]}...",
                        page_number=i + 1,
                        relevance_score=0.9 - i * 0.1,
                    )
                )

        return citations

    def _generate_answer(
        self,
        question: str,
        citations: list[Citation],
        context: ConversationContext,
    ) -> tuple[str, float]:
        """Generate answer from citations and context."""
        # Simulated answer generation
        # In production, would use LLM with RAG

        if not citations:
            return (
                "I don't have enough information to answer this question based on the available documents.",
                0.2,
            )

        # Build context from citations
        citation_texts = [c.content for c in citations]

        # Simulate answer
        answer = f"Based on the available documents: {citation_texts[0]}"

        # Calculate confidence based on citation scores
        avg_relevance = sum(c.relevance_score for c in citations) / len(citations)
        confidence = min(0.95, avg_relevance)

        return answer, confidence

    def _extract_entities(
        self,
        question: str,
        answer: str,
        context: ConversationContext,
    ) -> None:
        """Extract and track entities from conversation."""
        # Simple entity extraction
        # In production, would use NER

        # Track the subject of the conversation
        words = question.split()
        for i, word in enumerate(words):
            if word.lower() in ["about", "regarding", "concerning"] and i + 1 < len(words):
                context.entities["topic"] = words[i + 1]
                break

        # Track mentioned document types
        doc_types = ["invoice", "contract", "receipt", "form"]
        for doc_type in doc_types:
            if doc_type in question.lower() or doc_type in answer.lower():
                context.entities["document_type"] = doc_type
                break

    def _generate_follow_ups(
        self,
        question: str,
        answer: str,
        context: ConversationContext,
    ) -> list[str]:
        """Generate follow-up question suggestions."""
        follow_ups = []

        # Based on document type
        if "document_type" in context.entities:
            doc_type = context.entities["document_type"]
            if doc_type == "invoice":
                follow_ups.extend(
                    [
                        "What is the total amount?",
                        "When is the payment due?",
                        "What are the line items?",
                    ]
                )
            elif doc_type == "contract":
                follow_ups.extend(
                    [
                        "What are the key terms?",
                        "When does it expire?",
                        "Who are the parties involved?",
                    ]
                )

        # Generic follow-ups
        if not follow_ups:
            follow_ups = [
                "Can you provide more details?",
                "What else can you tell me about this?",
            ]

        return follow_ups[:3]

    def clear_conversation(
        self,
        conversation_id: str,
    ) -> bool:
        """Clear a conversation."""
        if conversation_id in self._conversations:
            del self._conversations[conversation_id]
            return True
        return False

    def get_all_conversations(self) -> list[ConversationContext]:
        """Get all active conversations."""
        return list(self._conversations.values())

    def get_statistics(self) -> dict[str, Any]:
        """Get service statistics."""
        total_turns = sum(c.turn_count for c in self._conversations.values())

        return {
            "active_conversations": len(self._conversations),
            "total_turns": total_turns,
            "max_history_turns": self.max_history_turns,
            "min_confidence": self.min_confidence,
        }


# Singleton instance
_conversational_qa: ConversationalQA | None = None


def get_conversational_qa() -> ConversationalQA:
    """Get or create conversational Q&A singleton."""
    global _conversational_qa
    if _conversational_qa is None:
        _conversational_qa = ConversationalQA()
    return _conversational_qa
