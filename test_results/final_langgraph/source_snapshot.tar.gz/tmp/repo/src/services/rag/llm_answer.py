"""LLM-based Answer Generator for Q&A.

Uses Qwen VLM in text-only mode via llama-cpp-python to generate
natural language answers from retrieved context chunks. Falls back
silently when no model is available.
"""

from pathlib import Path
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


def _find_gguf_model() -> Path | None:
    """Search for a text-generation GGUF model in known cache directories.

    Searches the project cache first (where download_models.py stores files),
    then falls back to the HuggingFace cache.
    """
    search_dirs = [
        # Primary: project download location
        Path.home() / ".cache" / "agentic-doc-extraction" / "models" / "gguf",
        # Fallback: HuggingFace cache
        Path.home() / ".cache" / "huggingface" / "hub",
    ]

    for cache_dir in search_dirs:
        if not cache_dir.exists():
            continue
        # Look for Qwen or olmOCR GGUF models (both can do text generation)
        candidates = [
            p
            for p in cache_dir.rglob("*.gguf")
            if "qwen" in p.name.lower() or "olmocr" in p.name.lower()
        ]
        if not candidates:
            continue
        # Prefer text-only (non-mmproj) files, prefer Qwen over olmOCR
        text_models = [c for c in candidates if "mmproj" not in c.name.lower()]
        if text_models:
            qwen = [c for c in text_models if "qwen" in c.name.lower()]
            return qwen[0] if qwen else text_models[0]
        return candidates[0]

    return None


class LLMAnswerGenerator:
    """Generates natural language answers using a local GGUF model."""

    _instance: "LLMAnswerGenerator | None" = None

    def __init__(self) -> None:
        self._model: Any = None
        self._available: bool | None = None

    @classmethod
    def get_instance(cls) -> "LLMAnswerGenerator":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @property
    def is_available(self) -> bool:
        if self._available is not None:
            return self._available
        self._available = self._try_init()
        return self._available

    def _try_init(self) -> bool:
        """Try to initialize the GGUF model."""
        try:
            model_path = _find_gguf_model()
            if model_path is None:
                logger.debug("No Qwen GGUF model found, LLM answering disabled")
                return False

            from llama_cpp import Llama

            self._model = Llama(
                model_path=str(model_path),
                n_ctx=4096,
                n_gpu_layers=-1,
                verbose=False,
            )
            logger.info("LLM answer generator initialized", model=str(model_path.name))
            return True
        except Exception as exc:
            logger.debug("LLM answer generator init failed", error=str(exc))
            return False

    def generate(
        self,
        question: str,
        context_chunks: list[str],
        conversation_history: list[dict[str, str]] | None = None,
    ) -> tuple[str, float] | None:
        """Generate an answer from context chunks.

        Args:
            question: User question.
            context_chunks: Retrieved text passages.
            conversation_history: Optional list of prior messages
                (each with "role" and "content" keys).

        Returns:
            Tuple of (answer_text, confidence) or None if unavailable.
        """
        if not self.is_available or self._model is None:
            return None

        try:
            context = "\n\n---\n\n".join(context_chunks[:5])

            system_instruction = (
                "You are a knowledgeable document analysis assistant. "
                "You provide clear, well-structured answers based on the provided document context. "
                "Format your responses using markdown: use headers, bullet points, bold text, "
                "and tables where appropriate. Be conversational and helpful. "
                "If the context doesn't contain enough information, say so."
            )

            # Build conversation context from history (last 6 turns)
            history_text = ""
            if conversation_history:
                recent = conversation_history[-6:]
                history_parts = []
                for msg in recent:
                    role = msg.get("role", "user").capitalize()
                    content = msg.get("content", "")
                    history_parts.append(f"{role}: {content}")
                history_text = "\n\n## Conversation History\n" + "\n".join(history_parts) + "\n"

            prompt = (
                f"{system_instruction}\n\n"
                f"## Context\n{context}\n"
                f"{history_text}\n"
                f"## Question\n{question}\n\n"
                "## Answer\n"
            )

            result = self._model(
                prompt,
                max_tokens=2048,
                temperature=0.1,
                repeat_penalty=1.2,
                frequency_penalty=0.1,
                stop=["## Question"],
            )

            answer_text = result["choices"][0]["text"].strip()
            answer_text = self._truncate_repetition(answer_text)
            if not answer_text:
                return None

            confidence = self._estimate_confidence(answer_text, context_chunks)
            return answer_text, confidence

        except Exception as exc:
            logger.warning("LLM answer generation failed", error=str(exc))
            return None

    @staticmethod
    def _truncate_repetition(text: str, min_phrase_len: int = 40) -> str:
        """Detect and truncate text that has entered a repetition loop.

        Scans for any phrase of ``min_phrase_len``+ characters that appears
        more than once.  When found, the text is cut just after the first
        occurrence and a trailing incomplete sentence is stripped.
        """
        if len(text) < min_phrase_len * 2:
            return text

        # Slide a window looking for the earliest repeated phrase
        for length in range(min_phrase_len, min(200, len(text) // 2) + 1):
            phrase = text[:length]
            second = text.find(phrase, length)
            if second != -1:
                # Keep everything up to the second occurrence
                truncated = text[:second].rstrip()
                # Strip any trailing incomplete sentence fragment
                for end_char in (".", "!", "?", "\n"):
                    last = truncated.rfind(end_char)
                    if last > len(truncated) // 2:
                        return truncated[: last + 1]
                return truncated
        return text

    def _estimate_confidence(self, answer: str, context_chunks: list[str]) -> float:
        """Estimate answer confidence based on answer-context overlap."""
        if not answer or not context_chunks:
            return 0.3

        answer_words = set(answer.lower().split())
        context_text = " ".join(context_chunks).lower()
        context_words = set(context_text.split())

        if not answer_words:
            return 0.3

        overlap = len(answer_words & context_words) / len(answer_words)
        # Scale to 0.4-0.9 range
        return min(0.9, max(0.4, 0.4 + overlap * 0.5))
