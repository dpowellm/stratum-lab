"""
Hybrid Search Service.

Task 3.1.2: Implements hybrid search combining dense and sparse
retrieval for better recall.
"""

import math
import re
from collections import Counter
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Protocol

from src.core.logging import get_logger

logger = get_logger(__name__)


class SearchMethod(StrEnum):
    """Search method type."""

    DENSE = "dense"  # Vector similarity
    SPARSE = "sparse"  # BM25/keyword
    HYBRID = "hybrid"  # Combined


@dataclass
class SearchDocument:
    """Document for search indexing."""

    document_id: str
    content: str
    title: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    embedding: list[float] | None = None
    tokens: list[str] | None = None


@dataclass
class HybridResult:
    """Result from hybrid search."""

    document_id: str
    content: str
    dense_score: float
    sparse_score: float
    combined_score: float
    title: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    method: SearchMethod = SearchMethod.HYBRID

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "document_id": self.document_id,
            "content": self.content,
            "title": self.title,
            "dense_score": self.dense_score,
            "sparse_score": self.sparse_score,
            "combined_score": self.combined_score,
            "method": self.method.value,
            "metadata": self.metadata,
        }


class Retriever(Protocol):
    """Retriever protocol."""

    def search(
        self,
        query: str,
        top_k: int = 10,
    ) -> list[tuple[str, float]]:
        """Search for documents."""
        ...


class DenseRetriever:
    """
    Dense (vector) retriever.

    Uses embedding similarity for semantic search.
    """

    def __init__(
        self,
        embedding_dim: int = 1024,
    ):
        """
        Initialize dense retriever.

        Args:
            embedding_dim: Embedding dimension
        """
        self.embedding_dim = embedding_dim
        self._documents: dict[str, SearchDocument] = {}

    def index(
        self,
        document: SearchDocument,
    ) -> bool:
        """Index a document."""
        # Generate embedding if not provided
        if document.embedding is None:
            document.embedding = self._generate_embedding(document.content)

        self._documents[document.document_id] = document
        return True

    def _generate_embedding(self, text: str) -> list[float]:
        """Generate embedding for text."""
        import hashlib

        hash_bytes = hashlib.sha256(text.encode()).digest()
        embedding = [float(b) / 255.0 for b in hash_bytes]

        while len(embedding) < self.embedding_dim:
            embedding.extend(embedding[: min(len(embedding), self.embedding_dim - len(embedding))])

        return embedding[: self.embedding_dim]

    def search(
        self,
        query: str,
        top_k: int = 10,
    ) -> list[tuple[str, float]]:
        """
        Search for similar documents.

        Args:
            query: Search query
            top_k: Number of results

        Returns:
            List of (document_id, score) tuples
        """
        query_embedding = self._generate_embedding(query)

        scores: list[tuple[str, float]] = []
        for doc_id, doc in self._documents.items():
            if doc.embedding:
                score = self._cosine_similarity(query_embedding, doc.embedding)
                scores.append((doc_id, score))

        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]

    def _cosine_similarity(
        self,
        vec1: list[float],
        vec2: list[float],
    ) -> float:
        """Calculate cosine similarity."""
        dot_product = sum(a * b for a, b in zip(vec1, vec2, strict=False))
        norm1 = sum(a * a for a in vec1) ** 0.5
        norm2 = sum(b * b for b in vec2) ** 0.5

        if norm1 == 0 or norm2 == 0:
            return 0.0

        return dot_product / (norm1 * norm2)


class SparseRetriever:
    """
    Sparse (BM25) retriever.

    Uses keyword matching with BM25 scoring.
    """

    def __init__(
        self,
        k1: float = 1.5,
        b: float = 0.75,
    ):
        """
        Initialize sparse retriever.

        Args:
            k1: BM25 term frequency saturation
            b: BM25 length normalization
        """
        self.k1 = k1
        self.b = b
        self._documents: dict[str, SearchDocument] = {}
        self._doc_lengths: dict[str, int] = {}
        self._avg_doc_length: float = 0.0
        self._idf_cache: dict[str, float] = {}

    def index(
        self,
        document: SearchDocument,
    ) -> bool:
        """Index a document."""
        # Tokenize if not provided
        if document.tokens is None:
            document.tokens = self._tokenize(document.content)

        self._documents[document.document_id] = document
        self._doc_lengths[document.document_id] = len(document.tokens)

        # Update average document length
        if self._doc_lengths:
            self._avg_doc_length = sum(self._doc_lengths.values()) / len(self._doc_lengths)

        # Clear IDF cache
        self._idf_cache.clear()

        return True

    def _tokenize(self, text: str) -> list[str]:
        """Tokenize text."""
        # Simple whitespace and punctuation tokenization
        text = text.lower()
        tokens = re.findall(r"\b\w+\b", text)
        return tokens

    def _get_idf(self, term: str) -> float:
        """Get IDF score for term."""
        if term in self._idf_cache:
            return self._idf_cache[term]

        # Count documents containing term
        n_docs = len(self._documents)
        n_containing = sum(
            1 for doc in self._documents.values() if doc.tokens and term in doc.tokens
        )

        # IDF calculation
        if n_containing == 0:
            idf = 0.0
        else:
            idf = math.log((n_docs - n_containing + 0.5) / (n_containing + 0.5) + 1)

        self._idf_cache[term] = idf
        return idf

    def _bm25_score(
        self,
        query_tokens: list[str],
        doc: SearchDocument,
    ) -> float:
        """Calculate BM25 score."""
        if not doc.tokens:
            return 0.0

        doc_length = self._doc_lengths.get(doc.document_id, 0)
        if doc_length == 0:
            return 0.0

        term_freqs = Counter(doc.tokens)
        score = 0.0

        for term in query_tokens:
            if term not in term_freqs:
                continue

            tf = term_freqs[term]
            idf = self._get_idf(term)

            # BM25 formula
            numerator = tf * (self.k1 + 1)
            denominator = tf + self.k1 * (
                1 - self.b + self.b * doc_length / max(1, self._avg_doc_length)
            )
            score += idf * (numerator / denominator)

        return score

    def search(
        self,
        query: str,
        top_k: int = 10,
    ) -> list[tuple[str, float]]:
        """
        Search for matching documents.

        Args:
            query: Search query
            top_k: Number of results

        Returns:
            List of (document_id, score) tuples
        """
        query_tokens = self._tokenize(query)

        scores: list[tuple[str, float]] = []
        for doc_id, doc in self._documents.items():
            score = self._bm25_score(query_tokens, doc)
            if score > 0:
                scores.append((doc_id, score))

        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]


class HybridSearchService:
    """
    Hybrid Search Service.

    Combines dense and sparse retrieval for optimal recall.
    """

    def __init__(
        self,
        dense_weight: float = 0.5,
        sparse_weight: float = 0.5,
        embedding_dim: int = 1024,
    ):
        """
        Initialize hybrid search.

        Args:
            dense_weight: Weight for dense scores
            sparse_weight: Weight for sparse scores
            embedding_dim: Embedding dimension for dense retriever
        """
        self.dense_weight = dense_weight
        self.sparse_weight = sparse_weight
        self._dense_retriever = DenseRetriever(embedding_dim)
        self._sparse_retriever = SparseRetriever()
        self._documents: dict[str, SearchDocument] = {}

    def index(
        self,
        document: SearchDocument,
    ) -> bool:
        """
        Index a document in both retrievers.

        Args:
            document: Document to index

        Returns:
            True if indexed successfully
        """
        self._documents[document.document_id] = document
        self._dense_retriever.index(document)
        self._sparse_retriever.index(document)

        logger.debug(
            "Document indexed",
            document_id=document.document_id,
        )
        return True

    def search(
        self,
        query: str,
        top_k: int = 10,
        method: SearchMethod = SearchMethod.HYBRID,
    ) -> list[HybridResult]:
        """
        Search for relevant documents.

        Args:
            query: Search query
            top_k: Number of results
            method: Search method to use

        Returns:
            List of hybrid search results
        """
        if method == SearchMethod.DENSE:
            dense_results = self._dense_retriever.search(query, top_k)
            return self._format_results(dense_results, [], method)

        elif method == SearchMethod.SPARSE:
            sparse_results = self._sparse_retriever.search(query, top_k)
            return self._format_results([], sparse_results, method)

        else:
            # Hybrid search
            dense_results = self._dense_retriever.search(query, top_k * 2)
            sparse_results = self._sparse_retriever.search(query, top_k * 2)
            return self._merge_results(dense_results, sparse_results, top_k)

    def _format_results(
        self,
        dense_results: list[tuple[str, float]],
        sparse_results: list[tuple[str, float]],
        method: SearchMethod,
    ) -> list[HybridResult]:
        """Format results from single retriever."""
        results = []
        result_list = dense_results if method == SearchMethod.DENSE else sparse_results

        for doc_id, score in result_list:
            doc = self._documents.get(doc_id)
            if doc:
                results.append(
                    HybridResult(
                        document_id=doc_id,
                        content=doc.content,
                        title=doc.title,
                        dense_score=score if method == SearchMethod.DENSE else 0.0,
                        sparse_score=score if method == SearchMethod.SPARSE else 0.0,
                        combined_score=score,
                        metadata=doc.metadata,
                        method=method,
                    )
                )

        return results

    def _merge_results(
        self,
        dense_results: list[tuple[str, float]],
        sparse_results: list[tuple[str, float]],
        top_k: int,
    ) -> list[HybridResult]:
        """Merge results from both retrievers."""
        # Normalize scores
        dense_scores = self._normalize_scores(dict(dense_results))
        sparse_scores = self._normalize_scores(dict(sparse_results))

        # Combine scores
        all_doc_ids = set(dense_scores.keys()) | set(sparse_scores.keys())
        combined_results = []

        for doc_id in all_doc_ids:
            dense_score = dense_scores.get(doc_id, 0.0)
            sparse_score = sparse_scores.get(doc_id, 0.0)

            combined_score = self.dense_weight * dense_score + self.sparse_weight * sparse_score

            doc = self._documents.get(doc_id)
            if doc:
                combined_results.append(
                    HybridResult(
                        document_id=doc_id,
                        content=doc.content,
                        title=doc.title,
                        dense_score=dense_score,
                        sparse_score=sparse_score,
                        combined_score=combined_score,
                        metadata=doc.metadata,
                        method=SearchMethod.HYBRID,
                    )
                )

        # Sort by combined score
        combined_results.sort(key=lambda r: r.combined_score, reverse=True)
        return combined_results[:top_k]

    def _normalize_scores(
        self,
        scores: dict[str, float],
    ) -> dict[str, float]:
        """Normalize scores to [0, 1] range."""
        if not scores:
            return {}

        min_score = min(scores.values())
        max_score = max(scores.values())
        range_score = max_score - min_score

        if range_score == 0:
            return dict.fromkeys(scores, 1.0)

        return {k: (v - min_score) / range_score for k, v in scores.items()}

    def delete_document(self, document_id: str) -> bool:
        """Delete a document from the index."""
        if document_id in self._documents:
            del self._documents[document_id]
            # Note: Would also need to remove from retrievers
            return True
        return False

    def get_statistics(self) -> dict[str, Any]:
        """Get service statistics."""
        return {
            "total_documents": len(self._documents),
            "dense_weight": self.dense_weight,
            "sparse_weight": self.sparse_weight,
        }


# Singleton instance
_hybrid_search: HybridSearchService | None = None


def get_hybrid_search() -> HybridSearchService:
    """Get or create hybrid search singleton."""
    global _hybrid_search
    if _hybrid_search is None:
        _hybrid_search = HybridSearchService()
    return _hybrid_search
