"""Retrieval service for RAG.

Provides document retrieval capabilities combining
vector search with optional reranking.
"""

import asyncio
from dataclasses import dataclass, field
from typing import Any

from src.core.logging import get_logger
from src.services.rag.embedding import EmbeddingServiceInterface
from src.services.rag.vector_store import VectorStoreInterface

logger = get_logger(__name__)


@dataclass
class RankedChunk:
    """A retrieved and ranked chunk."""

    chunk_id: str
    text: str
    document_id: str
    score: float
    page: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    rerank_score: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "chunk_id": self.chunk_id,
            "text": self.text,
            "document_id": self.document_id,
            "score": self.score,
            "page": self.page,
            "metadata": self.metadata,
            "rerank_score": self.rerank_score,
        }


@dataclass
class RetrievalResult:
    """Result from retrieval operation."""

    query: str
    chunks: list[RankedChunk]
    total_found: int
    search_method: str = "dense"
    filter_applied: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "chunks": [c.to_dict() for c in self.chunks],
            "total_found": self.total_found,
            "search_method": self.search_method,
            "filter_applied": self.filter_applied,
        }


class RetrievalService:
    """Service for retrieving relevant documents."""

    def __init__(
        self,
        vector_store: VectorStoreInterface,
        embedding_service: EmbeddingServiceInterface,
        collection_name: str = "documents",
        reranker=None,
    ):
        """Initialize retrieval service.

        Args:
            vector_store: Vector store for search
            embedding_service: Embedding service for queries
            collection_name: Default collection name
            reranker: Optional reranker model
        """
        self._vector_store = vector_store
        self._embedding_service = embedding_service
        self._collection_name = collection_name
        self._reranker = reranker

    async def retrieve(
        self,
        query: str,
        top_k: int = 10,
        collection: str | None = None,
        filter: dict[str, Any] | None = None,
        rerank: bool = False,
        score_threshold: float = 0.0,
    ) -> RetrievalResult:
        """Retrieve relevant chunks for a query.

        Args:
            query: Search query
            top_k: Number of results to return
            collection: Collection to search (uses default if None)
            filter: Metadata filter
            rerank: Whether to rerank results
            score_threshold: Minimum score threshold

        Returns:
            RetrievalResult with ranked chunks
        """
        collection = collection or self._collection_name

        logger.info(
            f"Retrieving for query: {query[:50]}...",
            top_k=top_k,
            collection=collection,
        )

        try:
            # Generate query embedding
            query_embedding = await self._embedding_service.embed_query(query)

            # Search vector store
            # Request more results if reranking
            search_limit = top_k * 3 if rerank else top_k

            results = await self._vector_store.search(
                collection=collection,
                query_vector=query_embedding.embedding,
                limit=search_limit,
                filter=filter,
            )

            # Filter by score threshold
            results = [r for r in results if r.score >= score_threshold]

            # Convert to ranked chunks
            chunks = [
                RankedChunk(
                    chunk_id=r.id,
                    text=r.payload.get("text", ""),
                    document_id=r.payload.get("document_id", ""),
                    score=r.score,
                    page=r.payload.get("page"),
                    metadata={
                        k: v
                        for k, v in r.payload.items()
                        if k not in ("text", "document_id", "page")
                    },
                )
                for r in results
            ]

            # Rerank if requested
            if rerank and self._reranker and chunks:
                chunks = await self._rerank(query, chunks)

            # Limit to top_k
            chunks = chunks[:top_k]

            logger.info(
                f"Retrieved {len(chunks)} chunks",
                query_length=len(query),
            )

            return RetrievalResult(
                query=query,
                chunks=chunks,
                total_found=len(results),
                search_method="dense" + ("+rerank" if rerank else ""),
                filter_applied=filter,
            )

        except Exception:
            logger.error(
                "Retrieval failed",
                query_length=len(query),
                collection=collection,
                exc_info=True,
            )
            return RetrievalResult(
                query=query,
                chunks=[],
                total_found=0,
                search_method="failed",
            )

    async def retrieve_for_documents(
        self,
        query: str,
        document_ids: list[str],
        top_k: int = 10,
        collection: str | None = None,
    ) -> RetrievalResult:
        """Retrieve from specific documents.

        Args:
            query: Search query
            document_ids: Documents to search within
            top_k: Number of results
            collection: Collection name

        Returns:
            RetrievalResult filtered to documents
        """
        return await self.retrieve(
            query=query,
            top_k=top_k,
            collection=collection,
            filter={"document_id": document_ids},
        )

    async def multi_query_retrieve(
        self,
        queries: list[str],
        top_k: int = 10,
        collection: str | None = None,
        filter: dict[str, Any] | None = None,
    ) -> RetrievalResult:
        """Retrieve using multiple query variations.

        Useful for query expansion where the same intent
        is expressed in different ways.

        Args:
            queries: List of query variations
            top_k: Number of results per query
            collection: Collection name
            filter: Metadata filter

        Returns:
            Merged and deduplicated results
        """
        collection = collection or self._collection_name

        # Run queries in parallel
        tasks = [
            self.retrieve(q, top_k=top_k, collection=collection, filter=filter) for q in queries
        ]

        results = await asyncio.gather(*tasks)

        # Merge and deduplicate
        seen_ids = set()
        merged_chunks = []

        for result in results:
            for chunk in result.chunks:
                if chunk.chunk_id not in seen_ids:
                    seen_ids.add(chunk.chunk_id)
                    merged_chunks.append(chunk)

        # Sort by score and limit
        merged_chunks.sort(key=lambda x: x.score, reverse=True)
        merged_chunks = merged_chunks[:top_k]

        return RetrievalResult(
            query=" | ".join(queries),
            chunks=merged_chunks,
            total_found=len(seen_ids),
            search_method="multi_query",
            filter_applied=filter,
        )

    async def _rerank(
        self,
        query: str,
        chunks: list[RankedChunk],
    ) -> list[RankedChunk]:
        """Rerank chunks using reranker model.

        Args:
            query: Original query
            chunks: Chunks to rerank

        Returns:
            Reranked chunks
        """
        if not self._reranker:
            return chunks

        logger.info(f"Reranking {len(chunks)} chunks")

        try:
            # Get rerank scores
            texts = [c.text for c in chunks]
            scores = await self._reranker.rerank(query, texts)

            # Update chunks with rerank scores
            for chunk, score in zip(chunks, scores, strict=False):
                chunk.rerank_score = score

            # Sort by rerank score
            chunks.sort(key=lambda x: x.rerank_score or 0, reverse=True)

            return chunks

        except Exception:
            logger.warning("Reranking failed, returning original order", exc_info=True)
            return chunks

    async def index_document(
        self,
        document_id: str,
        chunks: list[dict[str, Any]],
        collection: str | None = None,
    ) -> int:
        """Index document chunks into vector store.

        Args:
            document_id: Document identifier
            chunks: Chunks to index (must have 'text' key)
            collection: Collection name

        Returns:
            Number of chunks indexed
        """
        collection = collection or self._collection_name

        logger.info(
            f"Indexing {len(chunks)} chunks for document {document_id}",
            collection=collection,
        )

        # Generate embeddings
        texts = [c["text"] for c in chunks]
        embeddings = await self._embedding_service.embed_documents(texts)

        # Create vector records
        from src.services.rag.vector_store import VectorRecord

        records = []
        for i, (chunk, emb) in enumerate(zip(chunks, embeddings, strict=False)):
            records.append(
                VectorRecord(
                    id=chunk.get("id", f"{document_id}_chunk_{i}"),
                    vector=emb.embedding,
                    payload={
                        "text": chunk["text"],
                        "document_id": document_id,
                        "position": chunk.get("position", i),
                        "page": chunk.get("page"),
                        **chunk.get("metadata", {}),
                    },
                )
            )

        # Upsert to vector store
        await self._vector_store.upsert(collection, records)

        logger.info(f"Indexed {len(records)} chunks")
        return len(records)

    async def delete_document(
        self,
        document_id: str,
        collection: str | None = None,
    ) -> int:
        """Delete all chunks for a document.

        Args:
            document_id: Document identifier
            collection: Collection name

        Returns:
            Number of chunks deleted
        """
        collection = collection or self._collection_name

        logger.info(
            f"Deleting chunks for document {document_id}",
            collection=collection,
        )

        result = await self._vector_store.delete_by_filter(
            collection=collection,
            filter={"document_id": document_id},
        )

        logger.info(f"Deleted chunks for document {document_id}")
        return result

    async def get_document_chunks(
        self,
        document_id: str,
        collection: str | None = None,
        max_chunks: int = 500,
    ) -> list[dict[str, Any]]:
        """Get all chunks for a document.

        Uses a unit vector for search with document_id filter to retrieve
        all chunks belonging to a document. Results are sorted by position.

        Args:
            document_id: Document identifier
            collection: Collection name
            max_chunks: Maximum number of chunks to return

        Returns:
            List of chunk data sorted by position
        """
        collection = collection or self._collection_name

        # Use a normalised unit vector (rather than zero vector) to avoid
        # division-by-zero issues in cosine similarity computation.
        dim = self._embedding_service.dimension
        unit_vector = [1.0 / (dim**0.5)] * dim

        try:
            results = await self._vector_store.search(
                collection=collection,
                query_vector=unit_vector,
                limit=max_chunks,
                filter={"document_id": document_id},
            )
        except Exception:
            logger.warning(
                "Failed to retrieve document chunks",
                document_id=document_id,
                exc_info=True,
            )
            return []

        chunks = [
            {
                "id": r.id,
                "text": r.payload.get("text", ""),
                "position": r.payload.get("position", 0),
                "page": r.payload.get("page"),
                "metadata": {
                    k: v
                    for k, v in r.payload.items()
                    if k not in ("text", "document_id", "position", "page")
                },
            }
            for r in results
        ]

        # Sort by position for logical ordering
        chunks.sort(key=lambda c: c.get("position", 0))
        return chunks
