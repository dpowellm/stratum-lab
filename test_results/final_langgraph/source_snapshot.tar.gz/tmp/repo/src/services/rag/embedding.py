"""Embedding service for RAG.

Provides text embedding generation using BGE-M3 model
for multilingual dense embeddings.
"""

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class EmbeddingResult:
    """Result from embedding generation."""

    text: str
    embedding: list[float]
    model: str
    dimension: int
    tokens_used: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "text_preview": self.text[:100] if self.text else "",
            "dimension": self.dimension,
            "model": self.model,
            "tokens_used": self.tokens_used,
        }


class EmbeddingServiceInterface(ABC):
    """Abstract interface for embedding services."""

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Get model name."""
        pass

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Get embedding dimension."""
        pass

    @abstractmethod
    async def embed_text(self, text: str) -> EmbeddingResult:
        """Generate embedding for a single text."""
        pass

    @abstractmethod
    async def embed_texts(self, texts: list[str]) -> list[EmbeddingResult]:
        """Generate embeddings for multiple texts."""
        pass

    @abstractmethod
    async def embed_query(self, query: str) -> EmbeddingResult:
        """Generate embedding for a query (may use different prefix)."""
        pass


class BGEEmbeddingService(EmbeddingServiceInterface):
    """BGE-M3 embedding service.

    BGE-M3 is a multilingual embedding model with 1024 dimensions.
    It supports both dense and sparse (lexical) embeddings.
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-m3",
        device: str | None = None,
        max_length: int = 8192,
        batch_size: int = 32,
        use_fp16: bool = True,
    ):
        """Initialize BGE embedding service.

        Args:
            model_name: Model identifier
            device: Device to use (cuda, cpu, auto)
            max_length: Maximum sequence length
            batch_size: Batch size for encoding
            use_fp16: Use half precision
        """
        self._model_name = model_name
        self._device = device
        self._max_length = max_length
        self._batch_size = batch_size
        self._use_fp16 = use_fp16
        self._model = None
        self._dimension = 1024  # BGE-M3 dimension
        self._model_lock = asyncio.Lock()

    @property
    def model_name(self) -> str:
        return self._model_name

    @property
    def dimension(self) -> int:
        return self._dimension

    async def _ensure_model(self) -> None:
        """Ensure model is loaded (thread-safe with asyncio.Lock)."""
        if self._model is None:
            async with self._model_lock:
                if self._model is None:
                    await self._load_model()

    async def _load_model(self) -> None:
        """Load the embedding model."""
        logger.info(f"Loading embedding model: {self._model_name}")

        try:
            # Try to load FlagEmbedding (optimized for BGE)
            try:
                from FlagEmbedding import BGEM3FlagModel

                self._model = BGEM3FlagModel(
                    self._model_name,
                    use_fp16=self._use_fp16,
                )
                self._model_type = "flag"
                logger.info("Loaded BGE model using FlagEmbedding")
                return

            except ImportError:
                pass

            # Fall back to sentence-transformers
            import torch
            from sentence_transformers import SentenceTransformer

            device = self._device
            if device is None:
                device = "cuda" if torch.cuda.is_available() else "cpu"

            self._model = SentenceTransformer(
                self._model_name,
                device=device,
            )
            self._model_type = "sentence_transformer"
            self._dimension = self._model.get_sentence_embedding_dimension()

            logger.info(f"Loaded BGE model using SentenceTransformers on {device}")

        except Exception:
            logger.error(
                "Failed to load embedding model",
                model_name=self._model_name,
                exc_info=True,
            )
            raise

    async def embed_text(self, text: str) -> EmbeddingResult:
        """Generate embedding for a single text."""
        results = await self.embed_texts([text])
        return results[0]

    async def embed_texts(self, texts: list[str]) -> list[EmbeddingResult]:
        """Generate embeddings for multiple texts."""
        await self._ensure_model()

        logger.info(f"Generating embeddings for {len(texts)} texts")

        try:
            # Run in executor to not block the event loop
            loop = asyncio.get_running_loop()

            if self._model_type == "flag":
                embeddings = await loop.run_in_executor(
                    None,
                    lambda: self._model.encode(
                        texts,
                        batch_size=self._batch_size,
                        max_length=self._max_length,
                    )["dense_vecs"],
                )
            else:
                embeddings = await loop.run_in_executor(
                    None,
                    lambda: self._model.encode(
                        texts,
                        batch_size=self._batch_size,
                        show_progress_bar=False,
                        convert_to_numpy=True,
                    ),
                )

            results = []
            for text, embedding in zip(texts, embeddings, strict=False):
                results.append(
                    EmbeddingResult(
                        text=text,
                        embedding=embedding.tolist(),
                        model=self._model_name,
                        dimension=len(embedding),
                    )
                )

            logger.info(f"Generated {len(results)} embeddings")
            return results

        except Exception:
            logger.error(
                "Embedding generation failed",
                model=self._model_name,
                text_count=len(texts),
                exc_info=True,
            )
            raise

    async def embed_query(self, query: str) -> EmbeddingResult:
        """Generate embedding for a query.

        For BGE models, queries should be prefixed with "query: "
        for optimal retrieval performance.
        """
        await self._ensure_model()

        # Add query prefix for retrieval models
        prefixed_query = f"query: {query}" if "bge" in self._model_name.lower() else query

        return await self.embed_text(prefixed_query)

    async def embed_documents(
        self,
        documents: list[str],
    ) -> list[EmbeddingResult]:
        """Generate embeddings for documents.

        For BGE models, documents should be prefixed with "passage: "
        """
        # Add passage prefix for retrieval models
        if "bge" in self._model_name.lower():
            prefixed_docs = [f"passage: {doc}" for doc in documents]
        else:
            prefixed_docs = documents

        return await self.embed_texts(prefixed_docs)


class OpenAIEmbeddingService(EmbeddingServiceInterface):
    """OpenAI embedding service."""

    def __init__(
        self,
        api_key: str,
        model_name: str = "text-embedding-3-small",
    ):
        """Initialize OpenAI embedding service.

        Args:
            api_key: OpenAI API key
            model_name: Model identifier
        """
        self._api_key = api_key
        self._model_name = model_name
        self._client = None

        # Model dimensions
        self._dimensions = {
            "text-embedding-3-small": 1536,
            "text-embedding-3-large": 3072,
            "text-embedding-ada-002": 1536,
        }
        self._dimension = self._dimensions.get(model_name, 1536)

    @property
    def model_name(self) -> str:
        return self._model_name

    @property
    def dimension(self) -> int:
        return self._dimension

    async def _ensure_client(self) -> None:
        """Ensure client is initialized."""
        if self._client is None:
            from openai import AsyncOpenAI

            self._client = AsyncOpenAI(api_key=self._api_key)

    async def embed_text(self, text: str) -> EmbeddingResult:
        """Generate embedding for a single text."""
        results = await self.embed_texts([text])
        return results[0]

    async def embed_texts(self, texts: list[str]) -> list[EmbeddingResult]:
        """Generate embeddings for multiple texts."""
        await self._ensure_client()

        logger.info(f"Generating OpenAI embeddings for {len(texts)} texts")

        try:
            response = await self._client.embeddings.create(
                model=self._model_name,
                input=texts,
            )

            results = []
            for i, embedding_data in enumerate(response.data):
                results.append(
                    EmbeddingResult(
                        text=texts[i],
                        embedding=embedding_data.embedding,
                        model=self._model_name,
                        dimension=len(embedding_data.embedding),
                        tokens_used=response.usage.total_tokens // len(texts),
                    )
                )

            return results

        except Exception:
            logger.error(
                "OpenAI embedding failed",
                model=self._model_name,
                text_count=len(texts),
                exc_info=True,
            )
            raise

    async def embed_query(self, query: str) -> EmbeddingResult:
        """Generate embedding for a query."""
        return await self.embed_text(query)
