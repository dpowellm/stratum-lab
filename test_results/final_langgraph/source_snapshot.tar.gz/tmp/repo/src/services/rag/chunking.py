"""Document chunking service for RAG.

Provides strategies for splitting documents into chunks
suitable for embedding and retrieval.
"""

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class ChunkingMethod(StrEnum):
    """Chunking methods."""

    FIXED_SIZE = "fixed_size"
    SENTENCE = "sentence"
    PARAGRAPH = "paragraph"
    SEMANTIC = "semantic"
    RECURSIVE = "recursive"
    TABLE_AWARE = "table_aware"


@dataclass
class Chunk:
    """A document chunk."""

    id: str
    text: str
    document_id: str
    position: int  # Position in original document
    page: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def length(self) -> int:
        return len(self.text)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "text": self.text,
            "document_id": self.document_id,
            "position": self.position,
            "page": self.page,
            "length": self.length,
            "metadata": self.metadata,
        }


@dataclass
class ChunkingResult:
    """Result of chunking a document."""

    document_id: str
    chunks: list[Chunk]
    method: ChunkingMethod
    total_length: int
    avg_chunk_size: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "document_id": self.document_id,
            "num_chunks": len(self.chunks),
            "method": self.method.value,
            "total_length": self.total_length,
            "avg_chunk_size": self.avg_chunk_size,
        }


class ChunkingStrategy(ABC):
    """Abstract base for chunking strategies."""

    @property
    @abstractmethod
    def method(self) -> ChunkingMethod:
        """Get chunking method."""
        pass

    @abstractmethod
    def chunk(
        self,
        text: str,
        document_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> ChunkingResult:
        """Chunk a document.

        Args:
            text: Document text
            document_id: Document identifier
            metadata: Document metadata

        Returns:
            ChunkingResult with chunks
        """
        pass


class FixedSizeChunker(ChunkingStrategy):
    """Fixed size chunking with overlap."""

    def __init__(
        self,
        chunk_size: int = 512,
        overlap: int = 128,
        separator: str = " ",
    ):
        """Initialize fixed size chunker.

        Args:
            chunk_size: Target chunk size in characters
            overlap: Overlap between chunks
            separator: Word separator
        """
        self._chunk_size = chunk_size
        self._overlap = overlap
        self._separator = separator

    @property
    def method(self) -> ChunkingMethod:
        return ChunkingMethod.FIXED_SIZE

    def chunk(
        self,
        text: str,
        document_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> ChunkingResult:
        """Chunk text into fixed size pieces."""
        metadata = metadata or {}
        chunks = []
        position = 0

        # Split into words
        words = text.split(self._separator)
        current_chunk = []
        current_length = 0

        for word in words:
            word_length = len(word) + 1  # +1 for separator

            if current_length + word_length > self._chunk_size and current_chunk:
                # Create chunk
                chunk_text = self._separator.join(current_chunk)
                chunks.append(
                    Chunk(
                        id=f"{document_id}_chunk_{len(chunks)}",
                        text=chunk_text,
                        document_id=document_id,
                        position=position,
                        metadata=metadata.copy(),
                    )
                )

                # Calculate overlap in words
                overlap_words = self._calculate_overlap_words(current_chunk)
                current_chunk = current_chunk[-overlap_words:] if overlap_words else []
                current_length = sum(len(w) + 1 for w in current_chunk)
                position += 1

            current_chunk.append(word)
            current_length += word_length

        # Add final chunk
        if current_chunk:
            chunk_text = self._separator.join(current_chunk)
            chunks.append(
                Chunk(
                    id=f"{document_id}_chunk_{len(chunks)}",
                    text=chunk_text,
                    document_id=document_id,
                    position=position,
                    metadata=metadata.copy(),
                )
            )

        avg_size = sum(c.length for c in chunks) / len(chunks) if chunks else 0

        return ChunkingResult(
            document_id=document_id,
            chunks=chunks,
            method=self.method,
            total_length=len(text),
            avg_chunk_size=avg_size,
        )

    def _calculate_overlap_words(self, words: list[str]) -> int:
        """Calculate number of words for overlap."""
        total_length = 0
        count = 0

        for word in reversed(words):
            total_length += len(word) + 1
            if total_length > self._overlap:
                break
            count += 1

        return count


class SemanticChunker(ChunkingStrategy):
    """Semantic chunking that respects sentence and paragraph boundaries."""

    def __init__(
        self,
        chunk_size: int = 512,
        chunk_overlap: int = 128,
        min_chunk_size: int = 100,
        max_chunk_size: int = 1000,
    ):
        """Initialize semantic chunker.

        Args:
            chunk_size: Target chunk size
            chunk_overlap: Overlap between chunks
            min_chunk_size: Minimum chunk size
            max_chunk_size: Maximum chunk size
        """
        self._chunk_size = chunk_size
        self._chunk_overlap = chunk_overlap
        self._min_chunk_size = min_chunk_size
        self._max_chunk_size = max_chunk_size

        # Sentence ending patterns
        self._sentence_endings = re.compile(r"[.!?]\s+")

        # Paragraph patterns
        self._paragraph_split = re.compile(r"\n\n+")

    @property
    def method(self) -> ChunkingMethod:
        return ChunkingMethod.SEMANTIC

    def chunk(
        self,
        text: str,
        document_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> ChunkingResult:
        """Chunk text semantically."""
        metadata = metadata or {}
        chunks = []

        # First split by paragraphs
        paragraphs = self._paragraph_split.split(text)

        current_chunk_parts = []
        current_length = 0

        for raw_para in paragraphs:
            para = raw_para.strip()
            if not para:
                continue

            para_length = len(para)

            # If paragraph alone exceeds max, split it by sentences
            if para_length > self._max_chunk_size:
                # Flush current chunk first
                if current_chunk_parts:
                    chunk_text = "\n\n".join(current_chunk_parts)
                    chunks.append(
                        self._create_chunk(chunk_text, document_id, len(chunks), metadata)
                    )
                    current_chunk_parts = []
                    current_length = 0

                # Split paragraph by sentences
                sentence_chunks = self._split_by_sentences(para, document_id, len(chunks), metadata)
                chunks.extend(sentence_chunks)
                continue

            # Check if adding this paragraph exceeds target
            if current_length + para_length > self._chunk_size and current_chunk_parts:
                chunk_text = "\n\n".join(current_chunk_parts)
                chunks.append(self._create_chunk(chunk_text, document_id, len(chunks), metadata))

                # Keep overlap
                current_chunk_parts = self._get_overlap_parts(current_chunk_parts)
                current_length = sum(len(p) for p in current_chunk_parts)

            current_chunk_parts.append(para)
            current_length += para_length

        # Add final chunk
        if current_chunk_parts:
            chunk_text = "\n\n".join(current_chunk_parts)
            chunks.append(self._create_chunk(chunk_text, document_id, len(chunks), metadata))

        avg_size = sum(c.length for c in chunks) / len(chunks) if chunks else 0

        return ChunkingResult(
            document_id=document_id,
            chunks=chunks,
            method=self.method,
            total_length=len(text),
            avg_chunk_size=avg_size,
        )

    def _split_by_sentences(
        self,
        text: str,
        document_id: str,
        start_position: int,
        metadata: dict[str, Any],
    ) -> list[Chunk]:
        """Split text by sentences."""
        sentences = self._sentence_endings.split(text)
        chunks = []

        current_sentences = []
        current_length = 0

        for raw_sentence in sentences:
            sentence = raw_sentence.strip()
            if not sentence:
                continue

            sent_length = len(sentence)

            if current_length + sent_length > self._chunk_size and current_sentences:
                chunk_text = " ".join(current_sentences)
                if len(chunk_text) >= self._min_chunk_size:
                    chunks.append(
                        self._create_chunk(
                            chunk_text, document_id, start_position + len(chunks), metadata
                        )
                    )
                current_sentences = []
                current_length = 0

            current_sentences.append(sentence)
            current_length += sent_length

        # Add remaining sentences
        if current_sentences:
            chunk_text = " ".join(current_sentences)
            if len(chunk_text) >= self._min_chunk_size:
                chunks.append(
                    self._create_chunk(
                        chunk_text, document_id, start_position + len(chunks), metadata
                    )
                )

        return chunks

    def _create_chunk(
        self,
        text: str,
        document_id: str,
        position: int,
        metadata: dict[str, Any],
    ) -> Chunk:
        """Create a chunk object."""
        return Chunk(
            id=f"{document_id}_chunk_{position}",
            text=text,
            document_id=document_id,
            position=position,
            metadata=metadata.copy(),
        )

    def _get_overlap_parts(self, parts: list[str]) -> list[str]:
        """Get parts for overlap."""
        if not parts:
            return []

        # Keep last paragraph if it's small enough
        total = 0
        overlap_parts = []

        for part in reversed(parts):
            total += len(part)
            if total > self._chunk_overlap:
                break
            overlap_parts.insert(0, part)

        return overlap_parts


class RecursiveChunker(ChunkingStrategy):
    """Recursive text splitter that tries multiple separators."""

    def __init__(
        self,
        chunk_size: int = 512,
        chunk_overlap: int = 128,
        separators: list[str] | None = None,
    ):
        """Initialize recursive chunker.

        Args:
            chunk_size: Target chunk size
            chunk_overlap: Overlap between chunks
            separators: List of separators to try (in order)
        """
        self._chunk_size = chunk_size
        self._chunk_overlap = chunk_overlap
        self._separators = separators or [
            "\n\n",  # Paragraphs
            "\n",  # Lines
            ". ",  # Sentences
            ", ",  # Clauses
            " ",  # Words
            "",  # Characters
        ]

    @property
    def method(self) -> ChunkingMethod:
        return ChunkingMethod.RECURSIVE

    def chunk(
        self,
        text: str,
        document_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> ChunkingResult:
        """Chunk text recursively."""
        metadata = metadata or {}
        chunks = self._split_recursive(text, self._separators)

        result_chunks = []
        for i, chunk_text in enumerate(chunks):
            result_chunks.append(
                Chunk(
                    id=f"{document_id}_chunk_{i}",
                    text=chunk_text,
                    document_id=document_id,
                    position=i,
                    metadata=metadata.copy(),
                )
            )

        avg_size = sum(c.length for c in result_chunks) / len(result_chunks) if result_chunks else 0

        return ChunkingResult(
            document_id=document_id,
            chunks=result_chunks,
            method=self.method,
            total_length=len(text),
            avg_chunk_size=avg_size,
        )

    def _split_recursive(
        self,
        text: str,
        separators: list[str],
    ) -> list[str]:
        """Recursively split text."""
        if not separators:
            return [text]

        separator = separators[0]
        new_separators = separators[1:]

        splits = text.split(separator) if separator else list(text)

        chunks = []
        current_chunk = []
        current_length = 0

        for split in splits:
            split_length = len(split) + len(separator)

            if current_length + split_length > self._chunk_size and current_chunk:
                chunk_text = separator.join(current_chunk)
                chunks.append(chunk_text)

                # Overlap
                overlap_text = self._get_overlap(current_chunk, separator)
                current_chunk = [overlap_text] if overlap_text else []
                current_length = len(overlap_text) if overlap_text else 0

            current_chunk.append(split)
            current_length += split_length

        # Add remaining
        if current_chunk:
            chunk_text = separator.join(current_chunk)
            chunks.append(chunk_text)

        # Recursively split chunks that are still too large
        final_chunks = []
        for chunk in chunks:
            if len(chunk) > self._chunk_size and new_separators:
                final_chunks.extend(self._split_recursive(chunk, new_separators))
            else:
                final_chunks.append(chunk)

        return final_chunks

    def _get_overlap(self, parts: list[str], separator: str) -> str:
        """Get overlap text from parts."""
        if not parts:
            return ""

        total = 0
        overlap_parts = []

        for part in reversed(parts):
            total += len(part) + len(separator)
            if total > self._chunk_overlap:
                break
            overlap_parts.insert(0, part)

        return separator.join(overlap_parts)
