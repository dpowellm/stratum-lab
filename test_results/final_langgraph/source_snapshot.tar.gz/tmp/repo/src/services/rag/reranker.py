"""
BGE Reranking Service.

Task 3.1.3: Implements reranking step to improve retrieval precision.
"""

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class RerankerModel(StrEnum):
    """Available reranker models."""

    BGE_RERANKER_BASE = "bge-reranker-base"
    BGE_RERANKER_LARGE = "bge-reranker-large"
    BGE_RERANKER_V2 = "bge-reranker-v2-m3"
    COHERE = "cohere-rerank"


@dataclass
class RerankerConfig:
    """Configuration for reranker."""

    model: RerankerModel = RerankerModel.BGE_RERANKER_V2
    top_k: int = 10
    batch_size: int = 32
    score_threshold: float = 0.0
    normalize_scores: bool = True
    use_gpu: bool = True
    max_length: int = 512

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "model": self.model.value,
            "top_k": self.top_k,
            "batch_size": self.batch_size,
            "score_threshold": self.score_threshold,
            "normalize_scores": self.normalize_scores,
            "use_gpu": self.use_gpu,
            "max_length": self.max_length,
        }


@dataclass
class RerankedResult:
    """Result after reranking."""

    document_id: str
    content: str
    original_rank: int
    new_rank: int
    original_score: float
    rerank_score: float
    relevance_boost: float  # Improvement from reranking
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def rank_change(self) -> int:
        """Get rank change (positive = moved up)."""
        return self.original_rank - self.new_rank

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "document_id": self.document_id,
            "content": self.content,
            "original_rank": self.original_rank,
            "new_rank": self.new_rank,
            "original_score": self.original_score,
            "rerank_score": self.rerank_score,
            "relevance_boost": self.relevance_boost,
            "rank_change": self.rank_change,
            "metadata": self.metadata,
        }


@dataclass
class RerankCandidate:
    """Candidate for reranking."""

    document_id: str
    content: str
    score: float
    metadata: dict[str, Any] = field(default_factory=dict)


class BGEReranker:
    """
    BGE Reranker Service.

    Features:
    - Cross-encoder reranking
    - Batch processing
    - Score normalization
    - Precision improvement
    """

    def __init__(
        self,
        config: RerankerConfig | None = None,
    ):
        """
        Initialize BGE reranker.

        Args:
            config: Reranker configuration
        """
        self.config = config or RerankerConfig()
        self._initialized = False
        self._model = None

    def initialize(self) -> bool:
        """Initialize the reranker model."""
        try:
            # In production, this would load the actual BGE reranker model
            # For now, we'll simulate initialization
            self._initialized = True
            logger.info(
                "BGE reranker initialized",
                model=self.config.model.value,
            )
            return True
        except Exception as e:
            logger.error("Reranker initialization failed", error=str(e))
            return False

    def rerank(
        self,
        query: str,
        candidates: list[RerankCandidate],
    ) -> list[RerankedResult]:
        """
        Rerank candidates based on query relevance.

        Args:
            query: Search query
            candidates: List of candidates to rerank

        Returns:
            List of reranked results
        """
        if not self._initialized:
            self.initialize()

        if not candidates:
            return []

        # Calculate rerank scores
        scored_candidates = []
        for i, candidate in enumerate(candidates):
            rerank_score = self._calculate_rerank_score(query, candidate.content)
            scored_candidates.append(
                {
                    "index": i,
                    "candidate": candidate,
                    "original_rank": i + 1,
                    "original_score": candidate.score,
                    "rerank_score": rerank_score,
                }
            )

        # Sort by rerank score
        scored_candidates.sort(key=lambda x: x["rerank_score"], reverse=True)

        # Apply score threshold
        if self.config.score_threshold > 0:
            scored_candidates = [
                s for s in scored_candidates if s["rerank_score"] >= self.config.score_threshold
            ]

        # Create results with new rankings
        results = []
        for new_rank, item in enumerate(scored_candidates[: self.config.top_k], 1):
            candidate = item["candidate"]
            original_score = item["original_score"]
            rerank_score = item["rerank_score"]

            results.append(
                RerankedResult(
                    document_id=candidate.document_id,
                    content=candidate.content,
                    original_rank=item["original_rank"],
                    new_rank=new_rank,
                    original_score=original_score,
                    rerank_score=rerank_score,
                    relevance_boost=rerank_score - original_score,
                    metadata=candidate.metadata,
                )
            )

        return results

    def _calculate_rerank_score(
        self,
        query: str,
        content: str,
    ) -> float:
        """
        Calculate rerank score for query-content pair.

        In production, this would use the actual BGE cross-encoder model.
        """
        # Simulate cross-encoder scoring
        # Higher score for:
        # - Query terms in content
        # - Content length (up to a point)
        # - Query-content overlap

        query_terms = set(query.lower().split())
        content_terms = set(content.lower().split())

        # Term overlap
        overlap = len(query_terms & content_terms)
        max_overlap = max(len(query_terms), 1)
        term_score = overlap / max_overlap

        # Length factor (prefer medium-length content)
        content_len = len(content.split())
        length_score = min(content_len / 100, 1.0) * (1 - max(0, content_len - 500) / 1000)
        length_score = max(0, length_score)

        # Combine scores
        score = 0.7 * term_score + 0.3 * length_score

        # Normalize to [0, 1]
        if self.config.normalize_scores:
            score = max(0.0, min(1.0, score))

        return score

    def rerank_batch(
        self,
        queries: list[str],
        candidates_batch: list[list[RerankCandidate]],
    ) -> list[list[RerankedResult]]:
        """
        Rerank multiple query-candidates pairs.

        Args:
            queries: List of queries
            candidates_batch: List of candidate lists

        Returns:
            List of reranked result lists
        """
        if len(queries) != len(candidates_batch):
            raise ValueError("Queries and candidates batch must have same length")

        results = []
        for query, candidates in zip(queries, candidates_batch, strict=False):
            reranked = self.rerank(query, candidates)
            results.append(reranked)

        return results

    def get_statistics(self) -> dict[str, Any]:
        """Get reranker statistics."""
        return {
            "initialized": self._initialized,
            "config": self.config.to_dict(),
        }


class RerankerPipeline:
    """
    Reranking pipeline with multiple stages.

    Allows chaining multiple rerankers for improved precision.
    """

    def __init__(
        self,
        rerankers: list[BGEReranker] | None = None,
    ):
        """
        Initialize reranker pipeline.

        Args:
            rerankers: List of rerankers to chain
        """
        self.rerankers = rerankers or [BGEReranker()]

    def rerank(
        self,
        query: str,
        candidates: list[RerankCandidate],
    ) -> list[RerankedResult]:
        """
        Run reranking pipeline.

        Args:
            query: Search query
            candidates: Initial candidates

        Returns:
            Final reranked results
        """
        current_candidates = candidates

        for reranker in self.rerankers:
            results = reranker.rerank(query, current_candidates)

            # Convert results back to candidates for next stage
            current_candidates = [
                RerankCandidate(
                    document_id=r.document_id,
                    content=r.content,
                    score=r.rerank_score,
                    metadata=r.metadata,
                )
                for r in results
            ]

        # Final results
        final_results = []
        for i, candidate in enumerate(current_candidates):
            # Find original rank
            original_rank = next(
                (j + 1 for j, c in enumerate(candidates) if c.document_id == candidate.document_id),
                i + 1,
            )

            final_results.append(
                RerankedResult(
                    document_id=candidate.document_id,
                    content=candidate.content,
                    original_rank=original_rank,
                    new_rank=i + 1,
                    original_score=candidates[original_rank - 1].score
                    if original_rank <= len(candidates)
                    else 0.0,
                    rerank_score=candidate.score,
                    relevance_boost=candidate.score
                    - (
                        candidates[original_rank - 1].score
                        if original_rank <= len(candidates)
                        else 0.0
                    ),
                    metadata=candidate.metadata,
                )
            )

        return final_results


# Singleton instance
_reranker: BGEReranker | None = None


def get_reranker() -> BGEReranker:
    """Get or create BGE reranker singleton."""
    global _reranker
    if _reranker is None:
        _reranker = BGEReranker()
        _reranker.initialize()
    return _reranker
