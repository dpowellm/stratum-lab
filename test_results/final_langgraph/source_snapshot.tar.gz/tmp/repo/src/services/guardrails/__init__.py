"""Guardrails services for input validation and output quality gating."""
