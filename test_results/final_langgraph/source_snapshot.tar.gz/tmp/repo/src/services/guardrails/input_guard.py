"""
Input Guard Service.

Pre-extraction input validation for uploaded documents.
Checks file size, MIME type, magic bytes, PII, and content safety.
"""

from typing import Any

from pydantic import BaseModel, Field

from src.core.logging import get_logger
from src.services.security.pii_detection import get_pii_detector

logger = get_logger(__name__)

MAX_FILE_SIZE = 300 * 1024 * 1024  # 300MB

ALLOWED_MIME_TYPES: dict[str, str] = {
    "application/pdf": "pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "application/msword": "doc",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
    "application/vnd.ms-excel": "xls",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
    "application/vnd.ms-powerpoint": "ppt",
    "text/plain": "txt",
    "text/csv": "csv",
    "text/html": "html",
    "application/rtf": "rtf",
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/tiff": "tiff",
    "image/webp": "webp",
    "image/gif": "gif",
    "image/bmp": "bmp",
    "image/svg+xml": "svg",
    "image/heic": "heic",
    "image/heif": "heif",
}

MAGIC_BYTES: dict[str, bytes] = {
    "application/pdf": b"%PDF",
    "image/png": b"\x89PNG",
    "image/jpeg": b"\xff\xd8",
    "image/gif": b"GIF",
    "image/bmp": b"BM",
}


class InputCheckResult(BaseModel):
    """Result of a single input validation check."""

    name: str
    passed: bool
    message: str
    severity: str = Field(default="info", pattern=r"^(info|warning|error)$")


class InputGuardResult(BaseModel):
    """Aggregate result of all input validation checks."""

    passed: bool
    checks: list[InputCheckResult] = Field(default_factory=list)
    pii_entities: list[dict[str, Any]] = Field(default_factory=list)
    stats: dict[str, Any] = Field(default_factory=dict)


class InputGuard:
    """
    Pre-extraction input validation guard.

    Validates uploaded documents against file size, MIME type, magic bytes,
    file integrity, PII content, and content safety rules before extraction.
    Tracks aggregate statistics for monitoring and alerting.
    """

    def __init__(self) -> None:
        """Initialize the input guard with empty aggregate stats."""
        self._stats: dict[str, Any] = {
            "total_checked": 0,
            "total_blocked": 0,
            "pii_warnings": 0,
            "per_type_counts": {},
            "rejection_reasons": {},
        }
        logger.info("InputGuard initialized")

    def validate_input(
        self,
        filename: str,
        content: bytes,
        content_type: str,
    ) -> InputGuardResult:
        """
        Validate an uploaded file before extraction.

        Runs all checks and returns an aggregate result. Updates internal
        statistics regardless of outcome.

        Args:
            filename: Original filename of the uploaded document.
            content: Raw file content as bytes.
            content_type: MIME type provided by the client.

        Returns:
            InputGuardResult indicating whether the file passed validation.
        """
        checks: list[InputCheckResult] = []
        pii_entities: list[dict[str, Any]] = []

        # 1. File integrity (non-empty)
        checks.append(self._check_file_integrity(content))

        # 2. File size
        checks.append(self._check_file_size(content))

        # 3. MIME type validation
        checks.append(self._check_mime_type(content_type))

        # 4. Magic bytes validation
        checks.append(self._check_magic_bytes(content, content_type))

        # 5. Content safety (null bytes, embedded scripts)
        checks.append(self._check_content_safety(content, content_type))

        # 6. PII scan (only for text-decodable content)
        pii_check, pii_entities = self._check_pii(content, filename)
        checks.append(pii_check)

        # Determine overall pass/fail: fail if any error-severity check failed
        passed = all(check.passed for check in checks if check.severity == "error")

        # Update aggregate stats
        self._update_stats(passed, content_type, checks, pii_entities)

        result = InputGuardResult(
            passed=passed,
            checks=checks,
            pii_entities=pii_entities,
            stats=self.get_stats(),
        )

        logger.info(
            "Input validation completed",
            filename=filename,
            content_type=content_type,
            passed=passed,
            check_count=len(checks),
            pii_count=len(pii_entities),
        )

        return result

    def get_stats(self) -> dict[str, Any]:
        """
        Return current aggregate validation statistics.

        Returns:
            Dictionary of aggregate counters and breakdowns.
        """
        return dict(self._stats)

    def get_config(self) -> dict[str, Any]:
        """
        Return the current guard configuration.

        Returns:
            Dictionary of configuration constants.
        """
        return {
            "max_file_size": MAX_FILE_SIZE,
            "allowed_mime_types": list(ALLOWED_MIME_TYPES.keys()),
            "magic_bytes_types": list(MAGIC_BYTES.keys()),
        }

    # ------------------------------------------------------------------
    # Individual checks
    # ------------------------------------------------------------------

    def _check_file_integrity(self, content: bytes) -> InputCheckResult:
        """Check that the file is non-empty."""
        if not content or len(content) == 0:
            return InputCheckResult(
                name="file_integrity",
                passed=False,
                message="File is empty.",
                severity="error",
            )
        return InputCheckResult(
            name="file_integrity",
            passed=True,
            message=f"File is non-empty ({len(content)} bytes).",
            severity="info",
        )

    def _check_file_size(self, content: bytes) -> InputCheckResult:
        """Check that the file does not exceed the maximum allowed size."""
        size = len(content)
        if size > MAX_FILE_SIZE:
            return InputCheckResult(
                name="file_size",
                passed=False,
                message=(
                    f"File size {size} bytes exceeds maximum allowed size of {MAX_FILE_SIZE} bytes."
                ),
                severity="error",
            )
        return InputCheckResult(
            name="file_size",
            passed=True,
            message=f"File size {size} bytes is within the allowed limit.",
            severity="info",
        )

    def _check_mime_type(self, content_type: str) -> InputCheckResult:
        """Check that the content type is in the allowed list."""
        if content_type not in ALLOWED_MIME_TYPES:
            return InputCheckResult(
                name="mime_type",
                passed=False,
                message=f"MIME type '{content_type}' is not allowed.",
                severity="error",
            )
        return InputCheckResult(
            name="mime_type",
            passed=True,
            message=(
                f"MIME type '{content_type}' is allowed "
                f"(maps to '{ALLOWED_MIME_TYPES[content_type]}')."
            ),
            severity="info",
        )

    def _check_magic_bytes(self, content: bytes, content_type: str) -> InputCheckResult:
        """Validate file magic bytes against the declared MIME type."""
        expected = MAGIC_BYTES.get(content_type)
        if expected is None:
            return InputCheckResult(
                name="magic_bytes",
                passed=True,
                message=(f"No magic bytes rule for '{content_type}'; skipping."),
                severity="info",
            )

        if content[: len(expected)] != expected:
            return InputCheckResult(
                name="magic_bytes",
                passed=False,
                message=(
                    f"Magic bytes mismatch for '{content_type}'. "
                    f"Expected {expected!r} but got {content[: len(expected)]!r}."
                ),
                severity="error",
            )
        return InputCheckResult(
            name="magic_bytes",
            passed=True,
            message=f"Magic bytes match for '{content_type}'.",
            severity="info",
        )

    def _check_content_safety(self, content: bytes, content_type: str = "") -> InputCheckResult:
        """Detect null bytes and embedded script patterns."""
        issues: list[str] = []

        # Null byte detection -- only flag for text-based formats.
        # Binary formats (images, PDFs, Office docs) legitimately contain
        # null bytes.
        _text_types = {"text/plain", "text/csv", "text/html", "application/rtf"}
        if content_type in _text_types and b"\x00" in content:
            issues.append("File contains null bytes.")

        # Embedded script detection (check a decodable portion)
        try:
            text_sample = content[:65536].decode("utf-8", errors="ignore").lower()
        except Exception:
            text_sample = ""

        script_patterns = [
            "<script",
            "javascript:",
            "vbscript:",
            "onload=",
            "onerror=",
            "eval(",
        ]
        for pattern in script_patterns:
            if pattern in text_sample:
                issues.append(f"Embedded script pattern detected: '{pattern}'.")

        if issues:
            return InputCheckResult(
                name="content_safety",
                passed=False,
                message=" ".join(issues),
                severity="error",
            )
        return InputCheckResult(
            name="content_safety",
            passed=True,
            message="No content safety issues detected.",
            severity="info",
        )

    def _check_pii(
        self, content: bytes, filename: str
    ) -> tuple[InputCheckResult, list[dict[str, Any]]]:
        """Scan text content for PII entities."""
        pii_entities: list[dict[str, Any]] = []
        try:
            text = content[:131072].decode("utf-8", errors="ignore")
        except Exception:
            return (
                InputCheckResult(
                    name="pii_scan",
                    passed=True,
                    message="Could not decode file for PII scan; skipping.",
                    severity="info",
                ),
                pii_entities,
            )

        if not text.strip():
            return (
                InputCheckResult(
                    name="pii_scan",
                    passed=True,
                    message="No text content to scan for PII.",
                    severity="info",
                ),
                pii_entities,
            )

        detector = get_pii_detector()
        result = detector.detect(text, document_id=filename)

        if result.pii_found:
            pii_entities = [entity.to_dict() for entity in result.entities]
            return (
                InputCheckResult(
                    name="pii_scan",
                    passed=True,
                    message=(
                        f"PII detected: {result.pii_count} entit"
                        f"{'y' if result.pii_count == 1 else 'ies'} found. "
                        f"Review recommended."
                    ),
                    severity="warning",
                ),
                pii_entities,
            )

        return (
            InputCheckResult(
                name="pii_scan",
                passed=True,
                message="No PII detected.",
                severity="info",
            ),
            pii_entities,
        )

    # ------------------------------------------------------------------
    # Stats helpers
    # ------------------------------------------------------------------

    def _update_stats(
        self,
        passed: bool,
        content_type: str,
        checks: list[InputCheckResult],
        pii_entities: list[dict[str, Any]],
    ) -> None:
        """Update aggregate statistics after each validation run."""
        self._stats["total_checked"] += 1

        if not passed:
            self._stats["total_blocked"] += 1

        if pii_entities:
            self._stats["pii_warnings"] += 1

        # Per-type counts
        type_key = ALLOWED_MIME_TYPES.get(content_type, content_type)
        per_type: dict[str, int] = self._stats["per_type_counts"]
        per_type[type_key] = per_type.get(type_key, 0) + 1

        # Rejection reasons
        if not passed:
            rejection_reasons: dict[str, int] = self._stats["rejection_reasons"]
            for check in checks:
                if not check.passed and check.severity == "error":
                    rejection_reasons[check.name] = rejection_reasons.get(check.name, 0) + 1


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_input_guard: InputGuard | None = None


def get_input_guard() -> InputGuard:
    """Get or create the InputGuard singleton."""
    global _input_guard
    if _input_guard is None:
        _input_guard = InputGuard()
    return _input_guard
