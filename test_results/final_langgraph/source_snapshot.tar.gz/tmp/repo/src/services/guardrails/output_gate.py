"""
Output Gate Service.

Post-extraction quality gating that decides whether an extraction result
should be auto-accepted, sent for human-in-the-loop review, or rejected.
"""

from dataclasses import dataclass
from typing import Any, Literal

from pydantic import BaseModel, Field

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class GateConfiguration:
    """Runtime-tunable thresholds for output quality gating."""

    min_overall_confidence: float = 0.70
    max_missing_fields_ratio: float = 0.30
    min_consensus_score: float = 0.60
    auto_accept_confidence: float = 0.95
    auto_reject_confidence: float = 0.30


class GateCheckResult(BaseModel):
    """Result of a single quality gate check."""

    gate_name: str
    passed: bool
    message: str
    threshold: float
    actual_value: float


class GateDecision(BaseModel):
    """Final routing decision produced by the output gate."""

    action: Literal["accept", "hitl_review", "reject"]
    routing_target: str
    gate_checks: list[GateCheckResult] = Field(default_factory=list)
    overall_confidence: float
    consensus_score: float


class OutputGate:
    """
    Post-extraction quality gate.

    Evaluates extraction results against configurable thresholds and
    decides whether to auto-accept, route to human review, or reject.
    Tracks aggregate decision statistics for monitoring.
    """

    def __init__(self, config: GateConfiguration | None = None) -> None:
        """
        Initialize the output gate.

        Args:
            config: Optional custom gate configuration. Uses defaults
                    when not provided.
        """
        self._config = config or GateConfiguration()
        self._stats: dict[str, int] = {
            "total_evaluated": 0,
            "accepted": 0,
            "hitl_review": 0,
            "rejected": 0,
        }
        logger.info(
            "OutputGate initialized",
            min_overall_confidence=self._config.min_overall_confidence,
            auto_accept_confidence=self._config.auto_accept_confidence,
            auto_reject_confidence=self._config.auto_reject_confidence,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def evaluate(
        self,
        overall_confidence: float,
        field_confidences: dict[str, float],
        consensus_score: float,
        total_fields: int,
        missing_fields: int,
    ) -> GateDecision:
        """
        Evaluate an extraction result and return a routing decision.

        Args:
            overall_confidence: Aggregated extraction confidence (0-1).
            field_confidences: Per-field confidence scores.
            consensus_score: Council consensus score (0-1).
            total_fields: Total expected fields in the schema.
            missing_fields: Number of fields with no extracted value.

        Returns:
            GateDecision with action, routing target, and individual
            gate check results.
        """
        checks: list[GateCheckResult] = []

        # Gate 1: Overall confidence threshold
        checks.append(self._check_confidence(overall_confidence))

        # Gate 2: Field-level low-confidence check
        checks.append(self._check_field_level(field_confidences))

        # Gate 3: Schema completeness
        checks.append(self._check_schema_completeness(total_fields, missing_fields))

        # Gate 4: Consensus score
        checks.append(self._check_consensus(consensus_score))

        all_passed = all(check.passed for check in checks)

        # Determine action
        if all_passed and overall_confidence >= self._config.auto_accept_confidence:
            action: Literal["accept", "hitl_review", "reject"] = "accept"
            routing_target = "auto_accept"
        elif overall_confidence <= self._config.auto_reject_confidence:
            action = "reject"
            routing_target = "rejection_queue"
        else:
            action = "hitl_review"
            routing_target = "hitl_review_queue"

        decision = GateDecision(
            action=action,
            routing_target=routing_target,
            gate_checks=checks,
            overall_confidence=overall_confidence,
            consensus_score=consensus_score,
        )

        # Update stats
        self._stats["total_evaluated"] += 1
        _action_to_stat = {
            "accept": "accepted",
            "hitl_review": "hitl_review",
            "reject": "rejected",
        }
        self._stats[_action_to_stat[action]] += 1

        logger.info(
            "Output gate decision",
            action=action,
            routing_target=routing_target,
            overall_confidence=overall_confidence,
            consensus_score=consensus_score,
            gates_passed=sum(1 for c in checks if c.passed),
            gates_total=len(checks),
        )

        return decision

    def update_config(self, config: dict[str, float]) -> GateConfiguration:
        """
        Update gate thresholds at runtime.

        Only recognised keys are applied; unknown keys are silently
        ignored.

        Args:
            config: Dictionary of threshold names to new values.

        Returns:
            The updated GateConfiguration.
        """
        valid_keys = {
            "min_overall_confidence",
            "max_missing_fields_ratio",
            "min_consensus_score",
            "auto_accept_confidence",
            "auto_reject_confidence",
        }

        for key, value in config.items():
            if key in valid_keys:
                setattr(self._config, key, float(value))

        logger.info(
            "OutputGate config updated",
            min_overall_confidence=self._config.min_overall_confidence,
            max_missing_fields_ratio=self._config.max_missing_fields_ratio,
            min_consensus_score=self._config.min_consensus_score,
            auto_accept_confidence=self._config.auto_accept_confidence,
            auto_reject_confidence=self._config.auto_reject_confidence,
        )

        return self._config

    def get_config(self) -> dict[str, Any]:
        """
        Return the current gate configuration as a dictionary.

        Returns:
            Dictionary of threshold names and their current values.
        """
        return {
            "min_overall_confidence": self._config.min_overall_confidence,
            "max_missing_fields_ratio": self._config.max_missing_fields_ratio,
            "min_consensus_score": self._config.min_consensus_score,
            "auto_accept_confidence": self._config.auto_accept_confidence,
            "auto_reject_confidence": self._config.auto_reject_confidence,
        }

    def get_stats(self) -> dict[str, Any]:
        """
        Return aggregate decision statistics.

        Returns:
            Dictionary with total, accepted, hitl_review, and rejected
            counts.
        """
        return dict(self._stats)

    # ------------------------------------------------------------------
    # Individual gate checks
    # ------------------------------------------------------------------

    def _check_confidence(self, overall_confidence: float) -> GateCheckResult:
        """Gate 1: Overall confidence must meet the minimum threshold."""
        threshold = self._config.min_overall_confidence
        passed = overall_confidence >= threshold
        return GateCheckResult(
            gate_name="confidence_threshold",
            passed=passed,
            message=(
                f"Overall confidence {overall_confidence:.2f} "
                f"{'meets' if passed else 'below'} "
                f"threshold {threshold:.2f}."
            ),
            threshold=threshold,
            actual_value=overall_confidence,
        )

    def _check_field_level(self, field_confidences: dict[str, float]) -> GateCheckResult:
        """Gate 2: Count fields with confidence below the minimum."""
        threshold = self._config.min_overall_confidence
        total = len(field_confidences)
        if total == 0:
            return GateCheckResult(
                gate_name="field_level",
                passed=True,
                message="No field confidences provided; skipping.",
                threshold=threshold,
                actual_value=1.0,
            )

        low_count = sum(1 for conf in field_confidences.values() if conf < threshold)
        low_ratio = low_count / total
        passed = low_ratio <= self._config.max_missing_fields_ratio
        return GateCheckResult(
            gate_name="field_level",
            passed=passed,
            message=(
                f"{low_count}/{total} fields below {threshold:.2f} "
                f"(ratio {low_ratio:.2f}, max {self._config.max_missing_fields_ratio:.2f})."
            ),
            threshold=self._config.max_missing_fields_ratio,
            actual_value=low_ratio,
        )

    def _check_schema_completeness(self, total_fields: int, missing_fields: int) -> GateCheckResult:
        """Gate 3: Missing-fields ratio must not exceed the threshold."""
        if total_fields == 0:
            return GateCheckResult(
                gate_name="schema_completeness",
                passed=True,
                message="No fields in schema; skipping.",
                threshold=self._config.max_missing_fields_ratio,
                actual_value=0.0,
            )

        missing_ratio = missing_fields / total_fields
        passed = missing_ratio <= self._config.max_missing_fields_ratio
        return GateCheckResult(
            gate_name="schema_completeness",
            passed=passed,
            message=(
                f"{missing_fields}/{total_fields} fields missing "
                f"(ratio {missing_ratio:.2f}, max "
                f"{self._config.max_missing_fields_ratio:.2f})."
            ),
            threshold=self._config.max_missing_fields_ratio,
            actual_value=missing_ratio,
        )

    def _check_consensus(self, consensus_score: float) -> GateCheckResult:
        """Gate 4: Consensus score must meet the minimum threshold."""
        threshold = self._config.min_consensus_score
        passed = consensus_score >= threshold
        return GateCheckResult(
            gate_name="consensus_score",
            passed=passed,
            message=(
                f"Consensus score {consensus_score:.2f} "
                f"{'meets' if passed else 'below'} "
                f"threshold {threshold:.2f}."
            ),
            threshold=threshold,
            actual_value=consensus_score,
        )


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_output_gate: OutputGate | None = None


def get_output_gate() -> OutputGate:
    """Get or create the OutputGate singleton."""
    global _output_gate
    if _output_gate is None:
        _output_gate = OutputGate()
    return _output_gate
