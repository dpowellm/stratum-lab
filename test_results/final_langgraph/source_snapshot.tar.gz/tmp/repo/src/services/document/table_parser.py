"""Parse HTML tables (from PaddleOCR PPStructure) into structured JSON."""

import re
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


def parse_html_table(html: str) -> dict[str, Any]:
    """Parse an HTML table into structured data.

    Args:
        html: HTML string containing a <table> element (from PPStructure output).

    Returns:
        Dict with keys:
        - headers: list[str] — column headers
        - rows: list[list[str]] — data rows
        - row_count: int
        - col_count: int
    """
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        # Fallback to regex parsing if bs4 not available
        return _parse_html_table_regex(html)

    soup = BeautifulSoup(html, "html.parser")
    table = soup.find("table")
    if not table:
        return {"headers": [], "rows": [], "row_count": 0, "col_count": 0}

    headers: list[str] = []
    rows: list[list[str]] = []

    # Extract headers from <thead> or first <tr> with <th>
    thead = table.find("thead")
    if thead:
        header_row = thead.find("tr")
        if header_row:
            headers = [th.get_text(strip=True) for th in header_row.find_all(["th", "td"])]

    # Extract body rows
    tbody = table.find("tbody") or table
    for tr in tbody.find_all("tr"):
        cells = tr.find_all(["td", "th"])
        cell_texts = [c.get_text(strip=True) for c in cells]

        # If no headers yet and this looks like a header row (all th)
        if not headers and all(c.name == "th" for c in cells):
            headers = cell_texts
            continue

        if cell_texts:
            rows.append(cell_texts)

    # If still no headers, use first row as headers if it looks like one
    if not headers and rows:
        # Heuristic: if first row has no numeric values, treat as header
        first_row = rows[0]
        if all(not _is_numeric(cell) for cell in first_row if cell):
            headers = rows.pop(0)

    col_count = max(len(headers), max((len(r) for r in rows), default=0))

    return {
        "headers": headers,
        "rows": rows,
        "row_count": len(rows),
        "col_count": col_count,
    }


def _is_numeric(s: str) -> bool:
    """Check if a string looks numeric (including currency)."""
    cleaned = re.sub(r"[$,\u20ac\u00a3\u00a5%]", "", s.strip())
    try:
        float(cleaned)
        return True
    except ValueError:
        return False


def _parse_html_table_regex(html: str) -> dict[str, Any]:
    """Fallback regex-based HTML table parser."""
    headers: list[str] = []
    rows: list[list[str]] = []

    # Find all rows
    row_pattern = re.compile(r"<tr[^>]*>(.*?)</tr>", re.DOTALL | re.IGNORECASE)
    cell_pattern = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.DOTALL | re.IGNORECASE)
    tag_pattern = re.compile(r"<[^>]+>")

    for row_match in row_pattern.finditer(html):
        row_html = row_match.group(1)
        cells = []
        for cell_match in cell_pattern.finditer(row_html):
            text = tag_pattern.sub("", cell_match.group(1)).strip()
            cells.append(text)

        if not headers and "<th" in row_html.lower():
            headers = cells
        elif cells:
            rows.append(cells)

    if not headers and rows:
        first_row = rows[0]
        if all(not _is_numeric(cell) for cell in first_row if cell):
            headers = rows.pop(0)

    col_count = max(len(headers), max((len(r) for r in rows), default=0))

    return {
        "headers": headers,
        "rows": rows,
        "row_count": len(rows),
        "col_count": col_count,
    }
