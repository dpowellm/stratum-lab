"""Document repository for database operations."""

import uuid

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.database.document import Document, DocumentType, ProcessingStatus
from src.models.database.extraction import Extraction


class DocumentRepository:
    """Repository for document CRUD operations."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(
        self,
        filename: str,
        storage_path: str,
        file_size: int,
        mime_type: str,
        checksum: str,
        document_type: DocumentType = DocumentType.UNKNOWN,
    ) -> Document:
        """Create a new document record."""
        doc = Document(
            filename=filename,
            storage_path=storage_path,
            file_size=file_size,
            mime_type=mime_type,
            checksum=checksum,
            document_type=document_type,
            status=ProcessingStatus.PENDING,
        )
        self.session.add(doc)
        await self.session.flush()
        await self.session.refresh(doc)
        return doc

    async def get_by_id(self, document_id: uuid.UUID) -> Document | None:
        """Get a document by ID (excludes soft-deleted)."""
        stmt = select(Document).where(
            Document.id == document_id,
            Document.is_deleted.is_(False),
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_checksum(self, checksum: str) -> Document | None:
        """Get a document by checksum (excludes soft-deleted)."""
        stmt = select(Document).where(
            Document.checksum == checksum,
            Document.is_deleted.is_(False),
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def update_status(
        self,
        document_id: uuid.UUID,
        status: ProcessingStatus,
        message: str | None = None,
        progress: int | None = None,
    ) -> Document | None:
        """Update document processing status."""
        doc = await self.get_by_id(document_id)
        if doc is None:
            return None
        doc.update_status(status, message, progress)
        await self.session.flush()
        await self.session.refresh(doc)
        return doc

    async def list_documents(
        self,
        page: int = 1,
        page_size: int = 20,
        status: ProcessingStatus | None = None,
        document_type: DocumentType | None = None,
    ) -> tuple[list[Document], int]:
        """List documents with pagination and filtering."""
        base_filter = Document.is_deleted.is_(False)

        # Count query
        count_stmt = select(func.count()).select_from(Document).where(base_filter)
        if status is not None:
            count_stmt = count_stmt.where(Document.status == status)
        if document_type is not None:
            count_stmt = count_stmt.where(Document.document_type == document_type)
        count_result = await self.session.execute(count_stmt)
        total = count_result.scalar_one()

        # Data query
        stmt = select(Document).where(base_filter)
        if status is not None:
            stmt = stmt.where(Document.status == status)
        if document_type is not None:
            stmt = stmt.where(Document.document_type == document_type)
        stmt = stmt.order_by(Document.created_at.desc())
        stmt = stmt.offset((page - 1) * page_size).limit(page_size)

        result = await self.session.execute(stmt)
        docs = list(result.scalars().all())
        return docs, total

    async def soft_delete(self, document_id: uuid.UUID) -> Document | None:
        """Soft-delete a document.

        Mangles the checksum so the unique constraint does not block
        future uploads of the same content.
        """
        doc = await self.get_by_id(document_id)
        if doc is None:
            return None
        doc.soft_delete()
        # Mangle checksum so the unique index no longer blocks re-uploads
        doc.checksum = f"_del_{doc.id}_{doc.checksum}"[:64]
        await self.session.flush()
        await self.session.refresh(doc)
        return doc

    async def get_latest_extraction(self, document_id: uuid.UUID) -> Extraction | None:
        """Get the latest extraction for a document."""
        stmt = (
            select(Extraction)
            .where(
                Extraction.document_id == document_id,
                Extraction.is_latest.is_(True),
            )
            .order_by(Extraction.version.desc())
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def create_extraction(
        self,
        document_id: uuid.UUID,
        overall_confidence: float,
        extracted_data: dict,
        council_session_id: uuid.UUID | None = None,
        version: int = 1,
    ) -> Extraction:
        """Create a new extraction record."""
        extraction = Extraction(
            document_id=document_id,
            council_session_id=council_session_id,
            overall_confidence=overall_confidence,
            extracted_data=extracted_data,
            field_count=len(extracted_data),
            version=version,
            is_latest=True,
        )
        self.session.add(extraction)
        await self.session.flush()
        await self.session.refresh(extraction)
        return extraction
