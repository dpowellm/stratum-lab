"""
Quality evaluation service for extraction accuracy tracking.

Tracks extraction results and corrections, computing precision, recall, and F1
metrics per field, per model, and per document type.
"""

import datetime
import time
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class FieldResult:
    """Record of a single field extraction result."""

    field_name: str
    predicted_value: Any
    confidence: float
    model_name: str
    document_type: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class FieldCorrection:
    """Record of a human correction to an extracted field."""

    field_name: str
    original_value: Any
    corrected_value: Any
    model_name: str
    document_type: str
    timestamp: float = field(default_factory=time.time)


class FieldQualityMetrics(BaseModel):
    """Quality metrics for a single field."""

    field_name: str
    precision: float
    recall: float
    f1_score: float
    sample_count: int
    correct_count: int
    incorrect_count: int


class QualityReport(BaseModel):
    """Comprehensive quality report across all fields, models, and document types."""

    overall_accuracy: float
    overall_precision: float
    overall_recall: float
    overall_f1: float
    total_predictions: int
    total_corrections: int
    per_field_metrics: list[FieldQualityMetrics]
    per_model_metrics: dict[str, dict]
    per_doc_type_metrics: dict[str, dict]


class QualityEvaluator:
    """
    Evaluates extraction quality by tracking results and corrections.

    A field extraction with no corresponding correction is treated as correct.
    A field extraction that was later corrected is treated as incorrect (the
    original prediction was wrong).

    Precision = correct / total_predictions
    Recall = correct / (correct + missed)  -- missed approximated by corrections
    F1 = 2 * precision * recall / (precision + recall)
    """

    def __init__(self) -> None:
        self._results: list[FieldResult] = []
        self._corrections: list[FieldCorrection] = []
        logger.info("QualityEvaluator initialized")

    def record_extraction_result(
        self,
        field_name: str,
        predicted_value: Any,
        confidence: float,
        model_name: str,
        document_type: str,
    ) -> None:
        """Record an extraction result for quality tracking."""
        result = FieldResult(
            field_name=field_name,
            predicted_value=predicted_value,
            confidence=confidence,
            model_name=model_name,
            document_type=document_type,
        )
        self._results.append(result)
        logger.debug(
            "Recorded extraction result",
            field_name=field_name,
            model_name=model_name,
            document_type=document_type,
            confidence=confidence,
        )

    def record_correction(
        self,
        field_name: str,
        original_value: Any,
        corrected_value: Any,
        model_name: str,
        document_type: str,
    ) -> None:
        """Record a human correction for an extraction."""
        correction = FieldCorrection(
            field_name=field_name,
            original_value=original_value,
            corrected_value=corrected_value,
            model_name=model_name,
            document_type=document_type,
        )
        self._corrections.append(correction)
        logger.debug(
            "Recorded field correction",
            field_name=field_name,
            model_name=model_name,
            document_type=document_type,
        )

    def _compute_field_metrics(self, field_name: str) -> FieldQualityMetrics:
        """Compute quality metrics for a single field."""
        field_results = [r for r in self._results if r.field_name == field_name]
        field_corrections = [c for c in self._corrections if c.field_name == field_name]

        total = len(field_results)
        incorrect = len(field_corrections)
        correct = max(total - incorrect, 0)

        precision = correct / total if total > 0 else 0.0
        # Recall: correct out of all that should have been correct
        # (correct + corrections that indicate missed/wrong predictions)
        recall_denom = correct + incorrect
        recall = correct / recall_denom if recall_denom > 0 else 0.0
        f1 = 2.0 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

        return FieldQualityMetrics(
            field_name=field_name,
            precision=precision,
            recall=recall,
            f1_score=f1,
            sample_count=total,
            correct_count=correct,
            incorrect_count=incorrect,
        )

    def _compute_group_metrics(
        self, results: list[FieldResult], corrections: list[FieldCorrection]
    ) -> dict:
        """Compute aggregated metrics for a group of results."""
        total = len(results)
        incorrect = len(corrections)
        correct = max(total - incorrect, 0)

        precision = correct / total if total > 0 else 0.0
        recall_denom = correct + incorrect
        recall = correct / recall_denom if recall_denom > 0 else 0.0
        f1 = 2.0 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

        return {
            "accuracy": correct / total if total > 0 else 0.0,
            "precision": precision,
            "recall": recall,
            "f1_score": f1,
            "total_predictions": total,
            "total_corrections": incorrect,
        }

    def compute_overall_metrics(self) -> QualityReport:
        """Compute a comprehensive quality report."""
        total_predictions = len(self._results)
        total_corrections = len(self._corrections)
        correct = max(total_predictions - total_corrections, 0)

        overall_accuracy = correct / total_predictions if total_predictions > 0 else 0.0
        overall_precision = correct / total_predictions if total_predictions > 0 else 0.0
        recall_denom = correct + total_corrections
        overall_recall = correct / recall_denom if recall_denom > 0 else 0.0
        overall_f1 = (
            2.0 * overall_precision * overall_recall / (overall_precision + overall_recall)
            if (overall_precision + overall_recall) > 0
            else 0.0
        )

        # Per-field metrics
        field_names = sorted({r.field_name for r in self._results})
        per_field = [self._compute_field_metrics(fn) for fn in field_names]

        # Per-model metrics
        model_names = sorted({r.model_name for r in self._results})
        per_model: dict[str, dict] = {}
        for model in model_names:
            model_results = [r for r in self._results if r.model_name == model]
            model_corrections = [c for c in self._corrections if c.model_name == model]
            per_model[model] = self._compute_group_metrics(model_results, model_corrections)

        # Per-document-type metrics
        doc_types = sorted({r.document_type for r in self._results})
        per_doc_type: dict[str, dict] = {}
        for dt in doc_types:
            dt_results = [r for r in self._results if r.document_type == dt]
            dt_corrections = [c for c in self._corrections if c.document_type == dt]
            per_doc_type[dt] = self._compute_group_metrics(dt_results, dt_corrections)

        report = QualityReport(
            overall_accuracy=overall_accuracy,
            overall_precision=overall_precision,
            overall_recall=overall_recall,
            overall_f1=overall_f1,
            total_predictions=total_predictions,
            total_corrections=total_corrections,
            per_field_metrics=per_field,
            per_model_metrics=per_model,
            per_doc_type_metrics=per_doc_type,
        )

        logger.info(
            "Quality report computed",
            overall_accuracy=overall_accuracy,
            overall_f1=overall_f1,
            total_predictions=total_predictions,
            total_corrections=total_corrections,
        )

        return report

    def get_worst_performing_fields(self, n: int = 5) -> list[FieldQualityMetrics]:
        """Return the n worst-performing fields ranked by F1 score (ascending)."""
        field_names = sorted({r.field_name for r in self._results})
        metrics = [self._compute_field_metrics(fn) for fn in field_names]
        # Sort by F1 ascending (worst first), then by sample_count descending for ties
        metrics.sort(key=lambda m: (m.f1_score, -m.sample_count))
        return metrics[:n]

    def get_quality_trend(self, days: int = 30) -> list[dict]:
        """
        Compute daily aggregated quality metrics for the last N days.

        Returns a list of dicts with keys: date, accuracy, precision, recall,
        f1_score, predictions, corrections.
        """
        now = time.time()
        cutoff = now - (days * 86400)

        # Filter results within the window
        recent_results = [r for r in self._results if r.timestamp >= cutoff]
        recent_corrections = [c for c in self._corrections if c.timestamp >= cutoff]

        # Group by date
        daily_results: dict[str, list[FieldResult]] = {}
        for r in recent_results:
            day = datetime.date.fromtimestamp(r.timestamp).isoformat()
            daily_results.setdefault(day, []).append(r)

        daily_corrections: dict[str, list[FieldCorrection]] = {}
        for c in recent_corrections:
            day = datetime.date.fromtimestamp(c.timestamp).isoformat()
            daily_corrections.setdefault(day, []).append(c)

        # Compute metrics per day
        all_dates = sorted(set(list(daily_results.keys()) + list(daily_corrections.keys())))
        trend: list[dict] = []
        for day in all_dates:
            day_results = daily_results.get(day, [])
            day_corrections = daily_corrections.get(day, [])
            total = len(day_results)
            incorrect = len(day_corrections)
            correct = max(total - incorrect, 0)

            accuracy = correct / total if total > 0 else 0.0
            precision = correct / total if total > 0 else 0.0
            recall_denom = correct + incorrect
            recall = correct / recall_denom if recall_denom > 0 else 0.0
            f1 = (
                2.0 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
            )

            trend.append(
                {
                    "date": day,
                    "accuracy": accuracy,
                    "precision": precision,
                    "recall": recall,
                    "f1_score": f1,
                    "predictions": total,
                    "corrections": incorrect,
                }
            )

        return trend


_quality_evaluator: QualityEvaluator | None = None


def get_quality_evaluator() -> QualityEvaluator:
    """Get or create the singleton QualityEvaluator instance."""
    global _quality_evaluator
    if _quality_evaluator is None:
        _quality_evaluator = QualityEvaluator()
    return _quality_evaluator
