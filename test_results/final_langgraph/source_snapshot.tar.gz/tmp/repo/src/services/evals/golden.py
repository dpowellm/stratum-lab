"""Golden-file evaluation framework for extraction accuracy.

Compares extracted fields against ground-truth JSON files, computing
per-field precision, recall, and F1 using semantic value matching.
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from src.core.logging import get_logger
from src.council.value_matching import ValueMatcher

logger = get_logger(__name__)


class FieldEvalResult(BaseModel):
    """Evaluation result for a single field."""

    field_name: str
    expected_value: Any
    extracted_value: Any | None
    field_type: str | None
    is_match: bool
    is_present: bool  # whether the field was extracted at all


class EvalReport(BaseModel):
    """Evaluation report comparing extraction to ground truth."""

    document_name: str
    document_type: str
    total_fields: int
    matched_fields: int
    missing_fields: int
    extra_fields: int
    precision: float
    recall: float
    f1: float
    field_results: list[FieldEvalResult]


class AggregateReport(BaseModel):
    """Aggregate report across multiple golden files."""

    total_documents: int
    total_fields: int
    total_matched: int
    total_missing: int
    macro_precision: float
    macro_recall: float
    macro_f1: float
    per_document: list[EvalReport]
    per_type: dict[str, dict[str, float]]


@dataclass
class BaselineEntry:
    """Saved baseline for regression comparison."""

    document_type: str
    f1: float
    precision: float
    recall: float


@dataclass
class GoldenFileEvaluator:
    """Evaluates extraction results against golden ground-truth files.

    Uses ValueMatcher for semantic comparison so that equivalent
    representations (e.g. "$1,234" vs "1234.00") count as matches.
    """

    matcher: ValueMatcher = field(default_factory=ValueMatcher)
    baseline_path: Path | None = None

    def evaluate(
        self,
        extracted: dict[str, Any],
        golden: dict[str, Any],
        document_name: str = "unknown",
    ) -> EvalReport:
        """Compare extracted fields against ground-truth.

        Args:
            extracted: Dict of field_name -> value (or dict with "value" key).
            golden: Ground-truth dict with "fields" key containing
                    field_name -> {"value": ..., "type": ...}.
            document_name: Identifier for this document.

        Returns:
            EvalReport with per-field results and aggregate metrics.
        """
        golden_fields = golden.get("fields", {})
        document_type = golden.get("document_type", "unknown")

        field_results: list[FieldEvalResult] = []
        matched = 0
        missing = 0

        for field_name, field_info in golden_fields.items():
            expected_value = field_info["value"]
            field_type = field_info.get("type")

            # Look up extracted value — handle both flat and nested formats
            extracted_value = self._get_extracted_value(extracted, field_name)
            is_present = extracted_value is not None

            if is_present:
                is_match = self.matcher.values_match(extracted_value, expected_value, field_type)
            else:
                is_match = False
                missing += 1

            if is_match:
                matched += 1

            field_results.append(
                FieldEvalResult(
                    field_name=field_name,
                    expected_value=expected_value,
                    extracted_value=extracted_value,
                    field_type=field_type,
                    is_match=is_match,
                    is_present=is_present,
                )
            )

        # Extra fields: extracted but not in golden
        golden_keys = set(golden_fields.keys())
        extracted_keys = set(self._get_extracted_keys(extracted))
        extra_fields = len(extracted_keys - golden_keys)

        total_fields = len(golden_fields)
        # Precision: of all extracted fields that map to golden fields, how many matched?
        extracted_golden_count = len(extracted_keys & golden_keys)
        precision = matched / extracted_golden_count if extracted_golden_count > 0 else 0.0
        # Recall: of all golden fields, how many were correctly extracted?
        recall = matched / total_fields if total_fields > 0 else 0.0
        f1 = 2.0 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

        report = EvalReport(
            document_name=document_name,
            document_type=document_type,
            total_fields=total_fields,
            matched_fields=matched,
            missing_fields=missing,
            extra_fields=extra_fields,
            precision=precision,
            recall=recall,
            f1=f1,
            field_results=field_results,
        )

        logger.info(
            "Golden file evaluation",
            document_name=document_name,
            f1=f1,
            matched=matched,
            total=total_fields,
        )

        return report

    def evaluate_batch(
        self,
        results: list[tuple[str, dict[str, Any], dict[str, Any]]],
    ) -> AggregateReport:
        """Evaluate multiple documents.

        Args:
            results: List of (document_name, extracted, golden) tuples.

        Returns:
            AggregateReport with per-document and aggregate metrics.
        """
        per_document: list[EvalReport] = []
        for doc_name, extracted, golden in results:
            report = self.evaluate(extracted, golden, doc_name)
            per_document.append(report)

        total_fields = sum(r.total_fields for r in per_document)
        total_matched = sum(r.matched_fields for r in per_document)
        total_missing = sum(r.missing_fields for r in per_document)

        # Macro-averaged metrics (average per-document)
        if per_document:
            macro_precision = sum(r.precision for r in per_document) / len(per_document)
            macro_recall = sum(r.recall for r in per_document) / len(per_document)
            macro_f1 = sum(r.f1 for r in per_document) / len(per_document)
        else:
            macro_precision = 0.0
            macro_recall = 0.0
            macro_f1 = 0.0

        # Per-type metrics
        per_type: dict[str, dict[str, float]] = {}
        type_reports: dict[str, list[EvalReport]] = {}
        for r in per_document:
            type_reports.setdefault(r.document_type, []).append(r)
        for doc_type, reports in type_reports.items():
            per_type[doc_type] = {
                "precision": sum(r.precision for r in reports) / len(reports),
                "recall": sum(r.recall for r in reports) / len(reports),
                "f1": sum(r.f1 for r in reports) / len(reports),
                "count": float(len(reports)),
            }

        return AggregateReport(
            total_documents=len(per_document),
            total_fields=total_fields,
            total_matched=total_matched,
            total_missing=total_missing,
            macro_precision=macro_precision,
            macro_recall=macro_recall,
            macro_f1=macro_f1,
            per_document=per_document,
            per_type=per_type,
        )

    def load_golden_file(self, json_path: Path) -> dict[str, Any]:
        """Load a golden ground-truth JSON file."""
        return json.loads(json_path.read_text())

    def save_baseline(self, report: AggregateReport, path: Path) -> None:
        """Save an aggregate report as a baseline for future regression checks."""
        baseline = {
            "macro_f1": report.macro_f1,
            "macro_precision": report.macro_precision,
            "macro_recall": report.macro_recall,
            "per_type": report.per_type,
        }
        path.write_text(json.dumps(baseline, indent=2))
        logger.info("Baseline saved", path=str(path))

    def load_baseline(self, path: Path) -> dict[str, Any]:
        """Load a previously saved baseline."""
        return json.loads(path.read_text())

    def check_regression(
        self,
        current: AggregateReport,
        baseline: dict[str, Any],
        tolerance: float = 0.02,
    ) -> tuple[bool, list[str]]:
        """Check if current results regressed from baseline.

        Args:
            current: Current aggregate evaluation report.
            baseline: Previously saved baseline dict.
            tolerance: Maximum allowed F1 drop before flagging regression.

        Returns:
            (has_regression, list of regression descriptions)
        """
        regressions: list[str] = []

        baseline_f1 = baseline.get("macro_f1", 0.0)
        if current.macro_f1 < baseline_f1 - tolerance:
            regressions.append(
                f"Macro F1 regressed: {current.macro_f1:.4f} < {baseline_f1:.4f} - {tolerance}"
            )

        baseline_precision = baseline.get("macro_precision", 0.0)
        if current.macro_precision < baseline_precision - tolerance:
            regressions.append(
                f"Macro precision regressed: {current.macro_precision:.4f} < "
                f"{baseline_precision:.4f} - {tolerance}"
            )

        baseline_recall = baseline.get("macro_recall", 0.0)
        if current.macro_recall < baseline_recall - tolerance:
            regressions.append(
                f"Macro recall regressed: {current.macro_recall:.4f} < "
                f"{baseline_recall:.4f} - {tolerance}"
            )

        return len(regressions) > 0, regressions

    def _get_extracted_value(self, extracted: dict[str, Any], field_name: str) -> Any | None:
        """Get value from extracted dict, handling nested formats."""
        if field_name not in extracted:
            return None
        val = extracted[field_name]
        if isinstance(val, dict) and "value" in val:
            return val["value"]
        return val

    def _get_extracted_keys(self, extracted: dict[str, Any]) -> list[str]:
        """Get all field keys from extracted dict."""
        return list(extracted.keys())
