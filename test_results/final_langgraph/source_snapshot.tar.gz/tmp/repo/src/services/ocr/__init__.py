"""OCR services for council members.

This module provides OCR service implementations used by council members
for document extraction and text recognition.
"""

# Base interfaces and data models
from src.services.ocr.base import (
    # Enums
    BlockType,
    # Data classes
    BoundingBox,
    Capability,
    MockOCRService,
    OCRResult,
    # Service interface
    OCRServiceInterface,
    TableCell,
    TableData,
    TextBlock,
)
from src.services.ocr.olmocr import OlmOCRService

# Implementations
from src.services.ocr.paddle_ocr import PaddleOCRService
from src.services.ocr.qwen_vlm import QwenVLMService

__all__ = [
    # Enums
    "BlockType",
    # Data classes
    "BoundingBox",
    "Capability",
    "MockOCRService",
    "OCRResult",
    # Service interface
    "OCRServiceInterface",
    "OlmOCRService",
    # Implementations
    "PaddleOCRService",
    "QwenVLMService",
    "TableCell",
    "TableData",
    "TextBlock",
]
