"""Example usage of OCR services.

This module demonstrates how to use the OCR service implementations.
"""

import asyncio

from src.services.ocr.base import Capability, OCRServiceInterface
from src.services.ocr.olmocr import OlmOCRService
from src.services.ocr.paddle_ocr import PaddleOCRService
from src.services.ocr.qwen_vlm import QwenVLMService


async def example_paddle_ocr():
    """Example: Using PaddleOCR Service."""
    print("\n" + "=" * 60)
    print("PaddleOCR Service Example")
    print("=" * 60)

    # Create service instance
    service = PaddleOCRService(
        use_gpu=False,
        lang="en",
        confidence_threshold=0.5,
    )

    print(f"Model: {service.model_name} v{service.model_version}")
    print(f"Capabilities: {[c.value for c in service.capabilities]}")

    # Example 1: Extract text from image (mock)
    print("\n1. Text extraction (requires image bytes)")
    print("   await service.extract_text(image_bytes)")

    # Example 2: Check capabilities
    print("\n2. Check specific capability")
    print(f"   Has FAST_EXTRACTION: {service.has_capability(Capability.FAST_EXTRACTION)}")
    print(f"   Has TABLES: {service.has_capability(Capability.TABLES)}")

    # Example 3: Get expertise weight
    print("\n3. Expertise weights")
    for cap in [Capability.FAST_EXTRACTION, Capability.TABLES]:
        weight = service.get_expertise_weight(cap)
        print(f"   {cap.value}: {weight}")


async def example_olmocr():
    """Example: Using olmOCR Service."""
    print("\n" + "=" * 60)
    print("olmOCR Service Example")
    print("=" * 60)

    # Create service instance
    service = OlmOCRService(
        model_path=None,  # Would be set in production
        confidence_threshold=0.5,
    )

    print(f"Model: {service.model_name} v{service.model_version}")
    print(f"Capabilities: {[c.value for c in service.capabilities]}")

    # Example 1: Check capabilities
    print("\n1. Available capabilities for semantic understanding")
    semantic_caps = [
        c for c in service.capabilities if "semantic" in c.value or "layout" in c.value
    ]
    print(f"   {[c.value for c in semantic_caps]}")

    # Example 2: Expertise weights
    print("\n2. Expertise weights for VQA tasks")
    for cap in [
        Capability.SEMANTIC_UNDERSTANDING,
        Capability.COMPLEX_LAYOUTS,
        Capability.VISUAL_QA,
    ]:
        weight = service.get_expertise_weight(cap)
        print(f"   {cap.value}: {weight}")


async def example_qwen_vlm():
    """Example: Using Qwen VLM Service."""
    print("\n" + "=" * 60)
    print("Qwen VLM Service Example")
    print("=" * 60)

    # Create service instance
    service = QwenVLMService(
        model_name="qwen-vl-max",
        api_key=None,  # Would be set in production
        use_local=False,
    )

    print(f"Model: {service.model_name} v{service.model_version}")
    print(f"Capabilities: {[c.value for c in service.capabilities]}")

    # Example 1: Check all semantic capabilities
    print("\n1. All available capabilities")
    for cap in service.capabilities:
        print(f"   - {cap.value}")

    # Example 2: Expertise weights
    print("\n2. Expertise weights")
    for cap in service.capabilities[:3]:
        weight = service.get_expertise_weight(cap)
        print(f"   {cap.value}: {weight}")


async def example_service_selection():
    """Example: Selecting best service for a task."""
    print("\n" + "=" * 60)
    print("Service Selection Example")
    print("=" * 60)

    services: dict[str, OCRServiceInterface] = {
        "paddle": PaddleOCRService(),
        "olmocr": OlmOCRService(),
        "qwen": QwenVLMService(),
    }

    # Task: Extract text quickly
    print("\n1. Task: Fast text extraction")
    capability = Capability.FAST_EXTRACTION
    best_service = max(
        services.items(),
        key=lambda x: x[1].get_expertise_weight(capability),
    )
    print(
        f"   Best service: {best_service[0]} (weight: {best_service[1].get_expertise_weight(capability)})"
    )

    # Task: Handle complex layouts
    print("\n2. Task: Handle complex layouts")
    capability = Capability.COMPLEX_LAYOUTS
    best_service = max(
        services.items(),
        key=lambda x: x[1].get_expertise_weight(capability),
    )
    print(
        f"   Best service: {best_service[0]} (weight: {best_service[1].get_expertise_weight(capability)})"
    )

    # Task: Visual question answering
    print("\n3. Task: Visual question answering")
    capability = Capability.VISUAL_QA
    best_service = max(
        services.items(),
        key=lambda x: x[1].get_expertise_weight(capability),
    )
    print(
        f"   Best service: {best_service[0]} (weight: {best_service[1].get_expertise_weight(capability)})"
    )


async def example_data_structures():
    """Example: Using OCR data structures."""
    print("\n" + "=" * 60)
    print("Data Structures Example")
    print("=" * 60)

    from src.services.ocr import (
        BlockType,
        BoundingBox,
        OCRResult,
        TableCell,
        TableData,
        TextBlock,
    )

    # Create bounding box
    bbox = BoundingBox(x=10, y=20, width=100, height=50)
    print("\n1. BoundingBox:")
    print(f"   {bbox.to_dict()}")

    # Create text block
    block = TextBlock(
        text="Sample text",
        confidence=0.95,
        bbox=bbox,
        block_type=BlockType.TITLE,
    )
    print("\n2. TextBlock:")
    print(f"   {block.to_dict()}")

    # Create table cells
    cells = [
        TableCell(text="Header 1", row=0, col=0, is_header=True),
        TableCell(text="Header 2", row=0, col=1, is_header=True),
        TableCell(text="Value 1", row=1, col=0),
        TableCell(text="Value 2", row=1, col=1),
    ]

    # Create table data
    table = TableData(
        cells=cells,
        rows=2,
        cols=2,
    )
    print("\n3. TableData (markdown):")
    print(table.to_markdown())

    # Create OCR result
    result = OCRResult(
        blocks=[block],
        full_text="Sample text",
        confidence=0.95,
        tables=[table],
        model_name="test-model",
        model_version="1.0.0",
    )
    print("\n4. OCRResult summary:")
    print(f"   Blocks: {len(result.blocks)}")
    print(f"   Tables: {len(result.tables)}")
    print(f"   Confidence: {result.confidence}")


async def main():
    """Run all examples."""
    print("\n" + "=" * 60)
    print("OCR Services Examples")
    print("=" * 60)

    await example_paddle_ocr()
    await example_olmocr()
    await example_qwen_vlm()
    await example_service_selection()
    await example_data_structures()

    print("\n" + "=" * 60)
    print("Examples complete!")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
