"""Data models for OCR service layer.

This module contains reusable data structures for OCR results,
independent of the base service interface.
"""

from src.services.ocr.base import (
    BlockType,
    BoundingBox,
    OCRResult,
    TableCell,
    TableData,
    TextBlock,
)

__all__ = [
    "BlockType",
    "BoundingBox",
    "OCRResult",
    "TableCell",
    "TableData",
    "TextBlock",
]
