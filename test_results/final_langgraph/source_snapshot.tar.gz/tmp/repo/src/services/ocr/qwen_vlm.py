"""Qwen VLM Service Implementation.

Provides multimodal document understanding using Qwen VLM.
This is the semantic specialist in the OCR council.
"""

import base64
import io
import time

from src.core.logging import get_logger
from src.services.ocr.base import (
    BlockType,
    Capability,
    OCRResult,
    OCRServiceInterface,
    TableCell,
    TableData,
    TextBlock,
)

logger = get_logger(__name__)


class QwenVLMService(OCRServiceInterface):
    """Qwen VLM Service - Semantic document understanding.

    Strengths:
    - Excellent semantic understanding
    - Good at reasoning and interpretation
    - Handles complex documents well
    - Visual question answering capabilities

    Weaknesses:
    - May require API calls (depending on setup)
    - Slightly slower inference
    - Better for complex understanding than raw speed
    """

    def __init__(
        self,
        model_name: str = "qwen-vl-max",
        api_key: str | None = None,
        api_endpoint: str | None = None,
        timeout: int = 30,
        confidence_threshold: float = 0.5,
        use_local: bool = False,
    ):
        """Initialize Qwen VLM service.

        Args:
            model_name: Model identifier (qwen-vl-max, qwen-vl-plus, etc.)
            api_key: API key for Qwen API (if using cloud version)
            api_endpoint: API endpoint (if using cloud version)
            timeout: Request timeout in seconds
            confidence_threshold: Minimum confidence threshold
            use_local: Whether to use local model instead of API
        """
        import os

        self._model_name = model_name
        self._api_key = api_key or os.getenv("QWEN_API_KEY")
        self._api_endpoint = (
            api_endpoint
            or os.getenv("QWEN_API_ENDPOINT")
            or "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"
        )
        self._timeout = timeout
        self._confidence_threshold = confidence_threshold
        self._use_local = use_local
        self._client = None
        self._initialized = False

    @property
    def model_name(self) -> str:
        """Get model name."""
        return self._model_name

    @property
    def model_version(self) -> str:
        """Get model version."""
        return "1.0.0"

    @property
    def capabilities(self) -> list[Capability]:
        """Get model capabilities."""
        return [
            Capability.SEMANTIC_UNDERSTANDING,
            Capability.COMPLEX_LAYOUTS,
            Capability.CHARTS,
            Capability.DIAGRAMS,
            Capability.VISUAL_QA,
            Capability.TOKEN_EFFICIENCY,
            Capability.FORMS,
        ]

    async def _ensure_initialized(self) -> None:
        """Ensure the service is initialized."""
        if self._initialized:
            return

        logger.info(
            "Initializing Qwen VLM service",
            use_local=self._use_local,
            model=self._model_name,
        )

        try:
            if self._use_local:
                # Local model initialization

                logger.info("Loading local Qwen model")
                # This would load the local model
                # For now, we'll keep it as a mock
                self._initialized = True
            else:
                # API-based initialization
                if not self._api_key:
                    logger.warning("Qwen API key not provided, will attempt unauthenticated access")

                import http.client

                self._client = http.client
                self._initialized = True

            logger.info("Qwen VLM service initialized successfully")
        except Exception as e:
            logger.error("Failed to initialize Qwen VLM", error=str(e))
            raise

    async def extract_text(self, image: bytes) -> OCRResult:
        """Extract text from a single image.

        Args:
            image: Image bytes (PNG, JPEG, etc.)

        Returns:
            OCRResult with extracted text and confidence
        """
        start_time = time.time()
        await self._ensure_initialized()

        try:
            # Convert image bytes to base64
            image_base64 = base64.b64encode(image).decode("utf-8")

            # Prepare request payload
            prompt = """Analyze this document image and extract all text.
            Provide a JSON response with:
            {
                "text_blocks": [
                    {
                        "text": "extracted text",
                        "confidence": 0.95,
                        "type": "text",
                        "location": "description"
                    }
                ],
                "full_text": "complete extracted text",
                "language": "en",
                "document_structure": "description of layout"
            }"""

            if self._use_local:
                # Local inference
                result = await self._infer_local(image_base64, prompt)
            else:
                # API-based inference
                result = await self._infer_api(image_base64, prompt)

            processing_time_ms = (time.time() - start_time) * 1000
            result.processing_time_ms = processing_time_ms
            result.model_name = self.model_name
            result.model_version = self.model_version

            return result

        except Exception as e:
            logger.error(
                "Text extraction failed",
                error=str(e),
                processing_time_ms=(time.time() - start_time) * 1000,
            )
            return OCRResult(
                blocks=[],
                full_text="",
                confidence=0.0,
                page_count=1,
                model_name=self.model_name,
                model_version=self.model_version,
                processing_time_ms=(time.time() - start_time) * 1000,
                metadata={"error": str(e)},
            )

    async def _infer_local(
        self,
        image_base64: str,
        prompt: str,
    ) -> OCRResult:
        """Perform local inference (placeholder).

        Args:
            image_base64: Base64 encoded image
            prompt: Inference prompt

        Returns:
            OCRResult
        """
        # This is a placeholder for local inference
        # In a real implementation, this would use the loaded model
        logger.info("Performing local inference (mock)")
        return OCRResult(
            blocks=[
                TextBlock(
                    text="Local inference result",
                    confidence=0.85,
                    block_type=BlockType.TEXT,
                    page_number=1,
                )
            ],
            full_text="Local inference result",
            confidence=0.85,
            page_count=1,
        )

    async def _infer_api(
        self,
        image_base64: str,
        prompt: str,
    ) -> OCRResult:
        """Perform API-based inference.

        Args:
            image_base64: Base64 encoded image
            prompt: Inference prompt

        Returns:
            OCRResult
        """
        try:
            import json

            import httpx

            # Prepare request
            headers = {
                "Authorization": f"Bearer {self._api_key}" if self._api_key else "",
                "Content-Type": "application/json",
            }

            payload = {
                "model": self._model_name,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image_url",
                                "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"},
                            },
                            {
                                "type": "text",
                                "text": prompt,
                            },
                        ],
                    }
                ],
            }

            # Make API call with timeout
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(
                    self._api_endpoint,
                    headers=headers,
                    json=payload,
                )

            response.raise_for_status()
            response_data = response.json()

            # Parse response
            response_text = (
                response_data.get("choices", [{}])[0].get("message", {}).get("content", "")
            )

            try:
                parsed = json.loads(response_text)
            except json.JSONDecodeError:
                parsed = {
                    "text_blocks": [
                        {
                            "text": response_text,
                            "confidence": 0.8,
                            "type": "text",
                        }
                    ],
                    "full_text": response_text,
                    "language": "en",
                }

            # Build text blocks
            blocks = []
            confidences = []

            for block_data in parsed.get("text_blocks", []):
                text = block_data.get("text", "")
                confidence = block_data.get("confidence", 0.8)
                block_type = block_data.get("type", "text")

                if confidence >= self._confidence_threshold:
                    block = TextBlock(
                        text=text,
                        confidence=confidence,
                        block_type=BlockType(block_type)
                        if block_type in [e.value for e in BlockType]
                        else BlockType.TEXT,
                        page_number=1,
                        metadata={
                            "location": block_data.get("location"),
                        },
                    )
                    blocks.append(block)
                    confidences.append(confidence)

            full_text = parsed.get("full_text", "")
            language = parsed.get("language", "en")
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0.8

            return OCRResult(
                blocks=blocks,
                full_text=full_text,
                confidence=avg_confidence,
                page_count=1,
                language=language,
                metadata={
                    "document_structure": parsed.get("document_structure"),
                },
            )

        except Exception as e:
            logger.error("API inference failed", error=str(e))
            raise

    async def extract_from_pdf(
        self,
        pdf_bytes: bytes,
        pages: list[int] | None = None,
    ) -> list[OCRResult]:
        """Extract text from a PDF document.

        Args:
            pdf_bytes: PDF file bytes
            pages: Optional list of page numbers to process (1-indexed).
                   If None, process all pages.

        Returns:
            List of OCRResult, one per page
        """
        await self._ensure_initialized()

        try:
            import pdf2image

            # Convert PDF to images
            images = pdf2image.convert_from_bytes(pdf_bytes)

            # Determine which pages to process
            if pages is None:
                pages_to_process = list(range(len(images)))
            else:
                pages_to_process = [p - 1 for p in pages if 1 <= p <= len(images)]

            # Process selected pages
            results = []
            for page_idx in pages_to_process:
                if 0 <= page_idx < len(images):
                    img = images[page_idx]
                    img_bytes = io.BytesIO()
                    img.save(img_bytes, format="PNG")
                    img_bytes.seek(0)

                    result = await self.extract_text(img_bytes.getvalue())
                    result.page_count = len(images)
                    result.page_number = page_idx + 1  # type: ignore

                    results.append(result)

            return results

        except ImportError as e:
            logger.error("pdf2image not installed", error=str(e))
            return [
                OCRResult(
                    blocks=[],
                    full_text="",
                    confidence=0.0,
                    page_count=0,
                    model_name=self.model_name,
                    model_version=self.model_version,
                    metadata={"error": "pdf2image not installed"},
                )
            ]
        except Exception as e:
            logger.error("PDF extraction failed", error=str(e))
            return [
                OCRResult(
                    blocks=[],
                    full_text="",
                    confidence=0.0,
                    page_count=0,
                    model_name=self.model_name,
                    model_version=self.model_version,
                    metadata={"error": str(e)},
                )
            ]

    async def extract_tables(self, image: bytes) -> list[TableData]:
        """Extract tables from an image.

        Args:
            image: Image bytes

        Returns:
            List of TableData with extracted table structures
        """
        start_time = time.time()
        await self._ensure_initialized()

        try:
            # Convert image bytes to base64
            image_base64 = base64.b64encode(image).decode("utf-8")

            prompt = """Extract all tables from this image.
            Return JSON with:
            {
                "tables": [
                    {
                        "rows": 3,
                        "cols": 3,
                        "cells": [
                            {"text": "cell text", "row": 0, "col": 0, "is_header": true}
                        ]
                    }
                ]
            }"""

            if self._use_local:
                # Local inference
                import json

                # Mock response for local inference
                parsed = {"tables": []}
            else:
                # API-based inference
                import json

                import httpx

                headers = {
                    "Authorization": f"Bearer {self._api_key}" if self._api_key else "",
                    "Content-Type": "application/json",
                }

                payload = {
                    "model": self._model_name,
                    "messages": [
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "image_url",
                                    "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"},
                                },
                                {
                                    "type": "text",
                                    "text": prompt,
                                },
                            ],
                        }
                    ],
                }

                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    response = await client.post(
                        self._api_endpoint,
                        headers=headers,
                        json=payload,
                    )

                response.raise_for_status()
                response_data = response.json()
                response_text = (
                    response_data.get("choices", [{}])[0].get("message", {}).get("content", "")
                )

                try:
                    parsed = json.loads(response_text)
                except json.JSONDecodeError:
                    parsed = {"tables": []}

            # Build table data
            tables = []
            for table_data in parsed.get("tables", []):
                cells = []
                for cell_data in table_data.get("cells", []):
                    cell = TableCell(
                        text=cell_data.get("text", ""),
                        row=cell_data.get("row", 0),
                        col=cell_data.get("col", 0),
                        is_header=cell_data.get("is_header", False),
                        confidence=cell_data.get("confidence", 0.9),
                    )
                    cells.append(cell)

                if cells:
                    table = TableData(
                        cells=cells,
                        rows=table_data.get("rows", 1),
                        cols=table_data.get("cols", 1),
                        page_number=1,
                    )
                    tables.append(table)

            processing_time_ms = (time.time() - start_time) * 1000
            logger.info(
                "Table extraction completed",
                table_count=len(tables),
                processing_time_ms=processing_time_ms,
            )

            return tables

        except Exception as e:
            logger.error("Table extraction failed", error=str(e))
            return []

    async def health_check(self) -> bool:
        """Check if the service is healthy."""
        try:
            await self._ensure_initialized()
            return self._initialized
        except Exception:
            return False

    def get_expertise_weight(self, capability: Capability) -> float:
        """Get expertise weight for a capability.

        Qwen VLM excels at semantic understanding and reasoning.
        """
        weights = {
            Capability.SEMANTIC_UNDERSTANDING: 0.95,
            Capability.COMPLEX_LAYOUTS: 0.88,
            Capability.CHARTS: 0.85,
            Capability.DIAGRAMS: 0.85,
            Capability.VISUAL_QA: 0.95,
            Capability.TOKEN_EFFICIENCY: 0.80,
            Capability.FORMS: 0.82,
        }
        return weights.get(capability, 0.0)
