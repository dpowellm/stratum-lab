"""
Abstract base interface for OCR Council members.

All council members (PaddleOCR, olmOCR, Qwen) must implement this interface.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class BlockType(StrEnum):
    """Type of text block."""

    TEXT = "text"
    TITLE = "title"
    TABLE = "table"
    FIGURE = "figure"
    FORMULA = "formula"
    LIST = "list"
    HEADER = "header"
    FOOTER = "footer"
    CAPTION = "caption"
    UNKNOWN = "unknown"


class Capability(StrEnum):
    """OCR model capabilities."""

    FAST_EXTRACTION = "fast_extraction"
    TABLES = "tables"
    MULTILINGUAL = "multilingual"
    FORMS = "forms"
    TOKEN_EFFICIENCY = "token_efficiency"  # noqa: S105
    LONG_DOCUMENTS = "long_documents"
    MULTIPAGE = "multipage"
    SEMANTIC_UNDERSTANDING = "semantic_understanding"
    COMPLEX_LAYOUTS = "complex_layouts"
    CHARTS = "charts"
    DIAGRAMS = "diagrams"
    VISUAL_QA = "visual_qa"
    HANDWRITING = "handwriting"
    FORMULAS = "formulas"


@dataclass
class BoundingBox:
    """Bounding box coordinates for text location."""

    x: float
    y: float
    width: float
    height: float

    def to_dict(self) -> dict[str, float]:
        """Convert to dictionary."""
        return {
            "x": self.x,
            "y": self.y,
            "width": self.width,
            "height": self.height,
        }

    @classmethod
    def from_points(cls, points: list[list[float]]) -> "BoundingBox":
        """Create from corner points [[x1,y1], [x2,y2], [x3,y3], [x4,y4]]."""
        x_coords = [p[0] for p in points]
        y_coords = [p[1] for p in points]
        x = min(x_coords)
        y = min(y_coords)
        width = max(x_coords) - x
        height = max(y_coords) - y
        return cls(x=x, y=y, width=width, height=height)


@dataclass
class TextBlock:
    """Individual text block with confidence and position."""

    text: str
    confidence: float
    bbox: BoundingBox | None = None
    block_type: BlockType = BlockType.TEXT
    page_number: int = 1
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "text": self.text,
            "confidence": self.confidence,
            "bbox": self.bbox.to_dict() if self.bbox else None,
            "block_type": self.block_type.value,
            "page_number": self.page_number,
            "metadata": self.metadata,
        }


class CellType(StrEnum):
    """Type of table cell."""

    HEADER = "header"
    DATA = "data"
    MERGED = "merged"
    EMPTY = "empty"


class CellDataType(StrEnum):
    """Data type detected in a table cell."""

    TEXT = "text"
    NUMERIC = "numeric"
    CURRENCY = "currency"
    DATE = "date"
    PERCENTAGE = "percentage"


@dataclass
class TableCell:
    """Table cell data."""

    text: str
    row: int
    col: int
    row_span: int = 1
    col_span: int = 1
    is_header: bool = False
    confidence: float = 1.0
    cell_type: CellType = CellType.DATA
    data_type: CellDataType = CellDataType.TEXT
    parsed_value: Any = None


@dataclass
class TableData:
    """Extracted table data."""

    cells: list[TableCell]
    rows: int
    cols: int
    bbox: BoundingBox | None = None
    page_number: int = 1

    def to_markdown(self) -> str:
        """Convert table to markdown format."""
        if not self.cells:
            return ""

        # Build grid
        grid: list[list[str]] = [["" for _ in range(self.cols)] for _ in range(self.rows)]
        for cell in self.cells:
            if 0 <= cell.row < self.rows and 0 <= cell.col < self.cols:
                grid[cell.row][cell.col] = cell.text

        # Build markdown
        lines = []
        for i, row in enumerate(grid):
            lines.append("| " + " | ".join(row) + " |")
            if i == 0:
                lines.append("| " + " | ".join(["---"] * self.cols) + " |")

        return "\n".join(lines)

    def to_csv(self) -> str:
        """Convert table to CSV format."""
        import csv
        import io

        if not self.cells:
            return ""

        grid = self._build_grid()
        output = io.StringIO()
        writer = csv.writer(output)
        for row in grid:
            writer.writerow(row)
        return output.getvalue()

    def to_json(self) -> list[dict[str, str]]:
        """Convert table to list of dicts (one per data row, keyed by headers)."""
        if not self.cells:
            return []

        grid = self._build_grid()
        if len(grid) < 2:
            return []

        headers = grid[0]
        return [dict(zip(headers, row, strict=False)) for row in grid[1:]]

    def to_dataframe_dict(self) -> dict[str, list[str]]:
        """Convert table to column-oriented dict suitable for DataFrame construction."""
        if not self.cells:
            return {}

        grid = self._build_grid()
        if len(grid) < 2:
            return {}

        headers = grid[0]
        result: dict[str, list[str]] = {h: [] for h in headers}
        for row in grid[1:]:
            for h, val in zip(headers, row, strict=False):
                result[h].append(val)
        return result

    def _build_grid(self) -> list[list[str]]:
        """Build a 2D text grid from cells."""
        grid: list[list[str]] = [["" for _ in range(self.cols)] for _ in range(self.rows)]
        for cell in self.cells:
            if 0 <= cell.row < self.rows and 0 <= cell.col < self.cols:
                grid[cell.row][cell.col] = cell.text
        return grid

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "rows": self.rows,
            "cols": self.cols,
            "cells": [
                {
                    "text": c.text,
                    "row": c.row,
                    "col": c.col,
                    "row_span": c.row_span,
                    "col_span": c.col_span,
                    "is_header": c.is_header,
                    "confidence": c.confidence,
                    "cell_type": c.cell_type.value,
                    "data_type": c.data_type.value,
                }
                for c in self.cells
            ],
            "markdown": self.to_markdown(),
        }


@dataclass
class OCRResult:
    """Complete OCR result from a council member."""

    # Core extraction
    blocks: list[TextBlock]
    full_text: str
    confidence: float

    # Tables
    tables: list[TableData] = field(default_factory=list)

    # Metadata
    page_count: int = 1
    language: str | None = None
    model_name: str = ""
    model_version: str = ""
    processing_time_ms: float = 0.0
    tokens_used: int | None = None

    # Raw output for debugging
    raw_output: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "full_text": self.full_text,
            "confidence": self.confidence,
            "blocks": [b.to_dict() for b in self.blocks],
            "tables": [t.to_dict() for t in self.tables],
            "page_count": self.page_count,
            "language": self.language,
            "model_name": self.model_name,
            "model_version": self.model_version,
            "processing_time_ms": self.processing_time_ms,
            "tokens_used": self.tokens_used,
            "metadata": self.metadata,
        }


class OCRServiceInterface(ABC):
    """
    Abstract interface for OCR Council members.

    All council members (PaddleOCR, olmOCR, Qwen) must implement this interface.
    """

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Get the model name."""
        ...

    @property
    @abstractmethod
    def model_version(self) -> str:
        """Get the model version."""
        ...

    @property
    @abstractmethod
    def capabilities(self) -> list[Capability]:
        """Get the model's capabilities."""
        ...

    @abstractmethod
    async def extract_text(self, image: bytes) -> OCRResult:
        """
        Extract text from a single image.

        Args:
            image: Image bytes (PNG, JPEG, etc.)

        Returns:
            OCRResult with extracted text and confidence
        """
        ...

    @abstractmethod
    async def extract_from_pdf(
        self,
        pdf_bytes: bytes,
        pages: list[int] | None = None,
    ) -> list[OCRResult]:
        """
        Extract text from a PDF document.

        Args:
            pdf_bytes: PDF file bytes
            pages: Optional list of page numbers to process (1-indexed).
                   If None, process all pages.

        Returns:
            List of OCRResult, one per page
        """
        ...

    @abstractmethod
    async def extract_tables(self, image: bytes) -> list[TableData]:
        """
        Extract tables from an image.

        Args:
            image: Image bytes

        Returns:
            List of TableData with extracted table structures
        """
        ...

    async def health_check(self) -> bool:
        """
        Check if the model is available and healthy.

        Returns:
            True if healthy, False otherwise
        """
        return True

    def has_capability(self, capability: Capability) -> bool:
        """Check if model has a specific capability."""
        return capability in self.capabilities

    def get_expertise_weight(self, capability: Capability) -> float:
        """
        Get the expertise weight for a capability.

        Higher weight means this model is more reliable for this capability.
        Override in subclasses to provide model-specific weights.
        """
        if capability in self.capabilities:
            return 0.5  # Default weight
        return 0.0


class MockOCRService(OCRServiceInterface):
    """Mock OCR service for testing."""

    @property
    def model_name(self) -> str:
        return "mock-ocr"

    @property
    def model_version(self) -> str:
        return "1.0.0"

    @property
    def capabilities(self) -> list[Capability]:
        return [Capability.FAST_EXTRACTION, Capability.TABLES]

    async def extract_text(self, image: bytes) -> OCRResult:
        """Mock text extraction."""
        return OCRResult(
            blocks=[
                TextBlock(
                    text="Mock extracted text",
                    confidence=0.95,
                    block_type=BlockType.TEXT,
                )
            ],
            full_text="Mock extracted text",
            confidence=0.95,
            model_name=self.model_name,
            model_version=self.model_version,
            processing_time_ms=100.0,
        )

    async def extract_from_pdf(
        self,
        pdf_bytes: bytes,
        pages: list[int] | None = None,
    ) -> list[OCRResult]:
        """Mock PDF extraction."""
        return [
            OCRResult(
                blocks=[
                    TextBlock(
                        text="Mock PDF page 1",
                        confidence=0.90,
                        block_type=BlockType.TEXT,
                        page_number=1,
                    )
                ],
                full_text="Mock PDF page 1",
                confidence=0.90,
                page_count=1,
                model_name=self.model_name,
                model_version=self.model_version,
                processing_time_ms=200.0,
            )
        ]

    async def extract_tables(self, image: bytes) -> list[TableData]:
        """Mock table extraction."""
        return [
            TableData(
                cells=[
                    TableCell(text="Header 1", row=0, col=0, is_header=True),
                    TableCell(text="Header 2", row=0, col=1, is_header=True),
                    TableCell(text="Value 1", row=1, col=0),
                    TableCell(text="Value 2", row=1, col=1),
                ],
                rows=2,
                cols=2,
            )
        ]
