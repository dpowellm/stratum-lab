"""Structured data models for chart, graph, and diagram extraction.

These models represent the structured output of chart/diagram analysis
by VLM council members, enabling regeneration and search.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class DataPoint:
    """A single data point in a chart series."""

    label: str  # x-axis label or category
    value: float
    formatted_value: str = ""  # "$1.2M", "45%"


@dataclass
class DataSeries:
    """A data series in a chart."""

    name: str
    data_points: list[DataPoint] = field(default_factory=list)


@dataclass
class ChartData:
    """Structured data extracted from a chart or graph."""

    chart_type: str  # bar, line, pie, scatter, area, histogram
    title: str | None = None
    x_axis_label: str | None = None
    y_axis_label: str | None = None
    data_series: list[DataSeries] = field(default_factory=list)
    legend_entries: list[str] = field(default_factory=list)
    source_member: str = ""
    confidence: float = 0.0
    page_number: int = 1
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "chart_type": self.chart_type,
            "title": self.title,
            "x_axis_label": self.x_axis_label,
            "y_axis_label": self.y_axis_label,
            "data_series": [
                {
                    "name": s.name,
                    "data_points": [
                        {
                            "label": p.label,
                            "value": p.value,
                            "formatted_value": p.formatted_value,
                        }
                        for p in s.data_points
                    ],
                }
                for s in self.data_series
            ],
            "legend_entries": self.legend_entries,
            "source_member": self.source_member,
            "confidence": self.confidence,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ChartData":
        """Create from dictionary (e.g., VLM JSON output)."""
        series = []
        for s in data.get("data_series") or data.get("series", []):
            points = []
            for p in s.get("data_points") or s.get("points", []):
                points.append(
                    DataPoint(
                        label=str(p.get("label", "")),
                        value=float(p.get("value", 0)),
                        formatted_value=str(p.get("formatted_value", "")),
                    )
                )
            series.append(DataSeries(name=s.get("name", ""), data_points=points))

        return cls(
            chart_type=data.get("chart_type", "unknown"),
            title=data.get("title"),
            x_axis_label=data.get("x_axis_label") or data.get("x_axis"),
            y_axis_label=data.get("y_axis_label") or data.get("y_axis"),
            data_series=series,
            legend_entries=data.get("legend_entries", []),
            source_member=data.get("source_member", ""),
            confidence=float(data.get("confidence", 0.0)),
        )


@dataclass
class DiagramNode:
    """A node/component in a diagram."""

    id: str
    name: str
    node_type: str = ""  # server, database, service, process, decision
    description: str = ""


@dataclass
class DiagramEdge:
    """An edge/connection in a diagram."""

    source: str  # node id
    target: str  # node id
    label: str = ""
    edge_type: str = ""  # directed, bidirectional, dashed


@dataclass
class DiagramTopology:
    """Structured representation of a diagram."""

    diagram_type: str  # architecture, flowchart, sequence, network, er
    nodes: list[DiagramNode] = field(default_factory=list)
    edges: list[DiagramEdge] = field(default_factory=list)
    layout_hint: str = "top-down"  # top-down, left-right, radial
    title: str | None = None
    source_member: str = ""
    confidence: float = 0.0
    page_number: int = 1
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "diagram_type": self.diagram_type,
            "title": self.title,
            "layout_hint": self.layout_hint,
            "nodes": [
                {
                    "id": n.id,
                    "name": n.name,
                    "type": n.node_type,
                    "description": n.description,
                }
                for n in self.nodes
            ],
            "edges": [
                {
                    "source": e.source,
                    "target": e.target,
                    "label": e.label,
                    "type": e.edge_type,
                }
                for e in self.edges
            ],
            "source_member": self.source_member,
            "confidence": self.confidence,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DiagramTopology":
        """Create from dictionary (e.g., VLM JSON output)."""
        nodes = [
            DiagramNode(
                id=str(n.get("id", f"node_{i}")),
                name=n.get("name", ""),
                node_type=n.get("type", ""),
                description=n.get("description", ""),
            )
            for i, n in enumerate(data.get("nodes", []))
        ]
        edges = [
            DiagramEdge(
                source=str(e.get("source", "")),
                target=str(e.get("target", "")),
                label=e.get("label", ""),
                edge_type=e.get("type", "directed"),
            )
            for e in data.get("edges", [])
        ]
        return cls(
            diagram_type=data.get("diagram_type", "unknown"),
            nodes=nodes,
            edges=edges,
            layout_hint=data.get("layout_hint", "top-down"),
            title=data.get("title"),
            source_member=data.get("source_member", ""),
            confidence=float(data.get("confidence", 0.0)),
        )
