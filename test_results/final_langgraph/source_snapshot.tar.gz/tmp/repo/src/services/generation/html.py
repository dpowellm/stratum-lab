"""HTML document generation from extraction results.

Generates responsive HTML documents with:
- Semantic HTML5 elements
- Embedded chart images as base64
- Confidence indicators
- Council vote summaries
- Responsive tables with sticky headers
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class HTMLConfig:
    """Configuration for HTML generation."""

    theme: str = "light"  # light or dark
    include_confidence: bool = True
    include_council_votes: bool = True
    standalone: bool = True  # Include CSS/JS inline
    embed_images: bool = True


class HTMLGenerator:
    """Generates HTML documents from extraction data."""

    def __init__(self, config: HTMLConfig | None = None):
        self.config = config or HTMLConfig()

    def generate(
        self,
        extraction_data: dict[str, Any],
        title: str = "Extracted Document",
    ) -> str:
        """Generate an HTML document from extraction data.

        Args:
            extraction_data: Extracted fields, tables, charts, votes.
            title: Document title.

        Returns:
            HTML string.
        """
        parts: list[str] = []

        if self.config.standalone:
            parts.append(self._html_head(title))
        else:
            parts.append(f"<article><h1>{self._escape(title)}</h1>")

        # Timestamp
        parts.append(
            f'<p class="timestamp">Generated: {datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")}</p>'
        )

        # Extracted fields
        fields = extraction_data.get("extracted_fields", extraction_data)
        if fields and isinstance(fields, dict):
            parts.append(self._render_fields(fields, extraction_data))

        # Tables
        tables = extraction_data.get("tables", [])
        if tables:
            parts.append('<section class="tables"><h2>Tables</h2>')
            for i, table in enumerate(tables):
                parts.append(self._render_table(table, f"Table {i + 1}"))
            parts.append("</section>")

        # Charts (as embedded images)
        charts = extraction_data.get("charts", [])
        if charts and self.config.embed_images:
            parts.append('<section class="charts"><h2>Charts</h2>')
            for chart in charts:
                parts.append(self._render_chart(chart))
            parts.append("</section>")

        # Council votes
        if self.config.include_council_votes:
            votes = extraction_data.get("council_votes") or extraction_data.get(
                "voting_summary", {}
            )
            if votes:
                parts.append(self._render_votes(votes))

        if self.config.standalone:
            parts.append("</main></body></html>")
        else:
            parts.append("</article>")

        return "\n".join(parts)

    def _html_head(self, title: str) -> str:
        """Generate HTML head with embedded CSS."""
        bg = "#ffffff" if self.config.theme == "light" else "#1e1e1e"
        text_color = "#333333" if self.config.theme == "light" else "#e0e0e0"
        table_header_bg = "#4472C4" if self.config.theme == "light" else "#2a5298"
        border = "#dee2e6" if self.config.theme == "light" else "#444444"

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{self._escape(title)}</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: {bg}; color: {text_color}; margin: 0; padding: 20px; line-height: 1.6; }}
main {{ max-width: 900px; margin: 0 auto; }}
h1 {{ border-bottom: 2px solid {table_header_bg}; padding-bottom: 8px; }}
h2 {{ color: {table_header_bg}; margin-top: 2em; }}
.timestamp {{ color: #888; font-size: 0.9em; }}
.field-table {{ width: 100%; border-collapse: collapse; margin: 1em 0; }}
.field-table th, .field-table td {{ padding: 8px 12px; border: 1px solid {border}; text-align: left; }}
.field-table th {{ background: {table_header_bg}; color: white; position: sticky; top: 0; }}
.field-table tr:nth-child(even) {{ background: {"#f8f9fa" if self.config.theme == "light" else "#2a2a2a"}; }}
.badge {{ display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.8em; font-weight: bold; }}
.badge-high {{ background: #28a745; color: white; }}
.badge-medium {{ background: #ffc107; color: #333; }}
.badge-low {{ background: #dc3545; color: white; }}
details {{ margin: 1em 0; padding: 8px; border: 1px solid {border}; border-radius: 4px; }}
summary {{ cursor: pointer; font-weight: bold; }}
.chart-img {{ max-width: 100%; height: auto; margin: 1em 0; }}
</style>
</head>
<body><main>
<h1>{self._escape(title)}</h1>"""

    def _render_fields(self, fields: dict[str, Any], full_data: dict[str, Any]) -> str:
        """Render extracted fields as a styled table."""
        confidence_scores = full_data.get("confidence_scores", {})

        rows = []
        for field_name, field_data in fields.items():
            if isinstance(field_data, dict):
                value = field_data.get("value", "")
                source = field_data.get("source", "")
            else:
                value = field_data
                source = ""

            conf = confidence_scores.get(field_name, 0.0)
            conf_badge = self._confidence_badge(conf) if self.config.include_confidence else ""
            label = field_name.replace("_", " ").title()

            rows.append(
                f"<tr><td><strong>{self._escape(label)}</strong></td>"
                f"<td>{self._escape(str(value))}</td>"
                f"<td>{conf_badge}</td>"
                f"<td>{self._escape(source)}</td></tr>"
            )

        return (
            '<section class="fields"><h2>Extracted Fields</h2>'
            '<table class="field-table">'
            "<thead><tr><th>Field</th><th>Value</th><th>Confidence</th><th>Source</th></tr></thead>"
            f"<tbody>{''.join(rows)}</tbody></table></section>"
        )

    def _render_table(self, table: dict[str, Any] | Any, title: str) -> str:
        """Render a data table."""
        # Handle TableData objects
        if hasattr(table, "to_dict"):
            table = table.to_dict()

        if isinstance(table, dict) and "cells" in table:
            return self._render_table_from_cells(table, title)

        # Flat table: headers + rows
        headers = table.get("headers", []) if isinstance(table, dict) else []
        table_rows = table.get("rows", []) if isinstance(table, dict) else []

        if not headers:
            return ""

        header_html = "".join(f"<th>{self._escape(str(h))}</th>" for h in headers)
        rows_html = ""
        for row in table_rows:
            cells = "".join(f"<td>{self._escape(str(c))}</td>" for c in row)
            rows_html += f"<tr>{cells}</tr>"

        return (
            f"<h3>{self._escape(title)}</h3>"
            f'<div style="overflow-x: auto;"><table class="field-table">'
            f"<thead><tr>{header_html}</tr></thead>"
            f"<tbody>{rows_html}</tbody></table></div>"
        )

    def _render_table_from_cells(self, table: dict, title: str) -> str:
        """Render a table from cell-based structure."""
        rows = table.get("rows", 0)
        cols = table.get("cols", 0)
        cells = table.get("cells", [])

        grid: list[list[str]] = [["" for _ in range(cols)] for _ in range(rows)]
        for cell in cells:
            r, c = cell.get("row", 0), cell.get("col", 0)
            if 0 <= r < rows and 0 <= c < cols:
                grid[r][c] = str(cell.get("text", ""))

        html = f"<h3>{self._escape(title)}</h3>"
        html += '<div style="overflow-x: auto;"><table class="field-table"><tbody>'
        for i, row in enumerate(grid):
            tag = "th" if i == 0 else "td"
            cells_html = "".join(f"<{tag}>{self._escape(c)}</{tag}>" for c in row)
            html += f"<tr>{cells_html}</tr>"
        html += "</tbody></table></div>"
        return html

    def _render_chart(self, chart: dict[str, Any]) -> str:
        """Render chart data as embedded image or description."""
        image_data = chart.get("image_bytes")
        if image_data and isinstance(image_data, bytes):
            b64 = base64.b64encode(image_data).decode("ascii")
            title = chart.get("title", "Chart")
            return (
                f'<figure><img class="chart-img" src="data:image/png;base64,{b64}" '
                f'alt="{self._escape(title)}">'
                f"<figcaption>{self._escape(title)}</figcaption></figure>"
            )

        # Fallback: text description
        chart_type = chart.get("chart_type", "chart")
        title = chart.get("title", "")
        return f"<p><em>[{chart_type}: {self._escape(title)}]</em></p>"

    def _render_votes(self, votes: dict[str, Any]) -> str:
        """Render council votes as collapsible details sections."""
        html = '<section class="council-votes"><h2>Council Votes</h2>'
        html += "<details><summary>View voting details</summary>"
        html += '<table class="field-table">'
        html += "<thead><tr><th>Model</th><th>Vote</th><th>Confidence</th></tr></thead><tbody>"

        for model, vote_data in votes.items():
            if isinstance(vote_data, dict):
                value = vote_data.get("value", "")
                conf = vote_data.get("confidence", 0)
                badge = self._confidence_badge(conf)
                html += (
                    f"<tr><td>{self._escape(model)}</td>"
                    f"<td>{self._escape(str(value))}</td>"
                    f"<td>{badge}</td></tr>"
                )

        html += "</tbody></table></details></section>"
        return html

    def _confidence_badge(self, confidence: float) -> str:
        """Generate a color-coded confidence badge."""
        if confidence >= 0.9:
            cls = "badge-high"
        elif confidence >= 0.7:
            cls = "badge-medium"
        else:
            cls = "badge-low"
        return f'<span class="badge {cls}">{confidence:.0%}</span>'

    def _escape(self, text: str) -> str:
        """Escape HTML special characters."""
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
        )


# Singleton
_html_generator: HTMLGenerator | None = None


def get_html_generator() -> HTMLGenerator:
    """Get or create HTML generator singleton."""
    global _html_generator
    if _html_generator is None:
        _html_generator = HTMLGenerator()
    return _html_generator
