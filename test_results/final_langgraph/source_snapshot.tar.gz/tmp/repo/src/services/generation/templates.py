"""
Template Management System.

Task 3.2.4: Implements template management for customizable output.
"""

import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import TYPE_CHECKING, Any

from src.core.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

logger = get_logger(__name__)


class TemplateType(StrEnum):
    """Types of document templates."""

    INVOICE = "invoice"
    CONTRACT = "contract"
    RECEIPT = "receipt"
    REPORT = "report"
    SUMMARY = "summary"
    CUSTOM = "custom"


class VariableType(StrEnum):
    """Types of template variables."""

    STRING = "string"
    NUMBER = "number"
    DATE = "date"
    CURRENCY = "currency"
    LIST = "list"
    TABLE = "table"
    CONDITIONAL = "conditional"


@dataclass
class TemplateVariable:
    """A variable in a template."""

    name: str
    variable_type: VariableType
    required: bool = True
    default_value: Any = None
    format_string: str | None = None
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "variable_type": self.variable_type.value,
            "required": self.required,
            "default_value": self.default_value,
            "format_string": self.format_string,
            "description": self.description,
        }


@dataclass
class Template:
    """A document template."""

    template_id: str
    name: str
    template_type: TemplateType
    content: str
    variables: list[TemplateVariable] = field(default_factory=list)
    description: str = ""
    version: str = "1.0.0"
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def variable_names(self) -> list[str]:
        """Get list of variable names."""
        return [v.name for v in self.variables]

    @property
    def required_variables(self) -> list[str]:
        """Get list of required variable names."""
        return [v.name for v in self.variables if v.required]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "template_id": self.template_id,
            "name": self.name,
            "template_type": self.template_type.value,
            "content": self.content,
            "variables": [v.to_dict() for v in self.variables],
            "description": self.description,
            "version": self.version,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "metadata": self.metadata,
        }


@dataclass
class RenderedTemplate:
    """Result of template rendering."""

    template_id: str
    template_name: str
    content: str
    variables_used: dict[str, Any]
    rendered_at: datetime = field(default_factory=datetime.utcnow)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "template_id": self.template_id,
            "template_name": self.template_name,
            "content": self.content,
            "variables_used": self.variables_used,
            "rendered_at": self.rendered_at.isoformat(),
            "warnings": self.warnings,
        }


class TemplateManager:
    """
    Template Management System.

    Features:
    - Template CRUD operations
    - Variable substitution
    - Conditional rendering
    - Template versioning
    """

    # Default templates
    DEFAULT_TEMPLATES = [
        Template(
            template_id="invoice_summary",
            name="Invoice Summary",
            template_type=TemplateType.INVOICE,
            content="""# Invoice Summary

**Invoice Number:** {{invoice_number}}
**Date:** {{date}}
**Vendor:** {{vendor_name}}

## Line Items
{{#each line_items}}
- {{description}}: {{amount}}
{{/each}}

## Totals
- Subtotal: {{subtotal}}
- Tax: {{tax}}
- **Total: {{total}}**

---
*Generated on {{generated_date}}*
""",
            variables=[
                TemplateVariable("invoice_number", VariableType.STRING, required=True),
                TemplateVariable("date", VariableType.DATE),
                TemplateVariable("vendor_name", VariableType.STRING),
                TemplateVariable("line_items", VariableType.LIST),
                TemplateVariable("subtotal", VariableType.CURRENCY),
                TemplateVariable("tax", VariableType.CURRENCY),
                TemplateVariable("total", VariableType.CURRENCY, required=True),
            ],
            description="Standard invoice summary template",
        ),
        Template(
            template_id="extraction_report",
            name="Extraction Report",
            template_type=TemplateType.REPORT,
            content="""# Document Extraction Report

## Document Information
- **Type:** {{document_type}}
- **Processed:** {{processed_date}}
- **Confidence:** {{confidence}}%

## Extracted Fields
{{#each fields}}
| Field | Value |
|-------|-------|
| {{name}} | {{value}} |
{{/each}}

## Council Deliberation
{{#if consensus_achieved}}
✅ Consensus was achieved with {{agreement_ratio}}% agreement.
{{else}}
⚠️ No consensus - judge model was invoked.
{{/if}}

---
*Report generated by Document Extraction System*
""",
            variables=[
                TemplateVariable("document_type", VariableType.STRING),
                TemplateVariable("processed_date", VariableType.DATE),
                TemplateVariable("confidence", VariableType.NUMBER),
                TemplateVariable("fields", VariableType.TABLE),
                TemplateVariable("consensus_achieved", VariableType.CONDITIONAL),
                TemplateVariable("agreement_ratio", VariableType.NUMBER),
            ],
            description="Extraction result report template",
        ),
    ]

    def __init__(self):
        """Initialize template manager."""
        self._templates: dict[str, Template] = {}
        self._formatters: dict[VariableType, Callable[[Any, str | None], str]] = {
            VariableType.STRING: self._format_string,
            VariableType.NUMBER: self._format_number,
            VariableType.DATE: self._format_date,
            VariableType.CURRENCY: self._format_currency,
        }
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize with default templates."""
        for template in self.DEFAULT_TEMPLATES:
            self._templates[template.template_id] = template

        self._initialized = True
        logger.info(
            "Template manager initialized",
            templates=len(self._templates),
        )
        return True

    def create_template(
        self,
        name: str,
        template_type: TemplateType,
        content: str,
        variables: list[TemplateVariable] | None = None,
        description: str = "",
    ) -> Template:
        """
        Create a new template.

        Args:
            name: Template name
            template_type: Type of template
            content: Template content
            variables: Template variables
            description: Template description

        Returns:
            Created template
        """
        template_id = str(uuid.uuid4())[:8]

        # Auto-detect variables from content
        if variables is None:
            variables = self._detect_variables(content)

        template = Template(
            template_id=template_id,
            name=name,
            template_type=template_type,
            content=content,
            variables=variables,
            description=description,
        )

        self._templates[template_id] = template

        logger.info(
            "Template created",
            template_id=template_id,
            name=name,
        )

        return template

    def get_template(self, template_id: str) -> Template | None:
        """Get a template by ID."""
        return self._templates.get(template_id)

    def get_template_by_name(self, name: str) -> Template | None:
        """Get a template by name."""
        for template in self._templates.values():
            if template.name == name:
                return template
        return None

    def get_templates_by_type(
        self,
        template_type: TemplateType,
    ) -> list[Template]:
        """Get all templates of a specific type."""
        return [t for t in self._templates.values() if t.template_type == template_type]

    def get_all_templates(self) -> list[Template]:
        """Get all templates."""
        return list(self._templates.values())

    def update_template(
        self,
        template_id: str,
        **updates: Any,
    ) -> Template | None:
        """Update a template."""
        template = self._templates.get(template_id)
        if not template:
            return None

        for key, value in updates.items():
            if hasattr(template, key):
                setattr(template, key, value)

        template.updated_at = datetime.utcnow()
        return template

    def delete_template(self, template_id: str) -> bool:
        """Delete a template."""
        if template_id in self._templates:
            del self._templates[template_id]
            return True
        return False

    def render(
        self,
        template_id: str,
        data: dict[str, Any],
    ) -> RenderedTemplate:
        """
        Render a template with data.

        Args:
            template_id: Template ID
            data: Data to fill template

        Returns:
            Rendered template result
        """
        if not self._initialized:
            self.initialize()

        template = self._templates.get(template_id)
        if not template:
            raise ValueError(f"Template not found: {template_id}")

        warnings = []

        # Check required variables
        for var in template.variables:
            if var.required and var.name not in data:
                if var.default_value is not None:
                    data[var.name] = var.default_value
                else:
                    warnings.append(f"Missing required variable: {var.name}")

        # Render content
        content = self._substitute_variables(template, data)

        # Process conditionals
        content = self._process_conditionals(content, data)

        # Process loops
        content = self._process_loops(content, data)

        return RenderedTemplate(
            template_id=template_id,
            template_name=template.name,
            content=content,
            variables_used=data,
            warnings=warnings,
        )

    def _detect_variables(self, content: str) -> list[TemplateVariable]:
        """Detect variables from template content."""
        variables = []

        # Match {{variable_name}} pattern
        pattern = r"\{\{(\w+)\}\}"
        matches = re.findall(pattern, content)

        for match in set(matches):
            variables.append(
                TemplateVariable(
                    name=match,
                    variable_type=VariableType.STRING,
                )
            )

        return variables

    def _substitute_variables(
        self,
        template: Template,
        data: dict[str, Any],
    ) -> str:
        """Substitute variables in template."""
        content = template.content

        for var in template.variables:
            placeholder = f"{{{{{var.name}}}}}"
            if var.name in data:
                value = data[var.name]
                formatter = self._formatters.get(var.variable_type, self._format_string)
                formatted = formatter(value, var.format_string)
                content = content.replace(placeholder, formatted)

        return content

    def _process_conditionals(
        self,
        content: str,
        data: dict[str, Any],
    ) -> str:
        """Process conditional blocks."""
        # Match {{#if condition}}...{{else}}...{{/if}}
        pattern = r"\{\{#if (\w+)\}\}(.*?)(?:\{\{else\}\}(.*?))?\{\{/if\}\}"

        def replace_conditional(match):
            condition = match.group(1)
            true_content = match.group(2)
            false_content = match.group(3) or ""

            if data.get(condition):
                return true_content
            return false_content

        return re.sub(pattern, replace_conditional, content, flags=re.DOTALL)

    def _process_loops(
        self,
        content: str,
        data: dict[str, Any],
    ) -> str:
        """Process loop blocks."""
        # Match {{#each items}}...{{/each}}
        pattern = r"\{\{#each (\w+)\}\}(.*?)\{\{/each\}\}"

        def replace_loop(match):
            list_name = match.group(1)
            loop_content = match.group(2)

            items = data.get(list_name, [])
            if not isinstance(items, list):
                return ""

            result_parts = []
            for item in items:
                item_content = loop_content
                if isinstance(item, dict):
                    for key, value in item.items():
                        item_content = item_content.replace(f"{{{{{key}}}}}", str(value))
                else:
                    item_content = item_content.replace("{{.}}", str(item))
                result_parts.append(item_content)

            return "".join(result_parts)

        return re.sub(pattern, replace_loop, content, flags=re.DOTALL)

    def _format_string(self, value: Any, format_str: str | None) -> str:
        """Format string value."""
        return str(value)

    def _format_number(self, value: Any, format_str: str | None) -> str:
        """Format number value."""
        try:
            num = float(value)
            if format_str:
                return format_str.format(num)
            return f"{num:,.2f}"
        except (ValueError, TypeError):
            return str(value)

    def _format_date(self, value: Any, format_str: str | None) -> str:
        """Format date value."""
        if isinstance(value, datetime):
            fmt = format_str or "%Y-%m-%d"
            return value.strftime(fmt)
        return str(value)

    def _format_currency(self, value: Any, format_str: str | None) -> str:
        """Format currency value."""
        try:
            num = float(value)
            symbol = format_str or "$"
            return f"{symbol}{num:,.2f}"
        except (ValueError, TypeError):
            return str(value)

    def validate_template(self, template: Template) -> list[str]:
        """Validate a template for errors."""
        errors = []

        # Check for unclosed tags
        if template.content.count("{{#if") != template.content.count("{{/if}}"):
            errors.append("Unclosed {{#if}} block")

        if template.content.count("{{#each") != template.content.count("{{/each}}"):
            errors.append("Unclosed {{#each}} block")

        # Check for undefined variables
        detected = self._detect_variables(template.content)
        detected_names = {v.name for v in detected}
        defined_names = {v.name for v in template.variables}

        undefined = detected_names - defined_names
        if undefined:
            errors.append(f"Undefined variables: {', '.join(undefined)}")

        return errors

    def get_statistics(self) -> dict[str, Any]:
        """Get template manager statistics."""
        return {
            "total_templates": len(self._templates),
            "by_type": {
                t.value: len([tmpl for tmpl in self._templates.values() if tmpl.template_type == t])
                for t in TemplateType
            },
        }


# Singleton instance
_template_manager: TemplateManager | None = None


def get_template_manager() -> TemplateManager:
    """Get or create template manager singleton."""
    global _template_manager
    if _template_manager is None:
        _template_manager = TemplateManager()
        _template_manager.initialize()
    return _template_manager
