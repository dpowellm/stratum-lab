"""Chart regeneration using matplotlib.

Generates clean, resolution-independent charts from structured ChartData
extracted by VLM council members.
"""

from __future__ import annotations

import io
from dataclasses import dataclass, field
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class ChartConfig:
    """Configuration for chart generation."""

    width: float = 10.0
    height: float = 6.0
    dpi: int = 150
    style: str = "seaborn-v0_8"
    color_palette: list[str] = field(
        default_factory=lambda: [
            "#4472C4",
            "#ED7D31",
            "#A5A5A5",
            "#FFC000",
            "#5B9BD5",
            "#70AD47",
            "#264478",
            "#9B59B6",
        ]
    )
    show_grid: bool = True
    show_legend: bool = True
    font_size: int = 12


class ChartGenerator:
    """Generates charts from structured ChartData using matplotlib."""

    def __init__(self, config: ChartConfig | None = None):
        self.config = config or ChartConfig()

    def generate(
        self,
        chart_data: dict[str, Any],
        output_format: str = "png",
    ) -> bytes:
        """Generate a chart image from structured chart data.

        Args:
            chart_data: Chart data dict with chart_type, title, data_series, etc.
            output_format: Output format (png, svg, pdf).

        Returns:
            Chart image as bytes.
        """
        try:
            import matplotlib

            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            logger.error("matplotlib not installed")
            return b""

        chart_type = chart_data.get("chart_type", "bar")
        title = chart_data.get("title", "")
        x_label = chart_data.get("x_axis_label", "")
        y_label = chart_data.get("y_axis_label", "")
        series_list = chart_data.get("data_series") or chart_data.get("series", [])

        import contextlib

        with contextlib.suppress(OSError):
            plt.style.use(self.config.style)

        fig, ax = plt.subplots(figsize=(self.config.width, self.config.height))

        if chart_type == "bar":
            self._render_bar(ax, series_list)
        elif chart_type == "line":
            self._render_line(ax, series_list)
        elif chart_type == "pie":
            self._render_pie(ax, series_list)
        elif chart_type == "scatter":
            self._render_scatter(ax, series_list)
        elif chart_type == "area":
            self._render_area(ax, series_list)
        elif chart_type == "histogram":
            self._render_histogram(ax, series_list)
        else:
            self._render_bar(ax, series_list)

        if title:
            ax.set_title(title, fontsize=self.config.font_size + 2, fontweight="bold")
        if x_label:
            ax.set_xlabel(x_label, fontsize=self.config.font_size)
        if y_label:
            ax.set_ylabel(y_label, fontsize=self.config.font_size)

        if self.config.show_grid and chart_type not in ("pie",):
            ax.grid(True, alpha=0.3)

        if self.config.show_legend and chart_type != "pie":
            ax.legend(fontsize=self.config.font_size - 2)

        plt.tight_layout()

        buf = io.BytesIO()
        fig.savefig(buf, format=output_format, dpi=self.config.dpi, bbox_inches="tight")
        plt.close(fig)

        return buf.getvalue()

    def _get_points(self, series: dict[str, Any]) -> tuple[list[str], list[float]]:
        """Extract labels and values from a series."""
        points = series.get("data_points") or series.get("points", [])
        labels = [str(p.get("label", "")) for p in points]
        values = [float(p.get("value", 0)) for p in points]
        return labels, values

    def _render_bar(self, ax: Any, series_list: list[dict]) -> None:
        """Render a bar chart."""
        import numpy as np

        if not series_list:
            return

        first_labels, _ = self._get_points(series_list[0])
        x = np.arange(len(first_labels))
        width = 0.8 / max(len(series_list), 1)

        for i, series in enumerate(series_list):
            _, values = self._get_points(series)
            color = self.config.color_palette[i % len(self.config.color_palette)]
            offset = (i - len(series_list) / 2 + 0.5) * width
            ax.bar(
                x + offset, values, width, label=series.get("name", f"Series {i + 1}"), color=color
            )

        ax.set_xticks(x)
        ax.set_xticklabels(first_labels, rotation=45, ha="right")

    def _render_line(self, ax: Any, series_list: list[dict]) -> None:
        """Render a line chart."""
        for i, series in enumerate(series_list):
            labels, values = self._get_points(series)
            color = self.config.color_palette[i % len(self.config.color_palette)]
            ax.plot(
                labels,
                values,
                marker="o",
                label=series.get("name", f"Series {i + 1}"),
                color=color,
                linewidth=2,
            )

        if series_list:
            labels, _ = self._get_points(series_list[0])
            if len(labels) > 8:
                ax.tick_params(axis="x", rotation=45)

    def _render_pie(self, ax: Any, series_list: list[dict]) -> None:
        """Render a pie chart."""
        if not series_list:
            return

        labels, values = self._get_points(series_list[0])
        colors = self.config.color_palette[: len(values)]
        ax.pie(values, labels=labels, colors=colors, autopct="%1.1f%%", startangle=90)
        ax.axis("equal")

    def _render_scatter(self, ax: Any, series_list: list[dict]) -> None:
        """Render a scatter plot."""
        for i, series in enumerate(series_list):
            _, values = self._get_points(series)
            color = self.config.color_palette[i % len(self.config.color_palette)]
            x_vals = list(range(len(values)))
            ax.scatter(
                x_vals, values, label=series.get("name", f"Series {i + 1}"), color=color, s=50
            )

    def _render_area(self, ax: Any, series_list: list[dict]) -> None:
        """Render an area chart."""
        for i, series in enumerate(series_list):
            labels, values = self._get_points(series)
            color = self.config.color_palette[i % len(self.config.color_palette)]
            ax.fill_between(range(len(values)), values, alpha=0.3, color=color)
            ax.plot(
                range(len(values)),
                values,
                label=series.get("name", f"Series {i + 1}"),
                color=color,
                linewidth=2,
            )

        if series_list:
            labels, _ = self._get_points(series_list[0])
            ax.set_xticks(range(len(labels)))
            ax.set_xticklabels(labels, rotation=45, ha="right")

    def _render_histogram(self, ax: Any, series_list: list[dict]) -> None:
        """Render a histogram."""
        for i, series in enumerate(series_list):
            _, values = self._get_points(series)
            color = self.config.color_palette[i % len(self.config.color_palette)]
            ax.hist(
                values,
                bins="auto",
                label=series.get("name", f"Series {i + 1}"),
                color=color,
                alpha=0.7,
            )


# Singleton
_chart_generator: ChartGenerator | None = None


def get_chart_generator() -> ChartGenerator:
    """Get or create chart generator singleton."""
    global _chart_generator
    if _chart_generator is None:
        _chart_generator = ChartGenerator()
    return _chart_generator
