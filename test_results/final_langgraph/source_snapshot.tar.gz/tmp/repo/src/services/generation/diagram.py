"""Diagram regeneration using Mermaid syntax.

Generates Mermaid diagrams from structured DiagramTopology data
extracted by VLM council members.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class DiagramConfig:
    """Configuration for diagram generation."""

    theme: str = "default"  # default, dark, forest, neutral
    direction: str = "TD"  # TD (top-down), LR (left-right), BT, RL
    node_shape: str = "rounded"  # rounded, square, circle


class DiagramGenerator:
    """Generates Mermaid diagram syntax from DiagramTopology."""

    def __init__(self, config: DiagramConfig | None = None):
        self.config = config or DiagramConfig()

    def generate(
        self,
        topology: dict[str, Any],
        output_format: str = "mermaid",
    ) -> str | bytes:
        """Generate diagram from topology data.

        Args:
            topology: DiagramTopology as dict with nodes, edges, diagram_type.
            output_format: "mermaid" for text, "png"/"svg" for rendered image.

        Returns:
            Mermaid syntax string, or rendered image bytes.
        """
        diagram_type = topology.get("diagram_type", "flowchart")
        nodes = topology.get("nodes", [])
        edges = topology.get("edges", [])

        if diagram_type == "sequence":
            mermaid = self._generate_sequence(nodes, edges, topology)
        elif diagram_type == "er":
            mermaid = self._generate_er(nodes, edges, topology)
        else:
            mermaid = self._generate_flowchart(nodes, edges, topology)

        if output_format == "mermaid":
            return mermaid

        # For image output, try mermaid-cli
        return self._render_mermaid_image(mermaid, output_format)

    def _generate_flowchart(
        self,
        nodes: list[dict],
        edges: list[dict],
        topology: dict[str, Any],
    ) -> str:
        """Generate Mermaid flowchart syntax."""
        direction = topology.get("layout_hint", "top-down")
        direction_map = {
            "top-down": "TD",
            "left-right": "LR",
            "bottom-top": "BT",
            "right-left": "RL",
        }
        d = direction_map.get(direction, self.config.direction)

        lines = [f"graph {d}"]

        # Add nodes
        for node in nodes:
            nid = self._safe_id(node.get("id", ""))
            name = node.get("name", nid)
            node_type = node.get("type", "")

            if node_type in ("database", "db"):
                lines.append(f"    {nid}[({name})]")
            elif node_type in ("decision", "condition"):
                lines.append(f"    {nid}{{{{{name}}}}}")
            elif node_type in ("circle", "start", "end"):
                lines.append(f"    {nid}(({name}))")
            else:
                # Default rounded rectangle
                lines.append(f"    {nid}[{name}]")

        # Add edges
        for edge in edges:
            source = self._safe_id(edge.get("source", ""))
            target = self._safe_id(edge.get("target", ""))
            label = edge.get("label", "")
            edge_type = edge.get("type", "directed")

            if label and edge_type == "dashed":
                lines.append(f"    {source} -.->|{label}| {target}")
            elif label:
                lines.append(f"    {source} -->|{label}| {target}")
            elif edge_type == "dashed":
                lines.append(f"    {source} -.-> {target}")
            elif edge_type == "bidirectional":
                lines.append(f"    {source} <--> {target}")
            else:
                lines.append(f"    {source} --> {target}")

        return "\n".join(lines)

    def _generate_sequence(
        self,
        nodes: list[dict],
        edges: list[dict],
        topology: dict[str, Any],
    ) -> str:
        """Generate Mermaid sequence diagram syntax."""
        lines = ["sequenceDiagram"]

        # Declare participants
        for node in nodes:
            name = node.get("name", node.get("id", ""))
            lines.append(f"    participant {name}")

        # Add messages (edges)
        for edge in edges:
            source = edge.get("source", "")
            target = edge.get("target", "")
            label = edge.get("label", "message")
            edge_type = edge.get("type", "directed")

            if edge_type == "dashed":
                lines.append(f"    {source} -->> {target}: {label}")
            else:
                lines.append(f"    {source} ->> {target}: {label}")

        return "\n".join(lines)

    def _generate_er(
        self,
        nodes: list[dict],
        edges: list[dict],
        topology: dict[str, Any],
    ) -> str:
        """Generate Mermaid ER diagram syntax."""
        lines = ["erDiagram"]

        for edge in edges:
            source = self._safe_id(edge.get("source", ""))
            target = self._safe_id(edge.get("target", ""))
            label = edge.get("label", "relates")
            lines.append(f"    {source} ||--o{{ {target} : {label}")

        return "\n".join(lines)

    def _safe_id(self, raw_id: str) -> str:
        """Make a string safe for Mermaid node IDs."""
        import re

        safe = re.sub(r"[^a-zA-Z0-9_]", "_", str(raw_id))
        if not safe or safe[0].isdigit():
            safe = "n_" + safe
        return safe

    def _render_mermaid_image(
        self,
        mermaid_text: str,
        output_format: str,
    ) -> bytes:
        """Try to render Mermaid to image using mermaid-cli (mmdc).

        Falls back to returning the mermaid text as bytes with a note.
        """
        import shutil
        import subprocess
        import tempfile
        from pathlib import Path

        mmdc = shutil.which("mmdc")
        if mmdc is None:
            # Fallback: return mermaid source with a note
            fallback = (
                f"<!-- Render with: npm install -g @mermaid-js/mermaid-cli && "
                f"mmdc -i input.mmd -o output.{output_format} -->\n\n"
                f"```mermaid\n{mermaid_text}\n```"
            )
            return fallback.encode("utf-8")

        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                input_path = Path(tmpdir) / "diagram.mmd"
                output_path = Path(tmpdir) / f"diagram.{output_format}"
                input_path.write_text(mermaid_text)

                subprocess.run(
                    [mmdc, "-i", str(input_path), "-o", str(output_path)],
                    capture_output=True,
                    timeout=30,
                    check=True,
                )

                return output_path.read_bytes()
        except Exception as e:
            logger.warning("Mermaid rendering failed", error=str(e))
            return f"```mermaid\n{mermaid_text}\n```".encode()

    def generate_mermaid_block(self, topology: dict[str, Any]) -> str:
        """Generate a Mermaid code block for embedding in Markdown.

        Args:
            topology: DiagramTopology as dict.

        Returns:
            Markdown code block with mermaid syntax.
        """
        mermaid_text = self.generate(topology, output_format="mermaid")
        if isinstance(mermaid_text, bytes):
            mermaid_text = mermaid_text.decode("utf-8")
        return f"```mermaid\n{mermaid_text}\n```"


# Singleton
_diagram_generator: DiagramGenerator | None = None


def get_diagram_generator() -> DiagramGenerator:
    """Get or create diagram generator singleton."""
    global _diagram_generator
    if _diagram_generator is None:
        _diagram_generator = DiagramGenerator()
    return _diagram_generator
