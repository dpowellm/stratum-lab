"""
Human-in-the-Loop Queue.

Task 2.1.4: Creates system for routing low-confidence extractions
to human reviewers.
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class ReviewPriority(Enum):
    """Priority levels for review items."""

    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


class ReviewStatus(Enum):
    """Status of a review item."""

    PENDING = "pending"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    EXPIRED = "expired"


@dataclass
class ReviewerAssignment:
    """Assignment of a reviewer to an item."""

    reviewer_id: str
    item_id: str
    assigned_at: datetime = field(default_factory=datetime.utcnow)
    notes: str = ""


@dataclass
class ReviewItem:
    """Item in the review queue."""

    document_id: str
    confidence: float
    reason: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    priority: ReviewPriority = ReviewPriority.MEDIUM
    status: ReviewStatus = ReviewStatus.PENDING
    extracted_fields: dict[str, Any] = field(default_factory=dict)
    council_votes: dict[str, Any] = field(default_factory=dict)
    assigned_to: str | None = None
    assigned_at: datetime | None = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None
    corrections: dict[str, Any] = field(default_factory=dict)
    reviewer_notes: str = ""
    skip_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API."""
        return {
            "id": self.id,
            "document_id": self.document_id,
            "confidence": self.confidence,
            "reason": self.reason,
            "priority": self.priority.name,
            "status": self.status.value,
            "extracted_fields": self.extracted_fields,
            "council_votes": self.council_votes,
            "assigned_to": self.assigned_to,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class HITLQueue:
    """
    Human-in-the-Loop Review Queue.

    Features:
    - Priority-based queue management
    - Reviewer assignment
    - Review tracking
    - Statistics and metrics
    """

    def __init__(
        self,
        max_queue_size: int = 1000,
        review_timeout_hours: int = 24,
        max_skips: int = 3,
    ):
        """
        Initialize HITL queue.

        Args:
            max_queue_size: Maximum items in queue
            review_timeout_hours: Hours before assigned review expires
            max_skips: Maximum times an item can be skipped
        """
        self.max_queue_size = max_queue_size
        self.review_timeout_hours = review_timeout_hours
        self.max_skips = max_skips

        # Storage
        self._items: dict[str, ReviewItem] = {}
        self._assignments: dict[str, ReviewerAssignment] = {}

        # Statistics
        self._stats = {
            "total_added": 0,
            "total_completed": 0,
            "total_skipped": 0,
        }

    def add_item(self, item: ReviewItem) -> bool:
        """
        Add an item to the review queue.

        Args:
            item: ReviewItem to add

        Returns:
            True if added successfully
        """
        if len(self._items) >= self.max_queue_size:
            logger.warning("HITL queue full", size=len(self._items))
            return False

        # Auto-prioritize based on confidence
        if item.priority == ReviewPriority.MEDIUM:
            if item.confidence < 0.40:
                item.priority = ReviewPriority.HIGH
            elif item.confidence < 0.30:
                item.priority = ReviewPriority.CRITICAL

        self._items[item.id] = item
        self._stats["total_added"] += 1

        logger.info(
            "Added item to HITL queue",
            item_id=item.id,
            document_id=item.document_id,
            priority=item.priority.name,
            confidence=item.confidence,
        )

        return True

    def get_item(self, item_id: str) -> ReviewItem | None:
        """Get an item by ID."""
        return self._items.get(item_id)

    def get_pending(self) -> list[ReviewItem]:
        """Get all pending items."""
        return [item for item in self._items.values() if item.status == ReviewStatus.PENDING]

    def get_prioritized(self) -> list[ReviewItem]:
        """Get all pending items sorted by priority and age."""
        pending = self.get_pending()
        return sorted(
            pending,
            key=lambda x: (-x.priority.value, x.created_at),
        )

    def get_completed(self) -> list[ReviewItem]:
        """Get all completed items."""
        return [item for item in self._items.values() if item.status == ReviewStatus.COMPLETED]

    def assign_reviewer(
        self,
        item_id: str,
        reviewer_id: str,
    ) -> ReviewerAssignment | None:
        """
        Assign a reviewer to an item.

        Args:
            item_id: ID of the item
            reviewer_id: ID of the reviewer

        Returns:
            Assignment if successful
        """
        item = self._items.get(item_id)
        if not item:
            return None

        if item.status not in [ReviewStatus.PENDING, ReviewStatus.SKIPPED]:
            logger.warning(
                "Cannot assign item with status",
                item_id=item_id,
                status=item.status.value,
            )
            return None

        assignment = ReviewerAssignment(
            reviewer_id=reviewer_id,
            item_id=item_id,
        )

        item.status = ReviewStatus.ASSIGNED
        item.assigned_to = reviewer_id
        item.assigned_at = datetime.utcnow()

        self._assignments[item_id] = assignment

        logger.info(
            "Assigned reviewer",
            item_id=item_id,
            reviewer_id=reviewer_id,
        )

        return assignment

    def submit_review(
        self,
        item_id: str,
        reviewer_id: str,
        corrections: dict[str, Any],
        notes: str = "",
    ) -> bool:
        """
        Submit a completed review.

        Args:
            item_id: ID of the item
            reviewer_id: ID of the reviewer
            corrections: Corrected field values
            notes: Reviewer notes

        Returns:
            True if successful
        """
        item = self._items.get(item_id)
        if not item:
            return False

        if item.assigned_to != reviewer_id:
            logger.warning(
                "Reviewer mismatch",
                item_id=item_id,
                expected=item.assigned_to,
                actual=reviewer_id,
            )
            return False

        item.status = ReviewStatus.COMPLETED
        item.completed_at = datetime.utcnow()
        item.corrections = corrections
        item.reviewer_notes = notes

        self._stats["total_completed"] += 1

        # Feed corrections into learning system
        self._record_corrections_to_learning(item, corrections)

        logger.info(
            "Review submitted",
            item_id=item_id,
            reviewer_id=reviewer_id,
            num_corrections=len(corrections),
        )

        return True

    def _record_corrections_to_learning(
        self,
        item: "ReviewItem",
        corrections: dict[str, Any],
    ) -> None:
        """Feed HITL corrections into the council learning system."""
        try:
            from src.council.learning import (
                CorrectionPattern,
                LearningEvent,
                get_learning_system,
            )

            learning = get_learning_system()

            for field_name, corrected_value in corrections.items():
                original_value = item.extracted_fields.get(field_name)
                if original_value == corrected_value:
                    continue  # No change, skip

                doc_type = item.metadata.get("document_type", "unknown")
                correction = CorrectionPattern(
                    document_type=doc_type,
                    field_name=field_name,
                    original_value=original_value,
                    corrected_value=corrected_value,
                    source_model="council",
                    correction_source="human",
                    timestamp=datetime.utcnow(),
                    confidence=item.confidence,
                )
                learning.record_correction(correction)

                # Also record as incorrect event for learning
                learning.record_event(
                    LearningEvent(
                        model_name=item.metadata.get("source_model", "council"),
                        document_type=doc_type,
                        field_name=field_name,
                        was_correct=False,
                        confidence=item.confidence,
                        timestamp=datetime.utcnow(),
                    )
                )
        except Exception as exc:
            logger.warning(
                "Failed to record corrections to learning system",
                error=str(exc),
            )

    def skip_item(
        self,
        item_id: str,
        reviewer_id: str,
        reason: str = "",
    ) -> bool:
        """
        Skip an item and return to queue.

        Args:
            item_id: ID of the item
            reviewer_id: ID of the reviewer
            reason: Reason for skipping

        Returns:
            True if successful
        """
        item = self._items.get(item_id)
        if not item:
            return False

        item.skip_count += 1
        item.status = (
            ReviewStatus.PENDING if item.skip_count < self.max_skips else ReviewStatus.SKIPPED
        )
        item.assigned_to = None
        item.assigned_at = None

        if item_id in self._assignments:
            del self._assignments[item_id]

        # Increase priority if skipped multiple times
        if item.skip_count >= 2 and item.priority.value < ReviewPriority.HIGH.value:
            item.priority = ReviewPriority(item.priority.value + 1)

        self._stats["total_skipped"] += 1

        logger.info(
            "Item skipped",
            item_id=item_id,
            reviewer_id=reviewer_id,
            skip_count=item.skip_count,
            reason=reason,
        )

        return True

    def get_statistics(self) -> dict[str, Any]:
        """Get queue statistics."""
        pending = len(self.get_pending())
        completed = len(self.get_completed())
        assigned = len([i for i in self._items.values() if i.status == ReviewStatus.ASSIGNED])

        # Calculate average wait time
        wait_times = []
        for item in self._items.values():
            if item.status == ReviewStatus.COMPLETED and item.completed_at and item.created_at:
                wait_time = (item.completed_at - item.created_at).total_seconds() / 3600
                wait_times.append(wait_time)

        avg_wait = sum(wait_times) / len(wait_times) if wait_times else 0

        return {
            "total_items": len(self._items),
            "pending": pending,
            "assigned": assigned,
            "completed": completed,
            "total_added": self._stats["total_added"],
            "total_completed": self._stats["total_completed"],
            "total_skipped": self._stats["total_skipped"],
            "avg_wait_time": avg_wait,
        }

    def get_item_for_api(self, item_id: str) -> dict[str, Any] | None:
        """Get item in API-friendly format."""
        item = self._items.get(item_id)
        if not item:
            return None
        return item.to_dict()

    def get_reviewer_items(self, reviewer_id: str) -> list[ReviewItem]:
        """Get items assigned to a specific reviewer."""
        return [item for item in self._items.values() if item.assigned_to == reviewer_id]

    def cleanup_expired(self) -> int:
        """
        Clean up expired assignments.

        Returns:
            Number of expired items reset
        """
        now = datetime.utcnow()
        expired_count = 0

        for item in self._items.values():
            if item.status == ReviewStatus.ASSIGNED and item.assigned_at:
                hours_elapsed = (now - item.assigned_at).total_seconds() / 3600
                if hours_elapsed > self.review_timeout_hours:
                    item.status = ReviewStatus.PENDING
                    item.assigned_to = None
                    item.assigned_at = None
                    expired_count += 1

                    if item.id in self._assignments:
                        del self._assignments[item.id]

        if expired_count > 0:
            logger.info("Cleaned up expired assignments", count=expired_count)

        return expired_count

    def get_items_by_document(self, document_id: str) -> list[ReviewItem]:
        """Get all review items for a document."""
        return [item for item in self._items.values() if item.document_id == document_id]


# Singleton instance
_hitl_queue: HITLQueue | None = None


def get_hitl_queue() -> HITLQueue:
    """Get or create the HITL queue singleton."""
    global _hitl_queue
    if _hitl_queue is None:
        _hitl_queue = HITLQueue()
    return _hitl_queue
