"""
Feedback Learning Pipeline.

Task 2.3.4: Creates pipeline that learns from human corrections
to improve council performance.
"""

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class FeedbackSource(StrEnum):
    """Source of feedback."""

    HUMAN = "human"
    JUDGE = "judge"
    AUTO = "auto"
    VALIDATION = "validation"


@dataclass
class FeedbackEvent:
    """Individual feedback event."""

    document_id: str
    field_name: str
    original_value: Any
    corrected_value: Any
    source: FeedbackSource
    model_name: str
    document_type: str = "unknown"
    timestamp: datetime = field(default_factory=datetime.utcnow)
    confidence: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def was_corrected(self) -> bool:
        """Check if value was actually corrected."""
        return str(self.original_value) != str(self.corrected_value)


@dataclass
class CorrectionPattern:
    """Pattern of corrections."""

    field_name: str
    error_type: str
    frequency: int
    models_affected: list[str] = field(default_factory=list)
    document_types: list[str] = field(default_factory=list)
    examples: list[dict] = field(default_factory=list)


@dataclass
class LearningOutcome:
    """Outcome of learning from feedback."""

    model_name: str
    total_feedback: int
    corrections_applied: int
    improvement_rate: float
    accuracy_before: float
    accuracy_after: float
    patterns_identified: int
    timestamp: datetime = field(default_factory=datetime.utcnow)


class FeedbackPipeline:
    """
    Feedback Learning Pipeline.

    Features:
    - Correction storage
    - Pattern extraction
    - Model fine-tuning triggers
    - Weight adjustment
    """

    def __init__(
        self,
        min_samples_for_pattern: int = 5,
        learning_window_days: int = 30,
    ):
        """
        Initialize feedback pipeline.

        Args:
            min_samples_for_pattern: Minimum samples to identify pattern
            learning_window_days: Days to consider for learning
        """
        self.min_samples = min_samples_for_pattern
        self.learning_window_days = learning_window_days

        # Storage
        self._feedback: list[FeedbackEvent] = []
        self._patterns: list[CorrectionPattern] = []

        # Statistics by model
        self._model_stats: dict[str, dict[str, Any]] = defaultdict(
            lambda: {
                "total": 0,
                "corrected": 0,
                "by_field": defaultdict(lambda: {"total": 0, "corrected": 0}),
            }
        )

        # Source weights (higher = more trusted)
        self._source_weights = {
            FeedbackSource.HUMAN: 1.0,
            FeedbackSource.JUDGE: 0.9,
            FeedbackSource.VALIDATION: 0.7,
            FeedbackSource.AUTO: 0.5,
        }

    def record_feedback(self, event: FeedbackEvent) -> None:
        """
        Record a feedback event.

        Args:
            event: Feedback event to record
        """
        self._feedback.append(event)

        # Update statistics
        stats = self._model_stats[event.model_name]
        stats["total"] += 1

        if event.was_corrected:
            stats["corrected"] += 1

        field_stats = stats["by_field"][event.field_name]
        field_stats["total"] += 1
        if event.was_corrected:
            field_stats["corrected"] += 1

        logger.debug(
            "Recorded feedback",
            document_id=event.document_id,
            field=event.field_name,
            model=event.model_name,
            was_corrected=event.was_corrected,
        )

    def get_feedback_for_model(
        self,
        model_name: str,
    ) -> list[FeedbackEvent]:
        """Get all feedback for a specific model."""
        cutoff = datetime.utcnow() - timedelta(days=self.learning_window_days)
        return [f for f in self._feedback if f.model_name == model_name and f.timestamp >= cutoff]

    def get_all_feedback(self) -> list[FeedbackEvent]:
        """Get all feedback events."""
        return self._feedback.copy()

    def extract_patterns(
        self,
        model_name: str,
    ) -> list[CorrectionPattern]:
        """
        Extract correction patterns for a model.

        Args:
            model_name: Model to analyze

        Returns:
            List of identified patterns
        """
        feedback = self.get_feedback_for_model(model_name)
        patterns = []

        # Group by field
        by_field: dict[str, list[FeedbackEvent]] = defaultdict(list)
        for event in feedback:
            if event.was_corrected:
                by_field[event.field_name].append(event)

        # Identify patterns
        for field_name, events in by_field.items():
            if len(events) >= self.min_samples:
                # Determine error type
                error_type = self._detect_error_type(events)

                pattern = CorrectionPattern(
                    field_name=field_name,
                    error_type=error_type,
                    frequency=len(events),
                    models_affected=[model_name],
                    document_types=list({e.document_type for e in events}),
                    examples=[
                        {
                            "original": e.original_value,
                            "corrected": e.corrected_value,
                        }
                        for e in events[:5]
                    ],
                )
                patterns.append(pattern)

        return patterns

    def measure_learning(
        self,
        model_name: str,
    ) -> LearningOutcome:
        """
        Measure learning progress for a model.

        Args:
            model_name: Model to measure

        Returns:
            LearningOutcome with metrics
        """
        feedback = self.get_feedback_for_model(model_name)

        if not feedback:
            return LearningOutcome(
                model_name=model_name,
                total_feedback=0,
                corrections_applied=0,
                improvement_rate=0.0,
                accuracy_before=0.0,
                accuracy_after=0.0,
                patterns_identified=0,
            )

        # Split feedback into early and recent
        feedback.sort(key=lambda x: x.timestamp)
        midpoint = len(feedback) // 2

        early_feedback = feedback[:midpoint] if midpoint > 0 else feedback
        recent_feedback = feedback[midpoint:] if midpoint > 0 else []

        # Calculate accuracy (lower correction rate = higher accuracy)
        def calc_accuracy(events: list[FeedbackEvent]) -> float:
            if not events:
                return 0.0
            corrected = sum(1 for e in events if e.was_corrected)
            return 1.0 - (corrected / len(events))

        accuracy_before = calc_accuracy(early_feedback)
        accuracy_after = calc_accuracy(recent_feedback) if recent_feedback else accuracy_before

        improvement = accuracy_after - accuracy_before

        # Count patterns
        patterns = self.extract_patterns(model_name)

        return LearningOutcome(
            model_name=model_name,
            total_feedback=len(feedback),
            corrections_applied=sum(1 for f in feedback if f.was_corrected),
            improvement_rate=improvement,
            accuracy_before=accuracy_before,
            accuracy_after=accuracy_after,
            patterns_identified=len(patterns),
        )

    def apply_to_learning_system(self) -> bool:
        """
        Apply feedback to the learning system.

        Returns:
            True if successfully applied
        """
        try:
            from src.council.learning import CorrectionPattern as LP, get_learning_system

            learning = get_learning_system()

            # Convert and record patterns
            for event in self._feedback:
                if event.was_corrected:
                    correction = LP(
                        document_type=event.document_type,
                        field_name=event.field_name,
                        original_value=event.original_value,
                        corrected_value=event.corrected_value,
                        source_model=event.model_name,
                        correction_source=event.source.value,
                        timestamp=event.timestamp,
                    )
                    learning.record_correction(correction)

            logger.info(
                "Applied feedback to learning system",
                events_applied=len(self._feedback),
            )
            return True

        except Exception as e:
            logger.error(
                "Failed to apply feedback to learning system",
                error=str(e),
            )
            return False

    def get_source_weights(self) -> dict[FeedbackSource, float]:
        """Get source weight mappings."""
        return self._source_weights.copy()

    def _detect_error_type(
        self,
        events: list[FeedbackEvent],
    ) -> str:
        """Detect common error type from events."""
        # Simple heuristic - check what kind of corrections were made
        import re

        format_errors = 0
        value_errors = 0

        for event in events:
            original = str(event.original_value)
            corrected = str(event.corrected_value)

            # Format change (same digits, different format)
            orig_digits = re.sub(r"\D", "", original)
            corr_digits = re.sub(r"\D", "", corrected)

            if orig_digits == corr_digits and original != corrected:
                format_errors += 1
            else:
                value_errors += 1

        if format_errors > value_errors:
            return "format_error"
        return "value_error"

    def get_model_accuracy(
        self,
        model_name: str,
    ) -> float:
        """Get current accuracy for a model."""
        stats = self._model_stats.get(model_name, {})
        total = stats.get("total", 0)
        corrected = stats.get("corrected", 0)

        if total == 0:
            return 1.0

        return 1.0 - (corrected / total)

    def get_field_accuracy(
        self,
        model_name: str,
        field_name: str,
    ) -> float:
        """Get accuracy for a specific field."""
        stats = self._model_stats.get(model_name, {})
        field_stats = stats.get("by_field", {}).get(field_name, {})

        total = field_stats.get("total", 0)
        corrected = field_stats.get("corrected", 0)

        if total == 0:
            return 1.0

        return 1.0 - (corrected / total)

    def export_statistics(self) -> dict[str, Any]:
        """Export pipeline statistics."""
        return {
            "total_feedback": len(self._feedback),
            "feedback_by_source": {
                source.value: sum(1 for f in self._feedback if f.source == source)
                for source in FeedbackSource
            },
            "model_stats": dict(self._model_stats),
            "patterns_count": len(self._patterns),
        }


# Singleton instance
_pipeline: FeedbackPipeline | None = None


def get_feedback_pipeline() -> FeedbackPipeline:
    """Get or create the feedback pipeline singleton."""
    global _pipeline
    if _pipeline is None:
        _pipeline = FeedbackPipeline()
    return _pipeline
