"""
Performance Optimization Package.

Provides caching, batch processing, and model quantization components.
"""

from src.services.performance.batch_processing import (
    BatchConfig,
    BatchItem,
    BatchProcessor,
    BatchResult,
    get_batch_processor,
)
from src.services.performance.caching import (
    CacheConfig,
    CacheEntry,
    CacheStats,
    CachingLayer,
    get_caching_layer,
)
from src.services.performance.quantization import (
    ModelQuantizer,
    QuantizationConfig,
    QuantizationMode,
    QuantizedModel,
    get_model_quantizer,
)
from src.services.performance.tuning import (
    PerformanceMetrics,
    PerformanceTuner,
    TuningConfig,
    TuningRecommendation,
    get_performance_tuner,
)

__all__ = [
    # Batch Processing
    "BatchConfig",
    "BatchItem",
    "BatchProcessor",
    "BatchResult",
    # Caching
    "CacheConfig",
    "CacheEntry",
    "CacheStats",
    "CachingLayer",
    "ModelQuantizer",
    "PerformanceMetrics",
    "PerformanceTuner",
    # Quantization
    "QuantizationConfig",
    "QuantizationMode",
    "QuantizedModel",
    # Tuning
    "TuningConfig",
    "TuningRecommendation",
    "get_batch_processor",
    "get_caching_layer",
    "get_model_quantizer",
    "get_performance_tuner",
]
