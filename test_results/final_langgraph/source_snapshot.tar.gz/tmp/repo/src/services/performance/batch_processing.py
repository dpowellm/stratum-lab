"""
Batch Processing Service.

Task 4.2.3: Implement batch processing for high-throughput document processing.
"""

import queue
import threading
import time
import uuid
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any, TypeVar

from src.core.logging import get_logger

logger = get_logger(__name__)

T = TypeVar("T")
R = TypeVar("R")


class BatchStatus(StrEnum):
    """Status of a batch."""

    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIALLY_COMPLETED = "partially_completed"
    CANCELLED = "cancelled"


class ProcessingPriority(StrEnum):
    """Processing priority levels."""

    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class BatchConfig:
    """Configuration for batch processing."""

    max_batch_size: int = 100
    min_batch_size: int = 1
    batch_timeout_seconds: float = 30.0
    max_concurrent_batches: int = 4
    worker_threads: int = 8
    retry_failed_items: bool = True
    max_retries: int = 3
    enable_priority_queue: bool = True
    auto_scale_workers: bool = True
    memory_limit_mb: int = 4096

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "max_batch_size": self.max_batch_size,
            "min_batch_size": self.min_batch_size,
            "batch_timeout_seconds": self.batch_timeout_seconds,
            "max_concurrent_batches": self.max_concurrent_batches,
            "worker_threads": self.worker_threads,
            "retry_failed_items": self.retry_failed_items,
            "max_retries": self.max_retries,
            "enable_priority_queue": self.enable_priority_queue,
            "auto_scale_workers": self.auto_scale_workers,
            "memory_limit_mb": self.memory_limit_mb,
        }


@dataclass
class BatchItem[T]:
    """An item in a batch."""

    item_id: str
    data: T
    priority: ProcessingPriority = ProcessingPriority.NORMAL
    retries: int = 0
    created_at: datetime = field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary (without data)."""
        return {
            "item_id": self.item_id,
            "priority": self.priority.value,
            "retries": self.retries,
            "created_at": self.created_at.isoformat(),
            "metadata": self.metadata,
        }


@dataclass
class ItemResult[R]:
    """Result of processing a single item."""

    item_id: str
    success: bool
    result: R | None = None
    error: str | None = None
    processing_time_ms: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "item_id": self.item_id,
            "success": self.success,
            "error": self.error,
            "processing_time_ms": self.processing_time_ms,
        }


@dataclass
class BatchResult[R]:
    """Result of batch processing."""

    batch_id: str
    status: BatchStatus
    total_items: int
    successful_items: int
    failed_items: int
    results: list[ItemResult[R]] = field(default_factory=list)
    start_time: datetime | None = None
    end_time: datetime | None = None
    error_summary: dict[str, int] = field(default_factory=dict)

    @property
    def success_rate(self) -> float:
        """Calculate success rate."""
        if self.total_items == 0:
            return 0.0
        return self.successful_items / self.total_items

    @property
    def processing_time_seconds(self) -> float | None:
        """Calculate total processing time."""
        if self.start_time is None or self.end_time is None:
            return None
        return (self.end_time - self.start_time).total_seconds()

    @property
    def items_per_second(self) -> float | None:
        """Calculate throughput."""
        proc_time = self.processing_time_seconds
        if proc_time is None or proc_time == 0:
            return None
        return self.total_items / proc_time

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "batch_id": self.batch_id,
            "status": self.status.value,
            "total_items": self.total_items,
            "successful_items": self.successful_items,
            "failed_items": self.failed_items,
            "success_rate": self.success_rate,
            "processing_time_seconds": self.processing_time_seconds,
            "items_per_second": self.items_per_second,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "error_summary": self.error_summary,
            "results": [r.to_dict() for r in self.results],
        }


@dataclass
class BatchStats:
    """Statistics for batch processor."""

    total_batches_processed: int = 0
    total_items_processed: int = 0
    total_items_failed: int = 0
    average_batch_size: float = 0.0
    average_processing_time_ms: float = 0.0
    average_items_per_second: float = 0.0
    current_queue_size: int = 0
    active_workers: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "total_batches_processed": self.total_batches_processed,
            "total_items_processed": self.total_items_processed,
            "total_items_failed": self.total_items_failed,
            "average_batch_size": self.average_batch_size,
            "average_processing_time_ms": self.average_processing_time_ms,
            "average_items_per_second": self.average_items_per_second,
            "current_queue_size": self.current_queue_size,
            "active_workers": self.active_workers,
        }


class BatchProcessor[T, R]:
    """
    Batch Processing Service.

    Features:
    - Configurable batch sizes
    - Priority queue support
    - Concurrent processing
    - Retry mechanism
    - Statistics tracking
    - Auto-scaling workers
    """

    def __init__(self, config: BatchConfig | None = None):
        """Initialize batch processor."""
        self.config = config or BatchConfig()
        self._queue: queue.PriorityQueue[tuple[int, int, BatchItem[T]]] = queue.PriorityQueue()
        self._results: dict[str, BatchResult[R]] = {}
        self._stats = BatchStats()
        self._lock = threading.RLock()
        self._executor: ThreadPoolExecutor | None = None
        self._processor: Callable[[T], R] | None = None
        self._initialized = False
        self._running = False
        self._counter = 0  # Tie-breaker for priority queue

    def initialize(self, processor: Callable[[T], R] | None = None) -> bool:
        """Initialize the batch processor."""
        self._processor = processor
        self._executor = ThreadPoolExecutor(max_workers=self.config.worker_threads)
        self._initialized = True
        self._running = True
        logger.info(
            "Batch processor initialized",
            worker_threads=self.config.worker_threads,
            max_batch_size=self.config.max_batch_size,
        )
        return True

    def shutdown(self) -> None:
        """Shutdown the batch processor."""
        self._running = False
        if self._executor:
            self._executor.shutdown(wait=True)

    def add_item(
        self,
        data: T,
        priority: ProcessingPriority = ProcessingPriority.NORMAL,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """
        Add an item to the processing queue.

        Args:
            data: Item data
            priority: Processing priority
            metadata: Optional metadata

        Returns:
            Item ID
        """
        item_id = str(uuid.uuid4())
        item = BatchItem(
            item_id=item_id,
            data=data,
            priority=priority,
            metadata=metadata or {},
        )

        # Priority values (lower = higher priority)
        priority_values = {
            ProcessingPriority.CRITICAL: 0,
            ProcessingPriority.HIGH: 1,
            ProcessingPriority.NORMAL: 2,
            ProcessingPriority.LOW: 3,
        }

        with self._lock:
            self._counter += 1
            # Use (priority, counter, item) to ensure stable ordering
            self._queue.put((priority_values[priority], self._counter, item))
            self._stats.current_queue_size = self._queue.qsize()

        return item_id

    def add_items(
        self,
        items: list[T],
        priority: ProcessingPriority = ProcessingPriority.NORMAL,
    ) -> list[str]:
        """
        Add multiple items to the queue.

        Args:
            items: List of items
            priority: Processing priority

        Returns:
            List of item IDs
        """
        return [self.add_item(item, priority) for item in items]

    def process_batch(
        self,
        items: list[T],
        processor: Callable[[T], R] | None = None,
    ) -> BatchResult[R]:
        """
        Process a batch of items synchronously.

        Args:
            items: Items to process
            processor: Processing function (optional, uses default)

        Returns:
            Batch result
        """
        batch_id = str(uuid.uuid4())
        proc = processor or self._processor

        if proc is None:
            raise ValueError("No processor function provided")

        result = BatchResult[R](
            batch_id=batch_id,
            status=BatchStatus.PROCESSING,
            total_items=len(items),
            successful_items=0,
            failed_items=0,
            start_time=datetime.utcnow(),
        )

        for i, item in enumerate(items):
            item_id = f"{batch_id}_{i}"
            start = time.time()

            try:
                output = proc(item)
                item_result = ItemResult[R](
                    item_id=item_id,
                    success=True,
                    result=output,
                    processing_time_ms=(time.time() - start) * 1000,
                )
                result.successful_items += 1
            except Exception as e:
                item_result = ItemResult[R](
                    item_id=item_id,
                    success=False,
                    error=str(e),
                    processing_time_ms=(time.time() - start) * 1000,
                )
                result.failed_items += 1

                # Track error types
                error_type = type(e).__name__
                result.error_summary[error_type] = result.error_summary.get(error_type, 0) + 1

            result.results.append(item_result)

        result.end_time = datetime.utcnow()

        # Determine final status
        if result.failed_items == 0:
            result.status = BatchStatus.COMPLETED
        elif result.successful_items == 0:
            result.status = BatchStatus.FAILED
        else:
            result.status = BatchStatus.PARTIALLY_COMPLETED

        # Update statistics
        self._update_stats(result)

        self._results[batch_id] = result
        return result

    def process_batch_async(
        self,
        items: list[T],
        processor: Callable[[T], R] | None = None,
    ) -> Future[BatchResult[R]]:
        """
        Process a batch asynchronously.

        Args:
            items: Items to process
            processor: Processing function

        Returns:
            Future containing batch result
        """
        if self._executor is None:
            raise RuntimeError("Batch processor not initialized")

        return self._executor.submit(self.process_batch, items, processor)

    def process_queue(
        self,
        max_items: int | None = None,
        timeout_seconds: float | None = None,
    ) -> BatchResult[R]:
        """
        Process items from the queue.

        Args:
            max_items: Maximum items to process (default: max_batch_size)
            timeout_seconds: Timeout for collecting items

        Returns:
            Batch result
        """
        if self._processor is None:
            raise ValueError("No processor function provided")

        max_items = max_items or self.config.max_batch_size
        timeout = timeout_seconds or self.config.batch_timeout_seconds

        items: list[T] = []
        start_collect = time.time()

        while len(items) < max_items:
            remaining_timeout = timeout - (time.time() - start_collect)
            if remaining_timeout <= 0:
                break

            try:
                _, _, batch_item = self._queue.get(timeout=min(1.0, remaining_timeout))
                items.append(batch_item.data)
            except queue.Empty:
                if len(items) >= self.config.min_batch_size:
                    break

        if not items:
            return BatchResult[R](
                batch_id=str(uuid.uuid4()),
                status=BatchStatus.COMPLETED,
                total_items=0,
                successful_items=0,
                failed_items=0,
            )

        with self._lock:
            self._stats.current_queue_size = self._queue.qsize()

        return self.process_batch(items)

    def get_result(self, batch_id: str) -> BatchResult[R] | None:
        """Get result for a batch."""
        return self._results.get(batch_id)

    def get_stats(self) -> BatchStats:
        """Get processing statistics."""
        return self._stats

    def get_queue_size(self) -> int:
        """Get current queue size."""
        return self._queue.qsize()

    def clear_queue(self) -> int:
        """
        Clear the processing queue.

        Returns:
            Number of items cleared
        """
        cleared = 0
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
                cleared += 1
            except queue.Empty:
                break

        with self._lock:
            self._stats.current_queue_size = 0

        return cleared

    def _update_stats(self, result: BatchResult[R]) -> None:
        """Update statistics from a batch result."""
        with self._lock:
            self._stats.total_batches_processed += 1
            self._stats.total_items_processed += result.successful_items
            self._stats.total_items_failed += result.failed_items

            # Update running averages
            n = self._stats.total_batches_processed
            self._stats.average_batch_size = (
                self._stats.average_batch_size * (n - 1) + result.total_items
            ) / n

            if result.processing_time_seconds:
                proc_time_ms = result.processing_time_seconds * 1000
                self._stats.average_processing_time_ms = (
                    self._stats.average_processing_time_ms * (n - 1) + proc_time_ms
                ) / n

            if result.items_per_second:
                self._stats.average_items_per_second = (
                    self._stats.average_items_per_second * (n - 1) + result.items_per_second
                ) / n

    def estimate_completion_time(self, num_items: int) -> float:
        """
        Estimate time to process N items.

        Args:
            num_items: Number of items

        Returns:
            Estimated seconds
        """
        if self._stats.average_items_per_second == 0:
            return float("inf")
        return num_items / self._stats.average_items_per_second

    def get_optimal_batch_size(self) -> int:
        """
        Get optimal batch size based on statistics.

        Returns:
            Recommended batch size
        """
        # Start with configured max
        optimal = self.config.max_batch_size

        # Adjust based on average processing time
        if self._stats.average_processing_time_ms > 0:
            # Target ~1 second per batch
            target_time_ms = 1000.0
            items_per_target = int(
                target_time_ms
                / (self._stats.average_processing_time_ms / max(1, self._stats.average_batch_size))
            )
            optimal = min(optimal, items_per_target)

        return max(self.config.min_batch_size, optimal)


# Singleton instance
_batch_processor: BatchProcessor[Any, Any] | None = None


def get_batch_processor(config: BatchConfig | None = None) -> BatchProcessor[Any, Any]:
    """Get or create batch processor singleton."""
    global _batch_processor
    if _batch_processor is None:
        _batch_processor = BatchProcessor(config)
        _batch_processor.initialize()
    return _batch_processor
