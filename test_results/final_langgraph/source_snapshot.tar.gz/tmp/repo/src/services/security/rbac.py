"""
Role-Based Access Control (RBAC).

Task 4.1.3: Implement RBAC system.
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class Permission(StrEnum):
    """System permissions."""

    # Document permissions
    DOCUMENT_READ = "document:read"
    DOCUMENT_CREATE = "document:create"
    DOCUMENT_UPDATE = "document:update"
    DOCUMENT_DELETE = "document:delete"
    DOCUMENT_EXPORT = "document:export"

    # Extraction permissions
    EXTRACTION_READ = "extraction:read"
    EXTRACTION_CREATE = "extraction:create"
    EXTRACTION_APPROVE = "extraction:approve"
    EXTRACTION_REJECT = "extraction:reject"

    # Council permissions
    COUNCIL_VIEW = "council:view"
    COUNCIL_MANAGE = "council:manage"
    COUNCIL_OVERRIDE = "council:override"

    # User management
    USER_READ = "user:read"
    USER_CREATE = "user:create"
    USER_UPDATE = "user:update"
    USER_DELETE = "user:delete"

    # Admin permissions
    ADMIN_SETTINGS = "admin:settings"
    ADMIN_AUDIT = "admin:audit"
    ADMIN_SECURITY = "admin:security"
    ADMIN_SYSTEM = "admin:system"


@dataclass
class Role:
    """A role with associated permissions."""

    role_id: str
    name: str
    description: str = ""
    permissions: set[Permission] = field(default_factory=set)
    is_system: bool = False
    created_at: datetime = field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = field(default_factory=dict)

    def has_permission(self, permission: Permission) -> bool:
        """Check if role has a permission."""
        return permission in self.permissions

    def add_permission(self, permission: Permission) -> None:
        """Add a permission to the role."""
        self.permissions.add(permission)

    def remove_permission(self, permission: Permission) -> None:
        """Remove a permission from the role."""
        self.permissions.discard(permission)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "role_id": self.role_id,
            "name": self.name,
            "description": self.description,
            "permissions": [p.value for p in self.permissions],
            "is_system": self.is_system,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class User:
    """A user with roles and permissions."""

    user_id: str
    username: str
    email: str
    roles: set[str] = field(default_factory=set)  # Role IDs
    is_active: bool = True
    is_admin: bool = False
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_login: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def add_role(self, role_id: str) -> None:
        """Add a role to the user."""
        self.roles.add(role_id)

    def remove_role(self, role_id: str) -> None:
        """Remove a role from the user."""
        self.roles.discard(role_id)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "user_id": self.user_id,
            "username": self.username,
            "email": self.email,
            "roles": list(self.roles),
            "is_active": self.is_active,
            "is_admin": self.is_admin,
            "created_at": self.created_at.isoformat(),
            "last_login": self.last_login.isoformat() if self.last_login else None,
        }


@dataclass
class AccessPolicy:
    """An access control policy."""

    policy_id: str
    name: str
    resource_type: str  # document, extraction, council, etc.
    action: str
    conditions: dict[str, Any] = field(default_factory=dict)
    allow: bool = True
    priority: int = 0
    created_at: datetime = field(default_factory=datetime.utcnow)

    def evaluate(
        self,
        user: User,
        resource: dict[str, Any],
        context: dict[str, Any],
    ) -> bool | None:
        """
        Evaluate policy for a request.

        Returns:
            True if allowed, False if denied, None if not applicable
        """
        # Check if policy applies to resource type
        if resource.get("type") != self.resource_type:
            return None

        # Evaluate conditions
        for condition_key, condition_value in self.conditions.items():
            if condition_key == "owner_only":
                if condition_value and resource.get("owner_id") != user.user_id:
                    return None
            elif condition_key == "department":
                if user.metadata.get("department") != condition_value:
                    return None

        return self.allow

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "policy_id": self.policy_id,
            "name": self.name,
            "resource_type": self.resource_type,
            "action": self.action,
            "conditions": self.conditions,
            "allow": self.allow,
            "priority": self.priority,
        }


class RBACManager:
    """
    Role-Based Access Control Manager.

    Features:
    - Role management
    - Permission checking
    - Policy evaluation
    - Access audit
    """

    # Default system roles
    SYSTEM_ROLES = {
        "admin": {
            "name": "Administrator",
            "description": "Full system access",
            "permissions": list(Permission),
        },
        "operator": {
            "name": "Operator",
            "description": "Document processing operations",
            "permissions": [
                Permission.DOCUMENT_READ,
                Permission.DOCUMENT_CREATE,
                Permission.DOCUMENT_UPDATE,
                Permission.EXTRACTION_READ,
                Permission.EXTRACTION_CREATE,
                Permission.EXTRACTION_APPROVE,
                Permission.COUNCIL_VIEW,
            ],
        },
        "viewer": {
            "name": "Viewer",
            "description": "Read-only access",
            "permissions": [
                Permission.DOCUMENT_READ,
                Permission.EXTRACTION_READ,
                Permission.COUNCIL_VIEW,
            ],
        },
        "auditor": {
            "name": "Auditor",
            "description": "Audit and compliance access",
            "permissions": [
                Permission.DOCUMENT_READ,
                Permission.EXTRACTION_READ,
                Permission.COUNCIL_VIEW,
                Permission.ADMIN_AUDIT,
            ],
        },
    }

    def __init__(self):
        """Initialize RBAC manager."""
        self._roles: dict[str, Role] = {}
        self._users: dict[str, User] = {}
        self._policies: dict[str, AccessPolicy] = {}
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize with system roles."""
        # Create system roles
        for role_id, role_def in self.SYSTEM_ROLES.items():
            role = Role(
                role_id=role_id,
                name=role_def["name"],
                description=role_def["description"],
                permissions=set(role_def["permissions"]),
                is_system=True,
            )
            self._roles[role_id] = role

        self._initialized = True
        logger.info("RBAC manager initialized", roles=len(self._roles))
        return True

    def create_role(
        self,
        name: str,
        permissions: list[Permission],
        description: str = "",
    ) -> Role:
        """Create a new role."""
        role = Role(
            role_id=str(uuid.uuid4()),
            name=name,
            description=description,
            permissions=set(permissions),
        )
        self._roles[role.role_id] = role
        logger.info("Created role", role_id=role.role_id, name=name)
        return role

    def get_role(self, role_id: str) -> Role | None:
        """Get a role by ID."""
        return self._roles.get(role_id)

    def get_role_by_name(self, name: str) -> Role | None:
        """Get a role by name."""
        for role in self._roles.values():
            if role.name == name:
                return role
        return None

    def create_user(
        self,
        username: str,
        email: str,
        roles: list[str] | None = None,
        is_admin: bool = False,
    ) -> User:
        """Create a new user."""
        user = User(
            user_id=str(uuid.uuid4()),
            username=username,
            email=email,
            roles=set(roles or []),
            is_admin=is_admin,
        )
        self._users[user.user_id] = user
        logger.info("Created user", user_id=user.user_id, username=username)
        return user

    def get_user(self, user_id: str) -> User | None:
        """Get a user by ID."""
        return self._users.get(user_id)

    def get_user_by_username(self, username: str) -> User | None:
        """Get a user by username."""
        for user in self._users.values():
            if user.username == username:
                return user
        return None

    def assign_role(self, user_id: str, role_id: str) -> bool:
        """Assign a role to a user."""
        user = self._users.get(user_id)
        role = self._roles.get(role_id)

        if not user or not role:
            return False

        user.add_role(role_id)
        logger.info(
            "Assigned role to user",
            user_id=user_id,
            role_id=role_id,
        )
        return True

    def revoke_role(self, user_id: str, role_id: str) -> bool:
        """Revoke a role from a user."""
        user = self._users.get(user_id)

        if not user:
            return False

        user.remove_role(role_id)
        logger.info(
            "Revoked role from user",
            user_id=user_id,
            role_id=role_id,
        )
        return True

    def get_user_permissions(self, user_id: str) -> set[Permission]:
        """Get all permissions for a user."""
        user = self._users.get(user_id)
        if not user:
            return set()

        # Admin has all permissions
        if user.is_admin:
            return set(Permission)

        permissions: set[Permission] = set()
        for role_id in user.roles:
            role = self._roles.get(role_id)
            if role:
                permissions.update(role.permissions)

        return permissions

    def check_permission(
        self,
        user_id: str,
        permission: Permission,
    ) -> bool:
        """Check if user has a specific permission."""
        permissions = self.get_user_permissions(user_id)
        return permission in permissions

    def check_access(
        self,
        user_id: str,
        resource: dict[str, Any],
        action: str,
        context: dict[str, Any] | None = None,
    ) -> bool:
        """
        Check if user can access a resource.

        Args:
            user_id: User ID
            resource: Resource to access
            action: Action to perform
            context: Additional context

        Returns:
            True if access allowed
        """
        user = self._users.get(user_id)
        if not user or not user.is_active:
            return False

        # Admin always has access
        if user.is_admin:
            return True

        # Evaluate policies
        ctx = context or {}
        applicable_policies = sorted(
            [
                p
                for p in self._policies.values()
                if p.resource_type == resource.get("type") and p.action == action
            ],
            key=lambda p: p.priority,
            reverse=True,
        )

        for policy in applicable_policies:
            result = policy.evaluate(user, resource, ctx)
            if result is not None:
                return result

        # Default: check permission
        permission_map = {
            "read": f"{resource.get('type', 'document')}:read",
            "create": f"{resource.get('type', 'document')}:create",
            "update": f"{resource.get('type', 'document')}:update",
            "delete": f"{resource.get('type', 'document')}:delete",
        }

        perm_str = permission_map.get(action)
        if perm_str:
            try:
                perm = Permission(perm_str)
                return self.check_permission(user_id, perm)
            except ValueError:
                pass

        return False

    def create_policy(
        self,
        name: str,
        resource_type: str,
        action: str,
        allow: bool = True,
        conditions: dict[str, Any] | None = None,
        priority: int = 0,
    ) -> AccessPolicy:
        """Create an access policy."""
        policy = AccessPolicy(
            policy_id=str(uuid.uuid4()),
            name=name,
            resource_type=resource_type,
            action=action,
            allow=allow,
            conditions=conditions or {},
            priority=priority,
        )
        self._policies[policy.policy_id] = policy
        logger.info("Created policy", policy_id=policy.policy_id, name=name)
        return policy

    def get_all_roles(self) -> list[Role]:
        """Get all roles."""
        return list(self._roles.values())

    def get_all_users(self) -> list[User]:
        """Get all users."""
        return list(self._users.values())

    def get_summary(self) -> dict[str, Any]:
        """Get RBAC summary."""
        return {
            "initialized": self._initialized,
            "role_count": len(self._roles),
            "user_count": len(self._users),
            "policy_count": len(self._policies),
            "system_roles": list(self.SYSTEM_ROLES.keys()),
        }


# Singleton instance
_rbac_manager: RBACManager | None = None


def get_rbac_manager() -> RBACManager:
    """Get or create RBAC manager singleton."""
    global _rbac_manager
    if _rbac_manager is None:
        _rbac_manager = RBACManager()
        _rbac_manager.initialize()
    return _rbac_manager
