"""
PII Detection Service.

Task 4.1.1: Implement PII detection and handling.
"""

import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class PIIType(StrEnum):
    """Types of PII."""

    SSN = "ssn"
    CREDIT_CARD = "credit_card"
    EMAIL = "email"
    PHONE = "phone"
    ADDRESS = "address"
    NAME = "name"
    DATE_OF_BIRTH = "date_of_birth"
    PASSPORT = "passport"
    DRIVER_LICENSE = "driver_license"
    BANK_ACCOUNT = "bank_account"
    IP_ADDRESS = "ip_address"
    MEDICAL_ID = "medical_id"


class PIIMaskingStrategy(StrEnum):
    """Masking strategies for PII."""

    REDACT = "redact"  # Replace with [REDACTED]
    MASK = "mask"  # Replace with ***
    HASH = "hash"  # Replace with hash
    TOKENIZE = "tokenize"  # Replace with token
    PARTIAL = "partial"  # Show partial (e.g., ***-**-1234)


@dataclass
class PIIEntity:
    """A detected PII entity."""

    entity_id: str
    pii_type: PIIType
    value: str
    masked_value: str
    start_pos: int
    end_pos: int
    confidence: float
    context: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "entity_id": self.entity_id,
            "pii_type": self.pii_type.value,
            "value": self.value,
            "masked_value": self.masked_value,
            "start_pos": self.start_pos,
            "end_pos": self.end_pos,
            "confidence": self.confidence,
            "context": self.context,
            "metadata": self.metadata,
        }


@dataclass
class PIIDetectionResult:
    """Result of PII detection."""

    document_id: str
    original_text: str
    masked_text: str
    entities: list[PIIEntity] = field(default_factory=list)
    detection_time_ms: float = 0.0
    pii_found: bool = False

    @property
    def pii_count(self) -> int:
        """Count of PII entities found."""
        return len(self.entities)

    def get_entities_by_type(self, pii_type: PIIType) -> list[PIIEntity]:
        """Get entities of a specific type."""
        return [e for e in self.entities if e.pii_type == pii_type]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "document_id": self.document_id,
            "masked_text": self.masked_text,
            "pii_found": self.pii_found,
            "pii_count": self.pii_count,
            "entities": [e.to_dict() for e in self.entities],
            "detection_time_ms": self.detection_time_ms,
        }


class PIIDetector:
    """
    PII Detection Service.

    Features:
    - Pattern-based detection
    - Multiple PII types
    - Configurable masking
    - Confidence scoring
    """

    # Regex patterns for PII detection
    PATTERNS = {
        PIIType.SSN: r"\b\d{3}-\d{2}-\d{4}\b",
        PIIType.CREDIT_CARD: r"\b(?:\d{4}[-\s]?){3}\d{4}\b",
        PIIType.EMAIL: r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
        PIIType.PHONE: r"\b(?:\+1[-\s]?)?\(?\d{3}\)?[-\s]?\d{3}[-\s]?\d{4}\b",
        PIIType.IP_ADDRESS: r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
        PIIType.DATE_OF_BIRTH: r"\b(?:0[1-9]|1[0-2])[/-](?:0[1-9]|[12]\d|3[01])[/-](?:19|20)\d{2}\b",
        PIIType.PASSPORT: r"\b[A-Z]{1,2}\d{6,9}\b",
        PIIType.BANK_ACCOUNT: r"\b\d{8,17}\b",
    }

    CONFIDENCE_SCORES = {
        PIIType.SSN: 0.95,
        PIIType.CREDIT_CARD: 0.90,
        PIIType.EMAIL: 0.98,
        PIIType.PHONE: 0.85,
        PIIType.IP_ADDRESS: 0.80,
        PIIType.DATE_OF_BIRTH: 0.75,
        PIIType.PASSPORT: 0.70,
        PIIType.BANK_ACCOUNT: 0.65,
    }

    def __init__(
        self,
        default_strategy: PIIMaskingStrategy = PIIMaskingStrategy.MASK,
        enabled_types: list[PIIType] | None = None,
    ):
        """
        Initialize PII detector.

        Args:
            default_strategy: Default masking strategy
            enabled_types: PII types to detect (None = all)
        """
        self.default_strategy = default_strategy
        self.enabled_types = enabled_types or list(PIIType)
        self._compiled_patterns: dict[PIIType, re.Pattern] = {}
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize the detector."""
        # Compile regex patterns
        for pii_type, pattern in self.PATTERNS.items():
            if pii_type in self.enabled_types:
                self._compiled_patterns[pii_type] = re.compile(pattern, re.IGNORECASE)

        self._initialized = True
        logger.info(
            "PII detector initialized",
            enabled_types=len(self.enabled_types),
        )
        return True

    def detect(
        self,
        text: str,
        document_id: str | None = None,
        masking_strategy: PIIMaskingStrategy | None = None,
    ) -> PIIDetectionResult:
        """
        Detect PII in text.

        Args:
            text: Text to scan
            document_id: Optional document ID
            masking_strategy: Override masking strategy

        Returns:
            PII detection result
        """
        if not self._initialized:
            self.initialize()

        start_time = datetime.utcnow()
        doc_id = document_id or str(uuid.uuid4())
        strategy = masking_strategy or self.default_strategy

        entities: list[PIIEntity] = []
        masked_text = text

        # Detect each PII type
        for pii_type, pattern in self._compiled_patterns.items():
            for match in pattern.finditer(text):
                value = match.group()
                masked_value = self._mask_value(value, pii_type, strategy)

                entity = PIIEntity(
                    entity_id=str(uuid.uuid4()),
                    pii_type=pii_type,
                    value=value,
                    masked_value=masked_value,
                    start_pos=match.start(),
                    end_pos=match.end(),
                    confidence=self.CONFIDENCE_SCORES.get(pii_type, 0.5),
                    context=self._get_context(text, match.start(), match.end()),
                )
                entities.append(entity)

        # Apply masking to text
        if entities:
            masked_text = self._apply_masking(text, entities)

        end_time = datetime.utcnow()
        detection_time = (end_time - start_time).total_seconds() * 1000

        result = PIIDetectionResult(
            document_id=doc_id,
            original_text=text,
            masked_text=masked_text,
            entities=entities,
            detection_time_ms=detection_time,
            pii_found=len(entities) > 0,
        )

        if entities:
            logger.info(
                "PII detected",
                document_id=doc_id,
                count=len(entities),
            )

        return result

    def _mask_value(
        self,
        value: str,
        pii_type: PIIType,
        strategy: PIIMaskingStrategy,
    ) -> str:
        """Apply masking to a value."""
        if strategy == PIIMaskingStrategy.REDACT:
            return "[REDACTED]"
        elif strategy == PIIMaskingStrategy.MASK:
            return "*" * len(value)
        elif strategy == PIIMaskingStrategy.HASH:
            import hashlib

            return hashlib.sha256(value.encode()).hexdigest()[:16]
        elif strategy == PIIMaskingStrategy.TOKENIZE:
            return f"[TOKEN_{pii_type.value.upper()}]"
        elif strategy == PIIMaskingStrategy.PARTIAL:
            if pii_type == PIIType.SSN:
                return f"***-**-{value[-4:]}"
            elif pii_type == PIIType.CREDIT_CARD:
                return f"****-****-****-{value[-4:]}"
            elif pii_type == PIIType.EMAIL:
                parts = value.split("@")
                return f"{parts[0][0]}***@{parts[1]}" if len(parts) == 2 else "***"
            elif pii_type == PIIType.PHONE:
                return f"***-***-{value[-4:]}"
            else:
                return f"***{value[-4:]}" if len(value) > 4 else "***"
        return value

    def _get_context(
        self,
        text: str,
        start: int,
        end: int,
        context_chars: int = 50,
    ) -> str:
        """Get context around a match."""
        ctx_start = max(0, start - context_chars)
        ctx_end = min(len(text), end + context_chars)
        return text[ctx_start:ctx_end]

    def _apply_masking(
        self,
        text: str,
        entities: list[PIIEntity],
    ) -> str:
        """Apply masking to text for all entities."""
        # Sort by position (reverse) to maintain positions
        sorted_entities = sorted(entities, key=lambda e: e.start_pos, reverse=True)

        result = text
        for entity in sorted_entities:
            result = result[: entity.start_pos] + entity.masked_value + result[entity.end_pos :]
        return result

    def scan_document(
        self,
        fields: dict[str, str],
        document_id: str,
    ) -> dict[str, PIIDetectionResult]:
        """
        Scan all fields in a document.

        Args:
            fields: Field name to value mapping
            document_id: Document ID

        Returns:
            Field name to detection result mapping
        """
        results = {}
        for field_name, field_value in fields.items():
            if isinstance(field_value, str):
                results[field_name] = self.detect(
                    field_value,
                    document_id=f"{document_id}:{field_name}",
                )
        return results

    def get_summary(self) -> dict[str, Any]:
        """Get detector summary."""
        return {
            "initialized": self._initialized,
            "default_strategy": self.default_strategy.value,
            "enabled_types": [t.value for t in self.enabled_types],
            "pattern_count": len(self._compiled_patterns),
        }


# Singleton instance
_pii_detector: PIIDetector | None = None


def get_pii_detector() -> PIIDetector:
    """Get or create PII detector singleton."""
    global _pii_detector
    if _pii_detector is None:
        _pii_detector = PIIDetector()
        _pii_detector.initialize()
    return _pii_detector
