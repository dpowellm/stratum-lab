"""
Audit Logging Service.

Task 4.1.4: Implement comprehensive audit logging.
"""

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class AuditEventType(StrEnum):
    """Types of audit events."""

    # Authentication events
    AUTH_LOGIN = "auth.login"
    AUTH_LOGOUT = "auth.logout"
    AUTH_FAILED = "auth.failed"
    AUTH_TOKEN_REFRESH = "auth.token_refresh"  # noqa: S105

    # Document events
    DOC_UPLOAD = "document.upload"
    DOC_VIEW = "document.view"
    DOC_DOWNLOAD = "document.download"
    DOC_DELETE = "document.delete"
    DOC_SHARE = "document.share"

    # Extraction events
    EXTRACTION_START = "extraction.start"
    EXTRACTION_COMPLETE = "extraction.complete"
    EXTRACTION_FAILED = "extraction.failed"
    EXTRACTION_APPROVED = "extraction.approved"
    EXTRACTION_REJECTED = "extraction.rejected"

    # Council events
    COUNCIL_VOTE = "council.vote"
    COUNCIL_CONSENSUS = "council.consensus"
    COUNCIL_OVERRIDE = "council.override"

    # Security events
    SECURITY_PII_DETECTED = "security.pii_detected"
    SECURITY_ACCESS_DENIED = "security.access_denied"
    SECURITY_POLICY_VIOLATION = "security.policy_violation"
    SECURITY_KEY_ROTATION = "security.key_rotation"

    # Admin events
    ADMIN_USER_CREATE = "admin.user_create"
    ADMIN_USER_UPDATE = "admin.user_update"
    ADMIN_USER_DELETE = "admin.user_delete"
    ADMIN_ROLE_ASSIGN = "admin.role_assign"
    ADMIN_SETTINGS_CHANGE = "admin.settings_change"

    # System events
    SYSTEM_START = "system.start"
    SYSTEM_STOP = "system.stop"
    SYSTEM_ERROR = "system.error"
    SYSTEM_MAINTENANCE = "system.maintenance"


class AuditSeverity(StrEnum):
    """Severity levels for audit events."""

    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class AuditEvent:
    """An audit log event."""

    event_id: str
    event_type: AuditEventType
    timestamp: datetime
    user_id: str | None = None
    username: str | None = None
    ip_address: str | None = None
    resource_type: str | None = None
    resource_id: str | None = None
    action: str = ""
    outcome: str = "success"  # success, failure, error
    severity: AuditSeverity = AuditSeverity.INFO
    details: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "user_id": self.user_id,
            "username": self.username,
            "ip_address": self.ip_address,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "action": self.action,
            "outcome": self.outcome,
            "severity": self.severity.value,
            "details": self.details,
            "metadata": self.metadata,
        }

    def to_json(self) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict())


@dataclass
class AuditTrail:
    """A collection of audit events for a resource."""

    resource_type: str
    resource_id: str
    events: list[AuditEvent] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)

    def add_event(self, event: AuditEvent) -> None:
        """Add an event to the trail."""
        self.events.append(event)

    def get_events_by_type(
        self,
        event_type: AuditEventType,
    ) -> list[AuditEvent]:
        """Get events of a specific type."""
        return [e for e in self.events if e.event_type == event_type]

    def get_events_by_user(self, user_id: str) -> list[AuditEvent]:
        """Get events by user."""
        return [e for e in self.events if e.user_id == user_id]

    def get_events_in_range(
        self,
        start: datetime,
        end: datetime,
    ) -> list[AuditEvent]:
        """Get events in a time range."""
        return [e for e in self.events if start <= e.timestamp <= end]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "event_count": len(self.events),
            "created_at": self.created_at.isoformat(),
            "events": [e.to_dict() for e in self.events],
        }


class AuditLogger:
    """
    Audit Logging Service.

    Features:
    - Event logging
    - Audit trails
    - Search and filtering
    - Retention management
    - Export capabilities
    """

    def __init__(
        self,
        retention_days: int = 90,
        max_events: int = 1000000,
    ):
        """
        Initialize audit logger.

        Args:
            retention_days: Days to retain events
            max_events: Maximum events to store
        """
        self.retention_days = retention_days
        self.max_events = max_events
        self._events: list[AuditEvent] = []
        self._trails: dict[str, AuditTrail] = {}
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize audit logger."""
        # Log system start
        self.log_event(
            AuditEventType.SYSTEM_START,
            action="Audit logger initialized",
            severity=AuditSeverity.INFO,
        )

        self._initialized = True
        logger.info("Audit logger initialized")
        return True

    def log_event(
        self,
        event_type: AuditEventType,
        user_id: str | None = None,
        username: str | None = None,
        ip_address: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        action: str = "",
        outcome: str = "success",
        severity: AuditSeverity = AuditSeverity.INFO,
        details: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """
        Log an audit event.

        Args:
            event_type: Type of event
            user_id: User ID
            username: Username
            ip_address: Client IP
            resource_type: Type of resource
            resource_id: Resource ID
            action: Action description
            outcome: Event outcome
            severity: Severity level
            details: Additional details
            metadata: Metadata

        Returns:
            Audit event
        """
        event = AuditEvent(
            event_id=str(uuid.uuid4()),
            event_type=event_type,
            timestamp=datetime.utcnow(),
            user_id=user_id,
            username=username,
            ip_address=ip_address,
            resource_type=resource_type,
            resource_id=resource_id,
            action=action,
            outcome=outcome,
            severity=severity,
            details=details or {},
            metadata=metadata or {},
        )

        self._events.append(event)

        # Add to trail if resource specified
        if resource_type and resource_id:
            trail_key = f"{resource_type}:{resource_id}"
            if trail_key not in self._trails:
                self._trails[trail_key] = AuditTrail(
                    resource_type=resource_type,
                    resource_id=resource_id,
                )
            self._trails[trail_key].add_event(event)

        # Enforce max events
        if len(self._events) > self.max_events:
            self._events = self._events[-self.max_events :]

        # Log to standard logger
        logger.info(
            "Audit event",
            event_type=event_type.value,
            user_id=user_id,
            action=action,
            outcome=outcome,
        )

        return event

    def log_auth_event(
        self,
        event_type: AuditEventType,
        user_id: str,
        username: str,
        ip_address: str,
        success: bool,
        details: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log an authentication event."""
        return self.log_event(
            event_type=event_type,
            user_id=user_id,
            username=username,
            ip_address=ip_address,
            action=f"Authentication: {event_type.value}",
            outcome="success" if success else "failure",
            severity=AuditSeverity.INFO if success else AuditSeverity.WARNING,
            details=details,
        )

    def log_document_event(
        self,
        event_type: AuditEventType,
        document_id: str,
        user_id: str,
        action: str,
        details: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log a document event."""
        return self.log_event(
            event_type=event_type,
            user_id=user_id,
            resource_type="document",
            resource_id=document_id,
            action=action,
            details=details,
        )

    def log_extraction_event(
        self,
        event_type: AuditEventType,
        extraction_id: str,
        document_id: str,
        user_id: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log an extraction event."""
        return self.log_event(
            event_type=event_type,
            user_id=user_id,
            resource_type="extraction",
            resource_id=extraction_id,
            action=f"Extraction: {event_type.value}",
            details={
                "document_id": document_id,
                **(details or {}),
            },
        )

    def log_security_event(
        self,
        event_type: AuditEventType,
        user_id: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log a security event."""
        return self.log_event(
            event_type=event_type,
            user_id=user_id,
            resource_type=resource_type,
            resource_id=resource_id,
            action=f"Security: {event_type.value}",
            severity=AuditSeverity.WARNING,
            details=details,
        )

    def get_events(
        self,
        event_type: AuditEventType | None = None,
        user_id: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[AuditEvent]:
        """
        Search and filter audit events.

        Args:
            event_type: Filter by event type
            user_id: Filter by user
            resource_type: Filter by resource type
            resource_id: Filter by resource ID
            start_time: Start of time range
            end_time: End of time range
            limit: Maximum events to return
            offset: Offset for pagination

        Returns:
            Filtered events
        """
        events = self._events

        if event_type:
            events = [e for e in events if e.event_type == event_type]

        if user_id:
            events = [e for e in events if e.user_id == user_id]

        if resource_type:
            events = [e for e in events if e.resource_type == resource_type]

        if resource_id:
            events = [e for e in events if e.resource_id == resource_id]

        if start_time:
            events = [e for e in events if e.timestamp >= start_time]

        if end_time:
            events = [e for e in events if e.timestamp <= end_time]

        # Sort by timestamp descending
        events = sorted(events, key=lambda e: e.timestamp, reverse=True)

        return events[offset : offset + limit]

    def get_trail(
        self,
        resource_type: str,
        resource_id: str,
    ) -> AuditTrail | None:
        """Get audit trail for a resource."""
        trail_key = f"{resource_type}:{resource_id}"
        return self._trails.get(trail_key)

    def get_user_activity(
        self,
        user_id: str,
        days: int = 30,
    ) -> list[AuditEvent]:
        """Get user activity for the last N days."""
        start_time = datetime.utcnow() - timedelta(days=days)
        return self.get_events(
            user_id=user_id,
            start_time=start_time,
            limit=1000,
        )

    def get_security_events(
        self,
        days: int = 7,
    ) -> list[AuditEvent]:
        """Get security events for the last N days."""
        start_time = datetime.utcnow() - timedelta(days=days)
        security_types = [
            AuditEventType.SECURITY_PII_DETECTED,
            AuditEventType.SECURITY_ACCESS_DENIED,
            AuditEventType.SECURITY_POLICY_VIOLATION,
            AuditEventType.SECURITY_KEY_ROTATION,
            AuditEventType.AUTH_FAILED,
        ]

        events = []
        for event_type in security_types:
            events.extend(
                self.get_events(
                    event_type=event_type,
                    start_time=start_time,
                )
            )

        return sorted(events, key=lambda e: e.timestamp, reverse=True)

    def cleanup_old_events(self) -> int:
        """Remove events older than retention period."""
        cutoff = datetime.utcnow() - timedelta(days=self.retention_days)
        original_count = len(self._events)

        self._events = [e for e in self._events if e.timestamp >= cutoff]

        removed = original_count - len(self._events)
        if removed > 0:
            logger.info(
                "Cleaned up old audit events",
                removed=removed,
                remaining=len(self._events),
            )

        return removed

    def export_events(
        self,
        format: str = "json",
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> str:
        """
        Export audit events.

        Args:
            format: Export format (json, csv)
            start_time: Start of time range
            end_time: End of time range

        Returns:
            Exported data
        """
        events = self.get_events(
            start_time=start_time,
            end_time=end_time,
            limit=100000,
        )

        if format == "json":
            return json.dumps([e.to_dict() for e in events], indent=2)
        elif format == "csv":
            headers = [
                "event_id",
                "event_type",
                "timestamp",
                "user_id",
                "username",
                "resource_type",
                "resource_id",
                "action",
                "outcome",
            ]
            lines = [",".join(headers)]
            for event in events:
                row = [
                    event.event_id,
                    event.event_type.value,
                    event.timestamp.isoformat(),
                    event.user_id or "",
                    event.username or "",
                    event.resource_type or "",
                    event.resource_id or "",
                    event.action,
                    event.outcome,
                ]
                lines.append(",".join(f'"{v}"' for v in row))
            return "\n".join(lines)

        return ""

    def get_summary(self) -> dict[str, Any]:
        """Get audit logger summary."""
        return {
            "initialized": self._initialized,
            "total_events": len(self._events),
            "trail_count": len(self._trails),
            "retention_days": self.retention_days,
            "max_events": self.max_events,
        }


# Singleton instance
_audit_logger: AuditLogger | None = None


def get_audit_logger() -> AuditLogger:
    """Get or create audit logger singleton."""
    global _audit_logger
    if _audit_logger is None:
        _audit_logger = AuditLogger()
        _audit_logger.initialize()
    return _audit_logger
