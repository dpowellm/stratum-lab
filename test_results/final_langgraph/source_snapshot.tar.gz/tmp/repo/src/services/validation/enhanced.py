"""
Enhanced Validation Rules.

Task 2.1.3: Expands validation with industry-specific rules and
cross-document validation.
"""

import re
import statistics
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class ValidationTier(Enum):
    """Validation tier levels based on confidence."""

    MINIMAL = 1  # High confidence - basic checks only
    STANDARD = 2  # Medium confidence - standard validation
    THOROUGH = 3  # Low confidence - comprehensive validation


@dataclass
class ValidationError:
    """Validation error details."""

    field_name: str
    message: str
    rule_type: str
    severity: str = "error"  # "error", "warning", "info"
    suggested_value: Any = None


@dataclass
class ValidationResult:
    """Result of validation."""

    is_valid: bool
    errors: list[ValidationError] = field(default_factory=list)
    warnings: list[ValidationError] = field(default_factory=list)
    rules_applied: list[str] = field(default_factory=list)
    validation_tier: ValidationTier = ValidationTier.STANDARD


class ValidationRule:
    """Base class for validation rules."""

    def __init__(self, name: str, rule_type: str):
        self.name = name
        self.rule_type = rule_type

    def validate(self, data: dict[str, Any]) -> list[ValidationError]:
        """Validate data and return errors."""
        raise NotImplementedError


class IndustryRules:
    """Industry-specific validation rules."""

    @staticmethod
    def get_invoice_rules() -> list[Callable]:
        """Get invoice-specific validation rules."""
        return [
            IndustryRules._validate_invoice_totals,
            IndustryRules._validate_invoice_dates,
            IndustryRules._validate_invoice_number,
        ]

    @staticmethod
    def get_contract_rules() -> list[Callable]:
        """Get contract-specific validation rules."""
        return [
            IndustryRules._validate_contract_parties,
            IndustryRules._validate_contract_dates,
            IndustryRules._validate_contract_value,
        ]

    @staticmethod
    def get_receipt_rules() -> list[Callable]:
        """Get receipt-specific validation rules."""
        return [
            IndustryRules._validate_receipt_totals,
            IndustryRules._validate_receipt_items,
        ]

    @staticmethod
    def get_form_rules() -> list[Callable]:
        """Get form-specific validation rules."""
        return [
            IndustryRules._validate_form_required_fields,
            IndustryRules._validate_form_field_formats,
        ]

    @staticmethod
    def _validate_invoice_totals(fields: dict[str, Any]) -> list[ValidationError]:
        """Validate that invoice totals add up correctly."""
        errors = []

        subtotal = fields.get("subtotal")
        tax = fields.get("tax")
        total = fields.get("total")

        if subtotal is not None and tax is not None and total is not None:
            try:
                expected = float(subtotal) + float(tax)
                actual = float(total)
                if abs(expected - actual) > 0.01:
                    errors.append(
                        ValidationError(
                            field_name="total",
                            message=f"Total ({actual}) does not match subtotal + tax ({expected})",
                            rule_type="invoice_math",
                            suggested_value=expected,
                        )
                    )
            except (ValueError, TypeError):
                pass

        return errors

    @staticmethod
    def _validate_invoice_dates(fields: dict[str, Any]) -> list[ValidationError]:
        """Validate invoice date relationships."""
        errors = []

        invoice_date = fields.get("invoice_date")
        due_date = fields.get("due_date")

        if invoice_date and due_date and str(due_date) < str(invoice_date):
            errors.append(
                ValidationError(
                    field_name="due_date",
                    message="Due date is before invoice date",
                    rule_type="invoice_dates",
                )
            )

        return errors

    @staticmethod
    def _validate_invoice_number(fields: dict[str, Any]) -> list[ValidationError]:
        """Validate invoice number format."""
        errors = []

        invoice_number = fields.get("invoice_number")
        if not invoice_number:
            errors.append(
                ValidationError(
                    field_name="invoice_number",
                    message="Invoice number is required",
                    rule_type="invoice_required",
                )
            )

        return errors

    @staticmethod
    def _validate_contract_parties(fields: dict[str, Any]) -> list[ValidationError]:
        """Validate contract parties are specified."""
        errors = []

        party_a = fields.get("party_a") or fields.get("party_a_name")
        party_b = fields.get("party_b") or fields.get("party_b_name")

        if not party_a:
            errors.append(
                ValidationError(
                    field_name="party_a",
                    message="Party A is required in contracts",
                    rule_type="contract_required",
                )
            )

        if not party_b:
            errors.append(
                ValidationError(
                    field_name="party_b",
                    message="Party B is required in contracts",
                    rule_type="contract_required",
                )
            )

        return errors

    @staticmethod
    def _validate_contract_dates(fields: dict[str, Any]) -> list[ValidationError]:
        """Validate contract date sequence."""
        errors = []

        effective = fields.get("effective_date")
        termination = fields.get("termination_date")

        if effective and termination and str(termination) < str(effective):
            errors.append(
                ValidationError(
                    field_name="termination_date",
                    message="Termination date is before effective date",
                    rule_type="contract_dates",
                )
            )

        return errors

    @staticmethod
    def _validate_contract_value(fields: dict[str, Any]) -> list[ValidationError]:
        """Validate contract value if present."""
        errors = []

        value = fields.get("contract_value")
        if value is not None:
            try:
                v = float(value)
                if v < 0:
                    errors.append(
                        ValidationError(
                            field_name="contract_value",
                            message="Contract value cannot be negative",
                            rule_type="contract_value",
                        )
                    )
            except (ValueError, TypeError):
                errors.append(
                    ValidationError(
                        field_name="contract_value",
                        message="Invalid contract value format",
                        rule_type="contract_value",
                    )
                )

        return errors

    @staticmethod
    def _validate_receipt_totals(fields: dict[str, Any]) -> list[ValidationError]:
        """Validate receipt totals."""
        return IndustryRules._validate_invoice_totals(fields)

    @staticmethod
    def _validate_receipt_items(fields: dict[str, Any]) -> list[ValidationError]:
        """Validate receipt line items if present."""
        errors = []

        items = fields.get("items", [])
        subtotal = fields.get("subtotal")

        if items and subtotal:
            try:
                items_total = sum(float(item.get("price", 0)) for item in items)
                if abs(items_total - float(subtotal)) > 0.01:
                    errors.append(
                        ValidationError(
                            field_name="subtotal",
                            message=f"Subtotal ({subtotal}) doesn't match items total ({items_total})",
                            rule_type="receipt_items",
                        )
                    )
            except (ValueError, TypeError):
                pass

        return errors

    @staticmethod
    def _validate_form_required_fields(fields: dict[str, Any]) -> list[ValidationError]:
        """Validate form has required fields filled."""
        errors = []

        # Common required form fields
        required = ["full_name"]
        for field_name in required:
            if field_name in fields and not fields[field_name]:
                errors.append(
                    ValidationError(
                        field_name=field_name,
                        message=f"Required field '{field_name}' is empty",
                        rule_type="form_required",
                    )
                )

        return errors

    @staticmethod
    def _validate_form_field_formats(fields: dict[str, Any]) -> list[ValidationError]:
        """Validate form field formats."""
        errors = []

        # Email validation
        email = fields.get("email")
        if email:
            if not re.match(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", str(email)):
                errors.append(
                    ValidationError(
                        field_name="email",
                        message="Invalid email format",
                        rule_type="form_format",
                    )
                )

        # Phone validation
        phone = fields.get("phone")
        if phone:
            digits = re.sub(r"[\s\-\(\)\+\.]", "", str(phone))
            if not (digits.isdigit() and 7 <= len(digits) <= 15):
                errors.append(
                    ValidationError(
                        field_name="phone",
                        message="Invalid phone number format",
                        rule_type="form_format",
                    )
                )

        return errors


class AnomalyDetector:
    """Detects anomalies in extracted values."""

    def __init__(
        self,
        min_samples: int = 10,
        z_score_threshold: float = 3.0,
    ):
        """
        Initialize anomaly detector.

        Args:
            min_samples: Minimum samples before detecting anomalies
            z_score_threshold: Z-score threshold for numeric anomalies
        """
        self.min_samples = min_samples
        self.z_score_threshold = z_score_threshold

        # Value history by doc_type and field
        self._numeric_history: dict[str, dict[str, list[float]]] = defaultdict(
            lambda: defaultdict(list)
        )
        self._format_history: dict[str, dict[str, list[str]]] = defaultdict(
            lambda: defaultdict(list)
        )

    def record_value(
        self,
        doc_type: str,
        field_name: str,
        value: Any,
    ) -> None:
        """Record a value for baseline."""

        try:
            # Try numeric
            num_value = float(value)
            self._numeric_history[doc_type][field_name].append(num_value)
        except (ValueError, TypeError):
            # Store as string format
            self._format_history[doc_type][field_name].append(str(value))

    def is_anomaly(
        self,
        doc_type: str,
        field_name: str,
        value: Any,
    ) -> bool:
        """Check if a value is anomalous."""
        # Check numeric anomaly
        try:
            num_value = float(value)
            return self._is_numeric_anomaly(doc_type, field_name, num_value)
        except (ValueError, TypeError):
            return self._is_format_anomaly(doc_type, field_name, str(value))

    def _is_numeric_anomaly(
        self,
        doc_type: str,
        field_name: str,
        value: float,
    ) -> bool:
        """Check if numeric value is anomalous."""
        history = self._numeric_history[doc_type][field_name]

        if len(history) < self.min_samples:
            return False

        mean = statistics.mean(history)
        stdev = statistics.stdev(history) if len(history) > 1 else 0

        if stdev == 0:
            return abs(value - mean) > mean * 0.5  # 50% deviation

        z_score = abs(value - mean) / stdev
        return z_score > self.z_score_threshold

    def _is_format_anomaly(
        self,
        doc_type: str,
        field_name: str,
        value: str,
    ) -> bool:
        """Check if format is anomalous."""
        history = self._format_history[doc_type][field_name]

        if len(history) < self.min_samples:
            return False

        # Extract format pattern (simplified)
        def get_pattern(s: str) -> str:
            return re.sub(r"\d", "D", re.sub(r"[A-Za-z]", "A", s))

        value_pattern = get_pattern(value)
        patterns = [get_pattern(h) for h in history]

        # Check if pattern matches any in history
        pattern_counts = defaultdict(int)
        for p in patterns:
            pattern_counts[p] += 1

        if not pattern_counts:
            return False

        # Most common pattern
        most_common = max(pattern_counts, key=pattern_counts.get)
        common_ratio = pattern_counts[most_common] / len(patterns)

        # If most common pattern is dominant and value doesn't match
        return bool(common_ratio > 0.7 and value_pattern != most_common)


class EnhancedValidator:
    """
    Enhanced Validation System.

    Features:
    - Industry-specific rules (invoices, contracts, forms)
    - Cross-reference validation
    - Anomaly detection
    - Confidence-based validation tiers
    """

    def __init__(self):
        """Initialize enhanced validator."""
        self.anomaly_detector = AnomalyDetector()

        # Rule mappings by document type
        self._rules_by_type: dict[str, list[Callable]] = {
            "invoice": IndustryRules.get_invoice_rules(),
            "contract": IndustryRules.get_contract_rules(),
            "receipt": IndustryRules.get_receipt_rules(),
            "form": IndustryRules.get_form_rules(),
        }

    def validate(self, data: dict[str, Any]) -> ValidationResult:
        """
        Validate extracted data.

        Args:
            data: Extracted data with document_type and fields

        Returns:
            ValidationResult with errors and warnings
        """
        doc_type = data.get("document_type", "unknown")
        fields = data.get("fields", {})
        confidence = data.get("confidence", 0.8)
        cross_refs = data.get("cross_references", {})

        errors: list[ValidationError] = []
        warnings: list[ValidationError] = []
        rules_applied: list[str] = []

        # Determine validation tier
        tier = self._get_validation_tier(confidence)

        # Apply industry-specific rules
        industry_rules = self._rules_by_type.get(doc_type, [])
        for rule in industry_rules:
            rule_errors = rule(fields)
            errors.extend(rule_errors)
            if True:  # Track all applied rules
                rules_applied.append(doc_type)

        # Cross-reference validation if provided
        if cross_refs and tier.value >= ValidationTier.STANDARD.value:
            cross_errors = self._validate_cross_references(fields, cross_refs)
            errors.extend(cross_errors)
            if cross_errors:
                rules_applied.append("cross_reference")

        # Anomaly detection for thorough validation
        if tier == ValidationTier.THOROUGH:
            anomaly_warnings = self._check_anomalies(doc_type, fields)
            warnings.extend(anomaly_warnings)
            if anomaly_warnings:
                rules_applied.append("anomaly_detection")

        # Remove duplicates from rules_applied
        rules_applied = list(set(rules_applied))

        is_valid = len(errors) == 0

        logger.debug(
            "Validation complete",
            doc_type=doc_type,
            is_valid=is_valid,
            error_count=len(errors),
            warning_count=len(warnings),
            tier=tier.name,
        )

        return ValidationResult(
            is_valid=is_valid,
            errors=errors,
            warnings=warnings,
            rules_applied=rules_applied,
            validation_tier=tier,
        )

    def _get_validation_tier(self, confidence: float) -> ValidationTier:
        """Determine validation tier based on confidence."""
        if confidence >= 0.95:
            return ValidationTier.MINIMAL
        elif confidence >= 0.75:
            return ValidationTier.STANDARD
        else:
            return ValidationTier.THOROUGH

    def _validate_cross_references(
        self,
        fields: dict[str, Any],
        cross_refs: dict[str, dict],
    ) -> list[ValidationError]:
        """Validate cross-references between documents."""
        errors = []

        # Example: Check if PO number references match
        po_number = fields.get("po_number")
        if po_number and po_number in cross_refs:
            ref_data = cross_refs[po_number]

            # Check total matches
            doc_total = fields.get("total")
            ref_total = ref_data.get("total")

            if doc_total and ref_total:
                try:
                    if abs(float(doc_total) - float(ref_total)) > 0.01:
                        errors.append(
                            ValidationError(
                                field_name="total",
                                message="Total doesn't match referenced PO total",
                                rule_type="cross_reference",
                            )
                        )
                except (ValueError, TypeError):
                    pass

        return errors

    def _check_anomalies(
        self,
        doc_type: str,
        fields: dict[str, Any],
    ) -> list[ValidationError]:
        """Check for anomalous values."""
        warnings = []

        for field_name, value in fields.items():
            if value is not None:
                if self.anomaly_detector.is_anomaly(doc_type, field_name, value):
                    warnings.append(
                        ValidationError(
                            field_name=field_name,
                            message="Value appears unusual compared to historical data",
                            rule_type="anomaly",
                            severity="warning",
                        )
                    )

        return warnings

    def add_rule(
        self,
        doc_type: str,
        rule: Callable[[dict[str, Any]], list[ValidationError]],
    ) -> None:
        """Add a custom validation rule."""
        if doc_type not in self._rules_by_type:
            self._rules_by_type[doc_type] = []
        self._rules_by_type[doc_type].append(rule)


# Singleton instance
_validator: EnhancedValidator | None = None


def get_enhanced_validator() -> EnhancedValidator:
    """Get or create the enhanced validator singleton."""
    global _validator
    if _validator is None:
        _validator = EnhancedValidator()
    return _validator
