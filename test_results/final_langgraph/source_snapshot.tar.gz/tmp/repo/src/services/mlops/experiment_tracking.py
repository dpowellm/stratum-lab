"""
MLflow Experiment Tracking.

Task 3.4.1: Setup MLflow experiment tracking for council evaluation.
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class RunStatus(StrEnum):
    """Status of an experiment run."""

    RUNNING = "RUNNING"
    SCHEDULED = "SCHEDULED"
    FINISHED = "FINISHED"
    FAILED = "FAILED"
    KILLED = "KILLED"


@dataclass
class Metric:
    """A metric logged during a run."""

    key: str
    value: float
    timestamp: datetime = field(default_factory=datetime.utcnow)
    step: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "key": self.key,
            "value": self.value,
            "timestamp": self.timestamp.isoformat(),
            "step": self.step,
        }


@dataclass
class Parameter:
    """A parameter logged during a run."""

    key: str
    value: str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "key": self.key,
            "value": self.value,
        }


@dataclass
class Artifact:
    """An artifact logged during a run."""

    name: str
    path: str
    artifact_type: str
    size_bytes: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "path": self.path,
            "type": self.artifact_type,
            "size_bytes": self.size_bytes,
            "metadata": self.metadata,
        }


@dataclass
class Run:
    """An experiment run."""

    run_id: str
    experiment_id: str
    status: RunStatus = RunStatus.RUNNING
    start_time: datetime = field(default_factory=datetime.utcnow)
    end_time: datetime | None = None
    metrics: list[Metric] = field(default_factory=list)
    parameters: list[Parameter] = field(default_factory=list)
    artifacts: list[Artifact] = field(default_factory=list)
    tags: dict[str, str] = field(default_factory=dict)

    def log_metric(
        self,
        key: str,
        value: float,
        step: int = 0,
    ) -> Metric:
        """Log a metric."""
        metric = Metric(key=key, value=value, step=step)
        self.metrics.append(metric)
        return metric

    def log_parameter(self, key: str, value: str) -> Parameter:
        """Log a parameter."""
        param = Parameter(key=key, value=value)
        self.parameters.append(param)
        return param

    def log_artifact(
        self,
        name: str,
        path: str,
        artifact_type: str = "file",
    ) -> Artifact:
        """Log an artifact."""
        artifact = Artifact(name=name, path=path, artifact_type=artifact_type)
        self.artifacts.append(artifact)
        return artifact

    def set_tag(self, key: str, value: str) -> None:
        """Set a tag."""
        self.tags[key] = value

    def finish(self, status: RunStatus = RunStatus.FINISHED) -> None:
        """Finish the run."""
        self.status = status
        self.end_time = datetime.utcnow()

    def get_metric_history(self, key: str) -> list[Metric]:
        """Get history of a metric."""
        return [m for m in self.metrics if m.key == key]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "run_id": self.run_id,
            "experiment_id": self.experiment_id,
            "status": self.status.value,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "metrics": [m.to_dict() for m in self.metrics],
            "parameters": [p.to_dict() for p in self.parameters],
            "artifacts": [a.to_dict() for a in self.artifacts],
            "tags": self.tags,
        }


@dataclass
class Experiment:
    """An experiment tracking container."""

    experiment_id: str
    name: str
    description: str = ""
    artifact_location: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    runs: list[Run] = field(default_factory=list)
    tags: dict[str, str] = field(default_factory=dict)

    def create_run(self, tags: dict[str, str] | None = None) -> Run:
        """Create a new run."""
        run = Run(
            run_id=str(uuid.uuid4()),
            experiment_id=self.experiment_id,
            tags=tags or {},
        )
        self.runs.append(run)
        return run

    def get_run(self, run_id: str) -> Run | None:
        """Get a run by ID."""
        for run in self.runs:
            if run.run_id == run_id:
                return run
        return None

    def get_best_run(self, metric_key: str, ascending: bool = True) -> Run | None:
        """Get the best run based on a metric."""
        valid_runs = []
        for run in self.runs:
            if run.status == RunStatus.FINISHED:
                metrics = run.get_metric_history(metric_key)
                if metrics:
                    last_value = metrics[-1].value
                    valid_runs.append((run, last_value))

        if not valid_runs:
            return None

        valid_runs.sort(key=lambda x: x[1], reverse=not ascending)
        return valid_runs[0][0]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "experiment_id": self.experiment_id,
            "name": self.name,
            "description": self.description,
            "artifact_location": self.artifact_location,
            "created_at": self.created_at.isoformat(),
            "runs": [r.to_dict() for r in self.runs],
            "tags": self.tags,
        }


class ExperimentTracker:
    """
    MLflow-style Experiment Tracker.

    Features:
    - Experiment management
    - Run tracking
    - Metric logging
    - Parameter logging
    - Artifact storage
    """

    def __init__(self, tracking_uri: str = "mlruns"):
        """Initialize experiment tracker."""
        self.tracking_uri = tracking_uri
        self._experiments: dict[str, Experiment] = {}
        self._active_run: Run | None = None
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize the experiment tracker."""
        # Create default experiments
        self.create_experiment(
            name="council-evaluation",
            description="LLM Council evaluation experiments",
        )
        self.create_experiment(
            name="extraction-quality",
            description="Document extraction quality experiments",
        )
        self.create_experiment(
            name="model-comparison",
            description="Model comparison experiments",
        )

        self._initialized = True
        logger.info(f"Experiment tracker initialized at {self.tracking_uri}")
        return True

    def create_experiment(
        self,
        name: str,
        description: str = "",
        artifact_location: str = "",
    ) -> Experiment:
        """Create a new experiment."""
        experiment_id = str(uuid.uuid4())
        experiment = Experiment(
            experiment_id=experiment_id,
            name=name,
            description=description,
            artifact_location=artifact_location or f"{self.tracking_uri}/{name}",
        )
        self._experiments[name] = experiment
        logger.info(f"Created experiment: {name}")
        return experiment

    def get_experiment(self, name: str) -> Experiment | None:
        """Get an experiment by name."""
        return self._experiments.get(name)

    def get_experiment_by_id(self, experiment_id: str) -> Experiment | None:
        """Get an experiment by ID."""
        for experiment in self._experiments.values():
            if experiment.experiment_id == experiment_id:
                return experiment
        return None

    def start_run(
        self,
        experiment_name: str,
        run_name: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> Run:
        """Start a new run."""
        experiment = self._experiments.get(experiment_name)
        if not experiment:
            experiment = self.create_experiment(experiment_name)

        run = experiment.create_run(tags=tags or {})
        if run_name:
            run.set_tag("mlflow.runName", run_name)

        self._active_run = run
        logger.info(f"Started run {run.run_id} in experiment {experiment_name}")
        return run

    def end_run(self, status: RunStatus = RunStatus.FINISHED) -> None:
        """End the active run."""
        if self._active_run:
            self._active_run.finish(status)
            logger.info(f"Ended run {self._active_run.run_id} with status {status}")
            self._active_run = None

    def get_active_run(self) -> Run | None:
        """Get the active run."""
        return self._active_run

    def log_metric(
        self,
        key: str,
        value: float,
        step: int = 0,
    ) -> None:
        """Log a metric to the active run."""
        if self._active_run:
            self._active_run.log_metric(key, value, step)

    def log_metrics(
        self,
        metrics: dict[str, float],
        step: int = 0,
    ) -> None:
        """Log multiple metrics to the active run."""
        for key, value in metrics.items():
            self.log_metric(key, value, step)

    def log_parameter(self, key: str, value: str) -> None:
        """Log a parameter to the active run."""
        if self._active_run:
            self._active_run.log_parameter(key, value)

    def log_parameters(self, params: dict[str, str]) -> None:
        """Log multiple parameters to the active run."""
        for key, value in params.items():
            self.log_parameter(key, value)

    def log_artifact(
        self,
        name: str,
        path: str,
        artifact_type: str = "file",
    ) -> None:
        """Log an artifact to the active run."""
        if self._active_run:
            self._active_run.log_artifact(name, path, artifact_type)

    def set_tag(self, key: str, value: str) -> None:
        """Set a tag on the active run."""
        if self._active_run:
            self._active_run.set_tag(key, value)

    def search_runs(
        self,
        experiment_name: str,
        filter_string: str | None = None,
        max_results: int = 100,
    ) -> list[Run]:
        """Search runs in an experiment."""
        experiment = self._experiments.get(experiment_name)
        if not experiment:
            return []

        # Simple filtering by status
        runs = experiment.runs
        if filter_string and "status" in filter_string:
            if "FINISHED" in filter_string:
                runs = [r for r in runs if r.status == RunStatus.FINISHED]
            elif "FAILED" in filter_string:
                runs = [r for r in runs if r.status == RunStatus.FAILED]

        return runs[:max_results]

    def get_all_experiments(self) -> list[Experiment]:
        """Get all experiments."""
        return list(self._experiments.values())

    def delete_experiment(self, name: str) -> bool:
        """Delete an experiment."""
        if name in self._experiments:
            del self._experiments[name]
            return True
        return False


# Singleton instance
_experiment_tracker: ExperimentTracker | None = None


def get_experiment_tracker() -> ExperimentTracker:
    """Get or create experiment tracker singleton."""
    global _experiment_tracker
    if _experiment_tracker is None:
        _experiment_tracker = ExperimentTracker()
        _experiment_tracker.initialize()
    return _experiment_tracker
