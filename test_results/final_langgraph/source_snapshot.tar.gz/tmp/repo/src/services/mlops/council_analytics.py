"""
Council Analytics Dashboard.

Provides council-specific analytics and visualization.
"""

import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class VoteOutcome(StrEnum):
    """Outcome of a council vote."""

    CONSENSUS = "consensus"
    MAJORITY = "majority"
    TIE = "tie"
    SINGLE = "single"


class AgreementLevel(StrEnum):
    """Level of agreement between council members."""

    FULL = "full"  # 100% agreement
    HIGH = "high"  # > 75% agreement
    MODERATE = "moderate"  # 50-75% agreement
    LOW = "low"  # < 50% agreement


@dataclass
class MemberVote:
    """A vote from a council member."""

    member_id: str
    member_name: str
    field_name: str
    extracted_value: str
    confidence: float
    processing_time_ms: float
    timestamp: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "member_id": self.member_id,
            "member_name": self.member_name,
            "field_name": self.field_name,
            "extracted_value": self.extracted_value,
            "confidence": self.confidence,
            "processing_time_ms": self.processing_time_ms,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class ConsensusResult:
    """Result of a consensus vote."""

    vote_id: str
    field_name: str
    final_value: str
    outcome: VoteOutcome
    agreement_level: AgreementLevel
    votes: list[MemberVote] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.utcnow)

    @property
    def member_agreement(self) -> float:
        """Calculate agreement percentage."""
        if not self.votes:
            return 0.0
        matching = sum(1 for v in self.votes if v.extracted_value == self.final_value)
        return matching / len(self.votes)

    @property
    def average_confidence(self) -> float:
        """Calculate average confidence."""
        if not self.votes:
            return 0.0
        return sum(v.confidence for v in self.votes) / len(self.votes)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "vote_id": self.vote_id,
            "field_name": self.field_name,
            "final_value": self.final_value,
            "outcome": self.outcome.value,
            "agreement_level": self.agreement_level.value,
            "member_agreement": self.member_agreement,
            "average_confidence": self.average_confidence,
            "votes": [v.to_dict() for v in self.votes],
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class MemberPerformance:
    """Performance metrics for a council member."""

    member_id: str
    member_name: str
    total_votes: int = 0
    correct_votes: int = 0
    average_confidence: float = 0.0
    average_processing_time_ms: float = 0.0
    agreement_with_consensus: float = 0.0
    fields_specialized: list[str] = field(default_factory=list)
    confidence_by_field: dict[str, float] = field(default_factory=dict)

    @property
    def accuracy(self) -> float:
        """Calculate accuracy rate."""
        if self.total_votes == 0:
            return 0.0
        return self.correct_votes / self.total_votes

    def update_from_vote(
        self,
        vote: MemberVote,
        was_correct: bool,
    ) -> None:
        """Update performance from a vote."""
        self.total_votes += 1
        if was_correct:
            self.correct_votes += 1

        # Update running averages
        n = self.total_votes
        self.average_confidence = (self.average_confidence * (n - 1) + vote.confidence) / n
        self.average_processing_time_ms = (
            self.average_processing_time_ms * (n - 1) + vote.processing_time_ms
        ) / n

        # Update field-specific confidence
        field = vote.field_name
        if field not in self.confidence_by_field:
            self.confidence_by_field[field] = vote.confidence
        else:
            old_conf = self.confidence_by_field[field]
            self.confidence_by_field[field] = (old_conf + vote.confidence) / 2

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "member_id": self.member_id,
            "member_name": self.member_name,
            "total_votes": self.total_votes,
            "correct_votes": self.correct_votes,
            "accuracy": self.accuracy,
            "average_confidence": self.average_confidence,
            "average_processing_time_ms": self.average_processing_time_ms,
            "agreement_with_consensus": self.agreement_with_consensus,
            "fields_specialized": self.fields_specialized,
            "confidence_by_field": self.confidence_by_field,
        }


@dataclass
class ConsensusAnalytics:
    """Analytics for consensus patterns."""

    total_consensus_votes: int = 0
    full_agreement_count: int = 0
    majority_agreement_count: int = 0
    tie_count: int = 0
    average_agreement_rate: float = 0.0
    agreement_by_field: dict[str, float] = field(default_factory=dict)
    common_disagreements: list[dict[str, Any]] = field(default_factory=list)

    @property
    def full_agreement_rate(self) -> float:
        """Calculate full agreement rate."""
        if self.total_consensus_votes == 0:
            return 0.0
        return self.full_agreement_count / self.total_consensus_votes

    def update_from_result(self, result: ConsensusResult) -> None:
        """Update analytics from a consensus result."""
        self.total_consensus_votes += 1

        if result.outcome == VoteOutcome.CONSENSUS:
            self.full_agreement_count += 1
        elif result.outcome == VoteOutcome.MAJORITY:
            self.majority_agreement_count += 1
        elif result.outcome == VoteOutcome.TIE:
            self.tie_count += 1

        # Update running average
        n = self.total_consensus_votes
        self.average_agreement_rate = (
            self.average_agreement_rate * (n - 1) + result.member_agreement
        ) / n

        # Update field-specific agreement
        field = result.field_name
        if field not in self.agreement_by_field:
            self.agreement_by_field[field] = result.member_agreement
        else:
            old_rate = self.agreement_by_field[field]
            self.agreement_by_field[field] = (old_rate + result.member_agreement) / 2

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "total_consensus_votes": self.total_consensus_votes,
            "full_agreement_count": self.full_agreement_count,
            "full_agreement_rate": self.full_agreement_rate,
            "majority_agreement_count": self.majority_agreement_count,
            "tie_count": self.tie_count,
            "average_agreement_rate": self.average_agreement_rate,
            "agreement_by_field": self.agreement_by_field,
            "common_disagreements": self.common_disagreements,
        }


@dataclass
class CouncilMetrics:
    """Overall council metrics."""

    total_documents_processed: int = 0
    total_fields_extracted: int = 0
    total_votes_cast: int = 0
    average_processing_time_ms: float = 0.0
    consensus_rate: float = 0.0
    member_performances: dict[str, MemberPerformance] = field(default_factory=dict)
    consensus_analytics: ConsensusAnalytics = field(default_factory=ConsensusAnalytics)
    hourly_throughput: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "total_documents_processed": self.total_documents_processed,
            "total_fields_extracted": self.total_fields_extracted,
            "total_votes_cast": self.total_votes_cast,
            "average_processing_time_ms": self.average_processing_time_ms,
            "consensus_rate": self.consensus_rate,
            "member_performances": {k: v.to_dict() for k, v in self.member_performances.items()},
            "consensus_analytics": self.consensus_analytics.to_dict(),
            "hourly_throughput": self.hourly_throughput,
        }


class CouncilAnalytics:
    """
    Council Analytics Service.

    Features:
    - Member performance tracking
    - Consensus pattern analysis
    - Disagreement detection
    - Throughput monitoring
    """

    COUNCIL_MEMBERS = [
        ("paddle_ocr", "PaddleOCR"),
        ("olmocr", "olmOCR"),
        ("qwen", "Qwen-VLM"),
        ("colpali", "ColPali-VLM"),
    ]

    def __init__(self):
        """Initialize council analytics."""
        self._metrics = CouncilMetrics()
        self._consensus_results: list[ConsensusResult] = []
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize with council member configurations."""
        # Initialize member performances
        for member_id, member_name in self.COUNCIL_MEMBERS:
            self._metrics.member_performances[member_id] = MemberPerformance(
                member_id=member_id,
                member_name=member_name,
            )

        self._initialized = True
        logger.info("Council analytics initialized")
        return True

    def record_consensus_result(
        self,
        field_name: str,
        final_value: str,
        votes: list[dict[str, Any]],
    ) -> ConsensusResult:
        """Record a consensus voting result."""
        # Convert votes to MemberVote objects
        member_votes = []
        for vote_data in votes:
            vote = MemberVote(
                member_id=vote_data["member_id"],
                member_name=vote_data.get("member_name", vote_data["member_id"]),
                field_name=field_name,
                extracted_value=vote_data["value"],
                confidence=vote_data.get("confidence", 0.0),
                processing_time_ms=vote_data.get("processing_time_ms", 0.0),
            )
            member_votes.append(vote)

        # Determine outcome and agreement level
        outcome, agreement_level = self._analyze_votes(member_votes, final_value)

        result = ConsensusResult(
            vote_id=str(uuid.uuid4()),
            field_name=field_name,
            final_value=final_value,
            outcome=outcome,
            agreement_level=agreement_level,
            votes=member_votes,
        )

        self._consensus_results.append(result)

        # Update metrics
        self._update_metrics(result)

        return result

    def _analyze_votes(
        self,
        votes: list[MemberVote],
        final_value: str,
    ) -> tuple[VoteOutcome, AgreementLevel]:
        """Analyze votes to determine outcome and agreement level."""
        if not votes:
            return VoteOutcome.SINGLE, AgreementLevel.LOW

        matching = sum(1 for v in votes if v.extracted_value == final_value)
        agreement_rate = matching / len(votes)

        # Determine outcome
        if agreement_rate == 1.0:
            outcome = VoteOutcome.CONSENSUS
        elif agreement_rate > 0.5:
            outcome = VoteOutcome.MAJORITY
        elif len(votes) == 1:
            outcome = VoteOutcome.SINGLE
        else:
            outcome = VoteOutcome.TIE

        # Determine agreement level
        if agreement_rate == 1.0:
            agreement_level = AgreementLevel.FULL
        elif agreement_rate >= 0.75:
            agreement_level = AgreementLevel.HIGH
        elif agreement_rate >= 0.5:
            agreement_level = AgreementLevel.MODERATE
        else:
            agreement_level = AgreementLevel.LOW

        return outcome, agreement_level

    def _update_metrics(self, result: ConsensusResult) -> None:
        """Update metrics from a consensus result."""
        self._metrics.total_fields_extracted += 1
        self._metrics.total_votes_cast += len(result.votes)

        # Update member performances
        for vote in result.votes:
            was_correct = vote.extracted_value == result.final_value
            member_perf = self._metrics.member_performances.get(vote.member_id)
            if member_perf:
                member_perf.update_from_vote(vote, was_correct)

        # Update consensus analytics
        self._metrics.consensus_analytics.update_from_result(result)

        # Update consensus rate
        total = self._metrics.consensus_analytics.total_consensus_votes
        full = self._metrics.consensus_analytics.full_agreement_count
        self._metrics.consensus_rate = full / total if total > 0 else 0.0

        # Update hourly throughput
        hour_key = datetime.utcnow().strftime("%Y-%m-%d-%H")
        self._metrics.hourly_throughput[hour_key] = (
            self._metrics.hourly_throughput.get(hour_key, 0) + 1
        )

    def record_document_processed(
        self,
        document_id: str,
        processing_time_ms: float,
        field_count: int,
    ) -> None:
        """Record a processed document."""
        self._metrics.total_documents_processed += 1

        # Update running average processing time
        n = self._metrics.total_documents_processed
        self._metrics.average_processing_time_ms = (
            self._metrics.average_processing_time_ms * (n - 1) + processing_time_ms
        ) / n

    def get_member_performance(self, member_id: str) -> MemberPerformance | None:
        """Get performance metrics for a member."""
        return self._metrics.member_performances.get(member_id)

    def get_all_member_performances(self) -> list[MemberPerformance]:
        """Get all member performances."""
        return list(self._metrics.member_performances.values())

    def get_best_member_for_field(self, field_name: str) -> MemberPerformance | None:
        """Get the best performing member for a specific field."""
        best_member = None
        best_confidence = 0.0

        for member in self._metrics.member_performances.values():
            confidence = member.confidence_by_field.get(field_name, 0.0)
            if confidence > best_confidence:
                best_confidence = confidence
                best_member = member

        return best_member

    def get_consensus_analytics(self) -> ConsensusAnalytics:
        """Get consensus analytics."""
        return self._metrics.consensus_analytics

    def get_council_metrics(self) -> CouncilMetrics:
        """Get overall council metrics."""
        return self._metrics

    def get_disagreement_analysis(
        self,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Analyze common disagreements."""
        # Find results with low agreement
        disagreements = [
            r
            for r in self._consensus_results
            if r.agreement_level in [AgreementLevel.LOW, AgreementLevel.MODERATE]
        ]

        # Group by field
        field_disagreements: dict[str, list[ConsensusResult]] = defaultdict(list)
        for result in disagreements:
            field_disagreements[result.field_name].append(result)

        # Analyze patterns
        analysis = []
        for field_name, results in sorted(
            field_disagreements.items(),
            key=lambda x: len(x[1]),
            reverse=True,
        )[:limit]:
            analysis.append(
                {
                    "field_name": field_name,
                    "disagreement_count": len(results),
                    "average_agreement": sum(r.member_agreement for r in results) / len(results),
                    "examples": [r.to_dict() for r in results[:3]],
                }
            )

        return analysis

    def get_throughput_trend(
        self,
        hours: int = 24,
    ) -> dict[str, int]:
        """Get throughput trend for the last N hours."""
        now = datetime.utcnow()
        trend = {}

        for i in range(hours):
            hour = now - timedelta(hours=i)
            hour_key = hour.strftime("%Y-%m-%d-%H")
            trend[hour_key] = self._metrics.hourly_throughput.get(hour_key, 0)

        return dict(sorted(trend.items()))

    def generate_report(self) -> dict[str, Any]:
        """Generate a comprehensive analytics report."""
        return {
            "summary": {
                "total_documents": self._metrics.total_documents_processed,
                "total_fields": self._metrics.total_fields_extracted,
                "total_votes": self._metrics.total_votes_cast,
                "consensus_rate": self._metrics.consensus_rate,
                "average_processing_time_ms": self._metrics.average_processing_time_ms,
            },
            "member_performances": [m.to_dict() for m in self.get_all_member_performances()],
            "consensus_analytics": self._metrics.consensus_analytics.to_dict(),
            "disagreement_analysis": self.get_disagreement_analysis(),
            "throughput_trend": self.get_throughput_trend(),
        }


# Singleton instance
_council_analytics: CouncilAnalytics | None = None


def get_council_analytics() -> CouncilAnalytics:
    """Get or create council analytics singleton."""
    global _council_analytics
    if _council_analytics is None:
        _council_analytics = CouncilAnalytics()
        _council_analytics.initialize()
    return _council_analytics
