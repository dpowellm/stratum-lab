"""
Celery application configuration.

This module configures Celery for distributed task processing with:
- Multiple task queues
- Task routing by type
- Retry configuration
- Result backend
- Monitoring support
"""

from celery import Celery

from src.config.settings import get_settings

settings = get_settings()

# Create Celery app
celery_app = Celery(
    "agentic_doc_extraction",
    broker=settings.celery.broker_url,
    backend=settings.celery.result_backend,
)

# Configure Celery
celery_app.conf.update(
    # Task settings
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    # Task execution
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    task_track_started=True,
    task_time_limit=600,  # 10 minutes
    task_soft_time_limit=540,  # 9 minutes
    # Worker settings
    worker_prefetch_multiplier=1,
    worker_concurrency=4,
    # Result backend
    result_expires=86400,  # 24 hours
    result_extended=True,
    # Task routing
    task_routes={
        "src.workers.tasks.ingestion.*": {"queue": "ingestion"},
        "src.workers.tasks.council.*": {"queue": "council"},
        "src.workers.tasks.indexing.*": {"queue": "indexing"},
        "src.workers.tasks.generation.*": {"queue": "generation"},
    },
    # Default queue
    task_default_queue="default",
    # Queue definitions (includes dead-letter queue for max-retry failures)
    task_queues={
        "default": {"exchange": "default", "routing_key": "default"},
        "ingestion": {"exchange": "ingestion", "routing_key": "ingestion"},
        "council": {"exchange": "council", "routing_key": "council"},
        "indexing": {"exchange": "indexing", "routing_key": "indexing"},
        "generation": {"exchange": "generation", "routing_key": "generation"},
        "dead_letter": {"exchange": "dead_letter", "routing_key": "dead_letter"},
    },
    # Retry settings
    task_default_retry_delay=60,  # 1 minute
    task_max_retries=3,
    # Beat scheduler (for periodic tasks)
    beat_scheduler="celery.beat:PersistentScheduler",
)

# Auto-discover tasks
celery_app.autodiscover_tasks(["src.workers.tasks"])


# Dead-letter queue handler: route max-retried tasks to DLQ
@celery_app.task(name="src.workers.dead_letter_handler", queue="dead_letter")
def dead_letter_handler(original_task_name: str, args: list, kwargs: dict, einfo: str):
    """
    Handle tasks that have exhausted all retries.

    Logs the failure and stores it for manual inspection/replay.
    """
    import structlog

    logger = structlog.get_logger(__name__)
    logger.error(
        "Task moved to dead-letter queue",
        task_name=original_task_name,
        args=str(args)[:500],
        kwargs=str(kwargs)[:500],
        error=str(einfo)[:1000],
    )


def on_task_failure(self, exc, task_id, args, kwargs, einfo):
    """Send failed tasks to DLQ after max retries exhausted."""
    if self.request.retries >= self.max_retries:
        dead_letter_handler.apply_async(
            args=[self.name, list(args) if args else [], dict(kwargs) if kwargs else {}, str(einfo)],
            queue="dead_letter",
        )


# Monkey-patch failure handler onto base task
celery_app.Task.on_failure = on_task_failure
