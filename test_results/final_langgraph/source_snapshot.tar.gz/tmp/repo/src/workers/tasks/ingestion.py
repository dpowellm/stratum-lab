"""Document ingestion tasks.

These tasks handle document upload, validation, preprocessing, and initial processing.
Integrates with S3/MinIO storage service for file management.

Tasks:
- process_document: Main orchestration task
- preprocess_document: Preprocessing step (file type detection, format validation)
- validate_document: Document validation (checksum, file integrity)
- extract_text: Text extraction from documents
- calculate_checksum: SHA-256 checksum calculation
- cleanup_failed_upload: Resource cleanup on failure

Pipeline functions (async, testable without Celery):
- run_ingestion_pipeline: Full ingestion pipeline
- _download_document: Download file from storage
- _validate_document_from_storage: Validate file exists
- _convert_pdf_to_images: Convert PDF pages to images
"""

import hashlib
import io
import uuid
from pathlib import Path
from typing import Any

from celery.utils.log import get_task_logger

from src.config.settings import get_settings
from src.services.storage import get_storage_service
from src.workers.celery_app import celery_app

logger = get_task_logger(__name__)


# Try to import pdf2image; provide a fallback reference for mocking
try:
    from pdf2image import convert_from_bytes as pdf2image_convert
except ImportError:
    pdf2image_convert = None


@celery_app.task(
    bind=True,
    name="src.workers.tasks.ingestion.process_document",
    queue="ingestion",
    max_retries=3,
    default_retry_delay=60,
    autoretry_for=(Exception,),
    retry_backoff=True,
    retry_backoff_max=600,
)
def process_document(
    self,
    document_id: str,
    file_path: str,
    file_type: str,
    options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Process an uploaded document.

    This is the main entry point for document processing.
    It orchestrates validation, text extraction, and council session.

    Args:
        document_id: Unique document identifier
        file_path: Path to document in storage
        file_type: MIME type of the document
        options: Processing options

    Returns:
        Processing result with task IDs for subsequent steps
    """
    logger.info(
        "Processing document",
        extra={
            "document_id": document_id,
            "file_type": file_type,
            "task_id": self.request.id,
        },
    )

    options = options or {}

    try:
        # Step 1: Validate document
        validation_result = validate_document.delay(
            document_id=document_id,
            file_path=file_path,
            file_type=file_type,
        )

        # Step 2: Extract text (chained after validation)
        extract_result = extract_text.delay(
            document_id=document_id,
            file_path=file_path,
            file_type=file_type,
            options=options.get("extraction", {}),
        )

        return {
            "status": "processing",
            "document_id": document_id,
            "validation_task_id": validation_result.id,
            "extraction_task_id": extract_result.id,
            "message": "Document processing initiated",
        }

    except Exception as exc:
        logger.error(
            "Document processing failed",
            extra={
                "document_id": document_id,
                "error": str(exc),
            },
        )
        raise self.retry(exc=exc) from exc


@celery_app.task(
    bind=True,
    name="src.workers.tasks.ingestion.preprocess_document",
    queue="ingestion",
    max_retries=2,
    default_retry_delay=30,
    time_limit=120,  # 2 minutes
    soft_time_limit=90,  # 1.5 minutes
)
def preprocess_document(
    self,
    document_id: str,
    file_key: str,
) -> dict[str, Any]:
    """Preprocess a document before main processing.

    This is the preprocessing step that:
    - Detects file type and format
    - Validates file format
    - Checks file integrity
    - Extracts basic metadata
    - Stores preprocessing results

    Args:
        document_id: Unique document identifier
        file_key: Storage key/path to the document file

    Returns:
        Preprocessing result with file type, metadata, and validation status

    Raises:
        Retries on failure with exponential backoff
    """
    logger.info(
        "Preprocessing document",
        extra={
            "document_id": document_id,
            "file_key": file_key,
            "task_id": self.request.id,
        },
    )

    try:
        storage = get_storage_service()
        settings = get_settings()

        # Check if file exists in storage
        exists = _sync_run(storage.file_exists(file_key))
        if not exists:
            logger.error(
                "Document file not found in storage",
                extra={
                    "document_id": document_id,
                    "file_key": file_key,
                },
            )
            raise FileNotFoundError(f"File {file_key} not found in storage")

        # Get file metadata
        file_metadata = _sync_run(storage.get_file_metadata(file_key))

        # Determine file type from extension and content type
        path = Path(file_key)
        file_extension = path.suffix.lower()
        content_type = file_metadata.get("content_type", "application/octet-stream")

        # Map to processing-friendly format
        detected_file_type = _detect_file_type(file_extension, content_type)

        # Validate file format
        is_valid_format = _is_valid_file_format(detected_file_type)

        # Check file size (configurable, default 500MB)
        max_file_size = getattr(settings, "max_upload_size", 500 * 1024 * 1024)
        file_size = file_metadata.get("size", 0)
        size_ok = file_size <= max_file_size

        logger.info(
            "Document preprocessed successfully",
            extra={
                "document_id": document_id,
                "file_type": detected_file_type,
                "file_size": file_size,
                "valid_format": is_valid_format,
                "size_ok": size_ok,
            },
        )

        return {
            "document_id": document_id,
            "file_key": file_key,
            "status": "preprocessed",
            "file_type": detected_file_type,
            "file_extension": file_extension,
            "content_type": content_type,
            "file_size": file_size,
            "metadata": {
                "valid_format": is_valid_format,
                "size_ok": size_ok,
                "detected_at": file_metadata.get("last_modified"),
                "etag": file_metadata.get("etag"),
            },
        }

    except FileNotFoundError as exc:
        logger.warning(
            "Document preprocessing failed - file not found",
            extra={
                "document_id": document_id,
                "file_key": file_key,
            },
        )
        raise self.retry(exc=exc) from exc
    except Exception as exc:
        logger.error(
            "Document preprocessing failed",
            extra={
                "document_id": document_id,
                "file_key": file_key,
                "error": str(exc),
            },
        )
        raise self.retry(exc=exc) from exc


@celery_app.task(
    bind=True,
    name="src.workers.tasks.ingestion.validate_document",
    queue="ingestion",
    max_retries=2,
    default_retry_delay=30,
)
def validate_document(
    _self,
    document_id: str,
    _file_path: str,
    file_type: str,
) -> dict[str, Any]:
    """Validate a document for processing.

    Checks:
    - File exists in storage
    - File is not corrupted
    - File type matches content
    - File size within limits

    Args:
        document_id: Unique document identifier
        file_path: Path to document in storage
        file_type: Expected MIME type

    Returns:
        Validation result with details
    """
    logger.info(
        "Validating document",
        extra={
            "document_id": document_id,
            "file_type": file_type,
        },
    )

    # Validation logic would go here
    # For now, return a mock result

    return {
        "valid": True,
        "document_id": document_id,
        "file_type": file_type,
        "checks": {
            "file_exists": True,
            "type_matches": True,
            "size_ok": True,
            "not_corrupted": True,
        },
    }


@celery_app.task(
    bind=True,
    name="src.workers.tasks.ingestion.extract_text",
    queue="ingestion",
    max_retries=3,
    default_retry_delay=60,
    time_limit=300,  # 5 minutes
    soft_time_limit=270,  # 4.5 minutes
)
def extract_text(
    self,
    document_id: str,
    _file_path: str,
    file_type: str,
    options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Extract text from a document.

    Uses appropriate extraction method based on file type:
    - PDF: PDF parser + OCR fallback
    - Images: OCR only
    - TIFF: Multi-page OCR

    Args:
        document_id: Unique document identifier
        file_path: Path to document in storage
        file_type: MIME type for extraction method selection
        options: Extraction options (DPI, language, etc.)

    Returns:
        Extracted text and metadata
    """
    logger.info(
        "Extracting text from document",
        extra={
            "document_id": document_id,
            "file_type": file_type,
            "task_id": self.request.id,
        },
    )

    options = options or {}

    # Text extraction logic would go here
    # For now, return a mock result

    return {
        "document_id": document_id,
        "status": "extracted",
        "text_blocks": [],  # Would contain extracted text blocks
        "page_count": 0,
        "extraction_method": _get_extraction_method(file_type),
        "metadata": {
            "language": options.get("language", "en"),
            "dpi": options.get("dpi", 300),
        },
    }


def _get_extraction_method(file_type: str) -> str:
    """Determine extraction method based on file type."""
    pdf_types = ["application/pdf"]
    image_types = ["image/png", "image/jpeg", "image/jpg", "image/tiff", "image/webp"]

    if file_type in pdf_types:
        return "pdf_parser_with_ocr"
    elif file_type in image_types:
        return "ocr"
    else:
        return "text"


@celery_app.task(
    name="src.workers.tasks.ingestion.calculate_checksum",
    queue="ingestion",
)
def calculate_checksum(content: bytes) -> str:
    """Calculate SHA-256 checksum of content."""
    return hashlib.sha256(content).hexdigest()


@celery_app.task(
    name="src.workers.tasks.ingestion.cleanup_failed_upload",
    queue="ingestion",
)
def cleanup_failed_upload(document_id: str, file_path: str) -> bool:
    """Clean up resources from a failed upload.

    Removes the uploaded file from storage if document processing fails.
    Useful for rollback scenarios.

    Args:
        document_id: Document identifier
        file_path: Storage key/path to remove

    Returns:
        True if cleanup successful

    Raises:
        Logs errors but doesn't raise to allow cleanup attempts
    """
    logger.info(
        "Cleaning up failed upload",
        extra={
            "document_id": document_id,
            "file_path": file_path,
        },
    )

    try:
        storage = get_storage_service()
        success = _sync_run(storage.delete_file(file_path))

        if success:
            logger.info(
                "Successfully cleaned up failed upload",
                extra={
                    "document_id": document_id,
                    "file_path": file_path,
                },
            )
        return success

    except Exception as exc:
        logger.error(
            "Cleanup failed but continuing",
            extra={
                "document_id": document_id,
                "file_path": file_path,
                "error": str(exc),
            },
        )
        # Return False to indicate cleanup issue, but don't raise
        # to allow other cleanup tasks to complete
        return False


def _detect_file_type(file_extension: str, content_type: str) -> str:
    """Detect file type from extension and content type.

    Args:
        file_extension: File extension (e.g., '.pdf')
        content_type: MIME content type

    Returns:
        Normalized file type string
    """
    # Map extensions to file types
    extension_map = {
        ".pdf": "pdf",
        ".png": "image",
        ".jpg": "image",
        ".jpeg": "image",
        ".gif": "image",
        ".tiff": "image",
        ".tif": "image",
        ".webp": "image",
        ".bmp": "image",
        ".docx": "document",
        ".doc": "document",
        ".txt": "text",
        ".xlsx": "spreadsheet",
        ".xls": "spreadsheet",
        ".csv": "spreadsheet",
        ".pptx": "presentation",
        ".ppt": "presentation",
    }

    # Try extension first
    if file_extension in extension_map:
        return extension_map[file_extension]

    # Try content type
    content_type_map = {
        "application/pdf": "pdf",
        "image/": "image",
        "text/": "text",
        "application/msword": "document",
        "application/vnd.openxmlformats-officedocument.wordprocessingml": "document",
        "application/vnd.ms-excel": "spreadsheet",
        "application/vnd.openxmlformats-officedocument.spreadsheetml": "spreadsheet",
        "text/csv": "spreadsheet",
    }

    for prefix, file_type in content_type_map.items():
        if content_type.startswith(prefix):
            return file_type

    # Default to unknown
    return "unknown"


def _is_valid_file_format(file_type: str) -> bool:
    """Check if file type is valid for processing.

    Args:
        file_type: Detected file type

    Returns:
        True if file type is supported
    """
    supported_types = {
        "pdf",
        "image",
        "document",
        "text",
        "spreadsheet",
        "presentation",
    }
    return file_type in supported_types


def _sync_run(coro):
    """Run an async coroutine synchronously in Celery context.

    Celery tasks run in sync context, so we need to handle async
    storage operations. This is a helper for that.

    Args:
        coro: Async coroutine to run

    Returns:
        Result of the coroutine

    Note:
        This requires event loop support. In production, consider using
        async Celery or a sync storage wrapper.
    """
    import asyncio

    try:
        # Try to get existing event loop
        loop = asyncio.get_event_loop()
    except RuntimeError:
        # Create new loop if none exists
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    try:
        return loop.run_until_complete(coro)
    finally:
        # Don't close loop - let Celery manage it
        pass


# ---------------------------------------------------------------------------
# Async pipeline functions (testable without Celery broker)
# ---------------------------------------------------------------------------


async def _validate_document_from_storage(
    storage,
    file_path: str,
    file_type: str,
) -> dict[str, Any]:
    """Validate that a document exists in storage and is accessible.

    Args:
        storage: Storage service instance
        file_path: Storage key/path
        file_type: Expected MIME type

    Returns:
        Validation result dict with 'valid' boolean
    """
    exists = await storage.exists(file_path)
    if not exists:
        return {
            "valid": False,
            "error": f"File not found in storage: {file_path}",
        }

    return {
        "valid": True,
        "file_path": file_path,
        "file_type": file_type,
    }


async def _download_document(storage, file_path: str) -> bytes:
    """Download a document from storage.

    Args:
        storage: Storage service instance
        file_path: Storage key/path

    Returns:
        File content as bytes

    Raises:
        ObjectNotFoundError: If file doesn't exist
    """
    result = await storage.download(file_path)
    return result.content


async def _convert_pdf_to_images(
    pdf_content: bytes,
    dpi: int = 300,
) -> list[bytes]:
    """Convert PDF pages to images.

    Args:
        pdf_content: PDF file content as bytes
        dpi: Resolution for rendering

    Returns:
        List of PNG image bytes, one per page
    """
    if pdf2image_convert is None:
        raise ImportError(
            "pdf2image is required for PDF conversion. Install with: pip install pdf2image"
        )

    pil_images = pdf2image_convert(pdf_content, dpi=dpi)

    image_bytes_list = []
    for img in pil_images:
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        image_bytes_list.append(buf.getvalue())

    return image_bytes_list


async def run_ingestion_pipeline(
    document_id: str,
    storage_path: str,
    file_type: str,
    storage,
    session,
    _options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run the full document ingestion pipeline.

    This is the async, testable version of the ingestion flow:
    1. Update document status to PREPROCESSING
    2. Download file from storage
    3. Convert PDF to images (if PDF) or use raw image bytes
    4. Update document status to EXTRACTING
    5. Store image keys for council worker

    Args:
        document_id: Document UUID string
        storage_path: Path to file in storage
        file_type: MIME type of the document
        storage: Storage service instance
        session: Database session
        options: Processing options

    Returns:
        Dict with status, page_count, and image_keys for council worker

    Raises:
        ObjectNotFoundError: If file not in storage (document marked as FAILED)
    """
    from src.services.document.repository import DocumentRepository

    doc_uuid = uuid.UUID(document_id)
    repo = DocumentRepository(session)

    # Step 1: Mark as preprocessing
    await repo.update_status(doc_uuid, ProcessingStatus.PREPROCESSING, progress=5)
    await session.commit()

    try:
        # Step 2: Download from storage
        content = await _download_document(storage, storage_path)

        # Step 3: Convert to images
        image_type_prefixes = ["image/png", "image/jpeg", "image/tiff", "image/webp"]
        is_image = any(file_type.startswith(prefix) for prefix in image_type_prefixes)

        if is_image:
            page_images = [content]
        else:
            # PDF or other → convert to images
            page_images = await _convert_pdf_to_images(content)

        page_count = len(page_images)

        # Step 4: Store page images back to storage for council worker access
        image_keys = []
        for i, img_bytes in enumerate(page_images):
            image_key = f"documents/{document_id}/pages/page_{i + 1}.png"
            await storage.upload(
                key=image_key,
                content=img_bytes,
                content_type="image/png",
            )
            image_keys.append(image_key)

        # Step 5: Update document status and metadata
        doc = await repo.get_by_id(doc_uuid)
        if doc:
            doc.page_count = page_count
            doc.update_status(
                ProcessingStatus.EXTRACTING,
                message="Ready for council extraction",
                progress=30,
            )
            await session.flush()

        await session.commit()

        return {
            "status": "ready_for_council",
            "document_id": document_id,
            "page_count": page_count,
            "image_keys": image_keys,
        }

    except Exception as exc:
        # Mark document as failed
        doc = await repo.get_by_id(doc_uuid)
        if doc:
            doc.fail(str(exc))
            await session.commit()
        raise


# Re-export ProcessingStatus for use by pipeline
from src.models.database.document import ProcessingStatus  # noqa: E402
