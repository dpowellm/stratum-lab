"""Celery task modules for the document extraction system.

Comprehensive task orchestration for document processing pipeline:

Task Queues:
- ingestion: Document upload, validation, preprocessing
- council: LLM Council extraction, voting, consensus, and judge escalation
- indexing: Document chunking, embedding generation, vector indexing
- generation: RAG retrieval and answer generation

Task Flow:
1. Ingestion: process_document -> preprocess_document -> validate_document
2. Council: run_council_extraction -> collect votes -> consensus -> judge
3. Indexing: index_document -> chunk -> embeddings -> vector storage
4. Generation: retrieve_context -> generate_answer

Storage Integration:
- All tasks can work with S3/MinIO or local storage
- File keys passed through task chain
- Presigned URLs for direct access
"""

from src.workers.tasks.council import (
    calculate_consensus,
    collect_member_vote,
    collect_member_votes,
    escalate_to_judge,
    flag_for_human_review,
    run_council_extraction,
    run_council_session,
)
from src.workers.tasks.generation import (
    batch_generate,
    format_response,
    generate_answer,
    retrieve_context,
)
from src.workers.tasks.indexing import (
    chunk_document,
    delete_document_vectors,
    generate_embeddings,
    index_document,
    reindex_document,
    update_vector_index,
)
from src.workers.tasks.ingestion import (
    calculate_checksum,
    cleanup_failed_upload,
    extract_text,
    preprocess_document,
    process_document,
    validate_document,
)

__all__ = [
    "batch_generate",
    "calculate_checksum",
    "calculate_consensus",
    "chunk_document",
    "cleanup_failed_upload",
    "collect_member_vote",
    "collect_member_votes",
    "delete_document_vectors",
    "escalate_to_judge",
    "extract_text",
    "flag_for_human_review",
    "format_response",
    # Generation tasks
    "generate_answer",
    "generate_embeddings",
    # Indexing tasks
    "index_document",
    "preprocess_document",
    # Ingestion tasks
    "process_document",
    "reindex_document",
    "retrieve_context",
    # Council tasks
    "run_council_extraction",
    "run_council_session",
    "update_vector_index",
    "validate_document",
]
