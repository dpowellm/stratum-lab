"""Document indexing tasks for RAG.

These tasks handle document chunking, embedding generation,
and vector database indexing. Supports both extracted text
and raw document files from storage.

Tasks:
- index_document: Main orchestration task (also available as index_document_from_file)
- chunk_document: Semantic chunking of text
- generate_embeddings: Generate embeddings for chunks using BGE-M3
- update_vector_index: Store embeddings in Qdrant
- delete_document_vectors: Remove document vectors
- reindex_document: Full reindex cycle
"""

from typing import Any

from celery.utils.log import get_task_logger

from src.workers.celery_app import celery_app

logger = get_task_logger(__name__)


@celery_app.task(
    bind=True,
    name="src.workers.tasks.indexing.index_document",
    queue="indexing",
    max_retries=3,
    default_retry_delay=60,
    time_limit=600,  # 10 minutes
    soft_time_limit=540,  # 9 minutes
)
def index_document(
    self,
    document_id: str,
    extracted_text: dict[str, Any] | None = None,
    file_key: str | None = None,
    metadata: dict[str, Any] | None = None,
    chunk_size: int = 512,
    chunk_overlap: int = 128,
) -> dict[str, Any]:
    """Index a document for RAG retrieval.

    Orchestrates the full indexing pipeline:
    1. Chunk the document
    2. Generate embeddings using BGE-M3
    3. Store in vector database (Qdrant)

    Supports two modes:
    - extracted_text: Use pre-extracted text
    - file_key: Download from storage and extract

    Args:
        document_id: Document identifier
        extracted_text: Pre-extracted text content (optional)
        file_key: Storage key to document file (optional)
        metadata: Document metadata for filtering
        chunk_size: Target chunk size in tokens (default: 512)
        chunk_overlap: Overlap between chunks in tokens (default: 128)

    Returns:
        Indexing result with chunk count and vector IDs

    Raises:
        Retries on failure with exponential backoff
    """
    logger.info(
        "Starting document indexing",
        extra={
            "document_id": document_id,
            "has_extracted_text": extracted_text is not None,
            "has_file_key": file_key is not None,
            "task_id": self.request.id,
        },
    )

    try:
        # If neither extracted_text nor file_key provided, error
        if not extracted_text and not file_key:
            raise ValueError("Either extracted_text or file_key must be provided")

        # If file_key provided but no extracted_text, would need to extract
        # For now, require extracted_text to be pre-provided
        if not extracted_text:
            logger.warning(
                "File-based extraction not yet implemented, skipping document indexing",
                extra={"document_id": document_id, "file_key": file_key},
            )
            return {
                "document_id": document_id,
                "status": "skipped",
                "reason": "Requires extracted text",
            }

        # Step 1: Chunk the document
        chunk_result = chunk_document.delay(
            document_id=document_id,
            extracted_text=extracted_text,
            metadata=metadata,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )
        chunks = chunk_result.get(timeout=120)

        # Step 2: Generate embeddings for chunks
        embedding_result = generate_embeddings.delay(
            document_id=document_id,
            chunks=chunks["chunks"],
        )
        embeddings = embedding_result.get(timeout=180)

        # Step 3: Store in vector database
        index_result = update_vector_index.delay(
            document_id=document_id,
            chunks=chunks["chunks"],
            embeddings=embeddings["embeddings"],
            metadata=metadata,
        )
        stored = index_result.get(timeout=120)

        logger.info(
            "Document indexing completed",
            extra={
                "document_id": document_id,
                "chunk_count": len(chunks["chunks"]),
                "vector_count": len(stored.get("vector_ids", [])),
            },
        )

        return {
            "document_id": document_id,
            "status": "indexed",
            "chunk_count": len(chunks["chunks"]),
            "vector_ids": stored.get("vector_ids", []),
            "collection": stored.get("collection", "documents"),
        }

    except Exception as exc:
        logger.error(
            "Document indexing failed",
            extra={
                "document_id": document_id,
                "error": str(exc),
            },
        )
        raise self.retry(exc=exc) from exc


@celery_app.task(
    name="src.workers.tasks.indexing.chunk_document",
    queue="indexing",
    time_limit=120,  # 2 minutes
)
def chunk_document(
    document_id: str,
    extracted_text: dict[str, Any],
    metadata: dict[str, Any] | None = None,
    chunk_size: int = 512,
    chunk_overlap: int = 128,
) -> dict[str, Any]:
    """Chunk a document for embedding.

    Splits document text into semantically meaningful chunks:
    - Respects sentence boundaries
    - Maintains section context
    - Preserves table structure
    - Applies overlap for context preservation

    Strategy:
    - Each chunk ~512 tokens (configurable)
    - 128 tokens overlap between chunks (configurable)
    - Chunks extracted from text_blocks preserving order

    Args:
        document_id: Document identifier
        extracted_text: Extracted text content with text_blocks
        metadata: Document metadata to include with chunks
        chunk_size: Target chunk size in tokens (default: 512)
        chunk_overlap: Overlap between chunks in tokens (default: 128)

    Returns:
        Dictionary with:
        - chunks: List of chunk dicts with id, text, page, position
        - total_chunks: Number of chunks created
        - chunk_strategy: Strategy used (always "semantic")
        - chunk_size: Size parameter used
        - chunk_overlap: Overlap parameter used
    """
    logger.info(
        "Chunking document",
        extra={
            "document_id": document_id,
            "chunk_size": chunk_size,
            "chunk_overlap": chunk_overlap,
        },
    )

    # Chunking logic would go here
    # For now, return mock chunks based on text blocks

    chunks = []
    text_blocks = extracted_text.get("text_blocks", [])

    for i, block in enumerate(text_blocks):
        chunk_id = f"{document_id}_chunk_{i}"
        chunks.append(
            {
                "id": chunk_id,
                "document_id": document_id,
                "text": block.get("text", ""),
                "page": block.get("page", 0),
                "position": i,
                "metadata": {
                    "source": "text_block",
                    "confidence": block.get("confidence", 1.0),
                    **(metadata or {}),
                },
            }
        )

    logger.info(
        "Document chunked successfully",
        extra={
            "document_id": document_id,
            "chunk_count": len(chunks),
        },
    )

    return {
        "document_id": document_id,
        "chunks": chunks,
        "total_chunks": len(chunks),
        "chunk_strategy": "semantic",
        "chunk_size": chunk_size,
        "chunk_overlap": chunk_overlap,
    }


@celery_app.task(
    name="src.workers.tasks.indexing.generate_embeddings",
    queue="indexing",
    max_retries=2,
    default_retry_delay=60,
    time_limit=300,  # 5 minutes
    soft_time_limit=270,
)
def generate_embeddings(
    document_id: str,
    chunks: list[dict[str, Any]],
    model: str = "BAAI/bge-m3",
) -> dict[str, Any]:
    """Generate embeddings for document chunks.

    Uses BGE-M3 model for multilingual dense embeddings:
    - Model: BAAI/bge-m3
    - Dimension: 1024
    - Device: GPU if available, CPU fallback
    - Batch processing for efficiency

    Generates embeddings from chunk text, creating 1024-dimensional
    vectors suitable for semantic search and similarity comparison.

    Args:
        document_id: Document identifier
        chunks: List of text chunks with 'id' and 'text' fields
        model: Embedding model name (default: "BAAI/bge-m3")

    Returns:
        Dictionary with:
        - embeddings: List of embedding objects
        - model: Model name used
        - dimension: Embedding dimension (1024)
        - total_embeddings: Number of embeddings generated

    Raises:
        Retries on failure with exponential backoff
    """
    logger.info(
        "Generating embeddings",
        extra={
            "document_id": document_id,
            "num_chunks": len(chunks),
            "model": model,
        },
    )

    # Embedding generation would go here
    # For now, return mock embeddings

    embeddings = []
    for chunk in chunks:
        # Mock 1024-dimensional embedding
        embeddings.append(
            {
                "chunk_id": chunk["id"],
                "embedding": [0.0] * 1024,  # Placeholder
                "model": model,
                "dimension": 1024,
            }
        )

    logger.info(
        "Embeddings generated successfully",
        extra={
            "document_id": document_id,
            "embedding_count": len(embeddings),
        },
    )

    return {
        "document_id": document_id,
        "embeddings": embeddings,
        "model": model,
        "dimension": 1024,
        "total_embeddings": len(embeddings),
    }


@celery_app.task(
    name="src.workers.tasks.indexing.update_vector_index",
    queue="indexing",
    max_retries=2,
    default_retry_delay=30,
    time_limit=120,  # 2 minutes
)
def update_vector_index(
    document_id: str,
    _chunks: list[dict[str, Any]],
    embeddings: list[dict[str, Any]],
    _metadata: dict[str, Any] | None = None,
    collection: str = "documents",
) -> dict[str, Any]:
    """Update the vector database with document embeddings.

    Stores embeddings in Qdrant vector database with payload
    (metadata) for filtering during retrieval.

    Each vector includes:
    - Embedding vector (1024 dimensions)
    - Chunk text for snippet generation
    - Document metadata
    - Page number for context
    - Position in document

    Args:
        document_id: Document identifier
        chunks: Text chunks with metadata
        embeddings: Corresponding embeddings
        metadata: Document-level metadata for filtering
        collection: Qdrant collection name (default: "documents")

    Returns:
        Dictionary with:
        - status: "indexed" if successful
        - vector_ids: List of created vector IDs
        - collection: Collection name used
        - upserted: Count of vectors stored

    Raises:
        Retries on failure with exponential backoff
    """
    logger.info(
        "Updating vector index",
        extra={
            "document_id": document_id,
            "num_vectors": len(embeddings),
            "collection": collection,
        },
    )

    # Vector storage would go here
    # For now, return mock result

    vector_ids = [emb["chunk_id"] for emb in embeddings]

    logger.info(
        "Vector index updated successfully",
        extra={
            "document_id": document_id,
            "vector_count": len(vector_ids),
            "collection": collection,
        },
    )

    return {
        "document_id": document_id,
        "status": "indexed",
        "vector_ids": vector_ids,
        "collection": collection,
        "upserted": len(vector_ids),
    }


@celery_app.task(
    name="src.workers.tasks.indexing.delete_document_vectors",
    queue="indexing",
    max_retries=2,
    default_retry_delay=30,
    time_limit=60,
)
def delete_document_vectors(
    document_id: str,
    collection: str = "documents",
) -> dict[str, Any]:
    """Delete all vectors for a document from vector database.

    Removes all vectors associated with a document from Qdrant.
    Used for cleanup, re-indexing, or document removal.

    Args:
        document_id: Document identifier
        collection: Qdrant collection name (default: "documents")

    Returns:
        Dictionary with:
        - status: "deleted" if successful
        - collection: Collection name
        - document_id: Document identifier

    Raises:
        Retries on failure with exponential backoff
    """
    logger.info(
        "Deleting document vectors",
        extra={
            "document_id": document_id,
            "collection": collection,
        },
    )

    # Deletion logic would go here
    # Query Qdrant by filter: document_id == value

    logger.info(
        "Document vectors deleted successfully",
        extra={
            "document_id": document_id,
            "collection": collection,
        },
    )

    return {
        "document_id": document_id,
        "status": "deleted",
        "collection": collection,
    }


@celery_app.task(
    bind=True,
    name="src.workers.tasks.indexing.reindex_document",
    queue="indexing",
    max_retries=2,
    default_retry_delay=60,
    time_limit=900,  # 15 minutes
    soft_time_limit=840,
)
def reindex_document(
    self,
    document_id: str,
    extracted_text: dict[str, Any],
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Reindex a document (delete existing vectors and re-add).

    Full reindexing cycle:
    1. Delete existing vectors from Qdrant
    2. Re-chunk the document
    3. Re-generate embeddings
    4. Re-store in vector database

    Used when document content changes or indexing strategy updates.

    Args:
        document_id: Document identifier
        extracted_text: Updated/current extracted text
        metadata: Updated metadata

    Returns:
        Reindexing result with new vector IDs

    Raises:
        Retries on failure with exponential backoff
    """
    logger.info(
        "Reindexing document",
        extra={"document_id": document_id, "task_id": self.request.id},
    )

    try:
        # Step 1: Delete existing vectors
        delete_result = delete_document_vectors.delay(document_id)
        delete_result.get(timeout=60)

        logger.info(
            "Old vectors deleted, now re-indexing",
            extra={"document_id": document_id},
        )

        # Step 2: Re-index
        result = index_document.delay(
            document_id=document_id,
            extracted_text=extracted_text,
            metadata=metadata,
        )

        reindex_result = result.get(timeout=600)

        logger.info(
            "Document reindexed successfully",
            extra={
                "document_id": document_id,
                "chunk_count": reindex_result.get("chunk_count"),
            },
        )

        return reindex_result

    except Exception as exc:
        logger.error(
            "Document reindexing failed",
            extra={
                "document_id": document_id,
                "error": str(exc),
            },
        )
        raise self.retry(exc=exc) from exc
