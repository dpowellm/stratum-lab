"""
Processing agent with tools for data transformation and validation.
"""

import logging
from typing import Dict, Any, List, Optional, Type
from pydantic import BaseModel, Field
from crewai.tools import BaseTool
from crewai import Agent

from app.tools.validation import FinancialDataValidator, ValidationResult
from app.tools.telemetry import track_time
from app.tools.util import round_currency, safe_get

logger = logging.getLogger(__name__)


# Tool Input Schemas
class AggregateDataInput(BaseModel):
    """Input schema for data aggregation."""
    qbo_data: Dict[str, Any] = Field(..., description="Raw QuickBooks data from extraction")


class ValidateDataInput(BaseModel):
    """Input schema for validation."""
    data: Dict[str, Any] = Field(..., description="Financial data to validate")
    previous_data: Optional[Dict[str, Any]] = Field(None, description="Previous run data for anomaly detection")


class FormatForSheetsInput(BaseModel):
    """Input schema for sheets formatting."""
    processed_data: Dict[str, Any] = Field(..., description="Processed financial data")
    config: Optional[Dict[str, Any]] = Field(None, description="Formatting configuration")


# Tool Implementations
class AggregateFinancialDataTool(BaseTool):
    """Aggregate and calculate financial metrics from QuickBooks data."""

    name: str = "Aggregate Financial Data"
    description: str = "Aggregates QuickBooks data and calculates key financial metrics"
    args_schema: Type[BaseModel] = AggregateDataInput

    @track_time("aggregate_data")
    def _run(self, qbo_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Aggregate financial data.

        Args:
            qbo_data: Raw QuickBooks data

        Returns:
            Aggregated metrics
        """
        try:
            logger.info("Aggregating financial data")

            metrics = {}

            # Extract P&L metrics
            if 'pnl' in qbo_data and qbo_data['pnl'].get('success'):
                pnl = qbo_data['pnl']['data']
                metrics.update(self._extract_pnl_metrics(pnl))

            # Extract Balance Sheet metrics
            if 'balance_sheet' in qbo_data and qbo_data['balance_sheet'].get('success'):
                bs = qbo_data['balance_sheet']['data']
                metrics.update(self._extract_bs_metrics(bs))

            # Extract AR Aging metrics
            if 'ar_aging' in qbo_data and qbo_data['ar_aging'].get('success'):
                ar = qbo_data['ar_aging']['data']
                metrics['ar_aging'] = self._extract_aging_metrics(ar)

            # Extract AP Aging metrics
            if 'ap_aging' in qbo_data and qbo_data['ap_aging'].get('success'):
                ap = qbo_data['ap_aging']['data']
                metrics['ap_aging'] = self._extract_aging_metrics(ap)

            # Calculate derived metrics
            metrics['derived'] = self._calculate_derived_metrics(metrics)

            logger.info(f"Aggregated {len(metrics)} metric categories")

            return {
                "success": True,
                "metrics": metrics
            }

        except Exception as e:
            logger.error(f"Data aggregation failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    def _extract_pnl_metrics(self, pnl_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract metrics from P&L report."""
        # QuickBooks P&L structure varies, this is a simplified example
        # Adjust based on actual QBO response structure

        rows = safe_get(pnl_data, 'Rows', 'Row', default=[])

        metrics = {
            'revenue': 0.0,
            'cogs': 0.0,
            'gross_profit': 0.0,
            'operating_expenses': 0.0,
            'net_income': 0.0
        }

        # Parse P&L rows (simplified - actual implementation depends on QBO structure)
        for row in rows if isinstance(rows, list) else []:
            row_type = row.get('type')
            if row_type == 'Section':
                header = safe_get(row, 'Header', 'ColData', 0, 'value', default='')

                if 'Income' in header or 'Revenue' in header:
                    metrics['revenue'] = self._sum_row_values(row)
                elif 'Cost of Goods Sold' in header or 'COGS' in header:
                    metrics['cogs'] = self._sum_row_values(row)
                elif 'Expenses' in header:
                    metrics['operating_expenses'] = self._sum_row_values(row)
                elif 'Net Income' in header:
                    metrics['net_income'] = self._sum_row_values(row)

        metrics['gross_profit'] = metrics['revenue'] - metrics['cogs']

        return {'pnl': metrics}

    def _extract_bs_metrics(self, bs_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract metrics from Balance Sheet."""
        rows = safe_get(bs_data, 'Rows', 'Row', default=[])

        metrics = {
            'total_assets': 0.0,
            'total_liabilities': 0.0,
            'total_equity': 0.0
        }

        # Parse Balance Sheet rows
        for row in rows if isinstance(rows, list) else []:
            row_type = row.get('type')
            if row_type == 'Section':
                header = safe_get(row, 'Header', 'ColData', 0, 'value', default='')

                if 'Total Assets' in header:
                    metrics['total_assets'] = self._sum_row_values(row)
                elif 'Total Liabilities' in header:
                    metrics['total_liabilities'] = self._sum_row_values(row)
                elif 'Total Equity' in header:
                    metrics['total_equity'] = self._sum_row_values(row)

        return {'balance_sheet': metrics}

    def _extract_aging_metrics(self, aging_data: Dict[str, Any]) -> Dict[str, float]:
        """Extract metrics from aging report."""
        # Simplified aging extraction
        columns = safe_get(aging_data, 'Columns', 'Column', default=[])
        rows = safe_get(aging_data, 'Rows', 'Row', default=[])

        metrics = {
            'total': 0.0,
            'current': 0.0,
            '1-30': 0.0,
            '31-60': 0.0,
            '61-90': 0.0,
            '90+': 0.0
        }

        # Parse aging buckets (simplified)
        # Actual implementation depends on QuickBooks report structure

        return metrics

    def _sum_row_values(self, row: Dict[str, Any]) -> float:
        """Sum numeric values from a row."""
        summary = safe_get(row, 'Summary', default={})
        col_data = safe_get(summary, 'ColData', default=[])

        total = 0.0
        for col in col_data if isinstance(col_data, list) else []:
            value = col.get('value', '0')
            try:
                total += float(value)
            except (ValueError, TypeError):
                pass

        return total

    def _calculate_derived_metrics(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate derived/computed metrics."""
        derived = {}

        # Get base metrics
        pnl = metrics.get('pnl', {})
        bs = metrics.get('balance_sheet', {})

        revenue = pnl.get('revenue', 0)
        net_income = pnl.get('net_income', 0)
        total_assets = bs.get('total_assets', 0)
        total_equity = bs.get('total_equity', 0)

        # Profit margin
        if revenue > 0:
            derived['profit_margin'] = (net_income / revenue) * 100
        else:
            derived['profit_margin'] = 0.0

        # ROA (Return on Assets)
        if total_assets > 0:
            derived['roa'] = (net_income / total_assets) * 100
        else:
            derived['roa'] = 0.0

        # ROE (Return on Equity)
        if total_equity > 0:
            derived['roe'] = (net_income / total_equity) * 100
        else:
            derived['roe'] = 0.0

        return derived


class ValidateFinancialDataTool(BaseTool):
    """Validate financial data with business rules."""

    name: str = "Validate Financial Data"
    description: str = "Validates financial data using schema checks, business rules, and anomaly detection"
    args_schema: Type[BaseModel] = ValidateDataInput

    def __init__(self):
        super().__init__()
        self.validator = FinancialDataValidator()

    @track_time("validate_data")
    def _run(self, data: Dict[str, Any], previous_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Validate financial data.

        Args:
            data: Current financial data
            previous_data: Previous run data for comparison

        Returns:
            Validation result
        """
        try:
            logger.info("Validating financial data")

            result = self.validator.validate_all(data, previous_data)

            return {
                "success": result.valid,
                "validation_result": {
                    "valid": result.valid,
                    "errors": [
                        {
                            "severity": issue.severity,
                            "rule": issue.rule,
                            "message": issue.message,
                            "details": issue.details
                        }
                        for issue in result.issues
                    ],
                    "error_count": len(result.errors),
                    "warning_count": len(result.warnings)
                }
            }

        except Exception as e:
            logger.error(f"Validation failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


class FormatForSheetsTool(BaseTool):
    """Format processed data for Google Sheets."""

    name: str = "Format for Google Sheets"
    description: str = "Formats financial data into ranges suitable for Google Sheets"
    args_schema: Type[BaseModel] = FormatForSheetsInput

    @track_time("format_for_sheets")
    def _run(self, processed_data: Dict[str, Any], config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Format data for Sheets.

        Args:
            processed_data: Processed financial data
            config: Formatting configuration

        Returns:
            Formatted ranges for Sheets
        """
        try:
            logger.info("Formatting data for Google Sheets")

            metrics = processed_data.get('metrics', {})
            ranges = []

            # Overview section
            ranges.append(self._format_overview(metrics))

            # P&L section
            if 'pnl' in metrics:
                ranges.append(self._format_pnl(metrics['pnl']))

            # Balance Sheet section
            if 'balance_sheet' in metrics:
                ranges.append(self._format_balance_sheet(metrics['balance_sheet']))

            # AR Aging section
            if 'ar_aging' in metrics:
                ranges.append(self._format_aging(metrics['ar_aging'], 'AR'))

            # AP Aging section
            if 'ap_aging' in metrics:
                ranges.append(self._format_aging(metrics['ap_aging'], 'AP'))

            logger.info(f"Formatted {len(ranges)} sheet ranges")

            return {
                "success": True,
                "ranges": ranges
            }

        except Exception as e:
            logger.error(f"Formatting failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    def _format_overview(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Format overview section."""
        pnl = metrics.get('pnl', {})
        derived = metrics.get('derived', {})

        values = [
            ['Metric', 'Value'],
            ['Revenue', f"${pnl.get('revenue', 0):,.2f}"],
            ['Net Income', f"${pnl.get('net_income', 0):,.2f}"],
            ['Profit Margin', f"{derived.get('profit_margin', 0):.2f}%"],
            ['ROA', f"{derived.get('roa', 0):.2f}%"],
            ['ROE', f"{derived.get('roe', 0):.2f}%"]
        ]

        return {
            'range': 'Dashboard!A1:B6',
            'values': values
        }

    def _format_pnl(self, pnl: Dict[str, float]) -> Dict[str, Any]:
        """Format P&L section."""
        values = [
            ['P&L Item', 'Amount'],
            ['Revenue', f"${pnl.get('revenue', 0):,.2f}"],
            ['COGS', f"${pnl.get('cogs', 0):,.2f}"],
            ['Gross Profit', f"${pnl.get('gross_profit', 0):,.2f}"],
            ['Operating Expenses', f"${pnl.get('operating_expenses', 0):,.2f}"],
            ['Net Income', f"${pnl.get('net_income', 0):,.2f}"]
        ]

        return {
            'range': 'Dashboard!A8:B13',
            'values': values
        }

    def _format_balance_sheet(self, bs: Dict[str, float]) -> Dict[str, Any]:
        """Format Balance Sheet section."""
        values = [
            ['Balance Sheet Item', 'Amount'],
            ['Total Assets', f"${bs.get('total_assets', 0):,.2f}"],
            ['Total Liabilities', f"${bs.get('total_liabilities', 0):,.2f}"],
            ['Total Equity', f"${bs.get('total_equity', 0):,.2f}"]
        ]

        return {
            'range': 'Dashboard!A15:B18',
            'values': values
        }

    def _format_aging(self, aging: Dict[str, float], report_type: str) -> Dict[str, Any]:
        """Format aging report section."""
        row_offset = 20 if report_type == 'AR' else 26

        values = [
            [f'{report_type} Aging', 'Amount'],
            ['Total', f"${aging.get('total', 0):,.2f}"],
            ['Current', f"${aging.get('current', 0):,.2f}"],
            ['1-30 Days', f"${aging.get('1-30', 0):,.2f}"],
            ['31-60 Days', f"${aging.get('31-60', 0):,.2f}"],
            ['61-90 Days', f"${aging.get('61-90', 0):,.2f}"],
            ['90+ Days', f"${aging.get('90+', 0):,.2f}"]
        ]

        return {
            'range': f'Dashboard!A{row_offset}:B{row_offset + 6}',
            'values': values
        }


def create_processing_agent() -> Agent:
    """
    Create processing agent with transformation and validation tools.

    Returns:
        Configured CrewAI Agent
    """
    tools = [
        AggregateFinancialDataTool(),
        ValidateFinancialDataTool(),
        FormatForSheetsTool()
    ]

    agent = Agent(
        role='Financial Data Analyst & Transformer',
        goal='Transform raw QuickBooks data into validated, formatted metrics ready for dashboard publishing',
        backstory="""You are a senior financial analyst with expertise in data transformation and validation.
        You have deep knowledge of financial metrics, P&L statements, balance sheets, and aging reports.
        You ensure data quality through rigorous validation before any data is published.
        You understand business rules and can detect anomalies that might indicate data issues.""",
        tools=tools,
        verbose=True,
        memory=True,
        allow_delegation=False
    )

    logger.info("Created processing agent")
    return agent
