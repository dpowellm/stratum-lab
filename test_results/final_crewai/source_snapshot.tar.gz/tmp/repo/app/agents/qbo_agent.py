"""
QuickBooks Online agent with tools for data extraction.
"""

import logging
from typing import Dict, Any, Optional, Type
from pydantic import BaseModel, Field
from crewai.tools import BaseTool
from crewai import Agent

from app.tools.qbo_api import QBOClient
from app.tools.telemetry import track_time

logger = logging.getLogger(__name__)


# Tool Input Schemas
class ExtractPnLInput(BaseModel):
    """Input schema for P&L extraction."""
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")


class ExtractBalanceSheetInput(BaseModel):
    """Input schema for Balance Sheet extraction."""
    date: str = Field(..., description="As-of date in YYYY-MM-DD format")


class ExtractARAgingInput(BaseModel):
    """Input schema for AR Aging extraction."""
    as_of: Optional[str] = Field(None, description="As-of date in YYYY-MM-DD format (defaults to today)")


class ExtractAPAgingInput(BaseModel):
    """Input schema for AP Aging extraction."""
    as_of: Optional[str] = Field(None, description="As-of date in YYYY-MM-DD format (defaults to today)")


class ExtractCDCInput(BaseModel):
    """Input schema for CDC extraction."""
    since: str = Field(..., description="ISO 8601 timestamp to fetch changes since")
    entities: Optional[list] = Field(
        default=["Invoice", "Bill", "Payment", "Purchase"],
        description="List of entity types to check for changes"
    )


# Tool Implementations
class ExtractPnLTool(BaseTool):
    """Extract Profit & Loss report from QuickBooks."""

    name: str = "Extract QuickBooks P&L Report"
    description: str = "Extracts Profit & Loss report from QuickBooks for a given date range"
    args_schema: Type[BaseModel] = ExtractPnLInput

    def __init__(self):
        super().__init__()
        self.qbo_client = None

    @track_time("extract_pnl")
    def _run(self, start_date: str, end_date: str) -> Dict[str, Any]:
        """
        Execute P&L extraction.

        Args:
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)

        Returns:
            P&L report data
        """
        try:
            if not self.qbo_client:
                self.qbo_client = QBOClient()

            logger.info(f"Extracting P&L from {start_date} to {end_date}")

            pnl_data = self.qbo_client.get_pnl(start_date, end_date)

            return {
                "success": True,
                "data": pnl_data,
                "start_date": start_date,
                "end_date": end_date
            }

        except Exception as e:
            logger.error(f"P&L extraction failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


class ExtractBalanceSheetTool(BaseTool):
    """Extract Balance Sheet from QuickBooks."""

    name: str = "Extract QuickBooks Balance Sheet"
    description: str = "Extracts Balance Sheet from QuickBooks for a given date"
    args_schema: Type[BaseModel] = ExtractBalanceSheetInput

    def __init__(self):
        super().__init__()
        self.qbo_client = None

    @track_time("extract_balance_sheet")
    def _run(self, date: str) -> Dict[str, Any]:
        """
        Execute Balance Sheet extraction.

        Args:
            date: As-of date (YYYY-MM-DD)

        Returns:
            Balance Sheet data
        """
        try:
            if not self.qbo_client:
                self.qbo_client = QBOClient()

            logger.info(f"Extracting Balance Sheet as of {date}")

            bs_data = self.qbo_client.get_balance_sheet(date)

            return {
                "success": True,
                "data": bs_data,
                "date": date
            }

        except Exception as e:
            logger.error(f"Balance Sheet extraction failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


class ExtractARAgingTool(BaseTool):
    """Extract Accounts Receivable aging report from QuickBooks."""

    name: str = "Extract QuickBooks AR Aging"
    description: str = "Extracts Accounts Receivable aging report from QuickBooks"
    args_schema: Type[BaseModel] = ExtractARAgingInput

    def __init__(self):
        super().__init__()
        self.qbo_client = None

    @track_time("extract_ar_aging")
    def _run(self, as_of: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute AR Aging extraction.

        Args:
            as_of: As-of date (YYYY-MM-DD), defaults to today

        Returns:
            AR Aging data
        """
        try:
            if not self.qbo_client:
                self.qbo_client = QBOClient()

            logger.info(f"Extracting AR Aging as of {as_of or 'today'}")

            ar_data = self.qbo_client.get_ar_aging(as_of)

            return {
                "success": True,
                "data": ar_data,
                "as_of": as_of or "today"
            }

        except Exception as e:
            logger.error(f"AR Aging extraction failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


class ExtractAPAgingTool(BaseTool):
    """Extract Accounts Payable aging report from QuickBooks."""

    name: str = "Extract QuickBooks AP Aging"
    description: str = "Extracts Accounts Payable aging report from QuickBooks"
    args_schema: Type[BaseModel] = ExtractAPAgingInput

    def __init__(self):
        super().__init__()
        self.qbo_client = None

    @track_time("extract_ap_aging")
    def _run(self, as_of: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute AP Aging extraction.

        Args:
            as_of: As-of date (YYYY-MM-DD), defaults to today

        Returns:
            AP Aging data
        """
        try:
            if not self.qbo_client:
                self.qbo_client = QBOClient()

            logger.info(f"Extracting AP Aging as of {as_of or 'today'}")

            ap_data = self.qbo_client.get_ap_aging(as_of)

            return {
                "success": True,
                "data": ap_data,
                "as_of": as_of or "today"
            }

        except Exception as e:
            logger.error(f"AP Aging extraction failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


class ExtractCDCTool(BaseTool):
    """Extract changes using QuickBooks CDC (Change Data Capture)."""

    name: str = "Extract QuickBooks Changes (CDC)"
    description: str = "Extracts changed entities from QuickBooks since a given timestamp"
    args_schema: Type[BaseModel] = ExtractCDCInput

    def __init__(self):
        super().__init__()
        self.qbo_client = None

    @track_time("extract_cdc")
    def _run(self, since: str, entities: Optional[list] = None) -> Dict[str, Any]:
        """
        Execute CDC extraction.

        Args:
            since: ISO 8601 timestamp
            entities: List of entity types to check

        Returns:
            Dictionary of changed entities
        """
        try:
            if not self.qbo_client:
                self.qbo_client = QBOClient()

            if entities is None:
                entities = ["Invoice", "Bill", "Payment", "Purchase"]

            logger.info(f"Extracting CDC changes since {since}")

            changes = self.qbo_client.get_changes(since, entities)

            total_changes = sum(len(items) for items in changes.values())

            return {
                "success": True,
                "changes": changes,
                "total_changes": total_changes,
                "since": since
            }

        except Exception as e:
            logger.error(f"CDC extraction failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


def create_qbo_agent() -> Agent:
    """
    Create QuickBooks agent with extraction tools.

    Returns:
        Configured CrewAI Agent
    """
    # Initialize tools
    tools = [
        ExtractPnLTool(),
        ExtractBalanceSheetTool(),
        ExtractARAgingTool(),
        ExtractAPAgingTool(),
        ExtractCDCTool()
    ]

    # Create agent
    agent = Agent(
        role='QuickBooks Financial Data Specialist',
        goal='Extract accurate and complete financial data from QuickBooks Online API',
        backstory="""You are an expert in QuickBooks Online API with 10+ years of experience.
        You specialize in extracting financial reports, aging data, and change data capture.
        You always ensure data completeness and handle API errors gracefully.
        You understand the nuances of QuickBooks reports and know how to interpret the data structures.""",
        tools=tools,
        verbose=True,
        memory=True,
        allow_delegation=False
    )

    logger.info("Created QuickBooks agent")
    return agent
