"""
Orchestrator that coordinates QuickBooks → Processing → Sheets workflow.
Supports dry-run mode and user confirmation.
"""

import os
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from crewai import Crew, Task, Process

from app.agents.qbo_agent import create_qbo_agent
from app.agents.processing_agent import create_processing_agent
from app.agents.sheets_agent import create_sheets_agent
from app.tools.telemetry import TelemetryContext, setup_logging
from app.tools.util import get_date_range, iso_now

logger = logging.getLogger(__name__)


class WorkflowOrchestrator:
    """
    Orchestrates the end-to-end QuickBooks → Sheets workflow.

    Workflow:
    1. QBO Agent: Extract financial data
    2. Processing Agent: Transform and validate
    3. Sheets Agent: Write and verify

    Modes:
    - dry_run: Preview changes without publishing
    - publish: Execute full workflow with verification
    """

    def __init__(self, run_id: Optional[str] = None):
        """
        Initialize orchestrator.

        Args:
            run_id: Unique run identifier
        """
        self.run_id = run_id
        self.telemetry_context = None
        self.crew = None

    def run(
        self,
        mode: str = "publish",
        days: int = 30,
        use_cdc: bool = False,
        cdc_since: Optional[str] = None,
        require_confirmation: bool = False
    ) -> Dict[str, Any]:
        """
        Execute workflow.

        Args:
            mode: 'dry_run' or 'publish'
            days: Number of days of data to extract
            use_cdc: Whether to use CDC instead of full extraction
            cdc_since: ISO timestamp for CDC (if use_cdc=True)
            require_confirmation: Whether to require user confirmation before publishing

        Returns:
            Workflow result
        """
        # Setup logging
        log_level = os.getenv('LOG_LEVEL', 'INFO')
        setup_logging(log_level)

        # Initialize telemetry
        realm_id = os.getenv('QBO_REALM_ID')
        self.telemetry_context = TelemetryContext(
            run_id=self.run_id,
            realm_id=realm_id
        )

        with self.telemetry_context as ctx:
            try:
                logger.info(
                    "Starting workflow",
                    extra={
                        "run_id": self.run_id,
                        "mode": mode,
                        "days": days,
                        "use_cdc": use_cdc
                    }
                )

                # Determine date range
                if use_cdc and cdc_since:
                    date_info = {
                        "mode": "cdc",
                        "since": cdc_since
                    }
                else:
                    start_date, end_date = get_date_range(days)
                    date_info = {
                        "mode": "full",
                        "start_date": start_date,
                        "end_date": end_date,
                        "days": days
                    }

                # Create agents
                qbo_agent = create_qbo_agent()
                processing_agent = create_processing_agent()
                sheets_agent = create_sheets_agent()

                # Create tasks
                extract_task = self._create_extract_task(qbo_agent, date_info)
                process_task = self._create_process_task(processing_agent, extract_task)
                publish_task = self._create_publish_task(sheets_agent, process_task, mode)

                # Create crew
                self.crew = Crew(
                    agents=[qbo_agent, processing_agent, sheets_agent],
                    tasks=[extract_task, process_task, publish_task],
                    process=Process.sequential,
                    verbose=2,
                    memory=True,
                    cache=True,
                    max_rpm=10  # Rate limiting
                )

                # Dry run confirmation
                if mode == "dry_run":
                    logger.info("DRY RUN MODE: No data will be published")

                # Confirmation check
                if require_confirmation and mode == "publish":
                    logger.warning("CONFIRMATION REQUIRED: Set CONFIRM_PUBLISH=true to proceed")
                    if not os.getenv('CONFIRM_PUBLISH', '').lower() == 'true':
                        return {
                            "success": False,
                            "error": "Publishing requires confirmation. Set CONFIRM_PUBLISH=true",
                            "mode": mode
                        }

                # Execute workflow
                logger.info("Executing crew workflow")
                result = self.crew.kickoff()

                # Add metrics
                ctx.add_metric("mode", mode)
                ctx.add_metric("date_info", date_info)

                logger.info(
                    "Workflow completed successfully",
                    extra={"result": str(result)[:200]}
                )

                return {
                    "success": True,
                    "run_id": self.run_id,
                    "mode": mode,
                    "result": result,
                    "metrics": ctx.metrics
                }

            except Exception as e:
                logger.error(f"Workflow failed: {e}", exc_info=True)
                ctx.record_error("WORKFLOW_FAILURE", str(e))

                return {
                    "success": False,
                    "run_id": self.run_id,
                    "error": str(e),
                    "metrics": ctx.metrics
                }

    def _create_extract_task(self, agent, date_info: Dict[str, Any]) -> Task:
        """Create extraction task."""
        if date_info["mode"] == "cdc":
            description = f"""
            Extract changed financial data from QuickBooks using CDC (Change Data Capture).

            Fetch changes since: {date_info['since']}

            Use the Extract QuickBooks Changes (CDC) tool to get incremental updates.

            Return a dictionary with all changed entities.
            """
        else:
            description = f"""
            Extract financial data from QuickBooks for the date range:
            Start Date: {date_info['start_date']}
            End Date: {date_info['end_date']}

            Extract the following reports:
            1. Profit & Loss (P&L) for the date range
            2. Balance Sheet as of {date_info['end_date']}
            3. Accounts Receivable (AR) Aging as of {date_info['end_date']}
            4. Accounts Payable (AP) Aging as of {date_info['end_date']}

            Use the appropriate extraction tools and return a dictionary containing
            all extracted data with keys: pnl, balance_sheet, ar_aging, ap_aging.
            """

        return Task(
            description=description,
            agent=agent,
            expected_output="Dictionary with extracted QuickBooks data (pnl, balance_sheet, ar_aging, ap_aging)"
        )

    def _create_process_task(self, agent, context_task: Task) -> Task:
        """Create processing task."""
        description = """
        Process the extracted QuickBooks data:

        1. Aggregate the data and calculate key financial metrics
        2. Validate the data using business rules and schema validation
        3. Format the data for Google Sheets ranges

        Ensure all validations pass before formatting for Sheets.
        If validation fails with errors, do not proceed to formatting.

        Return a dictionary with:
        - processed_data: aggregated metrics
        - validation_result: validation status and issues
        - formatted_ranges: list of range/values dicts for Sheets
        """

        return Task(
            description=description,
            agent=agent,
            expected_output="Dictionary with processed_data, validation_result, and formatted_ranges",
            context=[context_task]
        )

    def _create_publish_task(self, agent, context_task: Task, mode: str) -> Task:
        """Create publishing task."""
        if mode == "dry_run":
            description = """
            DRY RUN MODE: Preview the changes without publishing.

            Analyze the formatted_ranges from the processing agent and:
            1. Log a summary of what would be written to each range
            2. Display the number of rows and cells that would be updated
            3. Generate a summary report

            DO NOT write any data to Google Sheets in dry run mode.

            Return a summary dictionary with preview information.
            """
        else:
            description = """
            Publish validated data to Google Sheets:

            1. Write the formatted ranges to Google Sheets using batch update
            2. Verify that all writes succeeded
            3. Generate a summary of the update

            Use the Write to Google Sheets tool with verification enabled.

            Return a dictionary with write results, checksums, and summary.
            """

        return Task(
            description=description,
            agent=agent,
            expected_output="Dictionary with publish results and summary",
            context=[context_task]
        )


def run_workflow(
    mode: str = "publish",
    days: int = 30,
    use_cdc: bool = False,
    cdc_since: Optional[str] = None,
    require_confirmation: bool = False
) -> Dict[str, Any]:
    """
    Convenience function to run workflow.

    Args:
        mode: 'dry_run' or 'publish'
        days: Number of days of data
        use_cdc: Use CDC instead of full extraction
        cdc_since: ISO timestamp for CDC
        require_confirmation: Require confirmation before publishing

    Returns:
        Workflow result
    """
    import uuid

    orchestrator = WorkflowOrchestrator(run_id=str(uuid.uuid4()))

    return orchestrator.run(
        mode=mode,
        days=days,
        use_cdc=use_cdc,
        cdc_since=cdc_since,
        require_confirmation=require_confirmation
    )
