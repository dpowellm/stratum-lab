"""
QuickBooks webhook signature verification using HMAC-SHA256.
"""

import os
import hmac
import hashlib
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def verify_webhook_signature(
    payload: bytes,
    signature: str,
    verifier_token: Optional[str] = None
) -> bool:
    """
    Verify Intuit webhook signature.

    QuickBooks sends webhook events with an 'intuit-signature' header
    containing an HMAC-SHA256 hash of the payload.

    Args:
        payload: Raw request body bytes
        signature: Signature from 'intuit-signature' header
        verifier_token: Verifier token (from env if not provided)

    Returns:
        True if signature is valid

    Raises:
        ValueError: If verifier token is missing
    """
    if verifier_token is None:
        verifier_token = os.getenv('QBO_VERIFIER_TOKEN')

    if not verifier_token:
        logger.error("Missing QBO_VERIFIER_TOKEN for webhook verification")
        raise ValueError("QBO_VERIFIER_TOKEN is required for webhook verification")

    try:
        # Compute HMAC-SHA256
        expected_signature = hmac.new(
            verifier_token.encode('utf-8'),
            payload,
            hashlib.sha256
        ).hexdigest()

        # Compare signatures (constant-time comparison)
        is_valid = hmac.compare_digest(signature, expected_signature)

        if is_valid:
            logger.info("Webhook signature verified successfully")
        else:
            logger.warning(
                "Webhook signature verification failed",
                extra={
                    "received_signature": signature[:16] + "...",
                    "expected_signature": expected_signature[:16] + "..."
                }
            )

        return is_valid

    except Exception as e:
        logger.error(f"Signature verification error: {e}")
        return False


def extract_signature_from_header(header_value: str) -> Optional[str]:
    """
    Extract signature from Intuit-Signature header.

    The header format is typically: "intuit-signature: <signature>"

    Args:
        header_value: Value of intuit-signature header

    Returns:
        Signature string or None
    """
    if not header_value:
        return None

    # Handle various formats
    if '=' in header_value:
        # Format: "intuit-signature=abc123" or "signature=abc123"
        parts = header_value.split('=', 1)
        return parts[1].strip() if len(parts) == 2 else header_value

    # Direct signature value
    return header_value.strip()
