"""
Data validation and business rule checks for financial data.
"""

import logging
from typing import Dict, List, Any, Optional, Tuple
from decimal import Decimal, ROUND_HALF_UP
from pydantic import BaseModel, Field, validator
from enum import Enum

logger = logging.getLogger(__name__)


class ValidationSeverity(str, Enum):
    """Validation issue severity levels."""
    ERROR = "ERROR"  # Blocks publishing
    WARNING = "WARNING"  # Logs but allows publishing
    INFO = "INFO"  # Informational only


class ValidationIssue(BaseModel):
    """Validation issue details."""
    severity: ValidationSeverity
    rule: str
    message: str
    details: Dict[str, Any] = Field(default_factory=dict)


class ValidationResult(BaseModel):
    """Validation result container."""
    valid: bool
    issues: List[ValidationIssue] = Field(default_factory=list)

    @property
    def errors(self) -> List[ValidationIssue]:
        """Get only error-level issues."""
        return [i for i in self.issues if i.severity == ValidationSeverity.ERROR]

    @property
    def warnings(self) -> List[ValidationIssue]:
        """Get only warning-level issues."""
        return [i for i in self.issues if i.severity == ValidationSeverity.WARNING]


class FinancialDataValidator:
    """
    Validates financial data with:
    - Schema validation (types, presence)
    - Currency rounding (2 decimals)
    - Non-negative invariants
    - P&L equation checks
    - Aging bucket totals
    - Anomaly detection (vs. prior run)
    """

    DECIMAL_PLACES = 2
    ROUNDING_MODE = ROUND_HALF_UP

    def __init__(self, tolerance: float = 0.01, anomaly_threshold: float = 0.25):
        """
        Initialize validator.

        Args:
            tolerance: Tolerance for numeric equality (default 1 cent)
            anomaly_threshold: Max % change for anomaly detection (default 25%)
        """
        self.tolerance = tolerance
        self.anomaly_threshold = anomaly_threshold

    def _round_currency(self, value: float) -> Decimal:
        """Round to 2 decimal places (currency standard)."""
        decimal_value = Decimal(str(value))
        return decimal_value.quantize(
            Decimal('0.01'),
            rounding=self.ROUNDING_MODE
        )

    def _approx_equal(self, a: float, b: float) -> bool:
        """Check if two numbers are approximately equal within tolerance."""
        return abs(a - b) <= self.tolerance

    def validate_schema(
        self,
        data: Dict[str, Any],
        required_fields: List[str]
    ) -> ValidationResult:
        """
        Validate data schema (presence and basic types).

        Args:
            data: Data dictionary to validate
            required_fields: List of required field names

        Returns:
            ValidationResult
        """
        result = ValidationResult(valid=True)

        for field in required_fields:
            if field not in data:
                result.issues.append(
                    ValidationIssue(
                        severity=ValidationSeverity.ERROR,
                        rule="REQUIRED_FIELD",
                        message=f"Missing required field: {field}",
                        details={"field": field}
                    )
                )
                result.valid = False

            elif data[field] is None:
                result.issues.append(
                    ValidationIssue(
                        severity=ValidationSeverity.ERROR,
                        rule="NULL_VALUE",
                        message=f"Field cannot be null: {field}",
                        details={"field": field}
                    )
                )
                result.valid = False

        return result

    def validate_currency_values(
        self,
        data: Dict[str, float],
        fields: Optional[List[str]] = None
    ) -> ValidationResult:
        """
        Validate currency values (rounding, format).

        Args:
            data: Data dictionary
            fields: Fields to validate (all numeric if None)

        Returns:
            ValidationResult
        """
        result = ValidationResult(valid=True)

        fields_to_check = fields or [k for k, v in data.items() if isinstance(v, (int, float))]

        for field in fields_to_check:
            if field not in data:
                continue

            value = data[field]

            if not isinstance(value, (int, float)):
                result.issues.append(
                    ValidationIssue(
                        severity=ValidationSeverity.ERROR,
                        rule="INVALID_TYPE",
                        message=f"Field must be numeric: {field}",
                        details={"field": field, "value": value, "type": type(value).__name__}
                    )
                )
                result.valid = False
                continue

            # Check decimal places
            rounded = float(self._round_currency(value))
            if not self._approx_equal(value, rounded):
                result.issues.append(
                    ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        rule="ROUNDING",
                        message=f"Value should be rounded to 2 decimals: {field}",
                        details={"field": field, "original": value, "rounded": rounded}
                    )
                )

        return result

    def validate_non_negative(
        self,
        data: Dict[str, float],
        fields: List[str]
    ) -> ValidationResult:
        """
        Validate that specified fields are non-negative.

        Args:
            data: Data dictionary
            fields: Fields that must be non-negative

        Returns:
            ValidationResult
        """
        result = ValidationResult(valid=True)

        for field in fields:
            if field not in data:
                continue

            value = data[field]

            if not isinstance(value, (int, float)):
                continue

            if value < 0:
                result.issues.append(
                    ValidationIssue(
                        severity=ValidationSeverity.ERROR,
                        rule="NEGATIVE_VALUE",
                        message=f"Field cannot be negative: {field}",
                        details={"field": field, "value": value}
                    )
                )
                result.valid = False

        return result

    def validate_pnl_equation(
        self,
        revenue: float,
        cogs: float,
        opex: float,
        net_income: float
    ) -> ValidationResult:
        """
        Validate P&L equation: Net Income = Revenue - COGS - OPEX.

        Args:
            revenue: Total revenue
            cogs: Cost of goods sold
            opex: Operating expenses
            net_income: Net income

        Returns:
            ValidationResult
        """
        result = ValidationResult(valid=True)

        calculated_net = revenue - cogs - opex

        if not self._approx_equal(calculated_net, net_income):
            result.issues.append(
                ValidationIssue(
                    severity=ValidationSeverity.ERROR,
                    rule="PNL_EQUATION",
                    message="P&L equation mismatch: Net Income != Revenue - COGS - OPEX",
                    details={
                        "revenue": revenue,
                        "cogs": cogs,
                        "opex": opex,
                        "reported_net_income": net_income,
                        "calculated_net_income": calculated_net,
                        "difference": abs(calculated_net - net_income)
                    }
                )
            )
            result.valid = False

        return result

    def validate_aging_buckets(
        self,
        buckets: Dict[str, float],
        total: float,
        bucket_names: Optional[List[str]] = None
    ) -> ValidationResult:
        """
        Validate aging report: sum(buckets) == total.

        Args:
            buckets: Dictionary of aging buckets (e.g., {"0-30": 1000, "31-60": 500})
            total: Expected total
            bucket_names: Specific bucket names to sum (all if None)

        Returns:
            ValidationResult
        """
        result = ValidationResult(valid=True)

        bucket_names = bucket_names or list(buckets.keys())
        calculated_total = sum(buckets.get(name, 0) for name in bucket_names)

        if not self._approx_equal(calculated_total, total):
            result.issues.append(
                ValidationIssue(
                    severity=ValidationSeverity.ERROR,
                    rule="AGING_TOTAL",
                    message="Aging buckets don't sum to total",
                    details={
                        "buckets": buckets,
                        "calculated_total": calculated_total,
                        "reported_total": total,
                        "difference": abs(calculated_total - total)
                    }
                )
            )
            result.valid = False

        return result

    def validate_category_sum(
        self,
        categories: Dict[str, float],
        total: float,
        category_names: Optional[List[str]] = None
    ) -> ValidationResult:
        """
        Validate that category values sum to total.

        Args:
            categories: Category values
            total: Expected total
            category_names: Specific categories to sum (all if None)

        Returns:
            ValidationResult
        """
        result = ValidationResult(valid=True)

        category_names = category_names or list(categories.keys())
        calculated_total = sum(categories.get(name, 0) for name in category_names)

        if not self._approx_equal(calculated_total, total):
            result.issues.append(
                ValidationIssue(
                    severity=ValidationSeverity.ERROR,
                    rule="CATEGORY_SUM",
                    message="Categories don't sum to total",
                    details={
                        "categories": {k: categories.get(k, 0) for k in category_names},
                        "calculated_total": calculated_total,
                        "reported_total": total,
                        "difference": abs(calculated_total - total)
                    }
                )
            )
            result.valid = False

        return result

    def detect_anomalies(
        self,
        current: Dict[str, float],
        previous: Dict[str, float],
        fields: Optional[List[str]] = None
    ) -> ValidationResult:
        """
        Detect anomalies by comparing current vs. previous run.

        Args:
            current: Current metrics
            previous: Previous metrics
            fields: Fields to check (all common if None)

        Returns:
            ValidationResult
        """
        result = ValidationResult(valid=True)

        fields_to_check = fields or list(set(current.keys()) & set(previous.keys()))

        for field in fields_to_check:
            if field not in current or field not in previous:
                continue

            curr_val = current[field]
            prev_val = previous[field]

            if not isinstance(curr_val, (int, float)) or not isinstance(prev_val, (int, float)):
                continue

            # Avoid division by zero
            if prev_val == 0:
                if curr_val != 0:
                    result.issues.append(
                        ValidationIssue(
                            severity=ValidationSeverity.WARNING,
                            rule="ANOMALY",
                            message=f"Value changed from 0 to {curr_val}: {field}",
                            details={"field": field, "current": curr_val, "previous": prev_val}
                        )
                    )
                continue

            # Calculate % change
            pct_change = abs((curr_val - prev_val) / prev_val)

            if pct_change > self.anomaly_threshold:
                result.issues.append(
                    ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        rule="ANOMALY",
                        message=f"Large change detected in {field}: {pct_change:.1%}",
                        details={
                            "field": field,
                            "current": curr_val,
                            "previous": prev_val,
                            "pct_change": pct_change,
                            "threshold": self.anomaly_threshold
                        }
                    )
                )

        return result

    def validate_all(
        self,
        data: Dict[str, Any],
        previous_data: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        """
        Run comprehensive validation suite.

        Args:
            data: Current financial data
            previous_data: Previous run data for anomaly detection

        Returns:
            Aggregated ValidationResult
        """
        all_results = ValidationResult(valid=True)

        # Run all validation checks and aggregate results
        validations = []

        # Schema validation (example required fields)
        if 'metrics' in data:
            validations.append(
                self.validate_schema(
                    data['metrics'],
                    ['revenue', 'expenses', 'net_income']
                )
            )

        # Currency validation
        if 'metrics' in data:
            validations.append(
                self.validate_currency_values(data['metrics'])
            )

        # Non-negative checks (example: AR/AP should be non-negative)
        if 'ar_aging' in data:
            validations.append(
                self.validate_non_negative(
                    data['ar_aging'],
                    ['total', 'current', '1-30', '31-60', '61-90', '90+']
                )
            )

        # Anomaly detection
        if previous_data and 'metrics' in data and 'metrics' in previous_data:
            validations.append(
                self.detect_anomalies(
                    data['metrics'],
                    previous_data['metrics']
                )
            )

        # Aggregate all issues
        for validation in validations:
            all_results.issues.extend(validation.issues)
            if not validation.valid:
                all_results.valid = False

        # Log summary
        if all_results.issues:
            logger.warning(
                f"Validation completed with {len(all_results.issues)} issues",
                extra={
                    "errors": len(all_results.errors),
                    "warnings": len(all_results.warnings),
                    "valid": all_results.valid
                }
            )
        else:
            logger.info("All validations passed")

        return all_results
