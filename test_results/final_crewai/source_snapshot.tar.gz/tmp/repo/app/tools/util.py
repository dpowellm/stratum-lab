"""
Utility functions for pagination, backoff/retries, time windows, currency utils.
"""

import time
import random
from datetime import datetime, timedelta
from typing import Optional, Callable, Any, TypeVar
from decimal import Decimal, ROUND_HALF_UP
import logging

logger = logging.getLogger(__name__)

T = TypeVar('T')


def format_date(date_obj: datetime) -> str:
    """
    Format datetime to YYYY-MM-DD string.

    Args:
        date_obj: datetime object

    Returns:
        Date string in YYYY-MM-DD format
    """
    return date_obj.strftime('%Y-%m-%d')


def parse_date(date_str: str) -> datetime:
    """
    Parse YYYY-MM-DD string to datetime.

    Args:
        date_str: Date string in YYYY-MM-DD format

    Returns:
        datetime object
    """
    return datetime.strptime(date_str, '%Y-%m-%d')


def get_date_range(days: int = 30, end_date: Optional[datetime] = None) -> tuple[str, str]:
    """
    Get date range for last N days.

    Args:
        days: Number of days to look back
        end_date: End date (defaults to today)

    Returns:
        Tuple of (start_date, end_date) as YYYY-MM-DD strings
    """
    if end_date is None:
        end_date = datetime.utcnow()

    start_date = end_date - timedelta(days=days)

    return format_date(start_date), format_date(end_date)


def get_time_windows(
    start_date: str,
    end_date: str,
    window_days: int = 30
) -> list[tuple[str, str]]:
    """
    Split date range into smaller windows for pagination.

    Args:
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        window_days: Window size in days

    Returns:
        List of (window_start, window_end) tuples
    """
    windows = []

    current_start = parse_date(start_date)
    final_end = parse_date(end_date)

    while current_start < final_end:
        current_end = min(current_start + timedelta(days=window_days), final_end)
        windows.append((
            format_date(current_start),
            format_date(current_end)
        ))
        current_start = current_end + timedelta(days=1)

    return windows


def round_currency(value: float, decimals: int = 2) -> Decimal:
    """
    Round currency value to specified decimal places.

    Args:
        value: Numeric value
        decimals: Number of decimal places (default: 2)

    Returns:
        Rounded Decimal
    """
    decimal_value = Decimal(str(value))
    quantizer = Decimal(10) ** -decimals
    return decimal_value.quantize(quantizer, rounding=ROUND_HALF_UP)


def format_currency(value: float, currency: str = "USD") -> str:
    """
    Format value as currency string.

    Args:
        value: Numeric value
        currency: Currency code

    Returns:
        Formatted currency string
    """
    rounded = round_currency(value)

    if currency == "USD":
        return f"${rounded:,.2f}"
    elif currency == "EUR":
        return f"€{rounded:,.2f}"
    elif currency == "GBP":
        return f"£{rounded:,.2f}"
    else:
        return f"{rounded:,.2f} {currency}"


def exponential_backoff_with_jitter(
    attempt: int,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    jitter: bool = True
) -> float:
    """
    Calculate exponential backoff delay with optional jitter.

    Args:
        attempt: Attempt number (0-indexed)
        base_delay: Base delay in seconds
        max_delay: Maximum delay in seconds
        jitter: Whether to add random jitter

    Returns:
        Delay in seconds
    """
    delay = min(base_delay * (2 ** attempt), max_delay)

    if jitter:
        delay += random.uniform(0, delay * 0.1)  # Add up to 10% jitter

    return delay


def retry_with_backoff(
    func: Callable[..., T],
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    retry_on: tuple = (Exception,),
    on_retry: Optional[Callable[[Exception, int], None]] = None
) -> T:
    """
    Retry function with exponential backoff.

    Args:
        func: Function to retry
        max_retries: Maximum number of retries
        base_delay: Base delay in seconds
        max_delay: Maximum delay in seconds
        retry_on: Tuple of exception types to retry on
        on_retry: Callback for retry events

    Returns:
        Function result

    Raises:
        Last exception if all retries fail
    """
    last_exception = None

    for attempt in range(max_retries):
        try:
            return func()
        except retry_on as e:
            last_exception = e

            if attempt < max_retries - 1:
                delay = exponential_backoff_with_jitter(attempt, base_delay, max_delay)

                logger.warning(
                    f"Retry attempt {attempt + 1}/{max_retries} after {delay:.2f}s",
                    extra={'error': str(e), 'delay': delay}
                )

                if on_retry:
                    on_retry(e, attempt)

                time.sleep(delay)
            else:
                logger.error(f"Max retries ({max_retries}) exceeded")
                raise

    if last_exception:
        raise last_exception


def paginate(
    fetch_func: Callable[[int, int], list],
    page_size: int = 100,
    max_items: Optional[int] = None
) -> list:
    """
    Generic pagination helper.

    Args:
        fetch_func: Function that accepts (offset, limit) and returns items
        page_size: Items per page
        max_items: Maximum total items to fetch

    Returns:
        List of all items
    """
    all_items = []
    offset = 0

    while True:
        # Determine limit for this page
        if max_items:
            remaining = max_items - len(all_items)
            if remaining <= 0:
                break
            limit = min(page_size, remaining)
        else:
            limit = page_size

        # Fetch page
        items = fetch_func(offset, limit)

        if not items:
            break

        all_items.extend(items)

        if len(items) < page_size:
            break

        offset += page_size

    return all_items


def chunk_list(items: list, chunk_size: int) -> list[list]:
    """
    Split list into chunks.

    Args:
        items: List to chunk
        chunk_size: Size of each chunk

    Returns:
        List of chunks
    """
    return [items[i:i + chunk_size] for i in range(0, len(items), chunk_size)]


def safe_get(d: dict, *keys, default=None):
    """
    Safely get nested dictionary value.

    Args:
        d: Dictionary
        *keys: Nested keys
        default: Default value if key not found

    Returns:
        Value or default

    Example:
        safe_get(data, 'user', 'profile', 'email', default='N/A')
    """
    for key in keys:
        if isinstance(d, dict):
            d = d.get(key)
            if d is None:
                return default
        else:
            return default
    return d


def coalesce(*values):
    """
    Return first non-None value.

    Args:
        *values: Values to check

    Returns:
        First non-None value or None
    """
    for value in values:
        if value is not None:
            return value
    return None


def iso_now() -> str:
    """
    Get current UTC timestamp in ISO 8601 format.

    Returns:
        ISO timestamp string
    """
    return datetime.utcnow().isoformat() + 'Z'


def iso_to_datetime(iso_str: str) -> datetime:
    """
    Parse ISO 8601 timestamp to datetime.

    Args:
        iso_str: ISO timestamp string

    Returns:
        datetime object
    """
    # Handle both with and without 'Z' suffix
    if iso_str.endswith('Z'):
        iso_str = iso_str[:-1] + '+00:00'

    return datetime.fromisoformat(iso_str)


def calculate_percentage_change(current: float, previous: float) -> Optional[float]:
    """
    Calculate percentage change between two values.

    Args:
        current: Current value
        previous: Previous value

    Returns:
        Percentage change (as decimal, e.g., 0.25 = 25%) or None if previous is 0
    """
    if previous == 0:
        return None if current == 0 else float('inf')

    return (current - previous) / previous


def truncate_string(s: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    Truncate string to max length.

    Args:
        s: String to truncate
        max_length: Maximum length
        suffix: Suffix to append if truncated

    Returns:
        Truncated string
    """
    if len(s) <= max_length:
        return s

    return s[:max_length - len(suffix)] + suffix
