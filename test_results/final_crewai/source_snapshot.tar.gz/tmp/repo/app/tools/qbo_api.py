"""
QuickBooks Online API wrapper with OAuth2, CDC, and robust error handling.
Always uses minorversion=75 for all Accounting API calls.
"""

import os
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from enum import Enum
import httpx
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class QBOErrorType(str, Enum):
    """QuickBooks error taxonomy for structured error handling."""
    AUTH = "AUTH"
    RATE_LIMIT = "RATE_LIMIT"
    VALIDATION = "VALIDATION"
    WRITE_FAIL = "WRITE_FAIL"
    NETWORK = "NETWORK"
    UNKNOWN = "UNKNOWN"


class QBOException(Exception):
    """Base exception for QuickBooks API errors."""
    def __init__(self, message: str, error_type: QBOErrorType, details: Optional[Dict] = None):
        super().__init__(message)
        self.error_type = error_type
        self.details = details or {}


class TokenResponse(BaseModel):
    """OAuth token response schema."""
    access_token: str
    refresh_token: str
    expires_in: int
    x_refresh_token_expires_in: int


class QBOClient:
    """
    QuickBooks Online API client with:
    - Automatic OAuth2 token refresh
    - Always uses minorversion=75
    - CDC (Change Data Capture) support
    - Pagination and rate limiting
    - Exponential backoff with jitter
    """

    MINOR_VERSION = 75  # Global default for all API calls
    BASE_URL_SANDBOX = "https://sandbox-quickbooks.api.intuit.com"
    BASE_URL_PROD = "https://quickbooks.api.intuit.com"
    TOKEN_URL = "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer"

    def __init__(
        self,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        refresh_token: Optional[str] = None,
        realm_id: Optional[str] = None,
        environment: str = "sandbox",
        minor_version: int = MINOR_VERSION
    ):
        """
        Initialize QBO client.

        Args:
            client_id: OAuth client ID
            client_secret: OAuth client secret
            refresh_token: OAuth refresh token
            realm_id: QuickBooks company ID
            environment: 'sandbox' or 'production'
            minor_version: API minor version (default: 75)
        """
        self.client_id = client_id or os.getenv("QBO_CLIENT_ID")
        self.client_secret = client_secret or os.getenv("QBO_CLIENT_SECRET")
        self.refresh_token = refresh_token or os.getenv("QBO_REFRESH_TOKEN")
        self.realm_id = realm_id or os.getenv("QBO_REALM_ID")
        self.environment = environment or os.getenv("QBO_ENV", "sandbox")
        self.minor_version = minor_version

        self.base_url = (
            self.BASE_URL_SANDBOX if self.environment == "sandbox"
            else self.BASE_URL_PROD
        )

        self.access_token: Optional[str] = None
        self.token_expires_at: Optional[datetime] = None
        self._http_client = httpx.Client(timeout=30.0)

        # Validate credentials
        if not all([self.client_id, self.client_secret, self.refresh_token, self.realm_id]):
            raise QBOException(
                "Missing required QBO credentials",
                QBOErrorType.AUTH,
                {"required": ["client_id", "client_secret", "refresh_token", "realm_id"]}
            )

    def _refresh_access_token(self) -> TokenResponse:
        """
        Refresh OAuth access token using refresh token.

        Returns:
            TokenResponse with new tokens

        Raises:
            QBOException: If refresh fails
        """
        logger.info("Refreshing QBO access token")

        try:
            response = self._http_client.post(
                self.TOKEN_URL,
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                auth=(self.client_id, self.client_secret),
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": self.refresh_token,
                }
            )
            response.raise_for_status()

            token_data = TokenResponse(**response.json())

            # Update stored tokens
            self.access_token = token_data.access_token
            self.refresh_token = token_data.refresh_token
            self.token_expires_at = datetime.utcnow() + timedelta(seconds=token_data.expires_in - 300)  # 5min buffer

            logger.info(
                "Token refreshed successfully",
                extra={"expires_in": token_data.expires_in}
            )

            return token_data

        except httpx.HTTPStatusError as e:
            logger.error(f"Token refresh failed: {e.response.text}")
            raise QBOException(
                f"OAuth token refresh failed: {e.response.status_code}",
                QBOErrorType.AUTH,
                {"status_code": e.response.status_code, "response": e.response.text}
            )
        except Exception as e:
            logger.error(f"Unexpected error during token refresh: {e}")
            raise QBOException(
                f"Token refresh error: {str(e)}",
                QBOErrorType.AUTH
            )

    def _ensure_valid_token(self) -> None:
        """Ensure access token is valid, refresh if needed."""
        if not self.access_token or not self.token_expires_at or datetime.utcnow() >= self.token_expires_at:
            self._refresh_access_token()

    def _build_headers(self) -> Dict[str, str]:
        """Build request headers with auth token."""
        self._ensure_valid_token()
        return {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.access_token}",
        }

    def _request_with_retry(
        self,
        method: str,
        url: str,
        max_retries: int = 3,
        **kwargs
    ) -> httpx.Response:
        """
        Make HTTP request with exponential backoff retry logic.

        Args:
            method: HTTP method
            url: Request URL
            max_retries: Maximum retry attempts
            **kwargs: Additional request parameters

        Returns:
            httpx.Response

        Raises:
            QBOException: On final failure
        """
        for attempt in range(max_retries):
            try:
                headers = self._build_headers()
                headers.update(kwargs.pop("headers", {}))

                response = self._http_client.request(
                    method,
                    url,
                    headers=headers,
                    **kwargs
                )

                # Handle 401 (token expired) - retry once after refresh
                if response.status_code == 401 and attempt == 0:
                    logger.warning("Received 401, refreshing token and retrying")
                    self._refresh_access_token()
                    continue

                # Handle 429 (rate limit) - respect Retry-After
                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", 5))
                    logger.warning(f"Rate limited, waiting {retry_after}s")
                    time.sleep(retry_after)
                    raise QBOException(
                        "Rate limit exceeded",
                        QBOErrorType.RATE_LIMIT,
                        {"retry_after": retry_after}
                    )

                response.raise_for_status()
                return response

            except httpx.HTTPStatusError as e:
                if e.response.status_code >= 500 and attempt < max_retries - 1:
                    # Exponential backoff with jitter for 5xx errors
                    delay = (2 ** attempt) + (time.time() % 1)
                    logger.warning(f"Server error {e.response.status_code}, retrying in {delay:.2f}s")
                    time.sleep(delay)
                    continue
                else:
                    logger.error(f"HTTP error: {e.response.text}")
                    raise QBOException(
                        f"QBO API error: {e.response.status_code}",
                        QBOErrorType.VALIDATION if e.response.status_code < 500 else QBOErrorType.NETWORK,
                        {"status_code": e.response.status_code, "response": e.response.text}
                    )

            except httpx.RequestError as e:
                if attempt < max_retries - 1:
                    delay = (2 ** attempt) + (time.time() % 1)
                    logger.warning(f"Network error, retrying in {delay:.2f}s: {e}")
                    time.sleep(delay)
                    continue
                else:
                    raise QBOException(
                        f"Network error: {str(e)}",
                        QBOErrorType.NETWORK
                    )

        raise QBOException("Max retries exceeded", QBOErrorType.NETWORK)

    def query(
        self,
        entity: str,
        query: str,
        max_results: int = 1000
    ) -> List[Dict[str, Any]]:
        """
        Execute QuickBooks query with pagination.

        Args:
            entity: Entity type (Invoice, Bill, etc.)
            query: SQL-like query string
            max_results: Maximum results to fetch

        Returns:
            List of entity dictionaries
        """
        logger.info(f"Querying {entity}: {query}")

        results = []
        start_position = 1
        page_size = min(1000, max_results)  # QBO max is 1000

        while len(results) < max_results:
            paginated_query = f"{query} STARTPOSITION {start_position} MAXRESULTS {page_size}"

            url = f"{self.base_url}/v3/company/{self.realm_id}/query"
            params = {
                "query": paginated_query,
                "minorversion": self.minor_version  # Always include minorversion
            }

            response = self._request_with_retry("GET", url, params=params)
            data = response.json()

            query_response = data.get("QueryResponse", {})
            entities = query_response.get(entity, [])

            if not entities:
                break

            results.extend(entities)

            if len(entities) < page_size:
                break

            start_position += page_size

        logger.info(f"Retrieved {len(results)} {entity} records")
        return results[:max_results]

    def get_report(
        self,
        report_name: str,
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Fetch QuickBooks report.

        Args:
            report_name: Report name (ProfitAndLoss, BalanceSheet, etc.)
            params: Report parameters (start_date, end_date, etc.)

        Returns:
            Report data dictionary
        """
        url = f"{self.base_url}/v3/company/{self.realm_id}/reports/{report_name}"

        query_params = params or {}
        query_params["minorversion"] = self.minor_version  # Always include

        logger.info(f"Fetching report: {report_name}", extra={"params": query_params})

        response = self._request_with_retry("GET", url, params=query_params)
        return response.json()

    def get_pnl(self, start_date: str, end_date: str) -> Dict[str, Any]:
        """
        Fetch Profit & Loss report.

        Args:
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)

        Returns:
            P&L report data
        """
        return self.get_report(
            "ProfitAndLoss",
            {
                "start_date": start_date,
                "end_date": end_date,
                "accounting_method": "Accrual"
            }
        )

    def get_balance_sheet(self, date: str) -> Dict[str, Any]:
        """
        Fetch Balance Sheet report.

        Args:
            date: As-of date (YYYY-MM-DD)

        Returns:
            Balance Sheet data
        """
        return self.get_report(
            "BalanceSheet",
            {
                "date": date,
                "accounting_method": "Accrual"
            }
        )

    def get_ar_aging(self, as_of: Optional[str] = None) -> Dict[str, Any]:
        """
        Fetch Accounts Receivable aging report.

        Args:
            as_of: As-of date (YYYY-MM-DD), defaults to today

        Returns:
            AR aging data
        """
        params = {}
        if as_of:
            params["report_date"] = as_of

        return self.get_report("AgedReceivables", params)

    def get_ap_aging(self, as_of: Optional[str] = None) -> Dict[str, Any]:
        """
        Fetch Accounts Payable aging report.

        Args:
            as_of: As-of date (YYYY-MM-DD), defaults to today

        Returns:
            AP aging data
        """
        params = {}
        if as_of:
            params["report_date"] = as_of

        return self.get_report("AgedPayables", params)

    def get_changes(
        self,
        since: str,
        entities: Optional[List[str]] = None
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        Fetch changes since a given timestamp (Change Data Capture).

        Args:
            since: ISO 8601 timestamp (e.g., "2024-01-01T00:00:00Z")
            entities: List of entity types to check (defaults to common ones)

        Returns:
            Dictionary mapping entity type to list of changed records
        """
        if entities is None:
            entities = ["Invoice", "Bill", "Payment", "Purchase", "JournalEntry"]

        logger.info(f"Fetching CDC changes since {since}", extra={"entities": entities})

        changes = {}

        for entity in entities:
            url = f"{self.base_url}/v3/company/{self.realm_id}/cdc"
            params = {
                "entities": entity,
                "changedSince": since,
                "minorversion": self.minor_version
            }

            try:
                response = self._request_with_retry("GET", url, params=params)
                data = response.json()

                cdc_response = data.get("CDCResponse", [])
                for item in cdc_response:
                    query_response = item.get("QueryResponse", [])
                    for qr in query_response:
                        entity_data = qr.get(entity, [])
                        if entity_data:
                            changes[entity] = entity_data
                            logger.info(f"Found {len(entity_data)} changes for {entity}")

            except QBOException as e:
                logger.warning(f"CDC failed for {entity}: {e}")
                # Continue with other entities
                continue

        return changes

    def close(self):
        """Close HTTP client."""
        self._http_client.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
