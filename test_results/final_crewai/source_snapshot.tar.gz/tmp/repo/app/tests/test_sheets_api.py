"""
Tests for Google Sheets API wrapper.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from app.tools.sheets_api import SheetsClient, SheetsException


class TestSheetsClient:
    """Test suite for SheetsClient."""

    @pytest.fixture
    def mock_env(self, monkeypatch, tmp_path):
        """Mock environment variables."""
        # Create fake credentials file
        creds_file = tmp_path / "fake-creds.json"
        creds_file.write_text('{"type": "service_account"}')

        monkeypatch.setenv("GOOGLE_APPLICATION_CREDENTIALS", str(creds_file))
        monkeypatch.setenv("SHEETS_SPREADSHEET_ID", "test_spreadsheet_id")

    @pytest.fixture
    def client(self, mock_env):
        """Create test client."""
        with patch('app.tools.sheets_api.service_account.Credentials.from_service_account_file'):
            with patch('app.tools.sheets_api.build'):
                return SheetsClient()

    def test_initialization(self, client):
        """Test client initialization."""
        assert client.spreadsheet_id == "test_spreadsheet_id"

    def test_missing_credentials(self, monkeypatch):
        """Test error on missing credentials."""
        monkeypatch.delenv("GOOGLE_APPLICATION_CREDENTIALS", raising=False)
        monkeypatch.delenv("SHEETS_SPREADSHEET_ID", raising=False)

        with pytest.raises(SheetsException):
            SheetsClient()

    def test_clear_range(self, client):
        """Test clearing a range."""
        mock_sheets = Mock()
        mock_sheets.values().clear().execute.return_value = {}

        client.sheets = mock_sheets

        result = client.clear_range("Dashboard!A1:Z100")

        assert result is True
        mock_sheets.values().clear.assert_called_once()

    def test_write_range(self, client):
        """Test writing to a range."""
        values = [["Header1", "Header2"], ["Value1", "Value2"]]

        mock_sheets = Mock()
        mock_sheets.values().update().execute.return_value = {
            "updatedCells": 4
        }

        client.sheets = mock_sheets

        result = client.write_range("Dashboard!A1:B2", values)

        assert result["updatedCells"] == 4

    def test_batch_update(self, client):
        """Test batch update."""
        updates = [
            {"range": "Dashboard!A1:B2", "values": [["A", "B"], ["1", "2"]]},
            {"range": "Dashboard!A3:B4", "values": [["C", "D"], ["3", "4"]]}
        ]

        mock_sheets = Mock()
        mock_sheets.values().batchUpdate().execute.return_value = {
            "totalUpdatedCells": 8
        }

        client.sheets = mock_sheets

        result = client.batch_update(updates)

        assert result["totalUpdatedCells"] == 8

    def test_verify_write_success(self, client):
        """Test successful write verification."""
        expected_values = [["A", "B"], ["1", "2"]]

        mock_sheets = Mock()
        mock_sheets.values().get().execute.return_value = {
            "values": [["A", "B"], ["1", "2"]]
        }

        client.sheets = mock_sheets

        success, error = client.verify_write("Dashboard!A1:B2", expected_values)

        assert success is True
        assert error is None

    def test_verify_write_mismatch(self, client):
        """Test write verification with mismatch."""
        expected_values = [["A", "B"], ["1", "2"]]

        mock_sheets = Mock()
        mock_sheets.values().get().execute.return_value = {
            "values": [["A", "B"], ["1", "3"]]  # Wrong value
        }

        client.sheets = mock_sheets

        success, error = client.verify_write("Dashboard!A1:B2", expected_values)

        assert success is False
        assert "mismatch" in error.lower()

    def test_compute_checksum(self, client):
        """Test checksum computation."""
        values = [["A", "B"], ["1", "2"]]

        checksum1 = client.compute_checksum(values)
        checksum2 = client.compute_checksum(values)

        # Same values should produce same checksum
        assert checksum1 == checksum2

        # Different values should produce different checksum
        different_values = [["A", "B"], ["1", "3"]]
        checksum3 = client.compute_checksum(different_values)
        assert checksum1 != checksum3

    def test_clear_and_write_verified(self, client):
        """Test complete clear-write-verify flow."""
        values = [["A", "B"], ["1", "2"]]

        mock_sheets = Mock()
        mock_sheets.values().clear().execute.return_value = {}
        mock_sheets.values().update().execute.return_value = {"updatedCells": 4}
        mock_sheets.values().get().execute.return_value = {"values": values}

        client.sheets = mock_sheets

        success, checksum, error = client.clear_and_write_verified(
            "Dashboard!A1:B2",
            values,
            verify=True
        )

        assert success is True
        assert checksum is not None
        assert error is None

    def test_batch_clear_and_write(self, client):
        """Test batch clear-write-verify."""
        updates = [
            {"range": "Dashboard!A1:B2", "values": [["A", "B"], ["1", "2"]]},
        ]

        mock_sheets = Mock()
        mock_sheets.values().clear().execute.return_value = {}
        mock_sheets.values().batchUpdate().execute.return_value = {"totalUpdatedCells": 4}
        mock_sheets.values().get().execute.return_value = {
            "values": [["A", "B"], ["1", "2"]]
        }

        client.sheets = mock_sheets

        success, checksums, error = client.batch_clear_and_write(updates, verify=True)

        assert success is True
        assert len(checksums) == 1
        assert error is None
