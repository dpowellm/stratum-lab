"""
End-to-end tests for workflow orchestrator.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
import json
from pathlib import Path


class TestOrchestratorE2E:
    """End-to-end test suite for workflow orchestrator."""

    @pytest.fixture
    def mock_env(self, monkeypatch, tmp_path):
        """Mock environment."""
        creds_file = tmp_path / "fake-creds.json"
        creds_file.write_text('{"type": "service_account"}')

        monkeypatch.setenv("QBO_CLIENT_ID", "test_id")
        monkeypatch.setenv("QBO_CLIENT_SECRET", "test_secret")
        monkeypatch.setenv("QBO_REFRESH_TOKEN", "test_token")
        monkeypatch.setenv("QBO_REALM_ID", "test_realm")
        monkeypatch.setenv("GOOGLE_APPLICATION_CREDENTIALS", str(creds_file))
        monkeypatch.setenv("SHEETS_SPREADSHEET_ID", "test_sheet")
        monkeypatch.setenv("LOG_LEVEL", "ERROR")

    @pytest.fixture
    def qbo_pnl_fixture(self):
        """Load P&L fixture."""
        fixture_path = Path(__file__).parent / "fixtures" / "qbo_pnl_sample.json"
        with open(fixture_path) as f:
            return json.load(f)

    @patch('app.agents.orchestrator.create_qbo_agent')
    @patch('app.agents.orchestrator.create_processing_agent')
    @patch('app.agents.orchestrator.create_sheets_agent')
    @patch('app.agents.orchestrator.Crew')
    def test_full_workflow_dry_run(
        self,
        mock_crew_class,
        mock_sheets_agent,
        mock_processing_agent,
        mock_qbo_agent,
        mock_env
    ):
        """Test full workflow in dry-run mode."""
        from app.agents.orchestrator import run_workflow

        # Mock agents
        mock_qbo = Mock()
        mock_processing = Mock()
        mock_sheets = Mock()

        mock_qbo_agent.return_value = mock_qbo
        mock_processing_agent.return_value = mock_processing
        mock_sheets_agent.return_value = mock_sheets

        # Mock crew execution
        mock_crew_instance = Mock()
        mock_crew_instance.kickoff.return_value = {
            "status": "dry_run_preview",
            "ranges_to_update": 5
        }
        mock_crew_class.return_value = mock_crew_instance

        # Run workflow
        result = run_workflow(mode="dry_run", days=7)

        assert result["success"] is True
        assert result["mode"] == "dry_run"
        mock_crew_instance.kickoff.assert_called_once()

    @patch('app.agents.orchestrator.create_qbo_agent')
    @patch('app.agents.orchestrator.create_processing_agent')
    @patch('app.agents.orchestrator.create_sheets_agent')
    @patch('app.agents.orchestrator.Crew')
    def test_workflow_with_cdc(
        self,
        mock_crew_class,
        mock_sheets_agent,
        mock_processing_agent,
        mock_qbo_agent,
        mock_env
    ):
        """Test workflow with CDC mode."""
        from app.agents.orchestrator import run_workflow

        mock_qbo = Mock()
        mock_processing = Mock()
        mock_sheets = Mock()

        mock_qbo_agent.return_value = mock_qbo
        mock_processing_agent.return_value = mock_processing
        mock_sheets_agent.return_value = mock_sheets

        mock_crew_instance = Mock()
        mock_crew_instance.kickoff.return_value = {
            "status": "success",
            "changes_processed": 10
        }
        mock_crew_class.return_value = mock_crew_instance

        # Run with CDC
        result = run_workflow(
            mode="publish",
            use_cdc=True,
            cdc_since="2024-01-01T00:00:00Z"
        )

        assert result["success"] is True

    @patch('app.agents.orchestrator.create_qbo_agent')
    @patch('app.agents.orchestrator.create_processing_agent')
    @patch('app.agents.orchestrator.create_sheets_agent')
    @patch('app.agents.orchestrator.Crew')
    def test_workflow_requires_confirmation(
        self,
        mock_crew_class,
        mock_sheets_agent,
        mock_processing_agent,
        mock_qbo_agent,
        mock_env,
        monkeypatch
    ):
        """Test that confirmation is required when enabled."""
        from app.agents.orchestrator import run_workflow

        # Don't set CONFIRM_PUBLISH
        monkeypatch.delenv("CONFIRM_PUBLISH", raising=False)

        mock_qbo = Mock()
        mock_processing = Mock()
        mock_sheets = Mock()

        mock_qbo_agent.return_value = mock_qbo
        mock_processing_agent.return_value = mock_processing
        mock_sheets_agent.return_value = mock_sheets

        # Run with confirmation required
        result = run_workflow(
            mode="publish",
            require_confirmation=True
        )

        assert result["success"] is False
        assert "confirmation" in result["error"].lower()

    @patch('app.agents.orchestrator.create_qbo_agent')
    @patch('app.agents.orchestrator.create_processing_agent')
    @patch('app.agents.orchestrator.create_sheets_agent')
    @patch('app.agents.orchestrator.Crew')
    def test_workflow_error_handling(
        self,
        mock_crew_class,
        mock_sheets_agent,
        mock_processing_agent,
        mock_qbo_agent,
        mock_env
    ):
        """Test workflow error handling."""
        from app.agents.orchestrator import run_workflow

        mock_qbo = Mock()
        mock_processing = Mock()
        mock_sheets = Mock()

        mock_qbo_agent.return_value = mock_qbo
        mock_processing_agent.return_value = mock_processing
        mock_sheets_agent.return_value = mock_sheets

        # Mock crew failure
        mock_crew_instance = Mock()
        mock_crew_instance.kickoff.side_effect = Exception("Crew execution failed")
        mock_crew_class.return_value = mock_crew_instance

        # Run workflow
        result = run_workflow(mode="publish")

        assert result["success"] is False
        assert "error" in result
        assert "Crew execution failed" in result["error"]
