"""
Tests for QuickBooks API wrapper.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from app.tools.qbo_api import QBOClient, QBOException, QBOErrorType


class TestQBOClient:
    """Test suite for QBOClient."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("QBO_CLIENT_ID", "test_client_id")
        monkeypatch.setenv("QBO_CLIENT_SECRET", "test_client_secret")
        monkeypatch.setenv("QBO_REFRESH_TOKEN", "test_refresh_token")
        monkeypatch.setenv("QBO_REALM_ID", "test_realm_id")
        monkeypatch.setenv("QBO_ENV", "sandbox")

    @pytest.fixture
    def client(self, mock_env):
        """Create test client."""
        return QBOClient()

    def test_initialization(self, client):
        """Test client initialization."""
        assert client.client_id == "test_client_id"
        assert client.realm_id == "test_realm_id"
        assert client.environment == "sandbox"
        assert client.minor_version == 75

    def test_missing_credentials(self, monkeypatch):
        """Test error on missing credentials."""
        monkeypatch.delenv("QBO_CLIENT_ID", raising=False)

        with pytest.raises(QBOException) as exc:
            QBOClient()

        assert exc.value.error_type == QBOErrorType.AUTH

    @patch('app.tools.qbo_api.httpx.Client')
    def test_token_refresh(self, mock_http, client):
        """Test OAuth token refresh."""
        # Mock successful token response
        mock_response = Mock()
        mock_response.json.return_value = {
            "access_token": "new_access_token",
            "refresh_token": "new_refresh_token",
            "expires_in": 3600,
            "x_refresh_token_expires_in": 8726400
        }
        mock_response.raise_for_status = Mock()

        mock_http.return_value.post.return_value = mock_response

        # Refresh token
        token_response = client._refresh_access_token()

        assert client.access_token == "new_access_token"
        assert client.refresh_token == "new_refresh_token"
        assert client.token_expires_at is not None

    @patch('app.tools.qbo_api.httpx.Client')
    def test_query_with_minorversion(self, mock_http, client):
        """Test that queries always include minorversion."""
        # Mock token refresh
        client.access_token = "test_token"
        client.token_expires_at = None  # Force refresh

        mock_token_response = Mock()
        mock_token_response.json.return_value = {
            "access_token": "test_token",
            "refresh_token": "test_refresh",
            "expires_in": 3600,
            "x_refresh_token_expires_in": 8726400
        }
        mock_token_response.raise_for_status = Mock()

        # Mock query response
        mock_query_response = Mock()
        mock_query_response.json.return_value = {
            "QueryResponse": {
                "Invoice": [
                    {"Id": "1", "TotalAmt": 100}
                ]
            }
        }
        mock_query_response.raise_for_status = Mock()
        mock_query_response.status_code = 200

        mock_http_instance = mock_http.return_value
        mock_http_instance.post.return_value = mock_token_response
        mock_http_instance.request.return_value = mock_query_response

        # Execute query
        results = client.query("Invoice", "SELECT * FROM Invoice")

        # Verify minorversion was included
        call_args = mock_http_instance.request.call_args
        assert call_args[1]['params']['minorversion'] == 75

    @patch('app.tools.qbo_api.httpx.Client')
    def test_retry_on_rate_limit(self, mock_http, client):
        """Test retry logic on 429 rate limit."""
        client.access_token = "test_token"

        # First call returns 429
        mock_429 = Mock()
        mock_429.status_code = 429
        mock_429.headers = {"Retry-After": "1"}

        # Create HTTPStatusError
        from httpx import HTTPStatusError, Request, Response

        request = Request("GET", "http://test.com")
        response = Response(429, headers={"Retry-After": "1"})
        rate_limit_error = HTTPStatusError("Rate limited", request=request, response=response)

        mock_http_instance = mock_http.return_value
        mock_http_instance.request.side_effect = rate_limit_error

        # Should raise QBOException with RATE_LIMIT type
        with pytest.raises(QBOException) as exc:
            client._request_with_retry("GET", "http://test.com")

        assert exc.value.error_type == QBOErrorType.RATE_LIMIT

    @patch('app.tools.qbo_api.httpx.Client')
    def test_get_pnl(self, mock_http, client):
        """Test P&L report retrieval."""
        client.access_token = "test_token"

        mock_response = Mock()
        mock_response.json.return_value = {
            "Header": {"ReportName": "ProfitAndLoss"},
            "Rows": {"Row": []}
        }
        mock_response.raise_for_status = Mock()
        mock_response.status_code = 200

        mock_http_instance = mock_http.return_value
        mock_http_instance.request.return_value = mock_response

        result = client.get_pnl("2024-01-01", "2024-01-31")

        assert "Header" in result
        assert result["Header"]["ReportName"] == "ProfitAndLoss"

        # Verify minorversion in params
        call_args = mock_http_instance.request.call_args
        assert call_args[1]['params']['minorversion'] == 75

    @patch('app.tools.qbo_api.httpx.Client')
    def test_cdc_extraction(self, mock_http, client):
        """Test CDC (Change Data Capture) extraction."""
        client.access_token = "test_token"

        mock_response = Mock()
        mock_response.json.return_value = {
            "CDCResponse": [
                {
                    "QueryResponse": [
                        {
                            "Invoice": [
                                {"Id": "123", "TotalAmt": 1500}
                            ]
                        }
                    ]
                }
            ]
        }
        mock_response.raise_for_status = Mock()
        mock_response.status_code = 200

        mock_http_instance = mock_http.return_value
        mock_http_instance.request.return_value = mock_response

        changes = client.get_changes("2024-01-01T00:00:00Z", ["Invoice"])

        assert "Invoice" in changes
        assert len(changes["Invoice"]) == 1
        assert changes["Invoice"][0]["Id"] == "123"
