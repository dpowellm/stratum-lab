#!/usr/bin/env python3
"""
QuickBooks OAuth 2.0 setup helper.
Opens browser for authentication and returns refresh token.
"""

import os
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import webbrowser
import requests
from dotenv import load_dotenv

load_dotenv()

# Configuration
CLIENT_ID = os.getenv("QBO_CLIENT_ID")
CLIENT_SECRET = os.getenv("QBO_CLIENT_SECRET")
REDIRECT_URI = os.getenv("QBO_REDIRECT_URI", "http://localhost:8000/callback")
ENVIRONMENT = os.getenv("QBO_ENV", "sandbox")

# OAuth URLs
if ENVIRONMENT == "production":
    AUTH_URL = "https://appcenter.intuit.com/connect/oauth2"
    TOKEN_URL = "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer"
else:
    AUTH_URL = "https://appcenter.intuit.com/connect/oauth2"
    TOKEN_URL = "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer"

SCOPES = "com.intuit.quickbooks.accounting"

# Global to store auth code
auth_code = None
realm_id = None


class CallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler for OAuth callback."""

    def do_GET(self):
        """Handle GET request with auth code."""
        global auth_code, realm_id

        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)

        if "code" in query:
            auth_code = query["code"][0]
            realm_id = query.get("realmId", [None])[0]

            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()

            html = """
            <html>
            <body>
                <h1>✅ Authentication Successful!</h1>
                <p>You can close this window and return to the terminal.</p>
            </body>
            </html>
            """
            self.wfile.write(html.encode())
        else:
            self.send_response(400)
            self.end_headers()
            error = query.get("error", ["Unknown error"])[0]
            self.wfile.write(f"Error: {error}".encode())

    def log_message(self, format, *args):
        """Suppress log messages."""
        pass


def get_authorization_url():
    """Generate authorization URL."""
    return (
        f"{AUTH_URL}?"
        f"client_id={CLIENT_ID}&"
        f"scope={SCOPES}&"
        f"redirect_uri={REDIRECT_URI}&"
        f"response_type=code&"
        f"state=test"
    )


def exchange_code_for_tokens(auth_code):
    """Exchange authorization code for access and refresh tokens."""
    response = requests.post(
        TOKEN_URL,
        headers={
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        auth=(CLIENT_ID, CLIENT_SECRET),
        data={
            "grant_type": "authorization_code",
            "code": auth_code,
            "redirect_uri": REDIRECT_URI,
        }
    )

    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Token exchange failed: {response.text}")


def main():
    """Run OAuth flow."""
    global auth_code, realm_id

    print("=" * 60)
    print("QuickBooks OAuth 2.0 Setup")
    print("=" * 60)
    print()

    if not CLIENT_ID or not CLIENT_SECRET:
        print("❌ Error: Missing CLIENT_ID or CLIENT_SECRET")
        print("\nSet in .env file:")
        print("  QBO_CLIENT_ID=your_client_id")
        print("  QBO_CLIENT_SECRET=your_client_secret")
        sys.exit(1)

    print(f"Environment: {ENVIRONMENT}")
    print(f"Redirect URI: {REDIRECT_URI}")
    print()

    # Step 1: Start local server
    port = int(REDIRECT_URI.split(":")[-1].split("/")[0])
    server = HTTPServer(("localhost", port), CallbackHandler)

    print(f"✓ Started local server on port {port}")
    print()

    # Step 2: Open browser
    auth_url = get_authorization_url()
    print("Opening browser for authentication...")
    print(f"URL: {auth_url}")
    print()
    webbrowser.open(auth_url)

    print("Waiting for callback...")
    print("(If browser doesn't open, copy the URL above)")
    print()

    # Step 3: Wait for callback
    server.handle_request()

    if not auth_code:
        print("❌ Error: No authorization code received")
        sys.exit(1)

    print(f"✓ Received authorization code: {auth_code[:20]}...")
    print(f"✓ Realm ID: {realm_id}")
    print()

    # Step 4: Exchange for tokens
    print("Exchanging code for tokens...")
    try:
        tokens = exchange_code_for_tokens(auth_code)

        print("=" * 60)
        print("✅ Success! Copy these values to your .env file:")
        print("=" * 60)
        print()
        print(f"QBO_REFRESH_TOKEN={tokens['refresh_token']}")
        print(f"QBO_REALM_ID={realm_id}")
        print()
        print("Token Details:")
        print(f"  - Access Token: {tokens['access_token'][:20]}...")
        print(f"  - Expires In: {tokens['expires_in']} seconds")
        print(f"  - Refresh Token Expires In: {tokens['x_refresh_token_expires_in']} seconds")
        print()
        print("⚠️  Important:")
        print("  - Store refresh token securely (never commit to git)")
        print("  - Refresh tokens expire after 100 days of inactivity")
        print("  - Re-run this script if token expires")
        print()

    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
