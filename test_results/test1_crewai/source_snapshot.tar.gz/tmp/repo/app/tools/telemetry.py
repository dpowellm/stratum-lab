"""
Structured JSON logging and telemetry for observability.
"""

import os
import sys
import json
import logging
import time
from datetime import datetime
from typing import Dict, Any, Optional
from contextlib import contextmanager
from functools import wraps
import uuid

# Configure JSON logging
class JsonFormatter(logging.Formatter):
    """Custom JSON formatter for structured logs."""

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        log_data = {
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
        }

        # Add extra fields if present
        if hasattr(record, 'run_id'):
            log_data['run_id'] = record.run_id
        if hasattr(record, 'realm_id'):
            log_data['realm_id'] = record.realm_id
        if hasattr(record, 'duration_ms'):
            log_data['duration_ms'] = record.duration_ms
        if hasattr(record, 'tool_name'):
            log_data['tool_name'] = record.tool_name
        if hasattr(record, 'retries'):
            log_data['retries'] = record.retries

        # Add any additional extra attributes
        for key, value in record.__dict__.items():
            if key not in ['name', 'msg', 'args', 'created', 'filename', 'funcName',
                          'levelname', 'lineno', 'module', 'msecs', 'message',
                          'pathname', 'process', 'processName', 'relativeCreated',
                          'thread', 'threadName', 'exc_info', 'exc_text', 'stack_info']:
                if key not in log_data:
                    log_data[key] = value

        # Add exception info if present
        if record.exc_info:
            log_data['exception'] = self.formatException(record.exc_info)

        return json.dumps(log_data)


def setup_logging(log_level: str = "INFO") -> None:
    """
    Setup structured JSON logging.

    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """
    level = getattr(logging, log_level.upper(), logging.INFO)

    # Create JSON formatter
    json_formatter = JsonFormatter()

    # Setup console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(json_formatter)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.handlers.clear()
    root_logger.addHandler(console_handler)

    # Suppress noisy libraries
    logging.getLogger('googleapiclient.discovery_cache').setLevel(logging.ERROR)
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('httpcore').setLevel(logging.WARNING)

    logging.info("Logging initialized", extra={'log_level': log_level})


class TelemetryContext:
    """
    Context manager for tracking telemetry across a workflow.
    """

    def __init__(self, run_id: Optional[str] = None, realm_id: Optional[str] = None):
        """
        Initialize telemetry context.

        Args:
            run_id: Unique run identifier
            realm_id: QuickBooks realm/company ID
        """
        self.run_id = run_id or str(uuid.uuid4())
        self.realm_id = realm_id or os.getenv('QBO_REALM_ID', 'unknown')
        self.start_time = None
        self.metrics: Dict[str, Any] = {
            'run_id': self.run_id,
            'realm_id': self.realm_id,
            'entities': [],
            'tool_calls': [],
            'errors': [],
            'rows_processed': 0,
            'cells_written': 0,
        }

    def __enter__(self):
        """Start telemetry context."""
        self.start_time = time.time()
        logging.info(
            "Starting workflow",
            extra={
                'run_id': self.run_id,
                'realm_id': self.realm_id
            }
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """End telemetry context and emit summary."""
        duration_ms = (time.time() - self.start_time) * 1000

        self.metrics['duration_ms'] = round(duration_ms, 2)
        self.metrics['status'] = 'failed' if exc_type else 'success'

        if exc_type:
            self.metrics['error_type'] = exc_type.__name__
            self.metrics['error_message'] = str(exc_val)

        logging.info(
            "Workflow completed",
            extra=self.metrics
        )

    def record_tool_call(
        self,
        tool_name: str,
        duration_ms: float,
        success: bool,
        retries: int = 0,
        details: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Record a tool call.

        Args:
            tool_name: Name of the tool
            duration_ms: Execution time in milliseconds
            success: Whether the call succeeded
            retries: Number of retries
            details: Additional details
        """
        call_record = {
            'tool': tool_name,
            'duration_ms': round(duration_ms, 2),
            'success': success,
            'retries': retries,
        }
        if details:
            call_record['details'] = details

        self.metrics['tool_calls'].append(call_record)

        logging.info(
            f"Tool call: {tool_name}",
            extra={
                'run_id': self.run_id,
                'tool_name': tool_name,
                'duration_ms': round(duration_ms, 2),
                'success': success,
                'retries': retries
            }
        )

    def record_error(
        self,
        error_type: str,
        message: str,
        details: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Record an error.

        Args:
            error_type: Type of error
            message: Error message
            details: Additional details
        """
        error_record = {
            'type': error_type,
            'message': message,
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }
        if details:
            error_record['details'] = details

        self.metrics['errors'].append(error_record)

        logging.error(
            f"Error: {error_type}",
            extra={
                'run_id': self.run_id,
                'error_type': error_type,
                'error_message': message
            }
        )

    def add_metric(self, key: str, value: Any) -> None:
        """Add a custom metric."""
        self.metrics[key] = value


@contextmanager
def timed_operation(
    context: TelemetryContext,
    tool_name: str,
    auto_record: bool = True
):
    """
    Context manager for timing operations.

    Args:
        context: TelemetryContext instance
        tool_name: Name of the operation
        auto_record: Whether to automatically record to context

    Yields:
        dict with timing info
    """
    start = time.time()
    timing = {'start': start, 'retries': 0, 'success': False}

    try:
        yield timing
        timing['success'] = True
    except Exception as e:
        timing['success'] = False
        timing['error'] = str(e)
        raise
    finally:
        timing['end'] = time.time()
        timing['duration_ms'] = (timing['end'] - timing['start']) * 1000

        if auto_record:
            context.record_tool_call(
                tool_name=tool_name,
                duration_ms=timing['duration_ms'],
                success=timing['success'],
                retries=timing.get('retries', 0)
            )


def track_time(tool_name: str):
    """
    Decorator to track function execution time.

    Args:
        tool_name: Name of the tool/function

    Example:
        @track_time("extract_invoices")
        def extract_invoices():
            ...
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.time()
            try:
                result = func(*args, **kwargs)
                duration_ms = (time.time() - start) * 1000

                logging.info(
                    f"{tool_name} completed",
                    extra={
                        'tool_name': tool_name,
                        'duration_ms': round(duration_ms, 2),
                        'success': True
                    }
                )
                return result
            except Exception as e:
                duration_ms = (time.time() - start) * 1000
                logging.error(
                    f"{tool_name} failed",
                    extra={
                        'tool_name': tool_name,
                        'duration_ms': round(duration_ms, 2),
                        'success': False,
                        'error': str(e)
                    }
                )
                raise
        return wrapper
    return decorator


def sanitize_phi(data: Dict[str, Any], fields_to_redact: Optional[list] = None) -> Dict[str, Any]:
    """
    Remove PHI (Protected Health Information) from data before logging.

    Args:
        data: Data dictionary
        fields_to_redact: List of field names to redact (default: common PHI fields)

    Returns:
        Sanitized data dictionary
    """
    if fields_to_redact is None:
        fields_to_redact = [
            'name', 'patient_name', 'customer_name', 'vendor_name',
            'email', 'phone', 'address', 'ssn', 'dob',
            'memo', 'description', 'notes', 'message'
        ]

    sanitized = data.copy()

    def redact_recursive(obj):
        """Recursively redact PHI fields."""
        if isinstance(obj, dict):
            return {
                k: '[REDACTED]' if k.lower() in [f.lower() for f in fields_to_redact]
                else redact_recursive(v)
                for k, v in obj.items()
            }
        elif isinstance(obj, list):
            return [redact_recursive(item) for item in obj]
        else:
            return obj

    return redact_recursive(sanitized)


def emit_metric(
    metric_name: str,
    value: float,
    unit: str = "count",
    dimensions: Optional[Dict[str, str]] = None
) -> None:
    """
    Emit a metric (for Prometheus/CloudWatch integration).

    Args:
        metric_name: Metric name
        value: Metric value
        unit: Unit of measurement
        dimensions: Additional dimensions/tags
    """
    metric_data = {
        'metric_name': metric_name,
        'value': value,
        'unit': unit,
        'timestamp': datetime.utcnow().isoformat() + 'Z'
    }

    if dimensions:
        metric_data['dimensions'] = dimensions

    logging.info(
        f"Metric: {metric_name}",
        extra=metric_data
    )
