"""
Google Sheets API wrapper with batch updates, verification, and idempotency.
"""

import os
import hashlib
import logging
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

logger = logging.getLogger(__name__)


class SheetsException(Exception):
    """Exception for Google Sheets API errors."""
    pass


class SheetsClient:
    """
    Google Sheets API client with:
    - Batch updates for performance
    - Read-back verification
    - Idempotent writes with checksums
    - Clear → Write → Verify pattern
    """

    SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

    def __init__(
        self,
        credentials_file: Optional[str] = None,
        spreadsheet_id: Optional[str] = None
    ):
        """
        Initialize Sheets client.

        Args:
            credentials_file: Path to service account JSON
            spreadsheet_id: Target spreadsheet ID
        """
        self.credentials_file = credentials_file or os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
        self.spreadsheet_id = spreadsheet_id or os.getenv("SHEETS_SPREADSHEET_ID")

        if not self.credentials_file:
            raise SheetsException("Missing Google credentials file")
        if not self.spreadsheet_id:
            raise SheetsException("Missing spreadsheet ID")

        # Initialize Google Sheets API
        try:
            creds = service_account.Credentials.from_service_account_file(
                self.credentials_file,
                scopes=self.SCOPES
            )
            self.service = build('sheets', 'v4', credentials=creds)
            self.sheets = self.service.spreadsheets()
            logger.info(f"Initialized Sheets client for spreadsheet: {self.spreadsheet_id}")

        except Exception as e:
            raise SheetsException(f"Failed to initialize Sheets client: {e}")

    def clear_range(self, range_name: str) -> bool:
        """
        Clear a range in the spreadsheet.

        Args:
            range_name: A1 notation range (e.g., "Dashboard!A1:Z100")

        Returns:
            True if successful

        Raises:
            SheetsException: On failure
        """
        try:
            logger.info(f"Clearing range: {range_name}")

            self.sheets.values().clear(
                spreadsheetId=self.spreadsheet_id,
                range=range_name
            ).execute()

            logger.info(f"Successfully cleared range: {range_name}")
            return True

        except HttpError as e:
            logger.error(f"Failed to clear range {range_name}: {e}")
            raise SheetsException(f"Clear range failed: {e}")

    def write_range(
        self,
        range_name: str,
        values: List[List[Any]],
        value_input_option: str = "USER_ENTERED"
    ) -> Dict[str, Any]:
        """
        Write values to a single range.

        Args:
            range_name: A1 notation range
            values: 2D array of values
            value_input_option: How values should be interpreted

        Returns:
            Update response

        Raises:
            SheetsException: On failure
        """
        try:
            logger.info(
                f"Writing to range: {range_name}",
                extra={
                    "rows": len(values),
                    "cols": len(values[0]) if values else 0
                }
            )

            body = {'values': values}

            result = self.sheets.values().update(
                spreadsheetId=self.spreadsheet_id,
                range=range_name,
                valueInputOption=value_input_option,
                body=body
            ).execute()

            logger.info(
                f"Successfully wrote to {range_name}",
                extra={"cells_updated": result.get('updatedCells', 0)}
            )

            return result

        except HttpError as e:
            logger.error(f"Failed to write range {range_name}: {e}")
            raise SheetsException(f"Write range failed: {e}")

    def batch_update(
        self,
        updates: List[Dict[str, Any]],
        value_input_option: str = "USER_ENTERED"
    ) -> Dict[str, Any]:
        """
        Perform batch update for multiple ranges.

        Args:
            updates: List of dicts with 'range' and 'values' keys
            value_input_option: How values should be interpreted

        Returns:
            Batch update response

        Raises:
            SheetsException: On failure
        """
        try:
            logger.info(f"Starting batch update with {len(updates)} ranges")

            data = [
                {
                    'range': update['range'],
                    'values': update['values']
                }
                for update in updates
            ]

            body = {
                'valueInputOption': value_input_option,
                'data': data
            }

            result = self.sheets.values().batchUpdate(
                spreadsheetId=self.spreadsheet_id,
                body=body
            ).execute()

            total_cells = result.get('totalUpdatedCells', 0)
            logger.info(
                f"Batch update completed",
                extra={
                    "ranges": len(updates),
                    "total_cells": total_cells
                }
            )

            return result

        except HttpError as e:
            logger.error(f"Batch update failed: {e}")
            raise SheetsException(f"Batch update failed: {e}")

    def read_range(self, range_name: str) -> List[List[Any]]:
        """
        Read values from a range.

        Args:
            range_name: A1 notation range

        Returns:
            2D array of values

        Raises:
            SheetsException: On failure
        """
        try:
            logger.info(f"Reading range: {range_name}")

            result = self.sheets.values().get(
                spreadsheetId=self.spreadsheet_id,
                range=range_name
            ).execute()

            values = result.get('values', [])
            logger.info(
                f"Read {len(values)} rows from {range_name}",
                extra={"rows": len(values)}
            )

            return values

        except HttpError as e:
            logger.error(f"Failed to read range {range_name}: {e}")
            raise SheetsException(f"Read range failed: {e}")

    def verify_write(
        self,
        range_name: str,
        expected_values: List[List[Any]],
        tolerance: float = 0.01
    ) -> Tuple[bool, Optional[str]]:
        """
        Verify written values by reading back and comparing.

        Args:
            range_name: A1 notation range
            expected_values: Expected 2D array
            tolerance: Tolerance for numeric comparisons

        Returns:
            (success: bool, error_message: Optional[str])
        """
        try:
            actual_values = self.read_range(range_name)

            # Compare dimensions
            if len(actual_values) != len(expected_values):
                return False, f"Row count mismatch: {len(actual_values)} vs {len(expected_values)}"

            # Compare values
            for i, (actual_row, expected_row) in enumerate(zip(actual_values, expected_values)):
                if len(actual_row) != len(expected_row):
                    return False, f"Column count mismatch at row {i}: {len(actual_row)} vs {len(expected_row)}"

                for j, (actual, expected) in enumerate(zip(actual_row, expected_row)):
                    # Handle numeric comparison with tolerance
                    if isinstance(expected, (int, float)) and isinstance(actual, (int, float, str)):
                        try:
                            actual_num = float(actual) if isinstance(actual, str) else actual
                            if abs(actual_num - expected) > tolerance:
                                return False, f"Value mismatch at [{i},{j}]: {actual} vs {expected}"
                        except ValueError:
                            return False, f"Type mismatch at [{i},{j}]: {actual} vs {expected}"
                    elif str(actual).strip() != str(expected).strip():
                        return False, f"Value mismatch at [{i},{j}]: '{actual}' vs '{expected}'"

            logger.info(f"Verification successful for {range_name}")
            return True, None

        except Exception as e:
            logger.error(f"Verification failed for {range_name}: {e}")
            return False, str(e)

    def compute_checksum(self, values: List[List[Any]]) -> str:
        """
        Compute checksum for values to detect changes.

        Args:
            values: 2D array of values

        Returns:
            SHA256 checksum hex string
        """
        # Flatten and stringify all values
        flat_str = '||'.join(
            '|'.join(str(cell) for cell in row)
            for row in values
        )
        return hashlib.sha256(flat_str.encode()).hexdigest()

    def write_metadata(
        self,
        sheet_name: str,
        metadata: Dict[str, Any],
        metadata_range: str = "A1:Z1"
    ) -> bool:
        """
        Write metadata (checksum, timestamp) to a hidden row or metadata tab.

        Args:
            sheet_name: Sheet name for metadata
            metadata: Metadata dict
            metadata_range: Range to write metadata

        Returns:
            True if successful
        """
        try:
            # Create metadata row
            meta_values = [[
                metadata.get('run_id', ''),
                metadata.get('timestamp', datetime.utcnow().isoformat()),
                metadata.get('checksum', ''),
                metadata.get('status', 'success')
            ]]

            range_name = f"{sheet_name}!{metadata_range}"
            self.write_range(range_name, meta_values)

            logger.info(f"Wrote metadata to {range_name}", extra=metadata)
            return True

        except Exception as e:
            logger.warning(f"Failed to write metadata: {e}")
            return False

    def clear_and_write_verified(
        self,
        range_name: str,
        values: List[List[Any]],
        verify: bool = True
    ) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Idempotent write operation: clear → write → verify.

        Args:
            range_name: A1 notation range
            values: 2D array of values
            verify: Whether to verify write

        Returns:
            (success: bool, checksum: Optional[str], error: Optional[str])
        """
        try:
            # Step 1: Clear
            self.clear_range(range_name)

            # Step 2: Write
            result = self.write_range(range_name, values)

            # Step 3: Compute checksum
            checksum = self.compute_checksum(values)

            # Step 4: Verify (optional)
            if verify:
                success, error = self.verify_write(range_name, values)
                if not success:
                    return False, None, f"Verification failed: {error}"

            logger.info(
                f"Clear-Write-Verify successful for {range_name}",
                extra={
                    "cells_updated": result.get('updatedCells', 0),
                    "checksum": checksum
                }
            )

            return True, checksum, None

        except Exception as e:
            logger.error(f"Clear-Write-Verify failed for {range_name}: {e}")
            return False, None, str(e)

    def batch_clear_and_write(
        self,
        updates: List[Dict[str, Any]],
        verify: bool = True
    ) -> Tuple[bool, Dict[str, str], Optional[str]]:
        """
        Batch version of clear_and_write_verified.

        Args:
            updates: List of dicts with 'range' and 'values' keys
            verify: Whether to verify writes

        Returns:
            (success: bool, checksums: Dict[range, checksum], error: Optional[str])
        """
        try:
            checksums = {}

            # Step 1: Clear all ranges
            for update in updates:
                self.clear_range(update['range'])

            # Step 2: Batch write
            result = self.batch_update(updates)

            # Step 3: Compute checksums and verify
            for update in updates:
                range_name = update['range']
                values = update['values']

                checksum = self.compute_checksum(values)
                checksums[range_name] = checksum

                if verify:
                    success, error = self.verify_write(range_name, values)
                    if not success:
                        return False, {}, f"Verification failed for {range_name}: {error}"

            logger.info(
                "Batch clear-write-verify successful",
                extra={
                    "ranges": len(updates),
                    "total_cells": result.get('totalUpdatedCells', 0)
                }
            )

            return True, checksums, None

        except Exception as e:
            logger.error(f"Batch clear-write-verify failed: {e}")
            return False, {}, str(e)

    def get_sheet_properties(self) -> List[Dict[str, Any]]:
        """Get all sheet properties (for discovering tabs)."""
        try:
            spreadsheet = self.sheets.get(spreadsheetId=self.spreadsheet_id).execute()
            return spreadsheet.get('sheets', [])
        except HttpError as e:
            logger.error(f"Failed to get sheet properties: {e}")
            raise SheetsException(f"Get properties failed: {e}")
