"""
Google Sheets agent with tools for writing and verifying data.
"""

import logging
from typing import Dict, Any, List, Optional, Type
from pydantic import BaseModel, Field
from crewai.tools import BaseTool
from crewai import Agent

from app.tools.sheets_api import SheetsClient
from app.tools.telemetry import track_time

logger = logging.getLogger(__name__)


# Tool Input Schemas
class WriteToSheetsInput(BaseModel):
    """Input schema for writing to Sheets."""
    ranges: List[Dict[str, Any]] = Field(..., description="List of range/values dicts to write")
    verify: bool = Field(True, description="Whether to verify writes")


class ClearSheetInput(BaseModel):
    """Input schema for clearing ranges."""
    ranges: List[str] = Field(..., description="List of A1 notation ranges to clear")


class VerifyWriteInput(BaseModel):
    """Input schema for verification."""
    range_name: str = Field(..., description="A1 notation range to verify")
    expected_values: List[List[Any]] = Field(..., description="Expected 2D array of values")


# Tool Implementations
class WriteToSheetsTool(BaseTool):
    """Write data to Google Sheets with verification."""

    name: str = "Write to Google Sheets"
    description: str = "Writes formatted data to Google Sheets with optional verification"
    args_schema: Type[BaseModel] = WriteToSheetsInput

    def __init__(self):
        super().__init__()
        self.sheets_client = None

    @track_time("write_to_sheets")
    def _run(self, ranges: List[Dict[str, Any]], verify: bool = True) -> Dict[str, Any]:
        """
        Write data to Sheets.

        Args:
            ranges: List of range/values dicts
            verify: Whether to verify writes

        Returns:
            Write result with checksums
        """
        try:
            if not self.sheets_client:
                self.sheets_client = SheetsClient()

            logger.info(f"Writing {len(ranges)} ranges to Google Sheets")

            # Perform batch clear-write-verify
            success, checksums, error = self.sheets_client.batch_clear_and_write(
                ranges,
                verify=verify
            )

            if not success:
                return {
                    "success": False,
                    "error": error
                }

            # Write metadata
            metadata = {
                'timestamp': '',  # Will be auto-filled
                'checksum': str(checksums),
                'status': 'success'
            }

            # Try to write metadata (non-critical)
            try:
                self.sheets_client.write_metadata('Metadata', metadata)
            except Exception as e:
                logger.warning(f"Failed to write metadata: {e}")

            logger.info(
                "Successfully wrote to Sheets",
                extra={
                    "ranges": len(ranges),
                    "checksums": checksums,
                    "verified": verify
                }
            )

            return {
                "success": True,
                "ranges_written": len(ranges),
                "checksums": checksums,
                "verified": verify
            }

        except Exception as e:
            logger.error(f"Sheets write failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


class ClearSheetRangesTool(BaseTool):
    """Clear ranges in Google Sheets."""

    name: str = "Clear Sheet Ranges"
    description: str = "Clears specified ranges in Google Sheets"
    args_schema: Type[BaseModel] = ClearSheetInput

    def __init__(self):
        super().__init__()
        self.sheets_client = None

    @track_time("clear_ranges")
    def _run(self, ranges: List[str]) -> Dict[str, Any]:
        """
        Clear ranges.

        Args:
            ranges: List of A1 notation ranges

        Returns:
            Clear result
        """
        try:
            if not self.sheets_client:
                self.sheets_client = SheetsClient()

            logger.info(f"Clearing {len(ranges)} ranges")

            for range_name in ranges:
                self.sheets_client.clear_range(range_name)

            return {
                "success": True,
                "ranges_cleared": len(ranges)
            }

        except Exception as e:
            logger.error(f"Clear ranges failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


class VerifySheetWriteTool(BaseTool):
    """Verify data written to Google Sheets."""

    name: str = "Verify Sheet Write"
    description: str = "Verifies that data was correctly written to Google Sheets"
    args_schema: Type[BaseModel] = VerifyWriteInput

    def __init__(self):
        super().__init__()
        self.sheets_client = None

    @track_time("verify_write")
    def _run(self, range_name: str, expected_values: List[List[Any]]) -> Dict[str, Any]:
        """
        Verify write.

        Args:
            range_name: A1 notation range
            expected_values: Expected 2D array

        Returns:
            Verification result
        """
        try:
            if not self.sheets_client:
                self.sheets_client = SheetsClient()

            logger.info(f"Verifying range: {range_name}")

            success, error = self.sheets_client.verify_write(range_name, expected_values)

            if not success:
                return {
                    "success": False,
                    "verified": False,
                    "error": error
                }

            return {
                "success": True,
                "verified": True,
                "range": range_name
            }

        except Exception as e:
            logger.error(f"Verification failed: {e}")
            return {
                "success": False,
                "verified": False,
                "error": str(e)
            }


class GenerateSheetSummaryTool(BaseTool):
    """Generate summary of sheet update."""

    name: str = "Generate Sheet Summary"
    description: str = "Generates a summary of what was written to Google Sheets"
    args_schema: Type[BaseModel] = BaseModel

    @track_time("generate_summary")
    def _run(self, write_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate summary.

        Args:
            write_result: Result from write operation

        Returns:
            Summary
        """
        try:
            summary = {
                "ranges_updated": write_result.get('ranges_written', 0),
                "verification_status": "verified" if write_result.get('verified') else "not verified",
                "status": "success" if write_result.get('success') else "failed",
                "checksums": write_result.get('checksums', {})
            }

            logger.info("Generated sheet update summary", extra=summary)

            return {
                "success": True,
                "summary": summary
            }

        except Exception as e:
            logger.error(f"Summary generation failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


def create_sheets_agent() -> Agent:
    """
    Create Google Sheets agent with write/verify tools.

    Returns:
        Configured CrewAI Agent
    """
    tools = [
        WriteToSheetsTool(),
        ClearSheetRangesTool(),
        VerifySheetWriteTool(),
        GenerateSheetSummaryTool()
    ]

    agent = Agent(
        role='Dashboard Publishing Specialist',
        goal='Publish validated financial data to Google Sheets dashboard with verification',
        backstory="""You are an expert in Google Sheets API and data publishing workflows.
        You ensure idempotent writes, verify data integrity, and maintain audit trails.
        You handle errors gracefully and always confirm successful publishes.
        You understand the importance of data accuracy in financial dashboards.""",
        tools=tools,
        verbose=True,
        memory=True,
        allow_delegation=False
    )

    logger.info("Created Sheets agent")
    return agent
