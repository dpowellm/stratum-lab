"""
FastAPI server with webhooks, manual triggers, and health checks.
"""

import os
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from fastapi import FastAPI, Request, HTTPException, BackgroundTasks, Header
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from app.agents.orchestrator import run_workflow
from app.server.signature import verify_webhook_signature, extract_signature_from_header
from app.server.queue import task_queue
from app.tools.telemetry import setup_logging
from app.tools.util import iso_now

# Setup logging
log_level = os.getenv('LOG_LEVEL', 'INFO')
setup_logging(log_level)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="QuickBooks Dashboard Automation",
    description="Automated QuickBooks → Google Sheets financial dashboard updates",
    version="1.0.0"
)


# Request/Response Models
class RunWorkflowRequest(BaseModel):
    """Request model for manual workflow runs."""
    mode: str = Field("publish", description="'dry_run' or 'publish'")
    days: int = Field(30, description="Number of days of data to extract")
    use_cdc: bool = Field(False, description="Use CDC instead of full extraction")
    cdc_since: Optional[str] = Field(None, description="ISO timestamp for CDC")
    require_confirmation: bool = Field(False, description="Require confirmation before publishing")


class WebhookEvent(BaseModel):
    """QuickBooks webhook event model."""
    eventNotifications: list = Field(..., description="List of event notifications")


# Endpoints
@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "service": "QuickBooks Dashboard Automation",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/healthz")
async def health_check():
    """Health check endpoint for Cloud Run / K8s."""
    return {
        "status": "healthy",
        "timestamp": iso_now()
    }


@app.post("/run")
async def run_manual(
    request: RunWorkflowRequest,
    background_tasks: BackgroundTasks
) -> Dict[str, Any]:
    """
    Manually trigger workflow.

    Args:
        request: Workflow configuration
        background_tasks: FastAPI background tasks

    Returns:
        Task information
    """
    try:
        logger.info(
            "Manual workflow triggered",
            extra={
                "mode": request.mode,
                "days": request.days,
                "use_cdc": request.use_cdc
            }
        )

        # Enqueue async task
        task_id = await task_queue.enqueue(
            run_workflow,
            mode=request.mode,
            days=request.days,
            use_cdc=request.use_cdc,
            cdc_since=request.cdc_since,
            require_confirmation=request.require_confirmation
        )

        return {
            "success": True,
            "message": "Workflow queued",
            "task_id": task_id,
            "status_url": f"/tasks/{task_id}"
        }

    except Exception as e:
        logger.error(f"Failed to queue workflow: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/qbo/webhook")
async def quickbooks_webhook(
    request: Request,
    intuit_signature: Optional[str] = Header(None)
) -> Dict[str, Any]:
    """
    QuickBooks webhook endpoint.

    Receives and verifies webhook events from QuickBooks,
    then processes them asynchronously.

    Args:
        request: FastAPI request
        intuit_signature: Webhook signature header

    Returns:
        Acknowledgment response
    """
    try:
        # Read raw body
        body = await request.body()

        # Extract signature
        if not intuit_signature:
            # Try alternate header names
            intuit_signature = request.headers.get('Intuit-Signature')

        if not intuit_signature:
            logger.error("Missing Intuit-Signature header")
            raise HTTPException(status_code=401, detail="Missing signature")

        signature = extract_signature_from_header(intuit_signature)

        # Verify signature
        if not verify_webhook_signature(body, signature):
            logger.error("Invalid webhook signature")
            raise HTTPException(status_code=401, detail="Invalid signature")

        # Parse event
        event_data = await request.json()
        event = WebhookEvent(**event_data)

        logger.info(
            "Webhook received",
            extra={
                "notifications": len(event.eventNotifications),
                "signature_verified": True
            }
        )

        # Process events asynchronously
        task_id = await task_queue.enqueue(
            process_webhook_events,
            event.eventNotifications
        )

        # ACK fast (< 3 seconds)
        return {
            "success": True,
            "message": "Webhook received and queued",
            "task_id": task_id,
            "processed_at": iso_now()
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Webhook processing error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/tasks/{task_id}")
async def get_task_status(task_id: str) -> Dict[str, Any]:
    """
    Get task status.

    Args:
        task_id: Task ID

    Returns:
        Task status
    """
    task = task_queue.get_task_status(task_id)

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    return task


@app.get("/tasks")
async def list_tasks() -> Dict[str, Any]:
    """List all tasks."""
    tasks = task_queue.get_all_tasks()

    return {
        "total": len(tasks),
        "tasks": list(tasks.values())
    }


@app.post("/tasks/cleanup")
async def cleanup_tasks(older_than_minutes: int = 60) -> Dict[str, Any]:
    """
    Clean up old completed tasks.

    Args:
        older_than_minutes: Remove tasks older than this

    Returns:
        Cleanup summary
    """
    removed = task_queue.cleanup_completed(older_than_minutes)

    return {
        "success": True,
        "removed": removed
    }


# Helper Functions
def process_webhook_events(notifications: list) -> Dict[str, Any]:
    """
    Process webhook event notifications.

    Args:
        notifications: List of event notifications

    Returns:
        Processing result
    """
    try:
        logger.info(f"Processing {len(notifications)} webhook notifications")

        affected_entities = set()
        last_timestamp = None

        # Parse notifications
        for notification in notifications:
            realm_id = notification.get('realmId')
            data_change_event = notification.get('dataChangeEvent', {})
            entities = data_change_event.get('entities', [])

            for entity in entities:
                entity_name = entity.get('name')
                operation = entity.get('operation')
                last_updated = entity.get('lastUpdated')

                affected_entities.add(entity_name)

                if last_updated:
                    last_timestamp = last_updated

                logger.info(
                    f"Entity change: {entity_name} ({operation})",
                    extra={
                        "realm_id": realm_id,
                        "entity": entity_name,
                        "operation": operation
                    }
                )

        # Determine if we need a full refresh or CDC
        if not last_timestamp:
            last_timestamp = iso_now()

        # Run targeted workflow
        # For simplicity, we'll do a CDC refresh
        result = run_workflow(
            mode="publish",
            use_cdc=True,
            cdc_since=last_timestamp
        )

        logger.info("Webhook events processed", extra={"result": result})

        return {
            "success": True,
            "notifications_processed": len(notifications),
            "affected_entities": list(affected_entities),
            "workflow_result": result
        }

    except Exception as e:
        logger.error(f"Webhook event processing failed: {e}", exc_info=True)
        return {
            "success": False,
            "error": str(e)
        }


# Startup/Shutdown Events
@app.on_event("startup")
async def startup_event():
    """Startup tasks."""
    logger.info("FastAPI server starting up")


@app.on_event("shutdown")
async def shutdown_event():
    """Shutdown tasks."""
    logger.info("FastAPI server shutting down")


# Error Handlers
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)

    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": str(exc),
            "timestamp": iso_now()
        }
    )


# CLI Entry Point
if __name__ == "__main__":
    import uvicorn
    import argparse

    parser = argparse.ArgumentParser(description="QuickBooks Dashboard Automation Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8080, help="Port to bind to")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")

    args = parser.parse_args()

    uvicorn.run(
        "app.server.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level=log_level.lower()
    )
