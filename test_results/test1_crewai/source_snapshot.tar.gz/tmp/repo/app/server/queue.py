"""
Async task queue for processing webhook events.
Simple in-process queue for lightweight deployments.
Can be replaced with Redis/Cloud Tasks for production scale.
"""

import asyncio
import logging
from typing import Dict, Any, Optional, Callable
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import uuid

logger = logging.getLogger(__name__)


class TaskQueue:
    """
    Simple async task queue for webhook event processing.

    For production, consider:
    - Redis Queue (RQ)
    - Celery
    - Google Cloud Tasks
    - AWS SQS + Lambda
    """

    def __init__(self, max_workers: int = 5):
        """
        Initialize task queue.

        Args:
            max_workers: Maximum concurrent workers
        """
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.tasks: Dict[str, Dict[str, Any]] = {}
        logger.info(f"Initialized task queue with {max_workers} workers")

    async def enqueue(
        self,
        func: Callable,
        *args,
        task_id: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        Enqueue a task for async execution.

        Args:
            func: Function to execute
            *args: Positional arguments
            task_id: Optional task ID
            **kwargs: Keyword arguments

        Returns:
            Task ID
        """
        if task_id is None:
            task_id = str(uuid.uuid4())

        logger.info(f"Enqueueing task: {task_id}", extra={"function": func.__name__})

        # Store task metadata
        self.tasks[task_id] = {
            "id": task_id,
            "status": "queued",
            "function": func.__name__,
            "enqueued_at": datetime.utcnow().isoformat() + 'Z',
            "started_at": None,
            "completed_at": None,
            "result": None,
            "error": None
        }

        # Execute in background
        loop = asyncio.get_event_loop()
        loop.run_in_executor(
            self.executor,
            self._execute_task,
            task_id,
            func,
            args,
            kwargs
        )

        return task_id

    def _execute_task(
        self,
        task_id: str,
        func: Callable,
        args: tuple,
        kwargs: dict
    ) -> None:
        """
        Execute task (runs in thread pool).

        Args:
            task_id: Task ID
            func: Function to execute
            args: Positional arguments
            kwargs: Keyword arguments
        """
        try:
            logger.info(f"Starting task: {task_id}")

            self.tasks[task_id]["status"] = "running"
            self.tasks[task_id]["started_at"] = datetime.utcnow().isoformat() + 'Z'

            # Execute function
            result = func(*args, **kwargs)

            # Update task status
            self.tasks[task_id]["status"] = "completed"
            self.tasks[task_id]["completed_at"] = datetime.utcnow().isoformat() + 'Z'
            self.tasks[task_id]["result"] = result

            logger.info(f"Task completed: {task_id}", extra={"result": str(result)[:200]})

        except Exception as e:
            logger.error(f"Task failed: {task_id}", exc_info=True)

            self.tasks[task_id]["status"] = "failed"
            self.tasks[task_id]["completed_at"] = datetime.utcnow().isoformat() + 'Z'
            self.tasks[task_id]["error"] = str(e)

    def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """
        Get task status.

        Args:
            task_id: Task ID

        Returns:
            Task metadata or None
        """
        return self.tasks.get(task_id)

    def get_all_tasks(self) -> Dict[str, Dict[str, Any]]:
        """Get all tasks."""
        return self.tasks.copy()

    def cleanup_completed(self, older_than_minutes: int = 60) -> int:
        """
        Clean up completed tasks older than specified minutes.

        Args:
            older_than_minutes: Remove tasks older than this

        Returns:
            Number of tasks removed
        """
        from datetime import timedelta

        cutoff = datetime.utcnow() - timedelta(minutes=older_than_minutes)
        removed = 0

        task_ids = list(self.tasks.keys())
        for task_id in task_ids:
            task = self.tasks[task_id]

            if task["status"] in ["completed", "failed"]:
                completed_at = task.get("completed_at")
                if completed_at:
                    completed_time = datetime.fromisoformat(completed_at.rstrip('Z'))
                    if completed_time < cutoff:
                        del self.tasks[task_id]
                        removed += 1

        if removed > 0:
            logger.info(f"Cleaned up {removed} old tasks")

        return removed


# Global task queue instance
task_queue = TaskQueue(max_workers=5)
