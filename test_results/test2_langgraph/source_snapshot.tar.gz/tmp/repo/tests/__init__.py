"""Test suite for Agentic Document Extraction System."""
