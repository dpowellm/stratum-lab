"""Unit tests for ColPali VLM council member."""

import json
from unittest.mock import MagicMock

import pytest

from src.council.members.base import ExtractionResult, MemberCapability
from src.council.members.colpali_vlm import ColPaliVLMMember


class TestColPaliMemberInit:
    """Tests for ColPali member initialization."""

    def test_member_name_and_version(self):
        """Test that name and version are set correctly."""
        member = ColPaliVLMMember()
        assert member.name == "colpali"
        assert member.model_version == "colpali-v1.3"

    def test_capabilities(self):
        """Test that expected capabilities are present."""
        member = ColPaliVLMMember()
        expected = {
            MemberCapability.TEXT_EXTRACTION,
            MemberCapability.LAYOUT_ANALYSIS,
            MemberCapability.FORM_UNDERSTANDING,
            MemberCapability.TABLE_EXTRACTION,
            MemberCapability.CHART_UNDERSTANDING,
            MemberCapability.DIAGRAM_ANALYSIS,
            MemberCapability.IMAGE_REASONING,
            MemberCapability.LOCAL_PROCESSING,
        }
        assert expected == member.capabilities

    def test_initialize_without_gguf_raises(self):
        """Test that initialization fails without gguf_path."""
        member = ColPaliVLMMember()
        with pytest.raises(RuntimeError, match="ColPali requires a GGUF model path"):
            import asyncio

            asyncio.get_event_loop().run_until_complete(member.initialize())

    def test_not_initialized_by_default(self):
        """Test member is not initialized by default."""
        member = ColPaliVLMMember()
        assert not member.is_initialized

    def test_gguf_path_stored(self):
        """Test that gguf_path is stored correctly."""
        member = ColPaliVLMMember(
            gguf_path="/path/to/colpali.gguf",
            mmproj_path="/path/to/mmproj.gguf",
        )
        assert member._gguf_path == "/path/to/colpali.gguf"
        assert member._mmproj_path == "/path/to/mmproj.gguf"

    def test_default_params(self):
        """Test default parameter values."""
        member = ColPaliVLMMember()
        assert member._max_tokens == 4096
        assert member._n_gpu_layers == -1
        assert member._temperature == 0.0
        assert member._confidence_threshold == 0.6


class TestColPaliExtraction:
    """Tests for ColPali extraction."""

    @pytest.fixture
    def mock_llamacpp(self):
        """Create a mock llama.cpp instance."""
        mock = MagicMock()
        mock.create_chat_completion.return_value = {
            "choices": [
                {
                    "message": {
                        "content": json.dumps(
                            {
                                "fields": [
                                    {
                                        "name": "invoice_number",
                                        "value": "INV-001",
                                        "confidence": 0.95,
                                        "reasoning": "Clearly visible",
                                    },
                                    {
                                        "name": "total",
                                        "value": "$1,000.00",
                                        "confidence": 0.90,
                                        "reasoning": "Bottom of page",
                                    },
                                ],
                                "document_type": "invoice",
                                "summary": "An invoice document",
                            }
                        )
                    }
                }
            ]
        }
        return mock

    @pytest.fixture
    def member_with_mock(self, mock_llamacpp):
        """Create a ColPaliVLMMember with mocked llama.cpp."""
        member = ColPaliVLMMember(gguf_path="/fake/path.gguf")
        member._llamacpp = mock_llamacpp
        member._initialized = True
        return member

    async def test_extract_returns_extraction_result(self, member_with_mock):
        """Test that extract returns an ExtractionResult."""
        result = await member_with_mock.extract(
            image_data=b"fake_image_data",
            document_type="invoice",
        )
        assert isinstance(result, ExtractionResult)
        assert result.member_name == "colpali"
        assert result.model_version == "colpali-v1.3"
        assert result.status == "success"

    async def test_extract_parses_fields(self, member_with_mock):
        """Test that fields are parsed correctly from response."""
        result = await member_with_mock.extract(image_data=b"fake_image_data")
        field_names = {f.field_name for f in result.fields}
        assert "invoice_number" in field_names
        assert "total" in field_names

        inv_field = result.get_field("invoice_number")
        assert inv_field is not None
        assert inv_field.value == "INV-001"
        assert inv_field.confidence == 0.95

    async def test_extract_handles_json_parse_error(self):
        """Test graceful fallback for non-JSON output."""
        mock_llm = MagicMock()
        mock_llm.create_chat_completion.return_value = {
            "choices": [{"message": {"content": "This is not valid JSON at all"}}]
        }
        member = ColPaliVLMMember(gguf_path="/fake/path.gguf")
        member._llamacpp = mock_llm
        member._initialized = True

        result = await member.extract(image_data=b"fake")
        assert result.status == "success"
        assert len(result.fields) == 1
        assert result.fields[0].field_name == "raw_extraction"
        assert result.fields[0].confidence == 0.7

    async def test_extract_handles_model_error(self):
        """Test that model errors return ExtractionResult with status='error'."""
        mock_llm = MagicMock()
        mock_llm.create_chat_completion.side_effect = RuntimeError("GPU OOM")
        member = ColPaliVLMMember(gguf_path="/fake/path.gguf")
        member._llamacpp = mock_llm
        member._initialized = True

        result = await member.extract(image_data=b"fake")
        assert result.status == "error"
        assert "GPU OOM" in result.error_message
        assert result.fields == []

    async def test_confidence_filtering(self):
        """Test that fields below confidence threshold are filtered out."""
        mock_llm = MagicMock()
        mock_llm.create_chat_completion.return_value = {
            "choices": [
                {
                    "message": {
                        "content": json.dumps(
                            {
                                "fields": [
                                    {"name": "high_conf", "value": "A", "confidence": 0.95},
                                    {"name": "low_conf", "value": "B", "confidence": 0.30},
                                ],
                            }
                        )
                    }
                }
            ]
        }
        member = ColPaliVLMMember(
            gguf_path="/fake/path.gguf",
            confidence_threshold=0.6,
        )
        member._llamacpp = mock_llm
        member._initialized = True

        result = await member.extract(image_data=b"fake")
        field_names = {f.field_name for f in result.fields}
        assert "high_conf" in field_names
        assert "low_conf" not in field_names

    async def test_batch_extraction(self, member_with_mock):
        """Test that batch extraction processes all images sequentially."""
        results = await member_with_mock.extract_batch(
            images=[b"img1", b"img2", b"img3"],
            document_type="invoice",
        )
        assert len(results) == 3
        assert all(isinstance(r, ExtractionResult) for r in results)
        assert all(r.member_name == "colpali" for r in results)

    async def test_shutdown_releases_resources(self):
        """Test that shutdown clears model reference and resets state."""
        member = ColPaliVLMMember(gguf_path="/fake/path.gguf")
        member._llamacpp = MagicMock()
        member._initialized = True

        await member.shutdown()
        assert member._llamacpp is None
        assert not member.is_initialized


class TestColPaliPromptBuilding:
    """Tests for prompt construction."""

    def test_prompt_with_document_type(self):
        member = ColPaliVLMMember()
        prompt = member._build_extraction_prompt("invoice", None)
        assert "invoice" in prompt

    def test_prompt_with_target_fields(self):
        member = ColPaliVLMMember()
        prompt = member._build_extraction_prompt(None, ["total", "date"])
        assert "total" in prompt
        assert "date" in prompt

    def test_prompt_contains_json_instructions(self):
        member = ColPaliVLMMember()
        prompt = member._build_extraction_prompt(None, None)
        assert "JSON" in prompt

    def test_prompt_mentions_visual_analysis(self):
        member = ColPaliVLMMember()
        prompt = member._build_extraction_prompt(None, None)
        assert "visual" in prompt.lower()


class TestColPaliResponseParsing:
    """Tests for response parsing."""

    def test_parse_valid_json(self):
        member = ColPaliVLMMember()
        fields = member._parse_response(
            '{"fields": [{"name": "total", "value": "$500", "confidence": 0.9}]}',
            "invoice",
        )
        assert len(fields) == 1
        assert fields[0].field_name == "total"
        assert fields[0].value == "$500"
        assert fields[0].extraction_method == "colpali_vlm"

    def test_parse_json_with_code_block(self):
        member = ColPaliVLMMember()
        response = '```json\n{"fields": [{"name": "date", "value": "2026-01-29", "confidence": 0.85}]}\n```'
        fields = member._parse_response(response, None)
        assert len(fields) == 1
        assert fields[0].field_name == "date"

    def test_parse_invalid_json_fallback(self):
        member = ColPaliVLMMember()
        fields = member._parse_response("Not JSON at all", None)
        assert len(fields) == 1
        assert fields[0].field_name == "raw_extraction"
        assert fields[0].confidence == 0.7
        assert fields[0].extraction_method == "colpali_vlm_text"

    def test_parse_includes_document_type(self):
        member = ColPaliVLMMember()
        fields = member._parse_response(
            '{"fields": [], "document_type": "receipt"}',
            None,
        )
        doc_type = [f for f in fields if f.field_name == "detected_document_type"]
        assert len(doc_type) == 1
        assert doc_type[0].value == "receipt"

    def test_parse_includes_layout_analysis(self):
        member = ColPaliVLMMember()
        fields = member._parse_response(
            '{"fields": [], "layout_analysis": {"structure": "two-column"}}',
            None,
        )
        layout = [f for f in fields if f.field_name == "layout_analysis"]
        assert len(layout) == 1
        assert layout[0].extraction_method == "colpali_vlm_analysis"

    def test_parse_includes_summary(self):
        member = ColPaliVLMMember()
        fields = member._parse_response(
            '{"fields": [], "summary": "A test document"}',
            None,
        )
        summary = [f for f in fields if f.field_name == "document_summary"]
        assert len(summary) == 1
        assert summary[0].value == "A test document"
