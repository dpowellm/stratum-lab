"""Tests for the LLM Answer Generator."""

from unittest.mock import MagicMock, patch

import pytest

from src.services.rag.llm_answer import LLMAnswerGenerator, _find_gguf_model


@pytest.mark.unit
class TestFindGgufModel:
    """Tests for _find_gguf_model helper."""

    def test_returns_none_when_cache_missing(self, tmp_path):
        with patch("src.services.rag.llm_answer.Path") as mock_path:
            mock_home = MagicMock()
            mock_path.home.return_value = mock_home
            cache_dir = mock_home / ".cache" / "huggingface" / "hub"
            cache_dir.exists.return_value = False
            result = _find_gguf_model()
            assert result is None

    def test_returns_none_when_no_qwen_gguf(self, tmp_path):
        with patch("src.services.rag.llm_answer.Path") as mock_path:
            mock_home = MagicMock()
            mock_path.home.return_value = mock_home
            cache_dir = mock_home / ".cache" / "huggingface" / "hub"
            cache_dir.exists.return_value = True
            cache_dir.rglob.return_value = []
            result = _find_gguf_model()
            assert result is None


@pytest.mark.unit
class TestLLMAnswerGenerator:
    """Tests for LLMAnswerGenerator."""

    def test_singleton(self):
        LLMAnswerGenerator._instance = None
        instance1 = LLMAnswerGenerator.get_instance()
        instance2 = LLMAnswerGenerator.get_instance()
        assert instance1 is instance2
        LLMAnswerGenerator._instance = None

    def test_not_available_without_model(self):
        gen = LLMAnswerGenerator()
        with patch("src.services.rag.llm_answer._find_gguf_model", return_value=None):
            assert gen.is_available is False

    def test_generate_returns_none_when_unavailable(self):
        gen = LLMAnswerGenerator()
        gen._available = False
        result = gen.generate("What is this?", ["some text"])
        assert result is None

    def test_generate_returns_none_for_empty_chunks(self):
        gen = LLMAnswerGenerator()
        gen._available = False
        result = gen.generate("What is this?", [])
        assert result is None

    def test_estimate_confidence_empty(self):
        gen = LLMAnswerGenerator()
        assert gen._estimate_confidence("", []) == 0.3
        assert gen._estimate_confidence("", ["text"]) == 0.3

    def test_estimate_confidence_high_overlap(self):
        gen = LLMAnswerGenerator()
        answer = "the invoice total is 500"
        chunks = ["the invoice total is 500 dollars"]
        conf = gen._estimate_confidence(answer, chunks)
        assert conf >= 0.7

    def test_estimate_confidence_low_overlap(self):
        gen = LLMAnswerGenerator()
        answer = "xyz abc unknown"
        chunks = ["the document contains financial data"]
        conf = gen._estimate_confidence(answer, chunks)
        assert conf <= 0.6
