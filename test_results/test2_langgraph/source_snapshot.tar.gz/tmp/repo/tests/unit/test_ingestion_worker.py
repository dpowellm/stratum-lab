"""Unit tests for the document ingestion worker tasks."""

import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import StaticPool

from src.models.database.base import Base
from src.models.database.document import ProcessingStatus
from src.services.document.repository import DocumentRepository

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture
async def db_engine():
    """Create a test database engine."""
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=False,
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(db_engine):
    """Create a test database session."""
    factory = async_sessionmaker(bind=db_engine, class_=AsyncSession, expire_on_commit=False)
    async with factory() as session:
        yield session


@pytest_asyncio.fixture
async def sample_document(db_session):
    """Create a sample document in the DB for testing."""
    repo = DocumentRepository(db_session)
    doc = await repo.create(
        filename="test_invoice.pdf",
        storage_path=f"documents/{uuid.uuid4()}/test_invoice.pdf",
        file_size=1024,
        mime_type="application/pdf",
        checksum=uuid.uuid4().hex,
    )
    await db_session.commit()
    return doc


@pytest.fixture
def mock_storage():
    """Create a mock storage service."""
    storage = AsyncMock()
    storage.download = AsyncMock()
    storage.exists = AsyncMock(return_value=True)
    storage.get_metadata = AsyncMock()
    return storage


# ---------------------------------------------------------------------------
# Tests for ingestion pipeline functions
# ---------------------------------------------------------------------------


class TestProcessDocumentPipeline:
    """Tests for the document processing pipeline logic."""

    async def test_validate_document_file_exists(self, mock_storage):
        """Test that validation checks file existence in storage."""
        from src.workers.tasks.ingestion import _validate_document_from_storage

        mock_storage.exists.return_value = True
        result = await _validate_document_from_storage(
            mock_storage, "documents/abc/test.pdf", "application/pdf"
        )
        assert result["valid"] is True
        mock_storage.exists.assert_called_once()

    async def test_validate_document_file_missing(self, mock_storage):
        """Test that validation fails when file does not exist in storage."""
        from src.workers.tasks.ingestion import _validate_document_from_storage

        mock_storage.exists.return_value = False
        result = await _validate_document_from_storage(
            mock_storage, "documents/missing/test.pdf", "application/pdf"
        )
        assert result["valid"] is False
        assert "not found" in result["error"].lower()

    async def test_update_document_status_in_pipeline(self, db_session, sample_document):
        """Test that document status is updated during processing."""
        repo = DocumentRepository(db_session)
        doc = await repo.update_status(
            sample_document.id, ProcessingStatus.PREPROCESSING, progress=5
        )
        assert doc is not None
        assert doc.status == ProcessingStatus.PREPROCESSING
        assert doc.progress_percent == 5

    async def test_update_document_through_all_stages(self, db_session, sample_document):
        """Test that document status can be updated through all processing stages."""
        repo = DocumentRepository(db_session)
        stages = [
            (ProcessingStatus.PREPROCESSING, 5),
            (ProcessingStatus.EXTRACTING, 30),
            (ProcessingStatus.COUNCIL_DELIBERATING, 60),
            (ProcessingStatus.VALIDATING, 80),
            (ProcessingStatus.COMPLETED, 100),
        ]
        for status, progress in stages:
            doc = await repo.update_status(sample_document.id, status, progress=progress)
            assert doc.status == status
            assert doc.progress_percent == progress

    async def test_process_document_downloads_from_storage(self, mock_storage):
        """Test that process_document downloads the file from storage."""
        from src.workers.tasks.ingestion import _download_document

        mock_content = b"%PDF-1.4 test content"
        mock_storage.download.return_value = MagicMock(content=mock_content)

        content = await _download_document(mock_storage, "documents/abc/test.pdf")
        assert content == mock_content
        mock_storage.download.assert_called_once_with("documents/abc/test.pdf")

    async def test_process_document_download_missing_file(self, mock_storage):
        """Test that process_document raises on missing file."""
        from src.services.storage.base import ObjectNotFoundError
        from src.workers.tasks.ingestion import _download_document

        mock_storage.download.side_effect = ObjectNotFoundError("not found")

        with pytest.raises(ObjectNotFoundError):
            await _download_document(mock_storage, "documents/missing/test.pdf")

    async def test_document_fail_on_error(self, db_session, sample_document):
        """Test that document is marked as failed on error."""
        repo = DocumentRepository(db_session)
        doc = await repo.get_by_id(sample_document.id)
        doc.fail("Test error message")
        await db_session.flush()
        await db_session.refresh(doc)

        assert doc.status == ProcessingStatus.FAILED
        assert doc.error_message == "Test error message"


class TestExtractionMethods:
    """Tests for text extraction method selection and execution."""

    def test_get_extraction_method_pdf(self):
        """Test extraction method selection for PDF."""
        from src.workers.tasks.ingestion import _get_extraction_method

        assert _get_extraction_method("application/pdf") == "pdf_parser_with_ocr"

    def test_get_extraction_method_png(self):
        """Test extraction method selection for PNG."""
        from src.workers.tasks.ingestion import _get_extraction_method

        assert _get_extraction_method("image/png") == "ocr"

    def test_get_extraction_method_jpeg(self):
        """Test extraction method selection for JPEG."""
        from src.workers.tasks.ingestion import _get_extraction_method

        assert _get_extraction_method("image/jpeg") == "ocr"

    def test_get_extraction_method_tiff(self):
        """Test extraction method selection for TIFF."""
        from src.workers.tasks.ingestion import _get_extraction_method

        assert _get_extraction_method("image/tiff") == "ocr"

    def test_get_extraction_method_text(self):
        """Test extraction method selection for text."""
        from src.workers.tasks.ingestion import _get_extraction_method

        assert _get_extraction_method("text/plain") == "text"

    def test_detect_file_type_pdf(self):
        """Test file type detection for PDF."""
        from src.workers.tasks.ingestion import _detect_file_type

        assert _detect_file_type(".pdf", "application/pdf") == "pdf"

    def test_detect_file_type_image(self):
        """Test file type detection for images."""
        from src.workers.tasks.ingestion import _detect_file_type

        assert _detect_file_type(".png", "image/png") == "image"
        assert _detect_file_type(".jpg", "image/jpeg") == "image"
        assert _detect_file_type(".tiff", "image/tiff") == "image"

    def test_detect_file_type_unknown(self):
        """Test file type detection for unknown type."""
        from src.workers.tasks.ingestion import _detect_file_type

        assert _detect_file_type(".xyz", "application/unknown") == "unknown"

    def test_is_valid_file_format(self):
        """Test file format validation."""
        from src.workers.tasks.ingestion import _is_valid_file_format

        assert _is_valid_file_format("pdf") is True
        assert _is_valid_file_format("image") is True
        assert _is_valid_file_format("unknown") is False


class TestConvertPdfToImages:
    """Tests for PDF to image conversion."""

    async def test_convert_pdf_returns_images(self):
        """Test that PDF conversion returns list of image bytes."""
        from src.workers.tasks.ingestion import _convert_pdf_to_images

        # Minimal PDF content (won't actually convert without poppler,
        # so we mock the underlying library)
        with patch("src.workers.tasks.ingestion.pdf2image_convert") as mock_convert:
            # Create a mock PIL Image
            mock_img = MagicMock()
            mock_img.tobytes.return_value = b"image_data"

            # Mock save to write bytes to a BytesIO
            def mock_save(buf, format):
                buf.write(b"PNG_IMAGE_DATA")

            mock_img.save = mock_save
            mock_convert.return_value = [mock_img]

            images = await _convert_pdf_to_images(b"%PDF-1.4 content")
            assert len(images) == 1
            assert isinstance(images[0], bytes)
            assert len(images[0]) > 0

    async def test_convert_pdf_multipage(self):
        """Test that multi-page PDF returns multiple images."""
        from src.workers.tasks.ingestion import _convert_pdf_to_images

        with patch("src.workers.tasks.ingestion.pdf2image_convert") as mock_convert:
            mock_images = []
            for _ in range(3):
                img = MagicMock()

                def mock_save(buf, format):
                    buf.write(b"PNG_DATA")

                img.save = mock_save
                mock_images.append(img)
            mock_convert.return_value = mock_images

            images = await _convert_pdf_to_images(b"%PDF-1.4 content")
            assert len(images) == 3


class TestIngestionOrchestration:
    """Tests for the full ingestion orchestration flow."""

    async def test_run_ingestion_pipeline_success(self, db_session, sample_document, mock_storage):
        """Test the full ingestion pipeline with mocked components."""
        from src.workers.tasks.ingestion import run_ingestion_pipeline

        mock_storage.download.return_value = MagicMock(content=b"file_content")

        with patch(
            "src.workers.tasks.ingestion._convert_pdf_to_images",
            return_value=[b"image_data"],
        ):
            result = await run_ingestion_pipeline(
                document_id=str(sample_document.id),
                storage_path=sample_document.storage_path,
                file_type="application/pdf",
                storage=mock_storage,
                session=db_session,
            )

        assert result["status"] == "ready_for_council"
        assert result["document_id"] == str(sample_document.id)
        assert result["page_count"] == 1
        assert len(result["image_keys"]) == 1

        # Verify document status was updated
        repo = DocumentRepository(db_session)
        doc = await repo.get_by_id(sample_document.id)
        assert doc.status == ProcessingStatus.EXTRACTING
        assert doc.progress_percent == 30

    async def test_run_ingestion_pipeline_image_file(self, db_session, mock_storage):
        """Test ingestion pipeline with an image file (no PDF conversion needed)."""
        from src.workers.tasks.ingestion import run_ingestion_pipeline

        repo = DocumentRepository(db_session)
        doc = await repo.create(
            filename="receipt.png",
            storage_path=f"documents/{uuid.uuid4()}/receipt.png",
            file_size=2048,
            mime_type="image/png",
            checksum=uuid.uuid4().hex,
        )
        await db_session.commit()

        mock_storage.download.return_value = MagicMock(content=b"\x89PNG_data")

        result = await run_ingestion_pipeline(
            document_id=str(doc.id),
            storage_path=doc.storage_path,
            file_type="image/png",
            storage=mock_storage,
            session=db_session,
        )

        assert result["status"] == "ready_for_council"
        assert result["page_count"] == 1

    async def test_run_ingestion_pipeline_file_not_found(
        self, db_session, sample_document, mock_storage
    ):
        """Test ingestion pipeline handles missing file."""
        from src.services.storage.base import ObjectNotFoundError
        from src.workers.tasks.ingestion import run_ingestion_pipeline

        mock_storage.download.side_effect = ObjectNotFoundError("not found")

        with pytest.raises(ObjectNotFoundError):
            await run_ingestion_pipeline(
                document_id=str(sample_document.id),
                storage_path=sample_document.storage_path,
                file_type="application/pdf",
                storage=mock_storage,
                session=db_session,
            )

        # Document should be marked as failed
        repo = DocumentRepository(db_session)
        doc = await repo.get_by_id(sample_document.id)
        assert doc.status == ProcessingStatus.FAILED

    async def test_run_ingestion_pipeline_updates_page_count(
        self, db_session, sample_document, mock_storage
    ):
        """Test that page count is updated on the document record."""
        from src.workers.tasks.ingestion import run_ingestion_pipeline

        mock_storage.download.return_value = MagicMock(content=b"file_content")

        with patch(
            "src.workers.tasks.ingestion._convert_pdf_to_images",
            return_value=[b"img1", b"img2", b"img3"],
        ):
            result = await run_ingestion_pipeline(
                document_id=str(sample_document.id),
                storage_path=sample_document.storage_path,
                file_type="application/pdf",
                storage=mock_storage,
                session=db_session,
            )

        assert result["page_count"] == 3

        repo = DocumentRepository(db_session)
        doc = await repo.get_by_id(sample_document.id)
        assert doc.page_count == 3
