"""
Unit tests for advanced RAG.

Tests for:
- Task 3.1.1: ColPali Multi-Modal Retrieval
- Task 3.1.2: Hybrid Search
- Task 3.1.3: BGE Reranking
- Task 3.1.4: Conversational Q&A
"""

from src.services.rag.colpali import (
    ColPaliRetriever,
    ContentType,
    MultiModalContent,
    MultiModalDocument,
    MultiModalQuery,
    RetrievalResult,
)
from src.services.rag.conversational import (
    Citation,
    ConversationalQA,
    ConversationContext,
    MessageRole,
    QAResponse,
)
from src.services.rag.hybrid import (
    DenseRetriever,
    HybridResult,
    HybridSearchService,
    SearchDocument,
    SearchMethod,
    SparseRetriever,
)
from src.services.rag.reranker import (
    BGEReranker,
    RerankCandidate,
    RerankedResult,
    RerankerConfig,
    RerankerPipeline,
)


class TestColPaliRetriever:
    """Tests for Task 3.1.1: ColPali Multi-Modal Retrieval."""

    def test_retriever_initialization(self):
        """Test ColPali retriever initialization."""
        retriever = ColPaliRetriever()
        result = retriever.initialize()

        assert result is True
        assert retriever._initialized is True

    def test_index_document(self):
        """Test document indexing."""
        retriever = ColPaliRetriever()

        doc = MultiModalDocument(
            document_id="doc_1",
            title="Test Invoice",
            contents=[
                MultiModalContent(
                    content_type=ContentType.TEXT,
                    content="Invoice total: $1,234.56",
                    position=0,
                ),
            ],
        )

        result = retriever.index_document(doc)

        assert result is True
        assert "doc_1" in retriever._documents

    def test_index_document_with_image(self):
        """Test indexing document with images."""
        retriever = ColPaliRetriever()

        doc = MultiModalDocument(
            document_id="doc_2",
            title="Document with Image",
            contents=[
                MultiModalContent(
                    content_type=ContentType.IMAGE,
                    content=b"fake_image_data",
                    position=0,
                ),
            ],
        )

        result = retriever.index_document(doc)

        assert result is True
        assert doc.has_images is True

    def test_retrieve_text(self):
        """Test text retrieval."""
        retriever = ColPaliRetriever()

        # Index documents
        for i in range(3):
            doc = MultiModalDocument(
                document_id=f"doc_{i}",
                title=f"Document {i}",
                contents=[
                    MultiModalContent(
                        content_type=ContentType.TEXT,
                        content=f"Content about topic {i}",
                        position=0,
                    ),
                ],
            )
            retriever.index_document(doc)

        # Query
        query = MultiModalQuery(
            text="topic",
            modalities=[ContentType.TEXT],
            top_k=2,
        )

        results = retriever.retrieve(query)

        assert len(results) <= 2
        assert all(isinstance(r, RetrievalResult) for r in results)

    def test_retrieve_tables(self):
        """Test table retrieval."""
        retriever = ColPaliRetriever()

        doc = MultiModalDocument(
            document_id="table_doc",
            title="Table Document",
            contents=[
                MultiModalContent(
                    content_type=ContentType.TABLE,
                    content="Item | Price\nApple | $1.00\nOrange | $1.50",
                    position=0,
                ),
            ],
        )
        retriever.index_document(doc)

        results = retriever.retrieve_tables("price", top_k=5)

        assert len(results) >= 0  # May or may not find based on scoring

    def test_document_content_count(self):
        """Test content type counting."""
        doc = MultiModalDocument(
            document_id="mixed_doc",
            title="Mixed Content",
            contents=[
                MultiModalContent(ContentType.TEXT, "text", 0),
                MultiModalContent(ContentType.TEXT, "more text", 1),
                MultiModalContent(ContentType.TABLE, "table", 2),
                MultiModalContent(ContentType.IMAGE, b"img", 3),
            ],
        )

        counts = doc.content_count

        assert counts["text"] == 2
        assert counts["table"] == 1
        assert counts["image"] == 1

    def test_get_statistics(self):
        """Test retriever statistics."""
        retriever = ColPaliRetriever()
        retriever.initialize()

        stats = retriever.get_statistics()

        assert "initialized" in stats
        assert "total_documents" in stats


class TestHybridSearch:
    """Tests for Task 3.1.2: Hybrid Search."""

    def test_dense_retriever(self):
        """Test dense (vector) retriever."""
        retriever = DenseRetriever()

        doc = SearchDocument(
            document_id="doc_1",
            content="The quick brown fox jumps over the lazy dog",
            title="Test",
        )
        retriever.index(doc)

        results = retriever.search("brown fox", top_k=5)

        assert len(results) >= 1
        assert results[0][0] == "doc_1"

    def test_sparse_retriever(self):
        """Test sparse (BM25) retriever."""
        retriever = SparseRetriever()

        doc = SearchDocument(
            document_id="doc_1",
            content="The quick brown fox jumps over the lazy dog",
            title="Test",
        )
        retriever.index(doc)

        results = retriever.search("brown fox", top_k=5)

        assert len(results) >= 1
        assert results[0][0] == "doc_1"

    def test_hybrid_search_combined(self):
        """Test hybrid search combines dense and sparse."""
        service = HybridSearchService(dense_weight=0.5, sparse_weight=0.5)

        # Index documents
        for i in range(5):
            doc = SearchDocument(
                document_id=f"doc_{i}",
                content=f"Document {i} contains information about topic {i}",
                title=f"Title {i}",
            )
            service.index(doc)

        results = service.search("information topic", top_k=3, method=SearchMethod.HYBRID)

        assert len(results) <= 3
        assert all(isinstance(r, HybridResult) for r in results)
        assert all(r.dense_score >= 0 for r in results)
        assert all(r.sparse_score >= 0 for r in results)

    def test_hybrid_search_dense_only(self):
        """Test dense-only search."""
        service = HybridSearchService()
        service.index(SearchDocument("doc_1", "test content", "title"))

        results = service.search("test", method=SearchMethod.DENSE)

        assert all(r.method == SearchMethod.DENSE for r in results)

    def test_hybrid_search_sparse_only(self):
        """Test sparse-only search."""
        service = HybridSearchService()
        service.index(SearchDocument("doc_1", "test content", "title"))

        results = service.search("test", method=SearchMethod.SPARSE)

        assert all(r.method == SearchMethod.SPARSE for r in results)

    def test_score_normalization(self):
        """Test that scores are normalized."""
        service = HybridSearchService()

        for i in range(5):
            service.index(SearchDocument(f"doc_{i}", f"content {i}", f"title {i}"))

        results = service.search("content", top_k=5)

        # Combined scores should be normalized
        for r in results:
            assert 0 <= r.combined_score <= 2.0  # Max with both weights at 0.5

    def test_get_statistics(self):
        """Test hybrid search statistics."""
        service = HybridSearchService()

        stats = service.get_statistics()

        assert "total_documents" in stats
        assert "dense_weight" in stats
        assert "sparse_weight" in stats


class TestBGEReranker:
    """Tests for Task 3.1.3: BGE Reranking."""

    def test_reranker_initialization(self):
        """Test reranker initialization."""
        reranker = BGEReranker()
        result = reranker.initialize()

        assert result is True
        assert reranker._initialized is True

    def test_rerank_candidates(self):
        """Test reranking candidates."""
        reranker = BGEReranker()

        candidates = [
            RerankCandidate("doc_1", "The quick brown fox", 0.8),
            RerankCandidate("doc_2", "A brown fox jumps", 0.6),
            RerankCandidate("doc_3", "Something unrelated", 0.9),
        ]

        results = reranker.rerank("brown fox", candidates)

        assert len(results) <= len(candidates)
        assert all(isinstance(r, RerankedResult) for r in results)

    def test_rerank_preserves_metadata(self):
        """Test that metadata is preserved during reranking."""
        reranker = BGEReranker()

        candidates = [
            RerankCandidate(
                "doc_1",
                "Content",
                0.5,
                metadata={"source": "test"},
            ),
        ]

        results = reranker.rerank("query", candidates)

        if results:
            assert results[0].metadata.get("source") == "test"

    def test_rerank_score_threshold(self):
        """Test score threshold filtering."""
        config = RerankerConfig(score_threshold=0.5)
        reranker = BGEReranker(config=config)

        candidates = [
            RerankCandidate("doc_1", "highly relevant content", 0.9),
            RerankCandidate("doc_2", "xyz", 0.1),  # Should be filtered
        ]

        results = reranker.rerank("relevant content", candidates)

        # Low-scoring candidates may be filtered
        assert len(results) <= 2

    def test_rerank_batch(self):
        """Test batch reranking."""
        reranker = BGEReranker()

        queries = ["query 1", "query 2"]
        candidates_batch = [
            [RerankCandidate("doc_1", "content 1", 0.5)],
            [RerankCandidate("doc_2", "content 2", 0.5)],
        ]

        results = reranker.rerank_batch(queries, candidates_batch)

        assert len(results) == 2
        assert all(isinstance(r, list) for r in results)

    def test_reranker_pipeline(self):
        """Test multi-stage reranking pipeline."""
        pipeline = RerankerPipeline(
            [
                BGEReranker(),
                BGEReranker(),
            ]
        )

        candidates = [
            RerankCandidate("doc_1", "content one", 0.5),
            RerankCandidate("doc_2", "content two", 0.6),
        ]

        results = pipeline.rerank("query", candidates)

        assert len(results) <= len(candidates)

    def test_rank_change_calculation(self):
        """Test rank change calculation."""
        result = RerankedResult(
            document_id="doc_1",
            content="test",
            original_rank=5,
            new_rank=2,
            original_score=0.5,
            rerank_score=0.8,
            relevance_boost=0.3,
        )

        assert result.rank_change == 3  # Moved up 3 positions


class TestConversationalQA:
    """Tests for Task 3.1.4: Conversational Q&A."""

    def test_create_conversation(self):
        """Test conversation creation."""
        qa = ConversationalQA()

        context = qa.create_conversation(document_ids=["doc_1", "doc_2"])

        assert context is not None
        assert len(context.document_ids) == 2

    def test_ask_question(self):
        """Test asking a question."""
        qa = ConversationalQA()
        context = qa.create_conversation()

        response = qa.ask(context.conversation_id, "What is the total?")

        assert isinstance(response, QAResponse)
        assert response.answer is not None
        assert response.confidence >= 0

    def test_multi_turn_conversation(self):
        """Test multi-turn conversation maintains context."""
        qa = ConversationalQA()
        context = qa.create_conversation(document_ids=["doc_1"])

        # First turn
        qa.ask(context.conversation_id, "Tell me about the invoice")

        # Second turn
        qa.ask(context.conversation_id, "What about the total?")

        # Should have 2 user messages + 2 assistant messages
        assert context.turn_count == 2
        assert len(context.messages) == 4

    def test_conversation_history_text(self):
        """Test conversation history retrieval."""
        qa = ConversationalQA()
        context = qa.create_conversation()

        qa.ask(context.conversation_id, "Question 1")
        qa.ask(context.conversation_id, "Question 2")

        history = context.get_history_text(max_turns=1)

        assert "Question 2" in history

    def test_entity_tracking(self):
        """Test entity extraction and tracking."""
        qa = ConversationalQA()
        context = qa.create_conversation()

        qa.ask(context.conversation_id, "Tell me about the invoice")

        # Should have tracked document type
        assert "document_type" in context.entities or context.turn_count > 0

    def test_follow_up_questions(self):
        """Test follow-up question generation."""
        qa = ConversationalQA()
        context = qa.create_conversation()

        response = qa.ask(context.conversation_id, "Tell me about the invoice")

        assert isinstance(response.follow_up_questions, list)

    def test_clear_conversation(self):
        """Test conversation clearing."""
        qa = ConversationalQA()
        context = qa.create_conversation()

        result = qa.clear_conversation(context.conversation_id)

        assert result is True
        assert qa.get_conversation(context.conversation_id) is None

    def test_qa_response_structure(self):
        """Test QA response structure."""
        response = QAResponse(
            answer="Test answer",
            citations=[
                Citation("doc_1", "relevant text", page_number=1, relevance_score=0.9),
            ],
            confidence=0.85,
            follow_up_questions=["Next question?"],
        )

        response_dict = response.to_dict()

        assert "answer" in response_dict
        assert "citations" in response_dict
        assert "confidence" in response_dict
        assert len(response_dict["citations"]) == 1

    def test_message_roles(self):
        """Test message role handling."""
        context = ConversationContext(conversation_id="test")

        context.add_message(MessageRole.USER, "User question")
        context.add_message(MessageRole.ASSISTANT, "Assistant answer")
        context.add_message(MessageRole.SYSTEM, "System message")

        assert len(context.messages) == 3
        assert context.messages[0].role == MessageRole.USER
        assert context.messages[1].role == MessageRole.ASSISTANT

    def test_get_statistics(self):
        """Test Q&A service statistics."""
        qa = ConversationalQA()
        qa.create_conversation()
        qa.create_conversation()

        stats = qa.get_statistics()

        assert stats["active_conversations"] == 2
