"""Tests for DocumentRepository."""

import uuid

from src.models.database.document import Document, DocumentType, ProcessingStatus
from src.services.document.repository import DocumentRepository


async def _create_doc(repo: DocumentRepository, suffix: str = "") -> Document:
    """Helper to create a test document."""
    return await repo.create(
        filename=f"test{suffix}.pdf",
        storage_path=f"docs/{uuid.uuid4()}/test{suffix}.pdf",
        file_size=1024,
        mime_type="application/pdf",
        checksum=uuid.uuid4().hex,
    )


class TestDocumentRepository:
    """Tests for DocumentRepository CRUD operations."""

    async def test_create_document(self, test_session):
        repo = DocumentRepository(test_session)
        doc = await _create_doc(repo)

        assert doc.id is not None
        assert doc.filename == "test.pdf"
        assert doc.file_size == 1024
        assert doc.mime_type == "application/pdf"
        assert doc.status == ProcessingStatus.PENDING
        assert doc.document_type == DocumentType.UNKNOWN
        assert doc.is_deleted is False

    async def test_get_document_by_id(self, test_session):
        repo = DocumentRepository(test_session)
        doc = await _create_doc(repo)

        found = await repo.get_by_id(doc.id)
        assert found is not None
        assert found.id == doc.id
        assert found.filename == doc.filename

    async def test_get_document_by_id_not_found(self, test_session):
        repo = DocumentRepository(test_session)
        found = await repo.get_by_id(uuid.uuid4())
        assert found is None

    async def test_get_document_by_checksum(self, test_session):
        repo = DocumentRepository(test_session)
        doc = await _create_doc(repo)

        found = await repo.get_by_checksum(doc.checksum)
        assert found is not None
        assert found.id == doc.id

    async def test_get_document_by_checksum_not_found(self, test_session):
        repo = DocumentRepository(test_session)
        found = await repo.get_by_checksum("nonexistent")
        assert found is None

    async def test_update_document_status(self, test_session):
        repo = DocumentRepository(test_session)
        doc = await _create_doc(repo)

        updated = await repo.update_status(
            doc.id,
            ProcessingStatus.EXTRACTING,
            message="Extracting text",
            progress=50,
        )
        assert updated is not None
        assert updated.status == ProcessingStatus.EXTRACTING
        assert updated.status_message == "Extracting text"
        assert updated.progress_percent == 50

    async def test_update_document_status_not_found(self, test_session):
        repo = DocumentRepository(test_session)
        updated = await repo.update_status(uuid.uuid4(), ProcessingStatus.EXTRACTING)
        assert updated is None

    async def test_list_documents_pagination(self, test_session):
        repo = DocumentRepository(test_session)
        await _create_doc(repo, "_1")
        await _create_doc(repo, "_2")
        await _create_doc(repo, "_3")

        docs, total = await repo.list_documents(page=1, page_size=2)
        assert len(docs) == 2
        assert total == 3

        docs_p2, _ = await repo.list_documents(page=2, page_size=2)
        assert len(docs_p2) == 1

    async def test_list_documents_status_filter(self, test_session):
        repo = DocumentRepository(test_session)
        doc1 = await _create_doc(repo, "_a")
        await _create_doc(repo, "_b")

        await repo.update_status(doc1.id, ProcessingStatus.COMPLETED)

        docs, total = await repo.list_documents(status=ProcessingStatus.COMPLETED)
        assert total == 1
        assert docs[0].id == doc1.id

    async def test_soft_delete(self, test_session):
        repo = DocumentRepository(test_session)
        doc = await _create_doc(repo)

        deleted = await repo.soft_delete(doc.id)
        assert deleted is not None
        assert deleted.is_deleted is True

        # Should not be found anymore
        found = await repo.get_by_id(doc.id)
        assert found is None

    async def test_soft_delete_not_found(self, test_session):
        repo = DocumentRepository(test_session)
        result = await repo.soft_delete(uuid.uuid4())
        assert result is None

    async def test_create_extraction(self, test_session):
        repo = DocumentRepository(test_session)
        doc = await _create_doc(repo)

        extraction = await repo.create_extraction(
            document_id=doc.id,
            overall_confidence=0.92,
            extracted_data={"invoice_number": "INV-001", "total": 1500.0},
        )

        assert extraction.id is not None
        assert extraction.document_id == doc.id
        assert extraction.overall_confidence == 0.92
        assert extraction.extracted_data["invoice_number"] == "INV-001"
        assert extraction.version == 1
        assert extraction.is_latest is True

    async def test_get_latest_extraction(self, test_session):
        repo = DocumentRepository(test_session)
        doc = await _create_doc(repo)

        await repo.create_extraction(
            document_id=doc.id,
            overall_confidence=0.85,
            extracted_data={"field": "v1"},
            version=1,
        )

        latest = await repo.get_latest_extraction(doc.id)
        assert latest is not None
        assert latest.overall_confidence == 0.85

    async def test_get_latest_extraction_not_found(self, test_session):
        repo = DocumentRepository(test_session)
        doc = await _create_doc(repo)

        latest = await repo.get_latest_extraction(doc.id)
        assert latest is None

    async def test_get_document_by_checksum_excludes_deleted(self, test_session):
        repo = DocumentRepository(test_session)
        doc = await _create_doc(repo)
        checksum = doc.checksum

        await repo.soft_delete(doc.id)

        found = await repo.get_by_checksum(checksum)
        assert found is None
