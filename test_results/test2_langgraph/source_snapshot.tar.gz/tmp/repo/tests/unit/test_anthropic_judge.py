"""Tests for AnthropicJudge."""

import json
from unittest.mock import AsyncMock, MagicMock

import pytest

from src.council.consensus import ConflictLevel, MemberVote
from src.council.judge import (
    AnthropicJudge,
    ConflictContext,
    get_judge_for_provider,
)


def _make_context(field_name: str = "total_amount") -> ConflictContext:
    return ConflictContext(
        field_name=field_name,
        member_votes={
            "member_a": MemberVote(member_name="member_a", value="$100", confidence=0.9),
            "member_b": MemberVote(member_name="member_b", value="$200", confidence=0.7),
        },
        conflict_level=ConflictLevel.MODERATE,
        is_critical=False,
    )


@pytest.mark.unit
class TestAnthropicJudge:
    """Tests for AnthropicJudge."""

    def test_model_name(self):
        judge = AnthropicJudge(api_key="test-key", model="claude-sonnet-4-20250514")
        assert judge.model_name == "claude-sonnet-4-20250514"

    def test_parse_response_valid_json(self):
        judge = AnthropicJudge(api_key="test-key")
        response = json.dumps(
            {
                "final_value": "$100",
                "confidence": 0.95,
                "reasoning": "Correct value based on context",
                "supporting_evidence": ["evidence 1"],
                "dissenting_members": ["member_b"],
                "requires_human_review": False,
            }
        )
        ctx = _make_context()
        decision = judge._parse_response("total_amount", response, ctx.member_votes)
        assert decision.final_value == "$100"
        assert decision.confidence == 0.95
        assert decision.requires_human_review is False

    def test_parse_response_json_in_markdown(self):
        judge = AnthropicJudge(api_key="test-key")
        response = '```json\n{"final_value": "$100", "confidence": 0.9, "reasoning": "test", "supporting_evidence": [], "dissenting_members": [], "requires_human_review": false}\n```'
        ctx = _make_context()
        decision = judge._parse_response("total_amount", response, ctx.member_votes)
        assert decision.final_value == "$100"

    def test_parse_response_invalid_json_fallback(self):
        judge = AnthropicJudge(api_key="test-key")
        ctx = _make_context()
        decision = judge._parse_response("total_amount", "not valid json", ctx.member_votes)
        # Falls back to highest confidence vote
        assert decision.final_value == "$100"
        assert decision.requires_human_review is True

    @pytest.mark.asyncio
    async def test_resolve_conflict_failure(self):
        judge = AnthropicJudge(api_key="test-key")
        mock_client = AsyncMock()
        mock_client.messages.create.side_effect = Exception("API error")
        judge._client = mock_client

        ctx = _make_context()
        decision = await judge.resolve_conflict(ctx)
        assert decision.confidence == 0.0
        assert decision.requires_human_review is True
        assert "API error" in decision.reasoning

    @pytest.mark.asyncio
    async def test_resolve_conflict_success(self):
        judge = AnthropicJudge(api_key="test-key")

        mock_response = MagicMock()
        mock_response.content = [
            MagicMock(
                text=json.dumps(
                    {
                        "final_value": "$100",
                        "confidence": 0.95,
                        "reasoning": "Based on document context",
                        "supporting_evidence": ["OCR match"],
                        "dissenting_members": ["member_b"],
                        "requires_human_review": False,
                    }
                )
            )
        ]
        mock_client = AsyncMock()
        mock_client.messages.create.return_value = mock_response
        judge._client = mock_client

        ctx = _make_context()
        decision = await judge.resolve_conflict(ctx)
        assert decision.final_value == "$100"
        assert decision.confidence == 0.95


@pytest.mark.unit
class TestGetJudgeForProvider:
    """Tests for get_judge_for_provider factory."""

    def test_openai_provider(self):
        from src.council.judge import OpenAIJudge

        judge = get_judge_for_provider("openai", "gpt-4o", "test-key")
        assert isinstance(judge, OpenAIJudge)

    def test_anthropic_provider(self):
        judge = get_judge_for_provider("anthropic", "claude-sonnet-4-20250514", "test-key")
        assert isinstance(judge, AnthropicJudge)

    def test_gemini_provider(self):
        from src.council.judge import GeminiJudge

        judge = get_judge_for_provider("gemini", "gemini-1.5-flash", "test-key")
        assert isinstance(judge, GeminiJudge)

    def test_unsupported_provider(self):
        with pytest.raises(ValueError, match="Unsupported provider"):
            get_judge_for_provider("unknown", "model", "key")
