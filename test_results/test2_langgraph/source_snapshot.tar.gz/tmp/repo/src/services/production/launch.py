"""
Production Launch Manager.

Task 4.3.4: Implement production launch preparation and checklist.
"""

import threading
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class LaunchPhase(StrEnum):
    """Launch phases."""

    PLANNING = "planning"
    PREPARATION = "preparation"
    STAGING = "staging"
    CANARY = "canary"
    GRADUAL_ROLLOUT = "gradual_rollout"
    FULL_LAUNCH = "full_launch"
    POST_LAUNCH = "post_launch"


class CheckStatus(StrEnum):
    """Status of a checklist item."""

    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    BLOCKED = "blocked"


class CheckPriority(StrEnum):
    """Priority of a checklist item."""

    CRITICAL = "critical"  # Must pass for launch
    HIGH = "high"  # Should pass
    MEDIUM = "medium"  # Nice to have
    LOW = "low"  # Optional


@dataclass
class ChecklistItem:
    """A checklist item for launch."""

    item_id: str
    name: str
    description: str
    category: str
    priority: CheckPriority
    status: CheckStatus = CheckStatus.NOT_STARTED
    check_function: Callable[[], bool] | None = None
    assigned_to: str = ""
    due_date: datetime | None = None
    completed_at: datetime | None = None
    completed_by: str = ""
    notes: str = ""
    blockers: list[str] = field(default_factory=list)

    @property
    def is_complete(self) -> bool:
        """Check if item is complete."""
        return self.status in [CheckStatus.PASSED, CheckStatus.SKIPPED]

    @property
    def is_blocking(self) -> bool:
        """Check if item is blocking launch."""
        return self.priority == CheckPriority.CRITICAL and self.status not in [
            CheckStatus.PASSED,
            CheckStatus.SKIPPED,
        ]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "item_id": self.item_id,
            "name": self.name,
            "description": self.description,
            "category": self.category,
            "priority": self.priority.value,
            "status": self.status.value,
            "is_complete": self.is_complete,
            "is_blocking": self.is_blocking,
            "assigned_to": self.assigned_to,
            "due_date": self.due_date.isoformat() if self.due_date else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "completed_by": self.completed_by,
            "notes": self.notes,
            "blockers": self.blockers,
        }


@dataclass
class LaunchChecklist:
    """Complete launch checklist."""

    checklist_id: str
    name: str
    phase: LaunchPhase
    items: list[ChecklistItem] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    target_launch_date: datetime | None = None

    @property
    def total_items(self) -> int:
        """Total number of items."""
        return len(self.items)

    @property
    def completed_items(self) -> int:
        """Number of completed items."""
        return sum(1 for item in self.items if item.is_complete)

    @property
    def blocking_items(self) -> list[ChecklistItem]:
        """Items blocking launch."""
        return [item for item in self.items if item.is_blocking]

    @property
    def progress_percentage(self) -> float:
        """Completion percentage."""
        if self.total_items == 0:
            return 0.0
        return (self.completed_items / self.total_items) * 100

    @property
    def is_ready_for_launch(self) -> bool:
        """Check if ready for launch."""
        return len(self.blocking_items) == 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "checklist_id": self.checklist_id,
            "name": self.name,
            "phase": self.phase.value,
            "total_items": self.total_items,
            "completed_items": self.completed_items,
            "progress_percentage": self.progress_percentage,
            "blocking_items_count": len(self.blocking_items),
            "is_ready_for_launch": self.is_ready_for_launch,
            "created_at": self.created_at.isoformat(),
            "target_launch_date": (
                self.target_launch_date.isoformat() if self.target_launch_date else None
            ),
            "items": [item.to_dict() for item in self.items],
        }


@dataclass
class LaunchConfig:
    """Configuration for launch management."""

    require_all_critical: bool = True
    require_all_high: bool = False
    min_progress_percentage: float = 90.0
    canary_percentage: float = 5.0
    gradual_rollout_steps: list[int] = field(default_factory=lambda: [5, 10, 25, 50, 100])
    rollback_threshold_errors: float = 0.05  # 5% error rate triggers rollback
    monitoring_period_hours: int = 24

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "require_all_critical": self.require_all_critical,
            "require_all_high": self.require_all_high,
            "min_progress_percentage": self.min_progress_percentage,
            "canary_percentage": self.canary_percentage,
            "gradual_rollout_steps": self.gradual_rollout_steps,
            "rollback_threshold_errors": self.rollback_threshold_errors,
            "monitoring_period_hours": self.monitoring_period_hours,
        }


@dataclass
class LaunchEvent:
    """A launch-related event."""

    event_id: str
    event_type: str
    phase: LaunchPhase
    timestamp: datetime = field(default_factory=datetime.utcnow)
    description: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "event_id": self.event_id,
            "event_type": self.event_type,
            "phase": self.phase.value,
            "timestamp": self.timestamp.isoformat(),
            "description": self.description,
            "metadata": self.metadata,
        }


class LaunchManager:
    """
    Production Launch Manager.

    Features:
    - Launch checklist management
    - Phase progression
    - Canary deployments
    - Gradual rollouts
    - Rollback support
    """

    # Default checklist categories and items
    DEFAULT_CHECKLIST_ITEMS = [
        # Infrastructure
        (
            "infrastructure",
            "Database migration",
            "Run and verify database migrations",
            CheckPriority.CRITICAL,
        ),
        (
            "infrastructure",
            "SSL certificates",
            "Verify SSL certificate validity",
            CheckPriority.CRITICAL,
        ),
        ("infrastructure", "DNS configuration", "Verify DNS records", CheckPriority.CRITICAL),
        ("infrastructure", "Load balancer", "Configure and test load balancer", CheckPriority.HIGH),
        ("infrastructure", "CDN setup", "Configure CDN for static assets", CheckPriority.MEDIUM),
        # Security
        ("security", "Security audit", "Complete security audit", CheckPriority.CRITICAL),
        ("security", "Penetration testing", "Complete penetration testing", CheckPriority.HIGH),
        ("security", "Secrets rotation", "Rotate all production secrets", CheckPriority.CRITICAL),
        ("security", "Access controls", "Verify RBAC configuration", CheckPriority.CRITICAL),
        ("security", "Encryption at rest", "Enable encryption at rest", CheckPriority.HIGH),
        # Performance
        ("performance", "Load testing", "Complete load testing", CheckPriority.HIGH),
        (
            "performance",
            "Performance baseline",
            "Establish performance baseline",
            CheckPriority.HIGH,
        ),
        ("performance", "Cache warming", "Warm production caches", CheckPriority.MEDIUM),
        ("performance", "Query optimization", "Optimize database queries", CheckPriority.MEDIUM),
        # Monitoring
        ("monitoring", "Alerting rules", "Configure alerting rules", CheckPriority.CRITICAL),
        ("monitoring", "Dashboard setup", "Set up monitoring dashboards", CheckPriority.HIGH),
        ("monitoring", "Log aggregation", "Configure log aggregation", CheckPriority.HIGH),
        ("monitoring", "Metrics collection", "Verify metrics collection", CheckPriority.HIGH),
        # Documentation
        ("documentation", "API documentation", "Complete API documentation", CheckPriority.HIGH),
        ("documentation", "Runbook", "Create operational runbook", CheckPriority.CRITICAL),
        (
            "documentation",
            "Incident response",
            "Document incident response procedures",
            CheckPriority.HIGH,
        ),
        ("documentation", "User guide", "Complete user documentation", CheckPriority.MEDIUM),
        # Operations
        ("operations", "Backup verification", "Verify backup and recovery", CheckPriority.CRITICAL),
        ("operations", "Rollback plan", "Document and test rollback plan", CheckPriority.CRITICAL),
        ("operations", "On-call schedule", "Set up on-call rotation", CheckPriority.HIGH),
        ("operations", "Escalation paths", "Define escalation procedures", CheckPriority.HIGH),
        # Testing
        ("testing", "Integration tests", "Run all integration tests", CheckPriority.CRITICAL),
        ("testing", "E2E tests", "Run end-to-end tests", CheckPriority.HIGH),
        ("testing", "Smoke tests", "Define production smoke tests", CheckPriority.CRITICAL),
        ("testing", "Chaos testing", "Complete chaos engineering tests", CheckPriority.MEDIUM),
    ]

    def __init__(self, config: LaunchConfig | None = None):
        """Initialize launch manager."""
        self.config = config or LaunchConfig()
        self._checklists: dict[str, LaunchChecklist] = {}
        self._current_phase: LaunchPhase = LaunchPhase.PLANNING
        self._events: list[LaunchEvent] = []
        self._lock = threading.RLock()
        self._initialized = False
        self._rollout_percentage: float = 0.0

    def initialize(self) -> bool:
        """Initialize the launch manager."""
        self._initialized = True
        logger.info("Launch manager initialized")
        return True

    def create_checklist(
        self,
        name: str,
        phase: LaunchPhase = LaunchPhase.PREPARATION,
        target_launch_date: datetime | None = None,
        include_defaults: bool = True,
    ) -> LaunchChecklist:
        """
        Create a new launch checklist.

        Args:
            name: Checklist name
            phase: Launch phase
            target_launch_date: Target launch date
            include_defaults: Include default checklist items

        Returns:
            Created checklist
        """
        import uuid

        checklist_id = str(uuid.uuid4())
        checklist = LaunchChecklist(
            checklist_id=checklist_id,
            name=name,
            phase=phase,
            target_launch_date=target_launch_date,
        )

        if include_defaults:
            for i, (category, item_name, desc, priority) in enumerate(self.DEFAULT_CHECKLIST_ITEMS):
                item = ChecklistItem(
                    item_id=f"item_{i:03d}",
                    name=item_name,
                    description=desc,
                    category=category,
                    priority=priority,
                )
                checklist.items.append(item)

        with self._lock:
            self._checklists[checklist_id] = checklist

        logger.info(
            "Checklist created",
            checklist_id=checklist_id,
            items=len(checklist.items),
        )

        return checklist

    def get_checklist(self, checklist_id: str) -> LaunchChecklist | None:
        """Get a checklist by ID."""
        return self._checklists.get(checklist_id)

    def update_item_status(
        self,
        checklist_id: str,
        item_id: str,
        status: CheckStatus,
        completed_by: str = "",
        notes: str = "",
    ) -> ChecklistItem | None:
        """Update status of a checklist item."""
        checklist = self._checklists.get(checklist_id)
        if not checklist:
            return None

        for item in checklist.items:
            if item.item_id == item_id:
                with self._lock:
                    item.status = status
                    if status == CheckStatus.PASSED:
                        item.completed_at = datetime.utcnow()
                        item.completed_by = completed_by
                    if notes:
                        item.notes = notes
                return item

        return None

    def run_automated_checks(self, checklist_id: str) -> dict[str, CheckStatus]:
        """Run all automated checks."""
        checklist = self._checklists.get(checklist_id)
        if not checklist:
            return {}

        results = {}
        for item in checklist.items:
            if item.check_function:
                try:
                    passed = item.check_function()
                    item.status = CheckStatus.PASSED if passed else CheckStatus.FAILED
                    item.completed_at = datetime.utcnow()
                except Exception as e:
                    item.status = CheckStatus.FAILED
                    item.notes = str(e)

                results[item.item_id] = item.status

        return results

    def get_current_phase(self) -> LaunchPhase:
        """Get current launch phase."""
        return self._current_phase

    def advance_phase(self, checklist_id: str) -> LaunchPhase | None:
        """
        Advance to the next launch phase.

        Args:
            checklist_id: Checklist to validate

        Returns:
            New phase or None if cannot advance
        """
        checklist = self._checklists.get(checklist_id)
        if not checklist:
            return None

        # Check if ready to advance
        if not self._can_advance_phase(checklist):
            return None

        # Phase progression
        phase_order = [
            LaunchPhase.PLANNING,
            LaunchPhase.PREPARATION,
            LaunchPhase.STAGING,
            LaunchPhase.CANARY,
            LaunchPhase.GRADUAL_ROLLOUT,
            LaunchPhase.FULL_LAUNCH,
            LaunchPhase.POST_LAUNCH,
        ]

        current_index = phase_order.index(self._current_phase)
        if current_index >= len(phase_order) - 1:
            return self._current_phase  # Already at final phase

        with self._lock:
            self._current_phase = phase_order[current_index + 1]
            checklist.phase = self._current_phase

        self._record_event(
            "phase_advanced",
            self._current_phase,
            f"Advanced to {self._current_phase.value}",
        )

        return self._current_phase

    def _can_advance_phase(self, checklist: LaunchChecklist) -> bool:
        """Check if phase can be advanced."""
        if self.config.require_all_critical:
            critical_items = [i for i in checklist.items if i.priority == CheckPriority.CRITICAL]
            if not all(i.is_complete for i in critical_items):
                return False

        if self.config.require_all_high:
            high_items = [i for i in checklist.items if i.priority == CheckPriority.HIGH]
            if not all(i.is_complete for i in high_items):
                return False

        return not checklist.progress_percentage < self.config.min_progress_percentage

    def start_canary(self) -> float:
        """Start canary deployment."""
        with self._lock:
            self._rollout_percentage = self.config.canary_percentage
            self._current_phase = LaunchPhase.CANARY

        self._record_event(
            "canary_started",
            LaunchPhase.CANARY,
            f"Started canary at {self._rollout_percentage}%",
        )

        return self._rollout_percentage

    def increase_rollout(self) -> float:
        """Increase rollout percentage."""
        current = self._rollout_percentage
        steps = self.config.gradual_rollout_steps

        # Find next step
        for step in steps:
            if step > current:
                with self._lock:
                    self._rollout_percentage = step
                    if step == 100:
                        self._current_phase = LaunchPhase.FULL_LAUNCH
                    else:
                        self._current_phase = LaunchPhase.GRADUAL_ROLLOUT
                break

        self._record_event(
            "rollout_increased",
            self._current_phase,
            f"Increased rollout to {self._rollout_percentage}%",
        )

        return self._rollout_percentage

    def rollback(self, reason: str = "") -> bool:
        """Rollback deployment."""
        with self._lock:
            self._rollout_percentage = 0.0
            self._current_phase = LaunchPhase.STAGING

        self._record_event(
            "rollback",
            LaunchPhase.STAGING,
            f"Rollback initiated: {reason}",
            {"reason": reason},
        )

        logger.warning("Rollback initiated", reason=reason)
        return True

    def get_rollout_percentage(self) -> float:
        """Get current rollout percentage."""
        return self._rollout_percentage

    def _record_event(
        self,
        event_type: str,
        phase: LaunchPhase,
        description: str,
        metadata: dict[str, Any] | None = None,
    ) -> LaunchEvent:
        """Record a launch event."""
        import uuid

        event = LaunchEvent(
            event_id=str(uuid.uuid4()),
            event_type=event_type,
            phase=phase,
            description=description,
            metadata=metadata or {},
        )

        with self._lock:
            self._events.append(event)

        return event

    def get_events(self, limit: int = 100) -> list[LaunchEvent]:
        """Get launch events."""
        return self._events[-limit:]

    def get_launch_status(self, checklist_id: str) -> dict[str, Any]:
        """Get comprehensive launch status."""
        checklist = self._checklists.get(checklist_id)

        return {
            "current_phase": self._current_phase.value,
            "rollout_percentage": self._rollout_percentage,
            "checklist": checklist.to_dict() if checklist else None,
            "is_ready_for_launch": (checklist.is_ready_for_launch if checklist else False),
            "blocking_items": [
                i.to_dict() for i in (checklist.blocking_items if checklist else [])
            ],
            "recent_events": [e.to_dict() for e in self._events[-10:]],
        }

    def generate_launch_report(self, checklist_id: str) -> dict[str, Any]:
        """Generate a launch readiness report."""
        checklist = self._checklists.get(checklist_id)
        if not checklist:
            return {"error": "Checklist not found"}

        # Group items by category
        by_category: dict[str, list[ChecklistItem]] = {}
        for item in checklist.items:
            if item.category not in by_category:
                by_category[item.category] = []
            by_category[item.category].append(item)

        category_summaries = {}
        for category, items in by_category.items():
            completed = sum(1 for i in items if i.is_complete)
            category_summaries[category] = {
                "total": len(items),
                "completed": completed,
                "percentage": (completed / len(items) * 100) if items else 0,
            }

        return {
            "checklist_id": checklist_id,
            "name": checklist.name,
            "phase": self._current_phase.value,
            "overall_progress": checklist.progress_percentage,
            "is_ready": checklist.is_ready_for_launch,
            "category_summaries": category_summaries,
            "blocking_items": [i.to_dict() for i in checklist.blocking_items],
            "rollout_percentage": self._rollout_percentage,
            "target_launch_date": (
                checklist.target_launch_date.isoformat() if checklist.target_launch_date else None
            ),
            "config": self.config.to_dict(),
        }


# Singleton instance
_launch_manager: LaunchManager | None = None


def get_launch_manager(config: LaunchConfig | None = None) -> LaunchManager:
    """Get or create launch manager singleton."""
    global _launch_manager
    if _launch_manager is None:
        _launch_manager = LaunchManager(config)
        _launch_manager.initialize()
    return _launch_manager
