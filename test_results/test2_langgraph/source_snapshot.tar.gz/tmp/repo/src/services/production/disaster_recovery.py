"""
Disaster Recovery Service.

Task 4.3.2: Implement disaster recovery and business continuity features.
"""

import hashlib
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class BackupType(StrEnum):
    """Types of backups."""

    FULL = "full"  # Complete backup
    INCREMENTAL = "incremental"  # Changes since last backup
    DIFFERENTIAL = "differential"  # Changes since last full backup
    SNAPSHOT = "snapshot"  # Point-in-time snapshot


class BackupStatus(StrEnum):
    """Backup status."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    VERIFYING = "verifying"
    VERIFIED = "verified"


class RecoveryStatus(StrEnum):
    """Recovery status."""

    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


class StorageLocation(StrEnum):
    """Backup storage locations."""

    LOCAL = "local"
    S3 = "s3"
    GCS = "gcs"
    AZURE_BLOB = "azure_blob"
    MULTI_REGION = "multi_region"


@dataclass
class BackupConfig:
    """Configuration for backups."""

    backup_type: BackupType = BackupType.FULL
    storage_location: StorageLocation = StorageLocation.S3
    retention_days: int = 30
    compression_enabled: bool = True
    encryption_enabled: bool = True
    verify_after_backup: bool = True
    auto_backup_enabled: bool = True
    backup_schedule_cron: str = "0 2 * * *"  # 2 AM daily
    max_concurrent_backups: int = 2
    cross_region_replication: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "backup_type": self.backup_type.value,
            "storage_location": self.storage_location.value,
            "retention_days": self.retention_days,
            "compression_enabled": self.compression_enabled,
            "encryption_enabled": self.encryption_enabled,
            "verify_after_backup": self.verify_after_backup,
            "auto_backup_enabled": self.auto_backup_enabled,
            "backup_schedule_cron": self.backup_schedule_cron,
            "max_concurrent_backups": self.max_concurrent_backups,
            "cross_region_replication": self.cross_region_replication,
        }


@dataclass
class Backup:
    """A backup record."""

    backup_id: str
    backup_type: BackupType
    status: BackupStatus = BackupStatus.PENDING
    storage_location: StorageLocation = StorageLocation.S3
    size_bytes: int = 0
    compressed_size_bytes: int = 0
    checksum: str = ""
    encryption_key_id: str = ""
    started_at: datetime | None = None
    completed_at: datetime | None = None
    expires_at: datetime | None = None
    storage_path: str = ""
    tenant_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    error_message: str = ""

    @property
    def compression_ratio(self) -> float:
        """Calculate compression ratio."""
        if self.size_bytes == 0:
            return 1.0
        return self.compressed_size_bytes / self.size_bytes

    @property
    def duration_seconds(self) -> float | None:
        """Calculate backup duration."""
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    @property
    def is_expired(self) -> bool:
        """Check if backup is expired."""
        if self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "backup_id": self.backup_id,
            "backup_type": self.backup_type.value,
            "status": self.status.value,
            "storage_location": self.storage_location.value,
            "size_bytes": self.size_bytes,
            "compressed_size_bytes": self.compressed_size_bytes,
            "compression_ratio": self.compression_ratio,
            "checksum": self.checksum,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "duration_seconds": self.duration_seconds,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "is_expired": self.is_expired,
            "storage_path": self.storage_path,
            "tenant_id": self.tenant_id,
            "error_message": self.error_message,
        }


@dataclass
class RecoveryPoint:
    """A recovery point in time."""

    recovery_point_id: str
    backup_id: str
    timestamp: datetime
    description: str = ""
    components: list[str] = field(default_factory=list)
    is_verified: bool = False
    verification_timestamp: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "recovery_point_id": self.recovery_point_id,
            "backup_id": self.backup_id,
            "timestamp": self.timestamp.isoformat(),
            "description": self.description,
            "components": self.components,
            "is_verified": self.is_verified,
            "verification_timestamp": (
                self.verification_timestamp.isoformat() if self.verification_timestamp else None
            ),
        }


@dataclass
class RecoveryOperation:
    """A recovery operation."""

    operation_id: str
    recovery_point_id: str
    status: RecoveryStatus = RecoveryStatus.NOT_STARTED
    target_timestamp: datetime | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    components_recovered: list[str] = field(default_factory=list)
    error_message: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "operation_id": self.operation_id,
            "recovery_point_id": self.recovery_point_id,
            "status": self.status.value,
            "target_timestamp": (
                self.target_timestamp.isoformat() if self.target_timestamp else None
            ),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "components_recovered": self.components_recovered,
            "error_message": self.error_message,
        }


class DisasterRecoveryManager:
    """
    Disaster Recovery Manager.

    Features:
    - Automated backups
    - Point-in-time recovery
    - Cross-region replication
    - Backup verification
    - Recovery testing
    """

    BACKUP_COMPONENTS = [
        "database",
        "document_store",
        "vector_store",
        "model_registry",
        "configuration",
        "audit_logs",
    ]

    def __init__(self, config: BackupConfig | None = None):
        """Initialize disaster recovery manager."""
        self.config = config or BackupConfig()
        self._backups: dict[str, Backup] = {}
        self._recovery_points: dict[str, RecoveryPoint] = {}
        self._recovery_operations: dict[str, RecoveryOperation] = {}
        self._lock = threading.RLock()
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize the disaster recovery manager."""
        self._initialized = True
        logger.info(
            "Disaster recovery manager initialized",
            backup_type=self.config.backup_type.value,
            storage=self.config.storage_location.value,
        )
        return True

    def create_backup(
        self,
        backup_type: BackupType | None = None,
        tenant_id: str | None = None,
        description: str = "",
    ) -> Backup:
        """
        Create a new backup.

        Args:
            backup_type: Type of backup (defaults to config)
            tenant_id: Optional tenant ID for tenant-specific backup
            description: Backup description

        Returns:
            Created backup record
        """
        backup_id = str(uuid.uuid4())
        btype = backup_type or self.config.backup_type

        backup = Backup(
            backup_id=backup_id,
            backup_type=btype,
            storage_location=self.config.storage_location,
            started_at=datetime.utcnow(),
            tenant_id=tenant_id,
            expires_at=datetime.utcnow() + timedelta(days=self.config.retention_days),
            storage_path=f"backups/{backup_id}/{btype.value}",
            metadata={"description": description},
        )

        backup.status = BackupStatus.IN_PROGRESS

        # Simulate backup process
        backup = self._perform_backup(backup)

        with self._lock:
            self._backups[backup_id] = backup

        # Create recovery point
        self._create_recovery_point(backup)

        logger.info(
            "Backup created",
            backup_id=backup_id,
            type=btype.value,
            status=backup.status.value,
        )

        return backup

    def _perform_backup(self, backup: Backup) -> Backup:
        """Perform the actual backup (simulated)."""
        import random
        import time

        # Simulate backup time
        time.sleep(0.01)

        # Simulate backup data
        backup.size_bytes = random.randint(100_000_000, 1_000_000_000)

        if self.config.compression_enabled:
            backup.compressed_size_bytes = int(backup.size_bytes * 0.3)
        else:
            backup.compressed_size_bytes = backup.size_bytes

        # Generate checksum
        backup.checksum = hashlib.sha256(
            f"{backup.backup_id}:{backup.size_bytes}".encode()
        ).hexdigest()

        if self.config.encryption_enabled:
            backup.encryption_key_id = f"key-{backup.backup_id[:8]}"

        backup.completed_at = datetime.utcnow()
        backup.status = BackupStatus.COMPLETED

        # Verify if configured
        if self.config.verify_after_backup:
            backup.status = BackupStatus.VERIFYING
            # Simulate verification
            time.sleep(0.01)
            backup.status = BackupStatus.VERIFIED

        return backup

    def _create_recovery_point(self, backup: Backup) -> RecoveryPoint:
        """Create a recovery point from a backup."""
        recovery_point = RecoveryPoint(
            recovery_point_id=str(uuid.uuid4()),
            backup_id=backup.backup_id,
            timestamp=backup.completed_at or datetime.utcnow(),
            description=backup.metadata.get("description", ""),
            components=self.BACKUP_COMPONENTS.copy(),
            is_verified=backup.status == BackupStatus.VERIFIED,
            verification_timestamp=(
                datetime.utcnow() if backup.status == BackupStatus.VERIFIED else None
            ),
        )

        with self._lock:
            self._recovery_points[recovery_point.recovery_point_id] = recovery_point

        return recovery_point

    def get_backup(self, backup_id: str) -> Backup | None:
        """Get a backup by ID."""
        return self._backups.get(backup_id)

    def get_all_backups(self, tenant_id: str | None = None) -> list[Backup]:
        """Get all backups, optionally filtered by tenant."""
        backups = list(self._backups.values())
        if tenant_id:
            backups = [b for b in backups if b.tenant_id == tenant_id]
        return sorted(backups, key=lambda b: b.started_at or datetime.min, reverse=True)

    def get_latest_backup(self, tenant_id: str | None = None) -> Backup | None:
        """Get the latest completed backup."""
        backups = [
            b
            for b in self._backups.values()
            if b.status in [BackupStatus.COMPLETED, BackupStatus.VERIFIED]
            and (tenant_id is None or b.tenant_id == tenant_id)
        ]
        if not backups:
            return None
        return max(backups, key=lambda b: b.completed_at or datetime.min)

    def delete_backup(self, backup_id: str) -> bool:
        """Delete a backup."""
        if backup_id not in self._backups:
            return False

        with self._lock:
            del self._backups[backup_id]
            # Remove associated recovery points
            points_to_remove = [
                rp_id for rp_id, rp in self._recovery_points.items() if rp.backup_id == backup_id
            ]
            for rp_id in points_to_remove:
                del self._recovery_points[rp_id]

        logger.info("Backup deleted", backup_id=backup_id)
        return True

    def get_recovery_point(self, recovery_point_id: str) -> RecoveryPoint | None:
        """Get a recovery point by ID."""
        return self._recovery_points.get(recovery_point_id)

    def get_all_recovery_points(self) -> list[RecoveryPoint]:
        """Get all recovery points."""
        return sorted(
            self._recovery_points.values(),
            key=lambda rp: rp.timestamp,
            reverse=True,
        )

    def recover_to_point(
        self,
        recovery_point_id: str,
        components: list[str] | None = None,
    ) -> RecoveryOperation:
        """
        Initiate recovery to a specific point.

        Args:
            recovery_point_id: Recovery point ID
            components: Specific components to recover (default: all)

        Returns:
            Recovery operation
        """
        recovery_point = self._recovery_points.get(recovery_point_id)
        if not recovery_point:
            raise ValueError(f"Recovery point not found: {recovery_point_id}")

        operation_id = str(uuid.uuid4())
        components_to_recover = components or recovery_point.components

        operation = RecoveryOperation(
            operation_id=operation_id,
            recovery_point_id=recovery_point_id,
            status=RecoveryStatus.IN_PROGRESS,
            target_timestamp=recovery_point.timestamp,
            started_at=datetime.utcnow(),
        )

        # Simulate recovery
        import time

        time.sleep(0.01)

        operation.components_recovered = components_to_recover.copy()
        operation.completed_at = datetime.utcnow()
        operation.status = RecoveryStatus.COMPLETED

        with self._lock:
            self._recovery_operations[operation_id] = operation

        logger.info(
            "Recovery completed",
            operation_id=operation_id,
            recovery_point_id=recovery_point_id,
            components=components_to_recover,
        )

        return operation

    def get_recovery_operation(self, operation_id: str) -> RecoveryOperation | None:
        """Get a recovery operation by ID."""
        return self._recovery_operations.get(operation_id)

    def verify_backup(self, backup_id: str) -> bool:
        """Verify a backup's integrity."""
        backup = self._backups.get(backup_id)
        if not backup:
            return False

        # Simulate verification
        import time

        time.sleep(0.01)

        with self._lock:
            backup.status = BackupStatus.VERIFIED

        return True

    def cleanup_expired_backups(self) -> int:
        """Remove expired backups."""
        removed = 0
        with self._lock:
            expired_ids = [b.backup_id for b in self._backups.values() if b.is_expired]
            for backup_id in expired_ids:
                del self._backups[backup_id]
                removed += 1

        if removed > 0:
            logger.info("Expired backups cleaned up", count=removed)

        return removed

    def get_backup_stats(self) -> dict[str, Any]:
        """Get backup statistics."""
        backups = list(self._backups.values())
        total_size = sum(b.size_bytes for b in backups)
        compressed_size = sum(b.compressed_size_bytes for b in backups)

        return {
            "total_backups": len(backups),
            "completed_backups": sum(1 for b in backups if b.status == BackupStatus.COMPLETED),
            "verified_backups": sum(1 for b in backups if b.status == BackupStatus.VERIFIED),
            "failed_backups": sum(1 for b in backups if b.status == BackupStatus.FAILED),
            "total_size_bytes": total_size,
            "total_compressed_bytes": compressed_size,
            "compression_ratio": compressed_size / total_size if total_size > 0 else 1.0,
            "recovery_points": len(self._recovery_points),
            "oldest_backup": min(
                (b.started_at for b in backups if b.started_at),
                default=None,
            ),
            "newest_backup": max(
                (b.started_at for b in backups if b.started_at),
                default=None,
            ),
        }

    def test_recovery(self, recovery_point_id: str) -> dict[str, Any]:
        """
        Test recovery without actually restoring.

        Args:
            recovery_point_id: Recovery point to test

        Returns:
            Test results
        """
        recovery_point = self._recovery_points.get(recovery_point_id)
        if not recovery_point:
            return {"success": False, "error": "Recovery point not found"}

        backup = self._backups.get(recovery_point.backup_id)
        if not backup:
            return {"success": False, "error": "Backup not found"}

        # Simulate recovery test
        return {
            "success": True,
            "recovery_point_id": recovery_point_id,
            "backup_id": backup.backup_id,
            "estimated_recovery_time_seconds": 300,
            "components_tested": recovery_point.components,
            "data_integrity_verified": True,
        }


# Singleton instance
_disaster_recovery_manager: DisasterRecoveryManager | None = None


def get_disaster_recovery_manager(
    config: BackupConfig | None = None,
) -> DisasterRecoveryManager:
    """Get or create disaster recovery manager singleton."""
    global _disaster_recovery_manager
    if _disaster_recovery_manager is None:
        _disaster_recovery_manager = DisasterRecoveryManager(config)
        _disaster_recovery_manager.initialize()
    return _disaster_recovery_manager
