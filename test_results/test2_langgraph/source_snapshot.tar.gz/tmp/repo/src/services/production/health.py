"""
Health Check Service.

Task 4.3.3: Implement comprehensive health monitoring for production.
"""

import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class HealthStatus(StrEnum):
    """Health status levels."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class ComponentType(StrEnum):
    """Types of system components."""

    API = "api"
    DATABASE = "database"
    CACHE = "cache"
    QUEUE = "queue"
    STORAGE = "storage"
    MODEL = "model"
    EXTERNAL = "external"


@dataclass
class ComponentHealth:
    """Health status of a component."""

    name: str
    component_type: ComponentType
    status: HealthStatus = HealthStatus.UNKNOWN
    latency_ms: float = 0.0
    last_check: datetime | None = None
    last_success: datetime | None = None
    consecutive_failures: int = 0
    error_message: str = ""
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def is_healthy(self) -> bool:
        """Check if component is healthy."""
        return self.status == HealthStatus.HEALTHY

    @property
    def time_since_last_check(self) -> timedelta | None:
        """Time since last health check."""
        if self.last_check is None:
            return None
        return datetime.utcnow() - self.last_check

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "component_type": self.component_type.value,
            "status": self.status.value,
            "is_healthy": self.is_healthy,
            "latency_ms": self.latency_ms,
            "last_check": self.last_check.isoformat() if self.last_check else None,
            "last_success": self.last_success.isoformat() if self.last_success else None,
            "consecutive_failures": self.consecutive_failures,
            "error_message": self.error_message,
            "details": self.details,
        }


@dataclass
class SystemHealth:
    """Overall system health."""

    status: HealthStatus = HealthStatus.UNKNOWN
    components: dict[str, ComponentHealth] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.utcnow)
    version: str = "1.0.0"
    uptime_seconds: float = 0.0

    @property
    def healthy_components(self) -> int:
        """Count of healthy components."""
        return sum(1 for c in self.components.values() if c.is_healthy)

    @property
    def total_components(self) -> int:
        """Total number of components."""
        return len(self.components)

    @property
    def health_percentage(self) -> float:
        """Percentage of healthy components."""
        if self.total_components == 0:
            return 0.0
        return (self.healthy_components / self.total_components) * 100

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "status": self.status.value,
            "timestamp": self.timestamp.isoformat(),
            "version": self.version,
            "uptime_seconds": self.uptime_seconds,
            "healthy_components": self.healthy_components,
            "total_components": self.total_components,
            "health_percentage": self.health_percentage,
            "components": {k: v.to_dict() for k, v in self.components.items()},
        }


@dataclass
class HealthCheckConfig:
    """Configuration for health checks."""

    check_interval_seconds: int = 30
    timeout_seconds: float = 5.0
    failure_threshold: int = 3  # Consecutive failures before unhealthy
    success_threshold: int = 2  # Consecutive successes to recover
    degraded_latency_ms: float = 1000.0  # Latency threshold for degraded
    include_details: bool = True

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "check_interval_seconds": self.check_interval_seconds,
            "timeout_seconds": self.timeout_seconds,
            "failure_threshold": self.failure_threshold,
            "success_threshold": self.success_threshold,
            "degraded_latency_ms": self.degraded_latency_ms,
            "include_details": self.include_details,
        }


class HealthChecker:
    """
    Health Check Service.

    Features:
    - Component health monitoring
    - Automatic health checks
    - Latency tracking
    - Failure detection
    - Readiness and liveness probes
    """

    def __init__(self, config: HealthCheckConfig | None = None):
        """Initialize health checker."""
        self.config = config or HealthCheckConfig()
        self._components: dict[str, ComponentHealth] = {}
        self._check_functions: dict[str, Callable[[], bool]] = {}
        self._lock = threading.RLock()
        self._initialized = False
        self._start_time = datetime.utcnow()
        self._check_thread: threading.Thread | None = None
        self._running = False

    def initialize(self) -> bool:
        """Initialize the health checker."""
        self._start_time = datetime.utcnow()
        self._initialized = True
        logger.info("Health checker initialized")
        return True

    def register_component(
        self,
        name: str,
        component_type: ComponentType,
        check_function: Callable[[], bool] | None = None,
    ) -> ComponentHealth:
        """
        Register a component for health monitoring.

        Args:
            name: Component name
            component_type: Type of component
            check_function: Optional health check function

        Returns:
            Component health object
        """
        component = ComponentHealth(
            name=name,
            component_type=component_type,
            status=HealthStatus.UNKNOWN,
        )

        with self._lock:
            self._components[name] = component
            if check_function:
                self._check_functions[name] = check_function

        logger.info(
            "Component registered",
            name=name,
            type=component_type.value,
        )

        return component

    def unregister_component(self, name: str) -> bool:
        """Unregister a component."""
        with self._lock:
            if name in self._components:
                del self._components[name]
                self._check_functions.pop(name, None)
                return True
        return False

    def check_component(self, name: str) -> ComponentHealth:
        """
        Check health of a specific component.

        Args:
            name: Component name

        Returns:
            Updated component health
        """
        component = self._components.get(name)
        if not component:
            raise ValueError(f"Component not found: {name}")

        check_func = self._check_functions.get(name)

        start_time = time.time()
        component.last_check = datetime.utcnow()

        try:
            is_healthy = check_func() if check_func else True

            latency_ms = (time.time() - start_time) * 1000
            component.latency_ms = latency_ms

            if is_healthy:
                component.last_success = datetime.utcnow()
                component.consecutive_failures = 0
                component.error_message = ""

                # Check if latency indicates degraded state
                if latency_ms > self.config.degraded_latency_ms:
                    component.status = HealthStatus.DEGRADED
                    component.details["degraded_reason"] = "high_latency"
                else:
                    component.status = HealthStatus.HEALTHY
                    component.details.pop("degraded_reason", None)
            else:
                component.consecutive_failures += 1
                if component.consecutive_failures >= self.config.failure_threshold:
                    component.status = HealthStatus.UNHEALTHY
                else:
                    component.status = HealthStatus.DEGRADED

        except Exception as e:
            component.consecutive_failures += 1
            component.error_message = str(e)
            component.latency_ms = (time.time() - start_time) * 1000

            if component.consecutive_failures >= self.config.failure_threshold:
                component.status = HealthStatus.UNHEALTHY
            else:
                component.status = HealthStatus.DEGRADED

        return component

    def check_all_components(self) -> dict[str, ComponentHealth]:
        """Check health of all components."""
        results = {}
        for name in list(self._components.keys()):
            try:
                results[name] = self.check_component(name)
            except Exception as e:
                logger.error("Health check failed", component=name, error=str(e))
        return results

    def get_component_health(self, name: str) -> ComponentHealth | None:
        """Get health status of a component."""
        return self._components.get(name)

    def get_system_health(self) -> SystemHealth:
        """Get overall system health."""
        # Determine overall status
        statuses = [c.status for c in self._components.values()]

        if not statuses:
            overall_status = HealthStatus.UNKNOWN
        elif all(s == HealthStatus.HEALTHY for s in statuses):
            overall_status = HealthStatus.HEALTHY
        elif any(s == HealthStatus.UNHEALTHY for s in statuses):
            overall_status = HealthStatus.UNHEALTHY
        elif any(s == HealthStatus.DEGRADED for s in statuses):
            overall_status = HealthStatus.DEGRADED
        else:
            overall_status = HealthStatus.UNKNOWN

        uptime = (datetime.utcnow() - self._start_time).total_seconds()

        return SystemHealth(
            status=overall_status,
            components=self._components.copy(),
            version="1.0.0",
            uptime_seconds=uptime,
        )

    def is_ready(self) -> bool:
        """
        Readiness probe - is the system ready to accept traffic?

        Returns:
            True if ready
        """
        system_health = self.get_system_health()
        return system_health.status in [HealthStatus.HEALTHY, HealthStatus.DEGRADED]

    def is_live(self) -> bool:
        """
        Liveness probe - is the system alive?

        Returns:
            True if alive
        """
        # Basic liveness - can we respond at all?
        return self._initialized

    def start_background_checks(self) -> None:
        """Start background health check thread."""
        if self._running:
            return

        self._running = True
        self._check_thread = threading.Thread(
            target=self._background_check_loop,
            daemon=True,
        )
        self._check_thread.start()

    def stop_background_checks(self) -> None:
        """Stop background health checks."""
        self._running = False
        if self._check_thread:
            self._check_thread.join(timeout=5.0)

    def _background_check_loop(self) -> None:
        """Background health check loop."""
        while self._running:
            try:
                self.check_all_components()
            except Exception as e:
                logger.error("Background health check error", error=str(e))

            time.sleep(self.config.check_interval_seconds)

    def get_unhealthy_components(self) -> list[ComponentHealth]:
        """Get list of unhealthy components."""
        return [c for c in self._components.values() if c.status == HealthStatus.UNHEALTHY]

    def get_degraded_components(self) -> list[ComponentHealth]:
        """Get list of degraded components."""
        return [c for c in self._components.values() if c.status == HealthStatus.DEGRADED]

    def generate_report(self) -> dict[str, Any]:
        """Generate a health report."""
        system_health = self.get_system_health()

        return {
            "system": system_health.to_dict(),
            "readiness": self.is_ready(),
            "liveness": self.is_live(),
            "unhealthy_components": [c.to_dict() for c in self.get_unhealthy_components()],
            "degraded_components": [c.to_dict() for c in self.get_degraded_components()],
            "config": self.config.to_dict(),
        }


# Singleton instance
_health_checker: HealthChecker | None = None


def get_health_checker(config: HealthCheckConfig | None = None) -> HealthChecker:
    """Get or create health checker singleton."""
    global _health_checker
    if _health_checker is None:
        _health_checker = HealthChecker(config)
        _health_checker.initialize()
    return _health_checker
