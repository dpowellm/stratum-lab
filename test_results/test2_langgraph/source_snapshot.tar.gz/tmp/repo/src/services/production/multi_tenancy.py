"""
Multi-Tenancy Support.

Task 4.3.1: Implement multi-tenant architecture for enterprise deployments.
"""

import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class TenantTier(StrEnum):
    """Tenant subscription tiers."""

    FREE = "free"
    STARTER = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"


class TenantStatus(StrEnum):
    """Tenant status."""

    ACTIVE = "active"
    SUSPENDED = "suspended"
    PENDING = "pending"
    ARCHIVED = "archived"


class IsolationLevel(StrEnum):
    """Data isolation levels."""

    SHARED = "shared"  # Shared resources with tenant_id filtering
    DEDICATED = "dedicated"  # Dedicated resources per tenant
    HYBRID = "hybrid"  # Critical data isolated, rest shared


@dataclass
class TenantQuota:
    """Resource quotas for a tenant."""

    max_documents_per_month: int = 1000
    max_storage_gb: float = 10.0
    max_api_calls_per_minute: int = 100
    max_concurrent_jobs: int = 5
    max_users: int = 10
    retention_days: int = 90

    # Current usage
    documents_this_month: int = 0
    storage_used_gb: float = 0.0
    api_calls_this_minute: int = 0
    active_jobs: int = 0
    current_users: int = 0

    @property
    def documents_remaining(self) -> int:
        """Get remaining document quota."""
        return max(0, self.max_documents_per_month - self.documents_this_month)

    @property
    def storage_remaining_gb(self) -> float:
        """Get remaining storage quota."""
        return max(0, self.max_storage_gb - self.storage_used_gb)

    @property
    def is_document_quota_exceeded(self) -> bool:
        """Check if document quota is exceeded."""
        return self.documents_this_month >= self.max_documents_per_month

    @property
    def is_storage_quota_exceeded(self) -> bool:
        """Check if storage quota is exceeded."""
        return self.storage_used_gb >= self.max_storage_gb

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "max_documents_per_month": self.max_documents_per_month,
            "max_storage_gb": self.max_storage_gb,
            "max_api_calls_per_minute": self.max_api_calls_per_minute,
            "max_concurrent_jobs": self.max_concurrent_jobs,
            "max_users": self.max_users,
            "retention_days": self.retention_days,
            "documents_this_month": self.documents_this_month,
            "storage_used_gb": self.storage_used_gb,
            "documents_remaining": self.documents_remaining,
            "storage_remaining_gb": self.storage_remaining_gb,
        }


@dataclass
class TenantConfig:
    """Configuration for a tenant."""

    tier: TenantTier = TenantTier.FREE
    isolation_level: IsolationLevel = IsolationLevel.SHARED
    custom_branding: bool = False
    sso_enabled: bool = False
    audit_logging: bool = True
    pii_detection: bool = True
    encryption_at_rest: bool = True
    custom_models: bool = False
    priority_processing: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "tier": self.tier.value,
            "isolation_level": self.isolation_level.value,
            "custom_branding": self.custom_branding,
            "sso_enabled": self.sso_enabled,
            "audit_logging": self.audit_logging,
            "pii_detection": self.pii_detection,
            "encryption_at_rest": self.encryption_at_rest,
            "custom_models": self.custom_models,
            "priority_processing": self.priority_processing,
        }


@dataclass
class Tenant:
    """A tenant in the system."""

    tenant_id: str
    name: str
    status: TenantStatus = TenantStatus.ACTIVE
    config: TenantConfig = field(default_factory=TenantConfig)
    quota: TenantQuota = field(default_factory=TenantQuota)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = field(default_factory=dict)

    # Contact information
    admin_email: str = ""
    billing_email: str = ""

    # Database identifiers
    database_schema: str = ""
    storage_bucket: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "tenant_id": self.tenant_id,
            "name": self.name,
            "status": self.status.value,
            "config": self.config.to_dict(),
            "quota": self.quota.to_dict(),
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "admin_email": self.admin_email,
            "billing_email": self.billing_email,
            "database_schema": self.database_schema,
            "storage_bucket": self.storage_bucket,
            "metadata": self.metadata,
        }


class TenantManager:
    """
    Multi-Tenancy Manager.

    Features:
    - Tenant CRUD operations
    - Quota management
    - Resource isolation
    - Usage tracking
    - Tier management
    """

    # Tier-based quota defaults
    TIER_QUOTAS = {
        TenantTier.FREE: TenantQuota(
            max_documents_per_month=100,
            max_storage_gb=1.0,
            max_api_calls_per_minute=10,
            max_concurrent_jobs=1,
            max_users=2,
            retention_days=30,
        ),
        TenantTier.STARTER: TenantQuota(
            max_documents_per_month=1000,
            max_storage_gb=10.0,
            max_api_calls_per_minute=50,
            max_concurrent_jobs=3,
            max_users=10,
            retention_days=90,
        ),
        TenantTier.PROFESSIONAL: TenantQuota(
            max_documents_per_month=10000,
            max_storage_gb=100.0,
            max_api_calls_per_minute=200,
            max_concurrent_jobs=10,
            max_users=50,
            retention_days=365,
        ),
        TenantTier.ENTERPRISE: TenantQuota(
            max_documents_per_month=999999999,  # Unlimited
            max_storage_gb=10000.0,
            max_api_calls_per_minute=1000,
            max_concurrent_jobs=100,
            max_users=10000,
            retention_days=3650,  # 10 years
        ),
    }

    def __init__(self):
        """Initialize tenant manager."""
        self._tenants: dict[str, Tenant] = {}
        self._lock = threading.RLock()
        self._initialized = False
        self._current_tenant_id: str | None = None

    def initialize(self) -> bool:
        """Initialize the tenant manager."""
        self._initialized = True
        logger.info("Tenant manager initialized")
        return True

    def create_tenant(
        self,
        name: str,
        tier: TenantTier = TenantTier.FREE,
        admin_email: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> Tenant:
        """
        Create a new tenant.

        Args:
            name: Tenant name
            tier: Subscription tier
            admin_email: Admin email address
            metadata: Additional metadata

        Returns:
            Created tenant
        """
        tenant_id = str(uuid.uuid4())

        # Get tier-based quota
        quota = self._get_tier_quota(tier)

        # Create config based on tier
        config = self._get_tier_config(tier)

        tenant = Tenant(
            tenant_id=tenant_id,
            name=name,
            config=config,
            quota=quota,
            admin_email=admin_email,
            billing_email=admin_email,
            database_schema=f"tenant_{tenant_id[:8]}",
            storage_bucket=f"tenant-{tenant_id[:8]}-storage",
            metadata=metadata or {},
        )

        with self._lock:
            self._tenants[tenant_id] = tenant

        logger.info(
            "Tenant created",
            tenant_id=tenant_id,
            name=name,
            tier=tier.value,
        )

        return tenant

    def _get_tier_quota(self, tier: TenantTier) -> TenantQuota:
        """Get quota for a tier."""
        default = self.TIER_QUOTAS.get(tier, self.TIER_QUOTAS[TenantTier.FREE])
        return TenantQuota(
            max_documents_per_month=default.max_documents_per_month,
            max_storage_gb=default.max_storage_gb,
            max_api_calls_per_minute=default.max_api_calls_per_minute,
            max_concurrent_jobs=default.max_concurrent_jobs,
            max_users=default.max_users,
            retention_days=default.retention_days,
        )

    def _get_tier_config(self, tier: TenantTier) -> TenantConfig:
        """Get config for a tier."""
        if tier == TenantTier.FREE:
            return TenantConfig(
                tier=tier,
                isolation_level=IsolationLevel.SHARED,
                custom_branding=False,
                sso_enabled=False,
                custom_models=False,
                priority_processing=False,
            )
        elif tier == TenantTier.STARTER:
            return TenantConfig(
                tier=tier,
                isolation_level=IsolationLevel.SHARED,
                custom_branding=True,
                sso_enabled=False,
                custom_models=False,
                priority_processing=False,
            )
        elif tier == TenantTier.PROFESSIONAL:
            return TenantConfig(
                tier=tier,
                isolation_level=IsolationLevel.HYBRID,
                custom_branding=True,
                sso_enabled=True,
                custom_models=True,
                priority_processing=True,
            )
        else:  # ENTERPRISE
            return TenantConfig(
                tier=tier,
                isolation_level=IsolationLevel.DEDICATED,
                custom_branding=True,
                sso_enabled=True,
                custom_models=True,
                priority_processing=True,
            )

    def get_tenant(self, tenant_id: str) -> Tenant | None:
        """Get a tenant by ID."""
        return self._tenants.get(tenant_id)

    def get_tenant_by_name(self, name: str) -> Tenant | None:
        """Get a tenant by name."""
        for tenant in self._tenants.values():
            if tenant.name == name:
                return tenant
        return None

    def get_all_tenants(self) -> list[Tenant]:
        """Get all tenants."""
        return list(self._tenants.values())

    def update_tenant(
        self,
        tenant_id: str,
        name: str | None = None,
        status: TenantStatus | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Tenant | None:
        """Update a tenant."""
        tenant = self._tenants.get(tenant_id)
        if not tenant:
            return None

        with self._lock:
            if name:
                tenant.name = name
            if status:
                tenant.status = status
            if metadata:
                tenant.metadata.update(metadata)
            tenant.updated_at = datetime.utcnow()

        return tenant

    def delete_tenant(self, tenant_id: str) -> bool:
        """Delete a tenant (soft delete by archiving)."""
        tenant = self._tenants.get(tenant_id)
        if not tenant:
            return False

        with self._lock:
            tenant.status = TenantStatus.ARCHIVED
            tenant.updated_at = datetime.utcnow()

        logger.info("Tenant archived", tenant_id=tenant_id)
        return True

    def upgrade_tier(self, tenant_id: str, new_tier: TenantTier) -> Tenant | None:
        """Upgrade a tenant's tier."""
        tenant = self._tenants.get(tenant_id)
        if not tenant:
            return None

        with self._lock:
            tenant.config = self._get_tier_config(new_tier)
            new_quota = self._get_tier_quota(new_tier)

            # Preserve current usage
            new_quota.documents_this_month = tenant.quota.documents_this_month
            new_quota.storage_used_gb = tenant.quota.storage_used_gb
            new_quota.current_users = tenant.quota.current_users

            tenant.quota = new_quota
            tenant.updated_at = datetime.utcnow()

        logger.info(
            "Tenant tier upgraded",
            tenant_id=tenant_id,
            new_tier=new_tier.value,
        )

        return tenant

    def record_usage(
        self,
        tenant_id: str,
        documents: int = 0,
        storage_gb: float = 0.0,
        api_calls: int = 0,
    ) -> bool:
        """Record resource usage for a tenant."""
        tenant = self._tenants.get(tenant_id)
        if not tenant:
            return False

        with self._lock:
            tenant.quota.documents_this_month += documents
            tenant.quota.storage_used_gb += storage_gb
            tenant.quota.api_calls_this_minute += api_calls

        return True

    def check_quota(
        self,
        tenant_id: str,
        resource: str,
    ) -> tuple[bool, str]:
        """
        Check if a quota allows the operation.

        Args:
            tenant_id: Tenant ID
            resource: Resource type (documents, storage, api_calls)

        Returns:
            Tuple of (allowed, message)
        """
        tenant = self._tenants.get(tenant_id)
        if not tenant:
            return False, "Tenant not found"

        if tenant.status != TenantStatus.ACTIVE:
            return False, f"Tenant is {tenant.status.value}"

        quota = tenant.quota

        if resource == "documents":
            if quota.is_document_quota_exceeded:
                return (
                    False,
                    f"Document quota exceeded ({quota.documents_this_month}/{quota.max_documents_per_month})",
                )
        elif resource == "storage":
            if quota.is_storage_quota_exceeded:
                return (
                    False,
                    f"Storage quota exceeded ({quota.storage_used_gb:.2f}/{quota.max_storage_gb:.2f} GB)",
                )
        elif resource == "api_calls":
            if quota.api_calls_this_minute >= quota.max_api_calls_per_minute:
                return False, "API rate limit exceeded"

        return True, "OK"

    def get_quota_usage(self, tenant_id: str) -> dict[str, Any] | None:
        """Get quota usage for a tenant."""
        tenant = self._tenants.get(tenant_id)
        if not tenant:
            return None

        return {
            "documents": {
                "used": tenant.quota.documents_this_month,
                "limit": tenant.quota.max_documents_per_month,
                "remaining": tenant.quota.documents_remaining,
                "percent_used": (
                    tenant.quota.documents_this_month / tenant.quota.max_documents_per_month * 100
                    if tenant.quota.max_documents_per_month > 0
                    else 0
                ),
            },
            "storage": {
                "used_gb": tenant.quota.storage_used_gb,
                "limit_gb": tenant.quota.max_storage_gb,
                "remaining_gb": tenant.quota.storage_remaining_gb,
                "percent_used": (
                    tenant.quota.storage_used_gb / tenant.quota.max_storage_gb * 100
                    if tenant.quota.max_storage_gb > 0
                    else 0
                ),
            },
            "api_calls": {
                "current_minute": tenant.quota.api_calls_this_minute,
                "limit_per_minute": tenant.quota.max_api_calls_per_minute,
            },
            "users": {
                "current": tenant.quota.current_users,
                "limit": tenant.quota.max_users,
            },
        }

    def set_current_tenant(self, tenant_id: str) -> bool:
        """Set the current tenant context."""
        if tenant_id not in self._tenants:
            return False
        self._current_tenant_id = tenant_id
        return True

    def get_current_tenant(self) -> Tenant | None:
        """Get the current tenant context."""
        if self._current_tenant_id:
            return self._tenants.get(self._current_tenant_id)
        return None

    def reset_monthly_usage(self) -> int:
        """Reset monthly usage for all tenants."""
        reset_count = 0
        with self._lock:
            for tenant in self._tenants.values():
                tenant.quota.documents_this_month = 0
                reset_count += 1
        return reset_count


# Singleton instance
_tenant_manager: TenantManager | None = None


def get_tenant_manager() -> TenantManager:
    """Get or create tenant manager singleton."""
    global _tenant_manager
    if _tenant_manager is None:
        _tenant_manager = TenantManager()
        _tenant_manager.initialize()
    return _tenant_manager
