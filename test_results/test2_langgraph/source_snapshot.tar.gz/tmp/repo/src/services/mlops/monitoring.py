"""
Monitoring Dashboards.

Provides metrics, alerts, and dashboard management for system observability.
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class MetricType(StrEnum):
    """Types of metrics."""

    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    SUMMARY = "summary"


class AlertSeverity(StrEnum):
    """Alert severity levels."""

    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class AlertStatus(StrEnum):
    """Alert status."""

    PENDING = "pending"
    FIRING = "firing"
    RESOLVED = "resolved"


@dataclass
class MetricValue:
    """A metric value at a point in time."""

    value: float
    timestamp: datetime = field(default_factory=datetime.utcnow)
    labels: dict[str, str] = field(default_factory=dict)


@dataclass
class MetricDefinition:
    """Definition of a metric."""

    name: str
    metric_type: MetricType
    description: str = ""
    unit: str = ""
    labels: list[str] = field(default_factory=list)
    values: list[MetricValue] = field(default_factory=list)

    def record(
        self,
        value: float,
        labels: dict[str, str] | None = None,
    ) -> MetricValue:
        """Record a metric value."""
        metric_value = MetricValue(value=value, labels=labels or {})
        self.values.append(metric_value)
        return metric_value

    def get_latest(self) -> MetricValue | None:
        """Get the latest value."""
        if not self.values:
            return None
        return self.values[-1]

    def get_range(
        self,
        start: datetime,
        end: datetime,
    ) -> list[MetricValue]:
        """Get values in a time range."""
        return [v for v in self.values if start <= v.timestamp <= end]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "type": self.metric_type.value,
            "description": self.description,
            "unit": self.unit,
            "labels": self.labels,
            "latest_value": self.get_latest().value if self.get_latest() else None,
        }


@dataclass
class Alert:
    """An alert definition."""

    alert_id: str
    name: str
    metric_name: str
    condition: str  # e.g., "> 0.9", "< 100"
    threshold: float
    severity: AlertSeverity = AlertSeverity.WARNING
    status: AlertStatus = AlertStatus.PENDING
    duration: int = 60  # seconds before firing
    description: str = ""
    labels: dict[str, str] = field(default_factory=dict)
    annotations: dict[str, str] = field(default_factory=dict)
    last_evaluated: datetime | None = None
    fired_at: datetime | None = None
    resolved_at: datetime | None = None

    def evaluate(self, current_value: float) -> bool:
        """Evaluate if alert should fire."""
        self.last_evaluated = datetime.utcnow()

        # Parse condition
        if self.condition.startswith(">"):
            should_fire = current_value > self.threshold
        elif self.condition.startswith("<"):
            should_fire = current_value < self.threshold
        elif self.condition.startswith(">="):
            should_fire = current_value >= self.threshold
        elif self.condition.startswith("<="):
            should_fire = current_value <= self.threshold
        elif self.condition.startswith("=="):
            should_fire = current_value == self.threshold
        else:
            should_fire = False

        if should_fire and self.status != AlertStatus.FIRING:
            self.status = AlertStatus.FIRING
            self.fired_at = datetime.utcnow()
            logger.warning(
                f"Alert {self.name} fired: {current_value} {self.condition} {self.threshold}"
            )
        elif not should_fire and self.status == AlertStatus.FIRING:
            self.status = AlertStatus.RESOLVED
            self.resolved_at = datetime.utcnow()
            logger.info(f"Alert {self.name} resolved")

        return should_fire

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "alert_id": self.alert_id,
            "name": self.name,
            "metric_name": self.metric_name,
            "condition": self.condition,
            "threshold": self.threshold,
            "severity": self.severity.value,
            "status": self.status.value,
            "duration": self.duration,
            "description": self.description,
            "labels": self.labels,
            "fired_at": self.fired_at.isoformat() if self.fired_at else None,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
        }


@dataclass
class DashboardPanel:
    """A panel in a dashboard."""

    panel_id: str
    title: str
    metric_names: list[str]
    panel_type: str = "timeseries"  # timeseries, gauge, stat, table
    description: str = ""
    width: int = 6
    height: int = 4
    options: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "panel_id": self.panel_id,
            "title": self.title,
            "metric_names": self.metric_names,
            "type": self.panel_type,
            "description": self.description,
            "width": self.width,
            "height": self.height,
            "options": self.options,
        }


@dataclass
class Dashboard:
    """A monitoring dashboard."""

    dashboard_id: str
    name: str
    description: str = ""
    panels: list[DashboardPanel] = field(default_factory=list)
    refresh_interval: int = 30  # seconds
    tags: dict[str, str] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)

    def add_panel(
        self,
        title: str,
        metric_names: list[str],
        panel_type: str = "timeseries",
        **options: Any,
    ) -> DashboardPanel:
        """Add a panel to the dashboard."""
        panel = DashboardPanel(
            panel_id=str(uuid.uuid4()),
            title=title,
            metric_names=metric_names,
            panel_type=panel_type,
            options=options,
        )
        self.panels.append(panel)
        return panel

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "dashboard_id": self.dashboard_id,
            "name": self.name,
            "description": self.description,
            "panels": [p.to_dict() for p in self.panels],
            "refresh_interval": self.refresh_interval,
            "tags": self.tags,
            "created_at": self.created_at.isoformat(),
        }


class MonitoringDashboard:
    """
    Monitoring Dashboard Service.

    Features:
    - Metric collection
    - Dashboard management
    - Alert management
    - Real-time monitoring
    """

    def __init__(self):
        """Initialize monitoring dashboard."""
        self._metrics: dict[str, MetricDefinition] = {}
        self._alerts: dict[str, Alert] = {}
        self._dashboards: dict[str, Dashboard] = {}
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize with default metrics and dashboards."""
        # Register default metrics
        self._register_default_metrics()

        # Create default dashboards
        self._create_default_dashboards()

        # Create default alerts
        self._create_default_alerts()

        self._initialized = True
        logger.info("Monitoring dashboard initialized")
        return True

    def _register_default_metrics(self) -> None:
        """Register default metrics."""
        default_metrics = [
            ("extraction_requests_total", MetricType.COUNTER, "Total extraction requests"),
            ("extraction_duration_seconds", MetricType.HISTOGRAM, "Extraction duration in seconds"),
            ("extraction_errors_total", MetricType.COUNTER, "Total extraction errors"),
            ("council_votes_total", MetricType.COUNTER, "Total council votes"),
            ("council_consensus_rate", MetricType.GAUGE, "Council consensus rate"),
            ("model_inference_time", MetricType.HISTOGRAM, "Model inference time"),
            ("queue_depth", MetricType.GAUGE, "Document queue depth"),
            ("memory_usage_bytes", MetricType.GAUGE, "Memory usage in bytes"),
            ("gpu_utilization", MetricType.GAUGE, "GPU utilization percentage"),
            ("cpu_utilization", MetricType.GAUGE, "CPU utilization percentage"),
        ]

        for name, metric_type, description in default_metrics:
            self.register_metric(name, metric_type, description)

    def _create_default_dashboards(self) -> None:
        """Create default dashboards."""
        # System Overview Dashboard
        system_dashboard = self.create_dashboard(
            name="System Overview",
            description="Overall system health and performance",
        )
        system_dashboard.add_panel(
            "Request Rate",
            ["extraction_requests_total"],
            panel_type="timeseries",
        )
        system_dashboard.add_panel(
            "Error Rate",
            ["extraction_errors_total"],
            panel_type="timeseries",
        )
        system_dashboard.add_panel(
            "Resource Usage",
            ["memory_usage_bytes", "cpu_utilization", "gpu_utilization"],
            panel_type="gauge",
        )

        # Council Dashboard
        council_dashboard = self.create_dashboard(
            name="Council Analytics",
            description="LLM Council performance metrics",
        )
        council_dashboard.add_panel(
            "Consensus Rate",
            ["council_consensus_rate"],
            panel_type="stat",
        )
        council_dashboard.add_panel(
            "Total Votes",
            ["council_votes_total"],
            panel_type="stat",
        )
        council_dashboard.add_panel(
            "Inference Time",
            ["model_inference_time"],
            panel_type="histogram",
        )

    def _create_default_alerts(self) -> None:
        """Create default alerts."""
        default_alerts = [
            ("high_error_rate", "extraction_errors_total", "> 0.1", 0.1, AlertSeverity.ERROR),
            ("low_consensus", "council_consensus_rate", "< 0.7", 0.7, AlertSeverity.WARNING),
            ("high_queue_depth", "queue_depth", "> 100", 100, AlertSeverity.WARNING),
            (
                "high_memory",
                "memory_usage_bytes",
                "> 8000000000",
                8000000000,
                AlertSeverity.CRITICAL,
            ),
            ("high_gpu_utilization", "gpu_utilization", "> 95", 95, AlertSeverity.WARNING),
        ]

        for name, metric, condition, threshold, severity in default_alerts:
            self.create_alert(
                name=name,
                metric_name=metric,
                condition=condition,
                threshold=threshold,
                severity=severity,
            )

    def register_metric(
        self,
        name: str,
        metric_type: MetricType,
        description: str = "",
        unit: str = "",
        labels: list[str] | None = None,
    ) -> MetricDefinition:
        """Register a metric."""
        metric = MetricDefinition(
            name=name,
            metric_type=metric_type,
            description=description,
            unit=unit,
            labels=labels or [],
        )
        self._metrics[name] = metric
        return metric

    def get_metric(self, name: str) -> MetricDefinition | None:
        """Get a metric by name."""
        return self._metrics.get(name)

    def record_metric(
        self,
        name: str,
        value: float,
        labels: dict[str, str] | None = None,
    ) -> bool:
        """Record a metric value."""
        metric = self._metrics.get(name)
        if not metric:
            return False
        metric.record(value, labels)

        # Evaluate alerts for this metric
        self._evaluate_alerts_for_metric(name, value)
        return True

    def increment_counter(
        self,
        name: str,
        amount: float = 1.0,
        labels: dict[str, str] | None = None,
    ) -> bool:
        """Increment a counter metric."""
        metric = self._metrics.get(name)
        if not metric or metric.metric_type != MetricType.COUNTER:
            return False

        current = metric.get_latest()
        new_value = (current.value if current else 0) + amount
        metric.record(new_value, labels)
        return True

    def create_dashboard(
        self,
        name: str,
        description: str = "",
        refresh_interval: int = 30,
    ) -> Dashboard:
        """Create a new dashboard."""
        dashboard = Dashboard(
            dashboard_id=str(uuid.uuid4()),
            name=name,
            description=description,
            refresh_interval=refresh_interval,
        )
        self._dashboards[name] = dashboard
        return dashboard

    def get_dashboard(self, name: str) -> Dashboard | None:
        """Get a dashboard by name."""
        return self._dashboards.get(name)

    def create_alert(
        self,
        name: str,
        metric_name: str,
        condition: str,
        threshold: float,
        severity: AlertSeverity = AlertSeverity.WARNING,
        duration: int = 60,
        description: str = "",
    ) -> Alert:
        """Create a new alert."""
        alert = Alert(
            alert_id=str(uuid.uuid4()),
            name=name,
            metric_name=metric_name,
            condition=condition,
            threshold=threshold,
            severity=severity,
            duration=duration,
            description=description,
        )
        self._alerts[name] = alert
        return alert

    def get_alert(self, name: str) -> Alert | None:
        """Get an alert by name."""
        return self._alerts.get(name)

    def _evaluate_alerts_for_metric(
        self,
        metric_name: str,
        value: float,
    ) -> None:
        """Evaluate all alerts for a metric."""
        for alert in self._alerts.values():
            if alert.metric_name == metric_name:
                alert.evaluate(value)

    def get_firing_alerts(self) -> list[Alert]:
        """Get all firing alerts."""
        return [alert for alert in self._alerts.values() if alert.status == AlertStatus.FIRING]

    def get_all_metrics(self) -> list[MetricDefinition]:
        """Get all metrics."""
        return list(self._metrics.values())

    def get_all_dashboards(self) -> list[Dashboard]:
        """Get all dashboards."""
        return list(self._dashboards.values())

    def get_all_alerts(self) -> list[Alert]:
        """Get all alerts."""
        return list(self._alerts.values())

    def export_dashboard(self, name: str) -> dict[str, Any]:
        """Export dashboard configuration."""
        dashboard = self._dashboards.get(name)
        if not dashboard:
            return {}
        return dashboard.to_dict()

    def get_metrics_summary(self) -> dict[str, Any]:
        """Get summary of all metrics."""
        summary = {}
        for name, metric in self._metrics.items():
            latest = metric.get_latest()
            summary[name] = {
                "type": metric.metric_type.value,
                "value": latest.value if latest else None,
                "timestamp": latest.timestamp.isoformat() if latest else None,
            }
        return summary


# Singleton instance
_monitoring_dashboard: MonitoringDashboard | None = None


def get_monitoring_dashboard() -> MonitoringDashboard:
    """Get or create monitoring dashboard singleton."""
    global _monitoring_dashboard
    if _monitoring_dashboard is None:
        _monitoring_dashboard = MonitoringDashboard()
        _monitoring_dashboard.initialize()
    return _monitoring_dashboard
