"""
Model Versioning and Registry.

Task 3.4.2: Implement model versioning for council members.
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class ModelStage(StrEnum):
    """Model lifecycle stages."""

    NONE = "None"
    STAGING = "Staging"
    PRODUCTION = "Production"
    ARCHIVED = "Archived"


class ModelFramework(StrEnum):
    """Model frameworks."""

    PYTORCH = "pytorch"
    TENSORFLOW = "tensorflow"
    ONNX = "onnx"
    HUGGINGFACE = "huggingface"
    CUSTOM = "custom"


@dataclass
class ModelMetadata:
    """Metadata for a model version."""

    framework: ModelFramework
    input_schema: dict[str, Any] = field(default_factory=dict)
    output_schema: dict[str, Any] = field(default_factory=dict)
    requirements: list[str] = field(default_factory=list)
    signature: dict[str, Any] = field(default_factory=dict)
    custom_metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "framework": self.framework.value,
            "input_schema": self.input_schema,
            "output_schema": self.output_schema,
            "requirements": self.requirements,
            "signature": self.signature,
            "custom_metadata": self.custom_metadata,
        }


@dataclass
class ModelVersion:
    """A version of a registered model."""

    version_id: str
    model_name: str
    version: int
    stage: ModelStage = ModelStage.NONE
    source_path: str = ""
    run_id: str | None = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_updated: datetime = field(default_factory=datetime.utcnow)
    description: str = ""
    metadata: ModelMetadata | None = None
    tags: dict[str, str] = field(default_factory=dict)
    metrics: dict[str, float] = field(default_factory=dict)

    def transition_stage(self, new_stage: ModelStage) -> None:
        """Transition to a new stage."""
        old_stage = self.stage
        self.stage = new_stage
        self.last_updated = datetime.utcnow()
        logger.info(
            f"Model {self.model_name} v{self.version} transitioned from {old_stage} to {new_stage}"
        )

    def update_metrics(self, metrics: dict[str, float]) -> None:
        """Update model metrics."""
        self.metrics.update(metrics)
        self.last_updated = datetime.utcnow()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "version_id": self.version_id,
            "model_name": self.model_name,
            "version": self.version,
            "stage": self.stage.value,
            "source_path": self.source_path,
            "run_id": self.run_id,
            "created_at": self.created_at.isoformat(),
            "last_updated": self.last_updated.isoformat(),
            "description": self.description,
            "metadata": self.metadata.to_dict() if self.metadata else None,
            "tags": self.tags,
            "metrics": self.metrics,
        }


@dataclass
class RegisteredModel:
    """A registered model in the registry."""

    name: str
    description: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_updated: datetime = field(default_factory=datetime.utcnow)
    versions: list[ModelVersion] = field(default_factory=list)
    tags: dict[str, str] = field(default_factory=dict)

    @property
    def latest_version(self) -> ModelVersion | None:
        """Get the latest version."""
        if not self.versions:
            return None
        return max(self.versions, key=lambda v: v.version)

    @property
    def production_version(self) -> ModelVersion | None:
        """Get the production version."""
        for version in self.versions:
            if version.stage == ModelStage.PRODUCTION:
                return version
        return None

    @property
    def staging_version(self) -> ModelVersion | None:
        """Get the staging version."""
        for version in self.versions:
            if version.stage == ModelStage.STAGING:
                return version
        return None

    def create_version(
        self,
        source_path: str,
        run_id: str | None = None,
        description: str = "",
        metadata: ModelMetadata | None = None,
    ) -> ModelVersion:
        """Create a new version."""
        version_num = len(self.versions) + 1
        version = ModelVersion(
            version_id=str(uuid.uuid4()),
            model_name=self.name,
            version=version_num,
            source_path=source_path,
            run_id=run_id,
            description=description,
            metadata=metadata,
        )
        self.versions.append(version)
        self.last_updated = datetime.utcnow()
        return version

    def get_version(self, version_num: int) -> ModelVersion | None:
        """Get a specific version."""
        for version in self.versions:
            if version.version == version_num:
                return version
        return None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "description": self.description,
            "created_at": self.created_at.isoformat(),
            "last_updated": self.last_updated.isoformat(),
            "versions": [v.to_dict() for v in self.versions],
            "tags": self.tags,
            "latest_version": self.latest_version.version if self.latest_version else None,
        }


class ModelVersionManager:
    """
    Model Version Manager.

    Features:
    - Model registration
    - Version management
    - Stage transitions
    - Model comparison
    """

    def __init__(self, registry_uri: str = "models"):
        """Initialize model version manager."""
        self.registry_uri = registry_uri
        self._models: dict[str, RegisteredModel] = {}
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize with council member models."""
        # Register council member models
        council_models = [
            ("paddle-ocr", "PaddleOCR model for text extraction"),
            ("olmocr", "olmOCR model for document understanding"),
            ("qwen-vlm", "Qwen VLM for multimodal extraction"),
        ]

        for name, description in council_models:
            model = self.register_model(name, description)
            # Create initial version
            version = model.create_version(
                source_path=f"{self.registry_uri}/{name}/v1",
                description="Initial version",
                metadata=ModelMetadata(
                    framework=ModelFramework.PYTORCH,
                    custom_metadata={"council_member": True},
                ),
            )
            version.transition_stage(ModelStage.PRODUCTION)

        self._initialized = True
        logger.info("Model version manager initialized")
        return True

    def register_model(
        self,
        name: str,
        description: str = "",
        tags: dict[str, str] | None = None,
    ) -> RegisteredModel:
        """Register a new model."""
        if name in self._models:
            return self._models[name]

        model = RegisteredModel(
            name=name,
            description=description,
            tags=tags or {},
        )
        self._models[name] = model
        logger.info(f"Registered model: {name}")
        return model

    def get_model(self, name: str) -> RegisteredModel | None:
        """Get a registered model."""
        return self._models.get(name)

    def create_model_version(
        self,
        model_name: str,
        source_path: str,
        run_id: str | None = None,
        description: str = "",
        metadata: ModelMetadata | None = None,
    ) -> ModelVersion | None:
        """Create a new version of a model."""
        model = self._models.get(model_name)
        if not model:
            return None

        version = model.create_version(
            source_path=source_path,
            run_id=run_id,
            description=description,
            metadata=metadata,
        )
        logger.info(f"Created version {version.version} for model {model_name}")
        return version

    def get_model_version(
        self,
        model_name: str,
        version: int | None = None,
        stage: ModelStage | None = None,
    ) -> ModelVersion | None:
        """Get a specific model version."""
        model = self._models.get(model_name)
        if not model:
            return None

        if stage == ModelStage.PRODUCTION:
            return model.production_version
        elif stage == ModelStage.STAGING:
            return model.staging_version
        elif version is not None:
            return model.get_version(version)
        else:
            return model.latest_version

    def transition_model_version_stage(
        self,
        model_name: str,
        version: int,
        stage: ModelStage,
        archive_existing: bool = True,
    ) -> bool:
        """Transition a model version to a new stage."""
        model = self._models.get(model_name)
        if not model:
            return False

        target_version = model.get_version(version)
        if not target_version:
            return False

        # Archive existing version in the same stage
        if archive_existing and stage in [ModelStage.PRODUCTION, ModelStage.STAGING]:
            for v in model.versions:
                if v.stage == stage and v.version != version:
                    v.transition_stage(ModelStage.ARCHIVED)

        target_version.transition_stage(stage)
        return True

    def compare_models(
        self,
        model_name: str,
        version_a: int,
        version_b: int,
        metric_keys: list[str] | None = None,
    ) -> dict[str, Any]:
        """Compare two model versions."""
        model = self._models.get(model_name)
        if not model:
            return {}

        va = model.get_version(version_a)
        vb = model.get_version(version_b)

        if not va or not vb:
            return {}

        comparison = {
            "model_name": model_name,
            "version_a": version_a,
            "version_b": version_b,
            "metrics_comparison": {},
        }

        keys = metric_keys or list(set(va.metrics.keys()) | set(vb.metrics.keys()))

        for key in keys:
            val_a = va.metrics.get(key)
            val_b = vb.metrics.get(key)
            comparison["metrics_comparison"][key] = {
                "version_a": val_a,
                "version_b": val_b,
                "diff": (val_b - val_a) if val_a and val_b else None,
            }

        return comparison

    def get_all_models(self) -> list[RegisteredModel]:
        """Get all registered models."""
        return list(self._models.values())

    def search_models(
        self,
        filter_tags: dict[str, str] | None = None,
        max_results: int = 100,
    ) -> list[RegisteredModel]:
        """Search for models."""
        results = []

        for model in self._models.values():
            if filter_tags:
                match = all(model.tags.get(k) == v for k, v in filter_tags.items())
                if not match:
                    continue
            results.append(model)

        return results[:max_results]

    def delete_model(self, name: str) -> bool:
        """Delete a registered model."""
        if name in self._models:
            del self._models[name]
            logger.info(f"Deleted model: {name}")
            return True
        return False


# Singleton instance
_model_manager: ModelVersionManager | None = None


def get_model_version_manager() -> ModelVersionManager:
    """Get or create model version manager singleton."""
    global _model_manager
    if _model_manager is None:
        _model_manager = ModelVersionManager()
        _model_manager.initialize()
    return _model_manager
