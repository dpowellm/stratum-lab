"""Judge Configuration Manager.

In-memory singleton that stores the runtime judge configuration
(provider, model, API key, enabled state). The frontend syncs from
localStorage on page load via the PUT endpoint.
"""

from dataclasses import dataclass
from typing import Any

from src.core.logging import get_logger
from src.council.judge import JudgeInterface, get_judge_for_provider

logger = get_logger(__name__)

DEFAULT_MODELS: dict[str, list[str]] = {
    "openai": ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo", "o1", "o3-mini"],
    "anthropic": [
        "claude-opus-4-20250514",
        "claude-sonnet-4-20250514",
        "claude-3-5-haiku-20241022",
    ],
    "gemini": ["gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-pro"],
}


@dataclass
class JudgeConfig:
    """Runtime judge configuration."""

    provider: str = "openai"
    model: str = "gpt-4o"
    api_key: str = ""
    enabled: bool = False
    always_use_judge: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "model": self.model,
            "has_api_key": bool(self.api_key),
            "enabled": self.enabled,
            "always_use_judge": self.always_use_judge,
        }


class JudgeConfigManager:
    """Singleton manager for judge configuration."""

    _instance: "JudgeConfigManager | None" = None

    def __init__(self) -> None:
        self._config = JudgeConfig()
        self._judge: JudgeInterface | None = None

    @classmethod
    def get_instance(cls) -> "JudgeConfigManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def get_config(self) -> JudgeConfig:
        return self._config

    def update_config(
        self,
        provider: str | None = None,
        model: str | None = None,
        api_key: str | None = None,
        enabled: bool | None = None,
        always_use_judge: bool | None = None,
    ) -> JudgeConfig:
        """Update configuration and invalidate cached judge."""
        if provider is not None:
            self._config.provider = provider
        if model is not None:
            self._config.model = model
        if api_key is not None:
            self._config.api_key = api_key
        if enabled is not None:
            self._config.enabled = enabled
        if always_use_judge is not None:
            self._config.always_use_judge = always_use_judge

        # Invalidate cached judge on config change
        self._judge = None
        logger.info(
            "Judge config updated",
            provider=self._config.provider,
            model=self._config.model,
            enabled=self._config.enabled,
        )
        return self._config

    def clear_api_key(self) -> None:
        """Clear the stored API key and disable judge."""
        self._config.api_key = ""
        self._config.enabled = False
        self._judge = None
        logger.info("Judge API key cleared")

    def get_judge(self) -> JudgeInterface | None:
        """Get or create a judge instance from current config.

        Returns None if not enabled or no API key.
        """
        if not self._config.enabled or not self._config.api_key:
            return None

        if self._judge is None:
            try:
                self._judge = get_judge_for_provider(
                    provider=self._config.provider,
                    model_name=self._config.model,
                    api_key=self._config.api_key,
                )
                logger.info(
                    "Judge instance created",
                    provider=self._config.provider,
                    model=self._config.model,
                )
            except Exception as exc:
                logger.error("Failed to create judge", error=str(exc))
                return None

        return self._judge

    async def fetch_models_from_provider(
        self, provider: str, api_key: str | None = None
    ) -> list[str]:
        """Fetch available models from a provider.

        Falls back to DEFAULT_MODELS if API call fails or no key provided.
        """
        key = api_key or self._config.api_key
        if not key:
            return DEFAULT_MODELS.get(provider, [])

        try:
            return await _fetch_models_from_provider(provider, key)
        except Exception as exc:
            logger.debug(
                "Failed to fetch models from provider, using defaults",
                provider=provider,
                error=str(exc),
            )
            return DEFAULT_MODELS.get(provider, [])


async def _fetch_models_from_provider(provider: str, api_key: str) -> list[str]:
    """Fetch models from provider API."""
    import httpx

    async with httpx.AsyncClient(timeout=10.0) as client:
        if provider == "openai":
            resp = await client.get(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {api_key}"},
            )
            resp.raise_for_status()
            data = resp.json()
            models = [m["id"] for m in data.get("data", [])]
            # Filter to relevant models
            prefixes = ("gpt-4", "gpt-3.5", "o1", "o3")
            return sorted([m for m in models if any(m.startswith(p) for p in prefixes)])

        elif provider == "anthropic":
            resp = await client.get(
                "https://api.anthropic.com/v1/models",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return sorted([m["id"] for m in data.get("data", [])])

        elif provider == "gemini":
            resp = await client.get(
                f"https://generativelanguage.googleapis.com/v1/models?key={api_key}",
            )
            resp.raise_for_status()
            data = resp.json()
            models = [m["name"].replace("models/", "") for m in data.get("models", [])]
            return sorted([m for m in models if "gemini" in m.lower()])

    return DEFAULT_MODELS.get(provider, [])


def get_judge_config_manager() -> JudgeConfigManager:
    """Get the singleton JudgeConfigManager instance."""
    return JudgeConfigManager.get_instance()
