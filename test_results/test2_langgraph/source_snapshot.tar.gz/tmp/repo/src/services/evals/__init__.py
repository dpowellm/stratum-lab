"""Evaluation services for quality metrics, calibration, drift, and regression detection."""
