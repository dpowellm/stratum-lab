"""
Regression detection service for monitoring metric degradation.

Uses Welch's t-test to detect statistically significant regressions in
extraction quality metrics (accuracy, F1, precision, recall, latency).
Implemented using only the Python standard library (math, statistics).
"""

import math
import statistics
from dataclasses import dataclass
from typing import ClassVar

from pydantic import BaseModel

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class _MetricSnapshot:
    """Internal record of a single metrics observation."""

    accuracy: float
    f1: float
    precision: float
    recall: float
    latency_ms: float


class RegressionResult(BaseModel):
    """Regression test result for a single metric."""

    metric_name: str
    baseline_mean: float
    current_mean: float
    difference: float
    p_value: float
    is_regression: bool
    severity: str  # "none" | "minor" | "major" | "critical"


class RegressionReport(BaseModel):
    """Full regression detection report across all tracked metrics."""

    results: list[RegressionResult]
    has_regression: bool
    worst_metric: str | None
    recommendations: list[str]


def _welch_t_test(sample1: list[float], sample2: list[float]) -> tuple[float, float]:
    """
    Perform Welch's t-test for two independent samples.

    Returns (t_statistic, approximate_p_value).
    The p-value is two-tailed, approximated using the t-distribution
    via the regularized incomplete beta function approximation.
    """
    n1 = len(sample1)
    n2 = len(sample2)

    if n1 < 2 or n2 < 2:
        return 0.0, 1.0

    mean1 = statistics.mean(sample1)
    mean2 = statistics.mean(sample2)
    var1 = statistics.variance(sample1)
    var2 = statistics.variance(sample2)

    # Avoid division by zero when both variances are zero
    denom_sq = var1 / n1 + var2 / n2
    if denom_sq == 0:
        return 0.0, 1.0

    t_stat = (mean1 - mean2) / math.sqrt(denom_sq)

    # Welch-Satterthwaite degrees of freedom
    numerator = denom_sq**2
    denominator = (var1 / n1) ** 2 / (n1 - 1) + (var2 / n2) ** 2 / (n2 - 1)

    if denominator == 0:
        return t_stat, 1.0

    df = numerator / denominator
    df = max(df, 1.0)

    p_value = _t_survival_two_tailed(abs(t_stat), df)
    return t_stat, p_value


def _t_survival_two_tailed(t: float, df: float) -> float:
    """
    Approximate the two-tailed p-value for the t-distribution.

    Uses the approximation: for large df, t approximately follows N(0,1).
    For smaller df, uses a refined normal approximation via the
    Cornish-Fisher expansion.
    """
    if df <= 0:
        return 1.0

    # For large df, use normal approximation directly
    if df > 100:
        p = 2.0 * _normal_survival(t)
        return min(p, 1.0)

    # Improved approximation using the relationship between t and F distributions
    # P(T > t | df) ≈ P(Z > z) where z is derived from the transformation
    # x = df / (df + t^2), then use regularized incomplete beta function
    x = df / (df + t * t)
    p = _regularized_incomplete_beta(df / 2.0, 0.5, x)
    return min(p, 1.0)


def _normal_survival(z: float) -> float:
    """Approximate 1 - Phi(z) using the error function."""
    return 0.5 * math.erfc(z / math.sqrt(2.0))


def _regularized_incomplete_beta(a: float, b: float, x: float) -> float:
    """
    Approximate the regularized incomplete beta function I_x(a, b).

    Uses a continued fraction expansion for numerical stability.
    This is the ratio B_x(a, b) / B(a, b).
    """
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0

    # Use the continued fraction representation
    # For better convergence, use the identity I_x(a,b) = 1 - I_(1-x)(b,a)
    # when x > (a+1)/(a+b+2)
    if x > (a + 1.0) / (a + b + 2.0):
        return 1.0 - _regularized_incomplete_beta(b, a, 1.0 - x)

    # Compute ln(B_x(a,b)) = a*ln(x) + b*ln(1-x) - ln(a) - lnBeta(a,b)
    try:
        log_prefix = a * math.log(x) + b * math.log(1.0 - x) - math.log(a) - _log_beta(a, b)
        prefix = math.exp(log_prefix)
    except (ValueError, OverflowError):
        return 0.5

    # Lentz's continued fraction algorithm
    cf = _beta_continued_fraction(a, b, x)
    return prefix * cf


def _log_beta(a: float, b: float) -> float:
    """Compute ln(Beta(a, b)) = ln(Gamma(a)) + ln(Gamma(b)) - ln(Gamma(a+b))."""
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def _beta_continued_fraction(
    a: float, b: float, x: float, max_iter: int = 200, tol: float = 1e-10
) -> float:
    """
    Evaluate the continued fraction for the incomplete beta function.

    Uses the modified Lentz algorithm.
    """
    tiny = 1e-30

    # f_0 = 1, C_0 = 1, D_0 = 1 - (a+b)*x/(a+1) or use 1
    qab = a + b
    qap = a + 1.0
    qam = a - 1.0

    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < tiny:
        d = tiny
    d = 1.0 / d
    result = d

    for m in range(1, max_iter + 1):
        m2 = 2 * m

        # Even step: d_{2m}
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + aa / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        result *= d * c

        # Odd step: d_{2m+1}
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + aa / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        delta = d * c
        result *= delta

        if abs(delta - 1.0) < tol:
            break

    return result


class RegressionDetector:
    """
    Detects metric regressions by comparing current metrics against a baseline.

    Baseline is established via update_baseline() which snapshots the current
    accumulated metrics. New metrics recorded after the baseline are compared
    using Welch's t-test.

    Severity levels:
    - minor:    p < 0.05 AND difference > 5%
    - major:    p < 0.01 AND difference > 10%
    - critical: p < 0.001 AND difference > 20%
    """

    METRIC_NAMES: ClassVar[list[str]] = ["accuracy", "f1", "precision", "recall", "latency_ms"]

    def __init__(self) -> None:
        self._baseline: list[_MetricSnapshot] = []
        self._current: list[_MetricSnapshot] = []
        self._has_baseline: bool = False
        logger.info("RegressionDetector initialized")

    def record_metrics(
        self,
        accuracy: float,
        f1: float,
        precision: float,
        recall: float,
        latency_ms: float,
    ) -> None:
        """Record a metrics observation."""
        snapshot = _MetricSnapshot(
            accuracy=accuracy,
            f1=f1,
            precision=precision,
            recall=recall,
            latency_ms=latency_ms,
        )
        self._current.append(snapshot)
        logger.debug(
            "Recorded metrics",
            accuracy=accuracy,
            f1=f1,
            precision=precision,
            recall=recall,
            latency_ms=latency_ms,
        )

    def update_baseline(self) -> None:
        """Snapshot the current metrics as the new baseline."""
        self._baseline = list(self._current)
        self._current = []
        self._has_baseline = True
        logger.info(
            "Baseline updated",
            baseline_size=len(self._baseline),
        )

    def _extract_metric(self, snapshots: list[_MetricSnapshot], name: str) -> list[float]:
        """Extract a list of values for a given metric name from snapshots."""
        return [getattr(s, name) for s in snapshots]

    def _classify_severity(self, p_value: float, pct_diff: float, metric_name: str) -> str:
        """
        Classify the severity of a regression.

        For latency, a regression means an increase (positive diff).
        For quality metrics, a regression means a decrease (negative diff).
        """
        # Determine if the direction indicates regression
        is_regressing = pct_diff > 0 if metric_name == "latency_ms" else pct_diff < 0

        abs_pct = abs(pct_diff)

        if not is_regressing:
            return "none"

        if p_value < 0.001 and abs_pct > 20.0:
            return "critical"
        elif p_value < 0.01 and abs_pct > 10.0:
            return "major"
        elif p_value < 0.05 and abs_pct > 5.0:
            return "minor"
        return "none"

    def check_regression(self) -> RegressionReport:
        """Check for regressions across all tracked metrics."""
        results: list[RegressionResult] = []

        for metric_name in self.METRIC_NAMES:
            baseline_vals = self._extract_metric(self._baseline, metric_name)
            current_vals = self._extract_metric(self._current, metric_name)

            if not baseline_vals or not current_vals:
                results.append(
                    RegressionResult(
                        metric_name=metric_name,
                        baseline_mean=0.0,
                        current_mean=0.0,
                        difference=0.0,
                        p_value=1.0,
                        is_regression=False,
                        severity="none",
                    )
                )
                continue

            baseline_mean = statistics.mean(baseline_vals)
            current_mean = statistics.mean(current_vals)
            difference = current_mean - baseline_mean

            # Percentage difference relative to baseline
            if baseline_mean != 0:
                pct_diff = (difference / abs(baseline_mean)) * 100.0
            else:
                pct_diff = 0.0 if difference == 0 else 100.0

            _t_stat, p_value = _welch_t_test(baseline_vals, current_vals)
            severity = self._classify_severity(p_value, pct_diff, metric_name)
            is_regression = severity != "none"

            results.append(
                RegressionResult(
                    metric_name=metric_name,
                    baseline_mean=baseline_mean,
                    current_mean=current_mean,
                    difference=difference,
                    p_value=p_value,
                    is_regression=is_regression,
                    severity=severity,
                )
            )

        has_regression = any(r.is_regression for r in results)

        # Find worst metric by severity then p-value
        severity_order = {"none": 0, "minor": 1, "major": 2, "critical": 3}
        worst = max(results, key=lambda r: (severity_order[r.severity], -r.p_value))
        worst_metric = worst.metric_name if worst.is_regression else None

        # Build recommendations
        recommendations: list[str] = []
        for r in results:
            if r.severity == "critical":
                recommendations.append(
                    f"Critical regression in {r.metric_name}: "
                    f"baseline={r.baseline_mean:.4f}, current={r.current_mean:.4f} "
                    f"(p={r.p_value:.4f}). Immediate investigation required."
                )
            elif r.severity == "major":
                recommendations.append(
                    f"Major regression in {r.metric_name}: "
                    f"baseline={r.baseline_mean:.4f}, current={r.current_mean:.4f} "
                    f"(p={r.p_value:.4f}). Review recent changes."
                )
            elif r.severity == "minor":
                recommendations.append(
                    f"Minor regression in {r.metric_name}: "
                    f"baseline={r.baseline_mean:.4f}, current={r.current_mean:.4f} "
                    f"(p={r.p_value:.4f}). Monitor trend."
                )

        if not has_regression:
            recommendations.append(
                "No significant regressions detected. All metrics are within baseline."
            )

        report = RegressionReport(
            results=results,
            has_regression=has_regression,
            worst_metric=worst_metric,
            recommendations=recommendations,
        )

        logger.info(
            "Regression report computed",
            has_regression=has_regression,
            worst_metric=worst_metric,
            regressing_metrics=[r.metric_name for r in results if r.is_regression],
        )

        return report


_regression_detector: RegressionDetector | None = None


def get_regression_detector() -> RegressionDetector:
    """Get or create the singleton RegressionDetector instance."""
    global _regression_detector
    if _regression_detector is None:
        _regression_detector = RegressionDetector()
    return _regression_detector
