"""
Drift detection service for monitoring data distribution changes.

Detects shifts in document characteristics (type distribution, confidence levels,
field counts) between a reference window and a recent test window using statistical
tests implemented with the Python standard library only.
"""

import math
from dataclasses import dataclass
from typing import Any

from pydantic import BaseModel

from src.core.logging import get_logger

logger = get_logger(__name__)

WINDOW_SIZE = 100


@dataclass
class _DocumentRecord:
    """Internal record of document-level statistics."""

    doc_type: str
    field_count: int
    avg_confidence: float
    file_size: int
    processing_time_ms: float


class DriftDimension(BaseModel):
    """Drift assessment for a single dimension."""

    dimension: str
    score: float
    p_value: float
    is_drifting: bool
    severity: str  # "none" | "warning" | "critical"


class DriftReport(BaseModel):
    """Full drift detection report across multiple dimensions."""

    dimensions: list[DriftDimension]
    overall_alert_level: str  # "none" | "warning" | "critical"
    recommendations: list[str]
    reference_window_size: int
    test_window_size: int


def _chi_squared_test(observed: dict[str, int], expected: dict[str, int]) -> tuple[float, float]:
    """
    Perform a chi-squared goodness-of-fit test.

    Compares the observed distribution against the expected distribution
    (scaled to the observed total).

    Returns (chi2_statistic, approximate_p_value).
    The p-value is approximated using the Wilson-Hilferty normal approximation
    to the chi-squared distribution.
    """
    all_keys = sorted(set(list(observed.keys()) + list(expected.keys())))
    obs_total = sum(observed.values())
    exp_total = sum(expected.values())

    if obs_total == 0 or exp_total == 0:
        return 0.0, 1.0

    chi2 = 0.0
    df = 0
    for key in all_keys:
        obs_count = observed.get(key, 0)
        # Scale expected to match observed total
        exp_count = (expected.get(key, 0) / exp_total) * obs_total
        if exp_count > 0:
            chi2 += (obs_count - exp_count) ** 2 / exp_count
            df += 1

    df = max(df - 1, 1)  # degrees of freedom = categories - 1

    # Approximate p-value using Wilson-Hilferty transformation
    p_value = _chi2_survival(chi2, df)
    return chi2, p_value


def _chi2_survival(x: float, df: int) -> float:
    """
    Approximate the survival function (1 - CDF) of the chi-squared distribution.

    Uses the Wilson-Hilferty normal approximation:
        z = ((x/df)^(1/3) - (1 - 2/(9*df))) / sqrt(2/(9*df))
    then p = 1 - Phi(z).
    """
    if df <= 0 or x <= 0:
        return 1.0

    ratio = x / df
    correction = 2.0 / (9.0 * df)

    try:
        cube_root = ratio ** (1.0 / 3.0)
    except (ValueError, OverflowError):
        return 0.0

    z = (cube_root - (1.0 - correction)) / math.sqrt(correction)
    return _normal_survival(z)


def _normal_survival(z: float) -> float:
    """Approximate 1 - Phi(z) using the error function."""
    return 0.5 * math.erfc(z / math.sqrt(2.0))


def _ks_test(sample1: list[float], sample2: list[float]) -> tuple[float, float]:
    """
    Two-sample Kolmogorov-Smirnov test.

    Returns (ks_statistic, approximate_p_value).
    """
    if not sample1 or not sample2:
        return 0.0, 1.0

    n1 = len(sample1)
    n2 = len(sample2)

    sorted1 = sorted(sample1)
    sorted2 = sorted(sample2)

    # Merge and compute the maximum difference in empirical CDFs
    all_values = sorted(set(sorted1 + sorted2))
    max_diff = 0.0

    for val in all_values:
        # CDF of sample1 at val
        cdf1 = _ecdf_at(sorted1, val)
        # CDF of sample2 at val
        cdf2 = _ecdf_at(sorted2, val)
        diff = abs(cdf1 - cdf2)
        max_diff = max(max_diff, diff)

    # Approximate p-value using the asymptotic distribution
    # p ≈ 2 * exp(-2 * n_eff * D^2)  (two-sided)
    n_eff = (n1 * n2) / (n1 + n2)
    exponent = -2.0 * n_eff * max_diff * max_diff

    try:
        p_value = 2.0 * math.exp(exponent)
    except OverflowError:
        p_value = 0.0

    p_value = min(p_value, 1.0)
    return max_diff, p_value


def _ecdf_at(sorted_data: list[float], value: float) -> float:
    """Compute the empirical CDF at a given value for sorted data."""
    n = len(sorted_data)
    if n == 0:
        return 0.0
    count = 0
    for x in sorted_data:
        if x <= value:
            count += 1
        else:
            break
    return count / n


class DriftDetector:
    """
    Detects distribution drift between a reference window and a test window.

    The reference window is the first WINDOW_SIZE documents recorded, and the
    test window is the last WINDOW_SIZE documents. If fewer documents exist
    than 2 * WINDOW_SIZE, the available data is split proportionally.

    Dimensions monitored:
    - doc_type_distribution (chi-squared test)
    - confidence_distribution (KS test)
    - field_count_distribution (KS test)
    - file_size_distribution (KS test)
    - processing_time_distribution (KS test)
    """

    def __init__(self) -> None:
        self._documents: list[_DocumentRecord] = []
        self._field_values: dict[str, list[Any]] = {}
        logger.info("DriftDetector initialized")

    def record_document(
        self,
        doc_type: str,
        field_count: int,
        avg_confidence: float,
        file_size: int,
        processing_time_ms: float,
    ) -> None:
        """Record document-level statistics for drift monitoring."""
        self._documents.append(
            _DocumentRecord(
                doc_type=doc_type,
                field_count=field_count,
                avg_confidence=avg_confidence,
                file_size=file_size,
                processing_time_ms=processing_time_ms,
            )
        )
        logger.debug(
            "Recorded document for drift",
            doc_type=doc_type,
            field_count=field_count,
            avg_confidence=avg_confidence,
        )

    def record_field_value(self, field_name: str, value: Any) -> None:
        """Record a field value for tracking field-level drift."""
        self._field_values.setdefault(field_name, []).append(value)
        logger.debug("Recorded field value for drift", field_name=field_name)

    def _split_windows(
        self,
    ) -> tuple[list[_DocumentRecord], list[_DocumentRecord]]:
        """Split documents into reference and test windows."""
        n = len(self._documents)
        if n < 2:
            return self._documents[:], self._documents[:]

        ref_size = min(WINDOW_SIZE, n // 2)
        test_size = min(WINDOW_SIZE, n - ref_size)

        reference = self._documents[:ref_size]
        test = self._documents[n - test_size :]
        return reference, test

    def _severity_from_pvalue(self, p_value: float) -> str:
        """Determine severity from a p-value."""
        if p_value < 0.01:
            return "critical"
        elif p_value < 0.05:
            return "warning"
        return "none"

    def check_drift(self) -> DriftReport:
        """Check for distribution drift across all monitored dimensions."""
        reference, test = self._split_windows()
        dimensions: list[DriftDimension] = []

        # 1. Document type distribution (chi-squared)
        ref_types: dict[str, int] = {}
        for doc in reference:
            ref_types[doc.doc_type] = ref_types.get(doc.doc_type, 0) + 1
        test_types: dict[str, int] = {}
        for doc in test:
            test_types[doc.doc_type] = test_types.get(doc.doc_type, 0) + 1

        chi2_stat, chi2_p = _chi_squared_test(test_types, ref_types)
        severity = self._severity_from_pvalue(chi2_p)
        dimensions.append(
            DriftDimension(
                dimension="doc_type_distribution",
                score=chi2_stat,
                p_value=chi2_p,
                is_drifting=chi2_p < 0.05,
                severity=severity,
            )
        )

        # 2. Confidence distribution (KS test)
        ref_conf = [d.avg_confidence for d in reference]
        test_conf = [d.avg_confidence for d in test]
        ks_stat, ks_p = _ks_test(ref_conf, test_conf)
        severity = self._severity_from_pvalue(ks_p)
        dimensions.append(
            DriftDimension(
                dimension="confidence_distribution",
                score=ks_stat,
                p_value=ks_p,
                is_drifting=ks_p < 0.05,
                severity=severity,
            )
        )

        # 3. Field count distribution (KS test)
        ref_fc = [float(d.field_count) for d in reference]
        test_fc = [float(d.field_count) for d in test]
        ks_stat, ks_p = _ks_test(ref_fc, test_fc)
        severity = self._severity_from_pvalue(ks_p)
        dimensions.append(
            DriftDimension(
                dimension="field_count_distribution",
                score=ks_stat,
                p_value=ks_p,
                is_drifting=ks_p < 0.05,
                severity=severity,
            )
        )

        # 4. File size distribution (KS test)
        ref_fs = [float(d.file_size) for d in reference]
        test_fs = [float(d.file_size) for d in test]
        ks_stat, ks_p = _ks_test(ref_fs, test_fs)
        severity = self._severity_from_pvalue(ks_p)
        dimensions.append(
            DriftDimension(
                dimension="file_size_distribution",
                score=ks_stat,
                p_value=ks_p,
                is_drifting=ks_p < 0.05,
                severity=severity,
            )
        )

        # 5. Processing time distribution (KS test)
        ref_pt = [d.processing_time_ms for d in reference]
        test_pt = [d.processing_time_ms for d in test]
        ks_stat, ks_p = _ks_test(ref_pt, test_pt)
        severity = self._severity_from_pvalue(ks_p)
        dimensions.append(
            DriftDimension(
                dimension="processing_time_distribution",
                score=ks_stat,
                p_value=ks_p,
                is_drifting=ks_p < 0.05,
                severity=severity,
            )
        )

        # Determine overall alert level
        severities = [d.severity for d in dimensions]
        if "critical" in severities:
            overall_alert = "critical"
        elif "warning" in severities:
            overall_alert = "warning"
        else:
            overall_alert = "none"

        # Build recommendations
        recommendations: list[str] = []
        for dim in dimensions:
            if dim.severity == "critical":
                recommendations.append(
                    f"Critical drift detected in {dim.dimension} "
                    f"(p={dim.p_value:.4f}). Immediate review recommended."
                )
            elif dim.severity == "warning":
                recommendations.append(
                    f"Warning: drift detected in {dim.dimension} "
                    f"(p={dim.p_value:.4f}). Monitor closely."
                )

        if overall_alert == "none":
            recommendations.append("No significant drift detected. System is stable.")

        report = DriftReport(
            dimensions=dimensions,
            overall_alert_level=overall_alert,
            recommendations=recommendations,
            reference_window_size=len(reference),
            test_window_size=len(test),
        )

        logger.info(
            "Drift report computed",
            overall_alert_level=overall_alert,
            drifting_dimensions=[d.dimension for d in dimensions if d.is_drifting],
            reference_window_size=len(reference),
            test_window_size=len(test),
        )

        return report


_drift_detector: DriftDetector | None = None


def get_drift_detector() -> DriftDetector:
    """Get or create the singleton DriftDetector instance."""
    global _drift_detector
    if _drift_detector is None:
        _drift_detector = DriftDetector()
    return _drift_detector
