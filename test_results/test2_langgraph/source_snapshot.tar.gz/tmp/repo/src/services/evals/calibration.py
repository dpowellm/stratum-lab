"""
Calibration tracking service for model confidence assessment.

Measures how well a model's predicted confidence aligns with actual accuracy
using Expected Calibration Error (ECE) and Maximum Calibration Error (MCE).
"""

from collections.abc import Callable
from dataclasses import dataclass

from pydantic import BaseModel

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class _Prediction:
    """Internal record of a single prediction with its outcome."""

    confidence: float
    was_correct: bool
    model_name: str = ""
    field_name: str = ""


class CalibrationBucket(BaseModel):
    """A single calibration bucket in the reliability diagram."""

    bucket_start: float
    bucket_end: float
    count: int
    avg_confidence: float
    avg_accuracy: float


class CalibrationReport(BaseModel):
    """Full calibration report with ECE, MCE, and per-bucket breakdowns."""

    ece: float
    mce: float
    buckets: list[CalibrationBucket]
    overconfidence_rate: float
    total_predictions: int
    per_model_ece: dict[str, float]
    per_field_ece: dict[str, float]


class CalibrationTracker:
    """
    Tracks prediction confidence vs. actual accuracy to measure calibration.

    Uses 10 equal-width buckets from [0.0, 0.1) to [0.9, 1.0].
    ECE (Expected Calibration Error) = weighted average of |accuracy - confidence|.
    MCE (Maximum Calibration Error) = max |accuracy - confidence|.
    Overconfidence rate = fraction of predictions where confidence > accuracy
    (computed per-bucket).
    """

    NUM_BUCKETS = 10

    def __init__(self) -> None:
        self._predictions: list[_Prediction] = []
        logger.info("CalibrationTracker initialized")

    def record_prediction(
        self,
        confidence: float,
        was_correct: bool,
        model_name: str = "",
        field_name: str = "",
    ) -> None:
        """Record a prediction with its confidence and actual outcome."""
        self._predictions.append(
            _Prediction(
                confidence=confidence,
                was_correct=was_correct,
                model_name=model_name,
                field_name=field_name,
            )
        )
        logger.debug(
            "Recorded prediction",
            confidence=confidence,
            was_correct=was_correct,
            model_name=model_name,
            field_name=field_name,
        )

    def _bucket_index(self, confidence: float) -> int:
        """Map a confidence score to its bucket index (0-9)."""
        idx = int(confidence * self.NUM_BUCKETS)
        # Clamp to valid range; confidence=1.0 goes to bucket 9
        return min(idx, self.NUM_BUCKETS - 1)

    def _compute_buckets(self, predictions: list[_Prediction]) -> list[CalibrationBucket]:
        """Compute calibration buckets from a list of predictions."""
        bucket_confs: list[list[float]] = [[] for _ in range(self.NUM_BUCKETS)]
        bucket_correct: list[list[bool]] = [[] for _ in range(self.NUM_BUCKETS)]

        for pred in predictions:
            idx = self._bucket_index(pred.confidence)
            bucket_confs[idx].append(pred.confidence)
            bucket_correct[idx].append(pred.was_correct)

        buckets: list[CalibrationBucket] = []
        for i in range(self.NUM_BUCKETS):
            start = i / self.NUM_BUCKETS
            end = (i + 1) / self.NUM_BUCKETS
            count = len(bucket_confs[i])

            if count > 0:
                avg_conf = sum(bucket_confs[i]) / count
                avg_acc = sum(1.0 for c in bucket_correct[i] if c) / count
            else:
                avg_conf = 0.0
                avg_acc = 0.0

            buckets.append(
                CalibrationBucket(
                    bucket_start=start,
                    bucket_end=end,
                    count=count,
                    avg_confidence=avg_conf,
                    avg_accuracy=avg_acc,
                )
            )

        return buckets

    def _compute_ece_from_buckets(self, buckets: list[CalibrationBucket], total: int) -> float:
        """Compute ECE from pre-computed buckets."""
        if total == 0:
            return 0.0
        ece = 0.0
        for bucket in buckets:
            if bucket.count > 0:
                weight = bucket.count / total
                ece += weight * abs(bucket.avg_accuracy - bucket.avg_confidence)
        return ece

    def _compute_mce_from_buckets(self, buckets: list[CalibrationBucket]) -> float:
        """Compute MCE from pre-computed buckets."""
        mce = 0.0
        for bucket in buckets:
            if bucket.count > 0:
                gap = abs(bucket.avg_accuracy - bucket.avg_confidence)
                mce = max(mce, gap)
        return mce

    def _compute_ece_for_subset(self, predictions: list[_Prediction]) -> float:
        """Compute ECE for a subset of predictions."""
        if not predictions:
            return 0.0
        buckets = self._compute_buckets(predictions)
        return self._compute_ece_from_buckets(buckets, len(predictions))

    def compute_calibration(self) -> CalibrationReport:
        """Compute a full calibration report."""
        total = len(self._predictions)
        buckets = self._compute_buckets(self._predictions)

        ece = self._compute_ece_from_buckets(buckets, total)
        mce = self._compute_mce_from_buckets(buckets)

        # Overconfidence rate: fraction of non-empty buckets where
        # avg_confidence > avg_accuracy, weighted by count
        overconfident_count = 0
        for bucket in buckets:
            if bucket.count > 0 and bucket.avg_confidence > bucket.avg_accuracy:
                overconfident_count += bucket.count
        overconfidence_rate = overconfident_count / total if total > 0 else 0.0

        # Per-model ECE
        model_names = sorted({p.model_name for p in self._predictions if p.model_name})
        per_model_ece: dict[str, float] = {}
        for model in model_names:
            model_preds = [p for p in self._predictions if p.model_name == model]
            per_model_ece[model] = self._compute_ece_for_subset(model_preds)

        # Per-field ECE
        field_names = sorted({p.field_name for p in self._predictions if p.field_name})
        per_field_ece: dict[str, float] = {}
        for fn in field_names:
            field_preds = [p for p in self._predictions if p.field_name == fn]
            per_field_ece[fn] = self._compute_ece_for_subset(field_preds)

        report = CalibrationReport(
            ece=ece,
            mce=mce,
            buckets=buckets,
            overconfidence_rate=overconfidence_rate,
            total_predictions=total,
            per_model_ece=per_model_ece,
            per_field_ece=per_field_ece,
        )

        logger.info(
            "Calibration report computed",
            ece=ece,
            mce=mce,
            overconfidence_rate=overconfidence_rate,
            total_predictions=total,
        )

        return report

    def get_reliability_diagram_data(self) -> list[dict]:
        """
        Return data suitable for rendering a reliability diagram.

        Returns a list of dicts with keys: confidence, accuracy, count.
        Only includes non-empty buckets.
        """
        buckets = self._compute_buckets(self._predictions)
        data: list[dict] = []
        for bucket in buckets:
            if bucket.count > 0:
                data.append(
                    {
                        "confidence": bucket.avg_confidence,
                        "accuracy": bucket.avg_accuracy,
                        "count": bucket.count,
                    }
                )
        return data

    def get_calibration_function(self, model_name: str) -> Callable[[float], float]:
        """Get a Platt scaling calibration function for a specific model.

        Uses logistic regression (Platt scaling) to map raw confidence
        scores to calibrated probabilities based on historical data.

        Args:
            model_name: Model to calibrate for.

        Returns:
            A callable that maps raw confidence → calibrated confidence.
        """
        import math

        model_preds = [p for p in self._predictions if p.model_name == model_name]
        if len(model_preds) < 10:
            # Not enough data — identity function
            return lambda x: x

        # Simple Platt scaling: fit logistic regression
        # P(correct | confidence) = 1 / (1 + exp(-(a*confidence + b)))
        # Use gradient descent to fit a and b
        a, b = self._fit_platt_params(model_preds)

        def calibrated(confidence: float) -> float:
            z = a * confidence + b
            z = max(-10.0, min(10.0, z))  # Prevent overflow
            return 1.0 / (1.0 + math.exp(-z))

        return calibrated

    def calibrate(self, confidence: float, model_name: str) -> float:
        """Calibrate a confidence score using Platt scaling.

        Args:
            confidence: Raw model confidence.
            model_name: Which model produced the score.

        Returns:
            Calibrated confidence (between 0 and 1).
        """
        func = self.get_calibration_function(model_name)
        return func(confidence)

    def _fit_platt_params(self, predictions: list[_Prediction]) -> tuple[float, float]:
        """Fit Platt scaling parameters (a, b) via simple gradient descent.

        Minimizes cross-entropy loss: -sum(y*log(p) + (1-y)*log(1-p))
        where p = sigmoid(a*x + b), x = confidence, y = was_correct.
        """
        import math

        a = 1.0
        b = 0.0
        lr = 0.1

        for _ in range(100):  # 100 iterations
            grad_a = 0.0
            grad_b = 0.0
            for pred in predictions:
                z = a * pred.confidence + b
                z = max(-10.0, min(10.0, z))
                p = 1.0 / (1.0 + math.exp(-z))
                y = 1.0 if pred.was_correct else 0.0
                error = p - y
                grad_a += error * pred.confidence
                grad_b += error

            n = len(predictions)
            a -= lr * grad_a / n
            b -= lr * grad_b / n

        return a, b


_calibration_tracker: CalibrationTracker | None = None


def get_calibration_tracker() -> CalibrationTracker:
    """Get or create the singleton CalibrationTracker instance."""
    global _calibration_tracker
    if _calibration_tracker is None:
        _calibration_tracker = CalibrationTracker()
    return _calibration_tracker
