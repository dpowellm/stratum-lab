"""
Security & Compliance Package.

Provides PII detection, encryption, RBAC, and audit logging components.
"""

from src.services.security.audit import (
    AuditEvent,
    AuditEventType,
    AuditLogger,
    AuditTrail,
    get_audit_logger,
)
from src.services.security.encryption import (
    EncryptedData,
    EncryptionAlgorithm,
    EncryptionService,
    KeyManager,
    get_encryption_service,
)
from src.services.security.pii_detection import (
    PIIDetector,
    PIIEntity,
    PIIMaskingStrategy,
    PIIType,
    get_pii_detector,
)
from src.services.security.rbac import (
    AccessPolicy,
    Permission,
    RBACManager,
    Role,
    User,
    get_rbac_manager,
)

__all__ = [
    "AccessPolicy",
    "AuditEvent",
    "AuditEventType",
    # Audit
    "AuditLogger",
    "AuditTrail",
    "EncryptedData",
    "EncryptionAlgorithm",
    # Encryption
    "EncryptionService",
    "KeyManager",
    # PII Detection
    "PIIDetector",
    "PIIEntity",
    "PIIMaskingStrategy",
    "PIIType",
    "Permission",
    # RBAC
    "RBACManager",
    "Role",
    "User",
    "get_audit_logger",
    "get_encryption_service",
    "get_pii_detector",
    "get_rbac_manager",
]
