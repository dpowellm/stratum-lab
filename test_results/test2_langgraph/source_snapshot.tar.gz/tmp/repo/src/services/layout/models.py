"""Layout data structures for region-based document extraction."""

from dataclasses import dataclass, field


@dataclass
class RegionSelector:
    """Defines a rectangular region on a PDF page using normalized coordinates.

    All coordinates are normalized to 0.0-1.0 range relative to page dimensions.
    """

    page_number: int  # 0-indexed
    x0: float  # left edge (0.0-1.0)
    y0: float  # top edge (0.0-1.0)
    x1: float  # right edge (0.0-1.0)
    y1: float  # bottom edge (0.0-1.0)
    label: str = ""

    def to_fitz_rect(self, page_width: float, page_height: float) -> tuple[float, ...]:
        """Convert normalized coordinates to absolute PyMuPDF points.

        Args:
            page_width: Page width in points.
            page_height: Page height in points.

        Returns:
            Tuple of (x0, y0, x1, y1) in absolute points.
        """
        return (
            self.x0 * page_width,
            self.y0 * page_height,
            self.x1 * page_width,
            self.y1 * page_height,
        )


@dataclass
class TextSpan:
    """A contiguous run of text with uniform formatting."""

    text: str
    font_name: str  # e.g. "Helvetica-Bold"
    font_size: float  # points
    color: int  # sRGB integer
    bold: bool
    italic: bool
    bbox: tuple[float, float, float, float]  # (x0, y0, x1, y1) in points
    font_weight: int = 400  # CSS-style: 400=normal, 700=bold
    text_color_rgb: tuple[int, int, int] = (0, 0, 0)  # RGB values 0-255
    line_spacing: float = 0.0  # Leading in points
    alignment: str = "left"  # left, center, right, justified


@dataclass
class TextLine:
    """A single line of text composed of spans."""

    spans: list[TextSpan]
    bbox: tuple[float, float, float, float]


@dataclass
class TextBlock:
    """A block of text composed of lines."""

    lines: list[TextLine]
    bbox: tuple[float, float, float, float]
    block_type: str = "text"  # "text" or "image"


@dataclass
class TableBlock:
    """A detected table block with headers and rows."""

    headers: list[str]
    rows: list[list[str]]
    bbox: tuple[float, float, float, float]
    block_type: str = "table"


@dataclass
class PageLayout:
    """Layout information for a single page or region of a page."""

    page_number: int
    page_width: float  # points
    page_height: float  # points
    blocks: list[TextBlock | TableBlock]
    region: RegionSelector | None = None


@dataclass
class DocumentLayout:
    """Layout information for an entire document or set of regions."""

    pages: list[PageLayout] = field(default_factory=list)
    source_filename: str = ""
    total_page_count: int = 0
