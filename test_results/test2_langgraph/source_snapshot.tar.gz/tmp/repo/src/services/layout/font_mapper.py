"""Font name mapping between PyMuPDF, reportlab, and python-docx."""

from __future__ import annotations

# PyMuPDF flags bitmask constants
_FLAG_SUPERSCRIPT = 1 << 0
_FLAG_ITALIC = 1 << 1
_FLAG_SERIF = 1 << 2
_FLAG_MONOSPACE = 1 << 3
_FLAG_BOLD = 1 << 4

# Mapping from PyMuPDF font name prefixes to reportlab built-in fonts
_REPORTLAB_MAP: dict[str, str] = {
    "helvetica": "Helvetica",
    "arial": "Helvetica",
    "times": "Times-Roman",
    "timesnewroman": "Times-Roman",
    "courier": "Courier",
    "couriernew": "Courier",
    "symbol": "Symbol",
    "zapfdingbats": "ZapfDingbats",
}

# Mapping from PyMuPDF font name prefixes to python-docx font names
_DOCX_MAP: dict[str, str] = {
    "helvetica": "Arial",
    "arial": "Arial",
    "times": "Times New Roman",
    "timesnewroman": "Times New Roman",
    "courier": "Courier New",
    "couriernew": "Courier New",
    "calibri": "Calibri",
    "cambria": "Cambria",
    "verdana": "Verdana",
    "georgia": "Georgia",
    "tahoma": "Tahoma",
    "trebuchet": "Trebuchet MS",
    "garamond": "Garamond",
}


def _normalize_name(font_name: str) -> str:
    """Normalize font name for lookup: lowercase, strip suffixes and separators."""
    name = font_name.lower().replace("-", "").replace("_", "").replace(" ", "")
    # Strip common style suffixes (order matters: check compound suffixes first)
    for suffix in ("bolditalic", "boldoblique", "italic", "oblique", "bold", "regular"):
        if name.endswith(suffix):
            name = name[: -len(suffix)]
            break
    # Only strip "roman" if it's a style suffix, not part of the base name like "timesnewroman"
    if name.endswith("roman") and name != "timesnewroman":
        name = name[: -len("roman")]
    return name.rstrip(",.")


class FontMapper:
    """Maps PyMuPDF font names to reportlab and python-docx font names."""

    @staticmethod
    def to_reportlab(font_name: str, bold: bool = False, italic: bool = False) -> str:
        """Map a PyMuPDF font name to a reportlab built-in font name.

        Args:
            font_name: Font name from PyMuPDF span.
            bold: Whether the text is bold.
            italic: Whether the text is italic.

        Returns:
            A reportlab font name string.
        """
        normalized = _normalize_name(font_name)
        base = _REPORTLAB_MAP.get(normalized, "Helvetica")

        # Build reportlab variant name
        if base in ("Helvetica", "Courier"):
            if bold and italic:
                return f"{base}-BoldOblique"
            if bold:
                return f"{base}-Bold"
            if italic:
                return f"{base}-Oblique"
            return base
        if base == "Times-Roman":
            if bold and italic:
                return "Times-BoldItalic"
            if bold:
                return "Times-Bold"
            if italic:
                return "Times-Italic"
            return "Times-Roman"
        return base

    @staticmethod
    def to_docx(font_name: str) -> str:
        """Map a PyMuPDF font name to a python-docx font name.

        Args:
            font_name: Font name from PyMuPDF span.

        Returns:
            A python-docx compatible font name string.
        """
        normalized = _normalize_name(font_name)
        return _DOCX_MAP.get(normalized, "Calibri")

    @staticmethod
    def detect_style_from_name(font_name: str) -> tuple[bool, bool]:
        """Detect bold/italic from font name suffix.

        Args:
            font_name: Font name string.

        Returns:
            Tuple of (bold, italic).
        """
        lower = font_name.lower()
        bold = "bold" in lower
        italic = "italic" in lower or "oblique" in lower
        return bold, italic

    @staticmethod
    def detect_style_from_flags(flags: int) -> tuple[bool, bool]:
        """Detect bold/italic from PyMuPDF span flags bitmask.

        PyMuPDF flags: bit 0 = superscript, bit 1 = italic, bit 4 = bold.

        Args:
            flags: Integer bitmask from PyMuPDF span["flags"].

        Returns:
            Tuple of (bold, italic).
        """
        bold = bool(flags & _FLAG_BOLD)
        italic = bool(flags & _FLAG_ITALIC)
        return bold, italic

    @staticmethod
    def color_int_to_rgb(color: int) -> tuple[int, int, int]:
        """Convert a PyMuPDF sRGB integer color to (R, G, B) tuple.

        Args:
            color: Integer color value from PyMuPDF span.

        Returns:
            Tuple of (red, green, blue) each 0-255.
        """
        r = (color >> 16) & 0xFF
        g = (color >> 8) & 0xFF
        b = color & 0xFF
        return r, g, b
