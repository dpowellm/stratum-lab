"""Background document processing pipeline.

Runs ingestion and council extraction asynchronously after a document
is uploaded.  Uses MockCouncilMembers so the pipeline works without
real OCR models while still persisting full CouncilSession, MemberVote,
and Extraction records to the database.

The pipeline extracts **real text** from uploaded documents:
  1. Embedded text via ``pypdf`` (fast, for text-based PDFs)
  2. OCR via ``PyMuPDF`` + ``pytesseract`` (for scanned/image PDFs and images)
"""

import asyncio
import io
import pathlib
import random
import re
import uuid
from typing import Any

import fitz  # PyMuPDF
import pytesseract
from PIL import Image
from pypdf import PdfReader

from src.core.logging import get_logger
from src.council.members.base import CouncilMember, MockCouncilMember
from src.models.database.base import get_session_factory
from src.models.database.document import ProcessingStatus
from src.services.document.content_analyzer import ContentAnalyzer
from src.services.document.repository import DocumentRepository
from src.services.storage.local import LocalStorageService
from src.workers.tasks.council import run_council_session_pipeline

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Text extraction helpers
# ---------------------------------------------------------------------------

_MAX_TEXT_LENGTH = 5000


def _ocr_image_bytes(image_bytes: bytes) -> str:
    """Run Tesseract OCR on raw image bytes via Pillow.

    Returns extracted text, or empty string on failure.
    """
    try:
        img = Image.open(io.BytesIO(image_bytes))
        text = pytesseract.image_to_string(img)
        return text.strip()
    except Exception as exc:
        logger.warning("Tesseract OCR failed on image", error=str(exc))
        return ""


def _ocr_pdf_with_pymupdf(file_bytes: bytes) -> tuple[str, int]:
    """Render each PDF page as an image with PyMuPDF and OCR with Tesseract.

    Returns:
        Tuple of (extracted_text, page_count).
    """
    try:
        pdf_doc = fitz.open(stream=file_bytes, filetype="pdf")
        pages: list[str] = []
        for page in pdf_doc:
            # Render page at 300 DPI for good OCR quality
            pix = page.get_pixmap(dpi=300)
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            text = pytesseract.image_to_string(img)
            pages.append(text.strip())
        page_count = len(pdf_doc)
        pdf_doc.close()
        full_text = "\n\n".join(pages)
        return full_text, page_count
    except Exception as exc:
        logger.warning("PyMuPDF + Tesseract OCR failed", error=str(exc))
        return "", 0


def _extract_text_from_pdf(file_bytes: bytes) -> tuple[str, int]:
    """Extract text from a PDF.

    Strategy:
      1. Try pypdf for embedded text (fast).
      2. If no meaningful text found, fall back to PyMuPDF + Tesseract OCR.

    Returns:
        Tuple of (extracted_text, page_count).
    """
    # Step 1: Try embedded text via pypdf
    try:
        reader = PdfReader(io.BytesIO(file_bytes))
        pages: list[str] = []
        for page in reader.pages:
            text = page.extract_text() or ""
            pages.append(text)
        full_text = "\n\n".join(pages)
        page_count = len(reader.pages)

        # If we got meaningful text, return it
        stripped = full_text.strip()
        if stripped and len(stripped.split()) > 5:
            return full_text, page_count
    except Exception as exc:
        logger.warning("pypdf text extraction failed", error=str(exc))

    # Step 2: Fall back to OCR
    logger.info("No embedded text found in PDF, falling back to OCR")
    return _ocr_pdf_with_pymupdf(file_bytes)


def render_pdf_pages(file_bytes: bytes, dpi: int = 300) -> list[bytes]:
    """Render each PDF page as a PNG image.

    Args:
        file_bytes: Raw PDF bytes.
        dpi: Resolution for rendering.

    Returns:
        List of PNG image bytes, one per page.
    """
    try:
        pdf_doc = fitz.open(stream=file_bytes, filetype="pdf")
        images: list[bytes] = []
        for page in pdf_doc:
            pix = page.get_pixmap(dpi=dpi)
            images.append(pix.tobytes("png"))
        pdf_doc.close()
        return images
    except Exception as exc:
        logger.warning("PDF page rendering failed", error=str(exc))
        return []


def _extract_text_from_docx(file_bytes: bytes) -> tuple[str, int]:
    """Extract text from a DOCX file using python-docx.

    Returns:
        Tuple of (extracted_text, page_count_estimate).
    """
    try:
        from docx import Document as DocxDoc

        doc = DocxDoc(io.BytesIO(file_bytes))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        text = "\n".join(paragraphs)
        # Rough page estimate: ~250 words per page
        page_count = max(1, len(text.split()) // 250)
        return text, page_count
    except Exception as exc:
        logger.warning("DOCX text extraction failed", error=str(exc))
        return "", 0


def _extract_text_from_plain(file_bytes: bytes) -> tuple[str, int]:
    """Extract text from plain text / CSV / HTML files.

    Returns:
        Tuple of (text, page_count_estimate).
    """
    try:
        text = file_bytes.decode("utf-8", errors="replace")
        page_count = max(1, len(text.split()) // 250)
        return text, page_count
    except Exception as exc:
        logger.warning("Plain text extraction failed", error=str(exc))
        return "", 0


def _extract_text_from_image(file_bytes: bytes) -> tuple[str, int]:
    """Extract text from an image file using Tesseract OCR.

    Returns:
        Tuple of (extracted_text, page_count=1).
    """
    text = _ocr_image_bytes(file_bytes)
    if text:
        return text, 1
    return "(Image document — OCR extraction returned no text.)", 1


def _extract_invoice_fields(text: str) -> dict[str, Any]:
    """Extract invoice-specific fields from text via regex."""
    fields: dict[str, Any] = {}
    inv_match = re.search(
        r"(?:invoice\s*(?:number|no|#|:)?\s*)([A-Z0-9][\w-]{2,20})",
        text,
        re.IGNORECASE,
    )
    if inv_match:
        fields["invoice_number"] = {"value": inv_match.group(1), "confidence": 0.93}

    amount_match = re.search(
        r"(?:total|amount\s*due|grand\s*total)[:\s]*\$?([\d,]+\.?\d*)",
        text,
        re.IGNORECASE,
    )
    if amount_match:
        fields["total_amount"] = {"value": f"${amount_match.group(1)}", "confidence": 0.91}

    date_match = re.search(
        r"(?:date|issued)[:\s]*([\d]{1,2}[/\-.][\d]{1,2}[/\-.][\d]{2,4}|\w+\s+\d{1,2},?\s*\d{4})",
        text,
        re.IGNORECASE,
    )
    if date_match:
        fields["invoice_date"] = {"value": date_match.group(1), "confidence": 0.89}

    vendor_match = re.search(r"(?:from|vendor|company|bill\s*from)[:\s]*(.+)", text, re.IGNORECASE)
    if vendor_match:
        fields["vendor_name"] = {
            "value": vendor_match.group(1).strip()[:80],
            "confidence": 0.85,
        }
    return fields


def _extract_resume_fields(text: str) -> dict[str, Any]:
    """Extract resume-specific fields from text via regex."""
    fields: dict[str, Any] = {}
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", text)
    if email_match:
        fields["email"] = {"value": email_match.group(0), "confidence": 0.95}

    phone_match = re.search(r"(\+?1?\s*[-.(]?\d{3}[-.)]\s*\d{3}[-.\s]\d{4})", text)
    if phone_match:
        fields["phone"] = {"value": phone_match.group(1).strip(), "confidence": 0.90}

    for line in text.split("\n"):
        name_candidate = line.strip()
        if (
            name_candidate
            and len(name_candidate) < 60
            and not re.search(r"@|http|www", name_candidate)
        ):
            fields["full_name"] = {"value": name_candidate, "confidence": 0.88}
            break

    skills_match = re.search(
        r"(?:skills|technologies|tech\s*stack)[:\s]*(.+?)(?:\n\n|\Z)",
        text,
        re.IGNORECASE | re.DOTALL,
    )
    if skills_match:
        fields["skills"] = {"value": skills_match.group(1).strip()[:200], "confidence": 0.82}
    return fields


def _extract_receipt_fields(text: str) -> dict[str, Any]:
    """Extract receipt-specific fields from text via regex."""
    fields: dict[str, Any] = {}
    total_match = re.search(r"(?:total|amount)[:\s]*\$?([\d,]+\.?\d*)", text, re.IGNORECASE)
    if total_match:
        fields["total_amount"] = {"value": f"${total_match.group(1)}", "confidence": 0.93}

    date_match = re.search(r"(\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4})", text)
    if date_match:
        fields["transaction_date"] = {"value": date_match.group(1), "confidence": 0.90}
    return fields


def _extract_generic_fields(text: str) -> dict[str, Any]:
    """Extract generic fields (email, date) from text."""
    fields: dict[str, Any] = {}
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", text)
    if email_match:
        fields["email_found"] = {"value": email_match.group(0), "confidence": 0.90}

    date_match = re.search(r"(\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}|\w+\s+\d{1,2},?\s*\d{4})", text)
    if date_match:
        fields["date_found"] = {"value": date_match.group(1), "confidence": 0.80}
    return fields


def _build_fields_from_text(text: str, filename: str, page_count: int) -> dict[str, Any]:
    """Build extraction fields from real document text and filename heuristics.

    Uses ContentAnalyzer for rich structure detection (sections, tables,
    diagrams, entities, summary) on top of the original basic metadata and
    domain-specific regex fields.
    """
    fields: dict[str, Any] = {}
    truncated = text[:_MAX_TEXT_LENGTH] if text else ""
    words = text.split() if text else []

    # Run content analysis
    analyzer = ContentAnalyzer()
    analyzed = analyzer.analyze(text, filename, page_count)

    # Always include basic metadata (backward compatible)
    first_line = ""
    for line in text.split("\n"):
        stripped = line.strip()
        if stripped:
            first_line = stripped[:120]
            break

    fields["document_title"] = {
        "value": first_line or filename,
        "confidence": 0.85 if first_line else 0.60,
    }
    fields["document_type"] = {
        "value": analyzed.document_type,
        "confidence": 0.80,
    }
    fields["document_text"] = {
        "value": truncated if truncated else "(no text extracted)",
        "confidence": 0.90 if truncated else 0.30,
    }
    fields["page_count"] = {"value": str(page_count), "confidence": 0.99}
    fields["word_count"] = {"value": str(len(words)), "confidence": 0.95}

    # Rich content fields
    fields["summary"] = {"value": analyzed.summary, "confidence": 0.85}

    if analyzed.sections:
        fields["sections"] = {
            "value": [
                {"title": s.title, "content": s.content, "level": s.level}
                for s in analyzed.sections
            ],
            "confidence": 0.82,
        }

    if analyzed.tables:
        fields["tables"] = {
            "value": [
                {"title": t.title, "headers": t.headers, "rows": t.rows} for t in analyzed.tables
            ],
            "confidence": 0.80,
        }

    if analyzed.diagrams:
        fields["diagrams"] = {
            "value": [
                {
                    "title": d.title,
                    "description": d.description,
                    "diagram_type": d.diagram_type,
                    "ascii_representation": d.ascii_representation,
                }
                for d in analyzed.diagrams
            ],
            "confidence": 0.70,
        }

    if analyzed.entities:
        fields["entities"] = {"value": analyzed.entities, "confidence": 0.85}

    # Domain-specific regex fields (preserve existing)
    lower = filename.lower()
    is_invoice = any(kw in lower for kw in ("invoice", "inv", "bill")) or re.search(
        r"invoice\s*(number|no|#|:)", text, re.IGNORECASE
    )

    if is_invoice:
        fields.update(_extract_invoice_fields(text))
    elif any(kw in lower for kw in ("resume", "cv", "curriculum")):
        fields.update(_extract_resume_fields(text))
    elif any(kw in lower for kw in ("receipt", "rcpt")):
        fields.update(_extract_receipt_fields(text))
    else:
        fields.update(_extract_generic_fields(text))

    return fields


def _jitter(fields: dict[str, Any], member_name: str) -> dict[str, Any]:
    """Add per-member variation so votes aren't identical."""
    jittered: dict[str, Any] = {}
    rng = random.Random(hash(member_name))
    for name, data in fields.items():
        delta = rng.uniform(-0.06, 0.04)
        conf = max(0.50, min(1.0, data["confidence"] + delta))
        jittered[name] = {"value": data["value"], "confidence": round(conf, 3)}
    return jittered


_TEXT_EXTENSIONS = (".txt", ".csv", ".html", ".htm", ".rtf")
_DOCX_EXTENSIONS = (".docx",)
_IMAGE_EXTENSIONS = (
    ".png",
    ".jpg",
    ".jpeg",
    ".tiff",
    ".tif",
    ".webp",
    ".gif",
    ".bmp",
    ".svg",
    ".heic",
    ".heif",
)


def _get_gguf_cache_dir() -> pathlib.Path:
    """Get the default GGUF model cache directory."""
    return pathlib.Path.home() / ".cache" / "agentic-doc-extraction" / "models" / "gguf"


def _is_non_blocking_member(member: CouncilMember) -> bool:
    """Check if a member uses a non-blocking backend (API/vLLM).

    GGUF (llama.cpp) and PaddleOCR hold the Python GIL during inference,
    blocking the asyncio event loop.  Only API and vLLM backends are safe
    for in-process use.
    """
    has_vllm = hasattr(member, "_client") and member._client is not None
    has_api = hasattr(member, "_api_client") and member._api_client is not None
    return has_vllm or has_api


def _should_use_mock() -> bool:
    """Determine whether to use mock council members based on council_mode setting.

    In "auto" mode, only use real members if they use non-blocking backends
    (API/vLLM).  GGUF/local inference holds the Python GIL and must run in
    separate processes (Celery workers), not the API event loop.
    """
    try:
        from src.config.settings import get_settings

        settings = get_settings()
        mode = settings.council.council_mode

        if mode == "mock":
            return True
        if mode in ("api", "gguf"):
            return False

        # mode == "auto": use real members only if non-blocking backends available
        return not _has_non_blocking_members()
    except Exception:
        return True


def _has_non_blocking_members() -> bool:
    """Check if any warmed-up members use non-blocking backends."""
    try:
        from src.council.members.factory import get_ready_members, is_warmup_done

        if not is_warmup_done():
            return False
        return any(_is_non_blocking_member(m) for m in get_ready_members())
    except Exception:
        return False


def _any_models_on_disk() -> bool:
    """Check filesystem for downloaded council models."""
    # PaddleOCR models
    paddle_dir = pathlib.Path.home() / ".paddleocr"
    if paddle_dir.exists() and any(paddle_dir.rglob("*.pdmodel")):
        logger.info("PaddleOCR models found on disk, using real council members")
        return True

    # GGUF models
    cache_dir = _get_gguf_cache_dir()
    if cache_dir.exists() and any(cache_dir.rglob("*.gguf")):
        logger.info("GGUF models found on disk, using real council members")
        return True

    return False


def _extract_document_content(filename: str, file_bytes: bytes) -> tuple[str, int]:
    """Extract text and page count from a document.

    Returns:
        Tuple of (extracted_text, page_count).
    """
    lower = filename.lower()
    if lower.endswith(".pdf"):
        return _extract_text_from_pdf(file_bytes)
    elif lower.endswith(_DOCX_EXTENSIONS):
        return _extract_text_from_docx(file_bytes)
    elif lower.endswith(_TEXT_EXTENSIONS):
        return _extract_text_from_plain(file_bytes)
    elif lower.endswith(_IMAGE_EXTENSIONS):
        return _extract_text_from_image(file_bytes)
    else:
        return _extract_text_from_plain(file_bytes)


def _build_members(filename: str, file_bytes: bytes) -> tuple[list[CouncilMember], str, int]:
    """Create council members with extraction data from real content.

    Respects the ``COUNCIL_MODE`` setting:
    - ``mock``  — always use mock members (default for local dev)
    - ``auto``  — try real members, fall back to mock
    - ``gguf``  — require GGUF backend
    - ``api``   — require API backend

    Returns:
        Tuple of (members, extracted_text, page_count).
    """

    text, page_count = _extract_document_content(filename, file_bytes)
    use_mock = _should_use_mock()

    if use_mock:
        base_fields = _build_fields_from_text(text, filename, page_count)
        members: list[CouncilMember] = []
        for name, version in [
            ("paddle_ocr", "paddleocr-2.8.0"),
            ("olmocr", "olmocr-2-7b"),
            ("qwen_vlm", "qwen2.5-vl-7b"),
            ("colpali", "colpali-v1.3"),
        ]:
            member = MockCouncilMember(name=name, model_version=version)
            member.set_mock_fields(_jitter(base_fields, name))
            members.append(member)
        return members, text, page_count

    # Use pre-initialized real members ONLY via non-blocking backends
    # (API or vLLM). GGUF/local inference holds the Python GIL and blocks
    # the event loop, so it must run in a separate process (Celery worker).
    from src.council.members.factory import get_ready_members, is_warmup_done

    if is_warmup_done():
        ready = get_ready_members()
        # Filter to members that use non-blocking backends (API, vLLM)
        non_blocking = [m for m in ready if _is_non_blocking_member(m)]
        if non_blocking:
            logger.info(
                "Using non-blocking real members",
                count=len(non_blocking),
                names=[m.name for m in non_blocking],
            )
            return non_blocking, text, page_count
        logger.info(
            "All ready members use local inference (GIL-blocking); "
            "using mock members for in-process pipeline. "
            "Use Celery workers for real model inference."
        )

    # Fallback to mock members (still extract real text from document)
    base_fields = _build_fields_from_text(text, filename, page_count)
    mock_members: list[CouncilMember] = []
    for name, version in [
        ("paddle_ocr", "paddleocr-2.8.0"),
        ("olmocr", "olmocr-2-7b"),
        ("qwen_vlm", "qwen2.5-vl-7b"),
        ("colpali", "colpali-v1.3"),
    ]:
        member = MockCouncilMember(name=name, model_version=version)
        member.set_mock_fields(_jitter(base_fields, name))
        mock_members.append(member)
    return mock_members, text, page_count


# ---------------------------------------------------------------------------
# Output gate evaluation + HITL routing
# ---------------------------------------------------------------------------


async def _route_through_output_gate(  # noqa: PLR0912
    document_id: str,
    result: dict,
) -> None:
    """Evaluate extraction via output gate and route to HITL if needed.

    This is a non-fatal operation — pipeline continues even if routing fails.
    """
    try:
        from src.services.guardrails.output_gate import get_output_gate
        from src.services.hitl.queue import (
            ReviewItem,
            ReviewPriority,
            get_hitl_queue,
        )

        gate = get_output_gate()
        queue = get_hitl_queue()

        consensus_score = result.get("consensus_score", 0.0) or 0.0
        overall_confidence = result.get("overall_confidence", consensus_score) or consensus_score
        unified = result.get("unified_extraction", {}) or {}
        requires_human = result.get("requires_human_review", False)

        # Build field confidences from unified extraction
        field_confidences: dict[str, float] = {}
        total_fields = 0
        missing_fields = 0
        for fname, fdata in unified.items():
            total_fields += 1
            if isinstance(fdata, dict) and "confidence" in fdata:
                field_confidences[fname] = float(fdata["confidence"])
            else:
                field_confidences[fname] = overall_confidence

        if total_fields == 0:
            total_fields = 1  # avoid division by zero in gate

        decision = gate.evaluate(
            overall_confidence=overall_confidence,
            field_confidences=field_confidences,
            consensus_score=consensus_score,
            total_fields=total_fields,
            missing_fields=missing_fields,
        )

        should_route = decision.action == "hitl_review"
        # Also route if council flagged human review but gate didn't catch it
        if requires_human and not should_route:
            should_route = True

        if should_route:
            # Build reason from failed gate checks
            failed_checks = [c for c in decision.gate_checks if not c.passed]
            if failed_checks:
                reason = "; ".join(c.message for c in failed_checks)
            elif requires_human:
                reason = "Council flagged for human review"
            else:
                reason = "Below quality thresholds"

            # Determine priority
            if overall_confidence < 0.4:
                priority = ReviewPriority.HIGH
            elif overall_confidence < 0.6:
                priority = ReviewPriority.MEDIUM
            else:
                priority = ReviewPriority.LOW

            # Flatten extracted fields for frontend display
            flat_fields: dict[str, str] = {}
            for fname, fdata in unified.items():
                if isinstance(fdata, dict) and "value" in fdata:
                    flat_fields[fname] = str(fdata["value"])
                elif isinstance(fdata, (str, int, float, bool)):
                    flat_fields[fname] = str(fdata)

            item = ReviewItem(
                document_id=document_id,
                confidence=overall_confidence,
                reason=reason,
                priority=priority,
                extracted_fields=flat_fields,
            )
            queue.add_item(item)
            logger.info(
                "Document routed to HITL queue",
                document_id=document_id,
                gate_action=decision.action,
                confidence=overall_confidence,
                priority=priority.name,
            )
        else:
            logger.info(
                "Document passed output gate",
                document_id=document_id,
                gate_action=decision.action,
                confidence=overall_confidence,
            )

    except Exception as exc:
        logger.warning(
            "Output gate routing failed (non-fatal)",
            document_id=document_id,
            error=str(exc),
        )


# ---------------------------------------------------------------------------
# RAG indexing
# ---------------------------------------------------------------------------


async def _index_for_rag(document_id: str, filename: str, file_bytes: bytes) -> None:
    """Index document text into the RAG vector store for retrieval.

    This is a best-effort operation — if RAG indexing fails, the document
    is still considered successfully processed.
    """
    try:
        from src.services.rag.service import get_rag_service

        rag = await get_rag_service()
        if not rag.is_available:
            logger.debug("RAG service not available, skipping indexing")
            return

        # Extract text (same logic as _build_members)
        lower = filename.lower()
        if lower.endswith(".pdf"):
            text, _ = _extract_text_from_pdf(file_bytes)
        elif lower.endswith(_DOCX_EXTENSIONS):
            text, _ = _extract_text_from_docx(file_bytes)
        elif lower.endswith(_TEXT_EXTENSIONS):
            text, _ = _extract_text_from_plain(file_bytes)
        elif lower.endswith(_IMAGE_EXTENSIONS):
            text, _ = _extract_text_from_image(file_bytes)
        else:
            text, _ = _extract_text_from_plain(file_bytes)

        if not text or len(text.strip()) < 10:
            logger.debug("Insufficient text for RAG indexing", document_id=document_id)
            return

        chunk_count = await rag.index_document(
            document_id=document_id,
            text=text,
            metadata={"filename": filename},
        )
        logger.info(
            "Document indexed for RAG",
            document_id=document_id,
            chunk_count=chunk_count,
        )
    except Exception as exc:
        # Non-fatal: document processing succeeds even if RAG indexing fails
        logger.warning(
            "RAG indexing failed (non-fatal)",
            document_id=document_id,
            error=str(exc),
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def process_document_background(
    document_id: str,
    storage_path: str,
    filename: str,
) -> None:
    """Process a document end-to-end in the background.

    Called via ``asyncio.create_task()`` from the upload endpoint.

    Pipeline stages with progress updates:
      1. PREPROCESSING (5%)  — initialise
      2. Download (10%)      — fetch file from storage
      3. Extract text (25%)  — OCR / text extraction
      4. Council start (35%) — create council session
      5. Member extraction (55%) — members vote
      6. Consensus (70%)     — deliberation complete
      7. Validation (85%)    — validate extracted fields
      8. Complete (100%)     — done
    """
    session_factory = get_session_factory()

    try:
        async with session_factory() as session:
            try:
                repo = DocumentRepository(session)
                doc_uuid = uuid.UUID(document_id)

                # Stage 1 — mark as preprocessing
                await repo.update_status(
                    doc_uuid,
                    ProcessingStatus.PREPROCESSING,
                    message="Initialising pipeline",
                    progress=5,
                )
                await session.commit()

                # Stage 2 — download file from storage
                try:
                    image_bytes = await _download_from_storage(storage_path)
                except Exception as exc:
                    await repo.update_status(
                        doc_uuid,
                        ProcessingStatus.FAILED,
                        message=f"Storage download failed: {exc}",
                        progress=5,
                    )
                    await session.commit()
                    return

                await repo.update_status(
                    doc_uuid,
                    ProcessingStatus.PREPROCESSING,
                    message="Document downloaded",
                    progress=10,
                )
                await session.commit()

                # Stage 3 — text extraction (run in thread to avoid blocking event loop)
                loop = asyncio.get_running_loop()
                try:
                    members, _extracted_text, page_count = await loop.run_in_executor(
                        None, _build_members, filename, image_bytes
                    )
                except Exception as exc:
                    await repo.update_status(
                        doc_uuid,
                        ProcessingStatus.FAILED,
                        message=f"Text extraction failed: {exc}",
                        progress=10,
                    )
                    await session.commit()
                    return

                await repo.update_status(
                    doc_uuid,
                    ProcessingStatus.EXTRACTING,
                    message="Text extracted, preparing council",
                    progress=25,
                )
                doc = await repo.get_by_id(doc_uuid)
                if doc:
                    doc.page_count = page_count
                await session.commit()

                # Stage 4-6 — council session (start → member votes → consensus)
                await repo.update_status(
                    doc_uuid,
                    ProcessingStatus.EXTRACTING,
                    message="Council session started",
                    progress=35,
                )
                await session.commit()

                # Render page images for council extraction (in thread — CPU-bound)
                if filename.lower().endswith(".pdf"):
                    page_images = await loop.run_in_executor(None, render_pdf_pages, image_bytes)
                    if not page_images:
                        page_images = [image_bytes]
                else:
                    page_images = [image_bytes]

                try:
                    result = await run_council_session_pipeline(
                        document_id=document_id,
                        image_data=page_images,
                        members=members,
                        session=session,
                        document_type=None,
                        critical_fields=None,
                        consensus_threshold=0.85,
                    )
                except Exception as exc:
                    await repo.update_status(
                        doc_uuid,
                        ProcessingStatus.FAILED,
                        message=f"Council deliberation failed: {exc}",
                        progress=35,
                    )
                    await session.commit()
                    return

                logger.info(
                    "Council deliberation completed",
                    document_id=document_id,
                    consensus_score=result.get("consensus_score"),
                    extraction_id=result.get("extraction_id"),
                )

                # Stage 7 — Output gate evaluation + HITL routing
                await repo.update_status(
                    doc_uuid,
                    ProcessingStatus.EXTRACTING,
                    message="Evaluating output quality gates",
                    progress=80,
                )
                await session.commit()

                await _route_through_output_gate(document_id, result)

                # Stage 8 — Index document for RAG retrieval
                await repo.update_status(
                    doc_uuid,
                    ProcessingStatus.INDEXING,
                    message="Indexing document for search",
                    progress=90,
                )
                await session.commit()

                await _index_for_rag(document_id, filename, image_bytes)

                # Stage 8 — mark as completed
                await repo.update_status(
                    doc_uuid,
                    ProcessingStatus.COMPLETED,
                    message="Processing complete",
                    progress=100,
                )
                await session.commit()

                logger.info(
                    "Document processing completed",
                    document_id=document_id,
                )

            except Exception:
                await session.rollback()
                raise

    except Exception as exc:
        logger.error(
            "Background document processing failed",
            document_id=document_id,
            error=str(exc),
        )
        # Mark document as FAILED in a fresh session
        try:
            async with session_factory() as err_session:
                repo = DocumentRepository(err_session)
                doc = await repo.get_by_id(uuid.UUID(document_id))
                if doc:
                    doc.fail(str(exc))
                    await err_session.commit()
        except Exception as inner:
            logger.error(
                "Failed to mark document as failed",
                document_id=document_id,
                error=str(inner),
            )


async def _download_from_storage(storage_path: str) -> bytes:
    """Download a file from local storage, returning raw bytes."""
    storage = LocalStorageService()
    result = await storage.download(storage_path)
    return result.content
