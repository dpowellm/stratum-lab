"""Content Analyzer — rule-based rich content extraction from document text.

Detects sections/headings, tables, diagrams, entities, and document type
using regex heuristics.  No external dependencies beyond the stdlib.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, ClassVar

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class ContentSection:
    title: str
    content: str
    level: int  # 1=heading, 2=subheading, 3=sub-sub
    start_line: int = 0


@dataclass
class ContentTable:
    headers: list[str]
    rows: list[list[str]]
    title: str | None = None
    detection_method: str = "pipe"  # "pipe", "tab", "aligned", "csv"


@dataclass
class ContentDiagram:
    title: str
    description: str
    diagram_type: str  # "architecture", "flow", "block", "sequence", "generic"
    ascii_representation: str = ""


@dataclass
class AnalyzedContent:
    sections: list[ContentSection] = field(default_factory=list)
    tables: list[ContentTable] = field(default_factory=list)
    diagrams: list[ContentDiagram] = field(default_factory=list)
    summary: str = ""
    document_type: str = "generic"
    entities: dict[str, list[str]] = field(default_factory=dict)
    key_stats: dict[str, Any] = field(default_factory=dict)
    # Content type flags for capability-driven routing
    has_tables: bool = False
    has_charts: bool = False
    has_diagrams: bool = False
    has_forms: bool = False
    has_handwriting: bool = False


# ---------------------------------------------------------------------------
# ContentAnalyzer
# ---------------------------------------------------------------------------


class ContentAnalyzer:
    """Analyse raw document text and return structured AnalyzedContent."""

    def analyze(
        self,
        text: str,
        filename: str = "",
        page_count: int = 1,
    ) -> AnalyzedContent:
        if not text or not text.strip():
            return AnalyzedContent(
                summary="Empty document.",
                document_type="generic",
                key_stats={
                    "word_count": 0,
                    "page_count": page_count,
                    "section_count": 0,
                    "table_count": 0,
                    "diagram_count": 0,
                },
            )

        lines = text.split("\n")
        result = AnalyzedContent()

        result.sections = self._detect_sections(lines)
        result.tables = self._detect_tables(lines)
        result.diagrams = self._detect_diagrams(lines)
        result.entities = self._extract_entities(text)
        result.document_type = self._detect_document_type(text, filename)

        word_count = len(text.split())
        result.key_stats = {
            "word_count": word_count,
            "page_count": page_count,
            "section_count": len(result.sections),
            "table_count": len(result.tables),
            "diagram_count": len(result.diagrams),
        }

        # Set content type flags for capability-driven routing
        result.has_tables = len(result.tables) > 0
        result.has_diagrams = len(result.diagrams) > 0
        result.has_charts = self._detect_charts(text)
        result.has_forms = self._detect_forms(text)

        result.summary = self._generate_summary(text, filename, result, page_count)
        return result

    def _detect_charts(self, text: str) -> bool:
        """Detect if text mentions charts or graphs."""
        chart_keywords = [
            "chart",
            "graph",
            "plot",
            "histogram",
            "pie chart",
            "bar chart",
            "line graph",
            "scatter",
            "trend",
        ]
        text_lower = text.lower()
        return any(kw in text_lower for kw in chart_keywords)

    def _detect_forms(self, text: str) -> bool:
        """Detect if document has form-like content."""
        form_keywords = [
            "name:",
            "date:",
            "address:",
            "signature:",
            "phone:",
            "email:",
            "□",
            "☐",
            "☑",
            "checkbox",
            "fill in",
        ]
        text_lower = text.lower()
        return sum(1 for kw in form_keywords if kw in text_lower) >= 2

    # ------------------------------------------------------------------
    # Section detection
    # ------------------------------------------------------------------

    def _detect_sections(self, lines: list[str]) -> list[ContentSection]:
        """Detect headings and split text into sections."""
        headings: list[tuple[int, str, int]] = []  # (line_idx, title, level)

        i = 0
        while i < len(lines):
            line = lines[i]
            stripped = line.strip()

            # 1. Markdown headings: # Title
            md_match = re.match(r"^(#{1,6})\s+(.+)$", stripped)
            if md_match:
                level = len(md_match.group(1))
                title = md_match.group(2).strip()
                headings.append((i, title, level))
                i += 1
                continue

            # 2. Underlined headings: Title followed by === or ---
            if stripped and i + 1 < len(lines) and not stripped.startswith("#"):
                next_stripped = lines[i + 1].strip()
                if next_stripped and len(next_stripped) >= 3:
                    if re.match(r"^=+$", next_stripped):
                        headings.append((i, stripped, 1))
                        i += 2
                        continue
                    if re.match(r"^-+$", next_stripped):
                        headings.append((i, stripped, 2))
                        i += 2
                        continue

            # 3. Numbered headings: 1. Title, 1.1. Title
            num_match = re.match(r"^(\d+(?:\.\d+)*)\.\s+(.+)$", stripped)
            if num_match:
                dots = num_match.group(1).count(".")
                level = dots + 1
                title = stripped
                headings.append((i, title, level))
                i += 1
                continue

            # 4. ALL CAPS lines (< 80 chars, not a separator)
            if (
                stripped
                and stripped == stripped.upper()
                and len(stripped) < 80
                and len(stripped) >= 3
                and re.search(r"[A-Z]{2,}", stripped)
                and not re.match(r"^[-=_*#|+]+$", stripped)
            ):
                headings.append((i, stripped, 1))
                i += 1
                continue

            i += 1

        # Build sections from headings
        if not headings:
            # Fallback: entire text as single section
            first_line = ""
            for ln in lines:
                if ln.strip():
                    first_line = ln.strip()[:120]
                    break
            return [
                ContentSection(
                    title=first_line or "Document",
                    content="\n".join(lines).strip(),
                    level=1,
                    start_line=0,
                )
            ]

        sections: list[ContentSection] = []
        for idx, (line_idx, title, level) in enumerate(headings):
            # Content runs from the line after this heading until the next heading
            end = headings[idx + 1][0] if idx + 1 < len(headings) else len(lines)
            content_lines = lines[line_idx + 1 : end]
            # Strip underline artifacts
            content_lines = [ln for ln in content_lines if not re.match(r"^[=\-]{3,}$", ln.strip())]
            content = "\n".join(content_lines).strip()
            sections.append(
                ContentSection(
                    title=title,
                    content=content,
                    level=level,
                    start_line=line_idx,
                )
            )
        return sections

    # ------------------------------------------------------------------
    # Table detection
    # ------------------------------------------------------------------

    def _detect_tables(self, lines: list[str]) -> list[ContentTable]:
        tables: list[ContentTable] = []

        # Strategy 1: pipe-delimited tables
        tables.extend(self._detect_pipe_tables(lines))
        # Strategy 2: tab-separated tables
        tables.extend(self._detect_tab_tables(lines))
        # Strategy 3: CSV-like tables
        tables.extend(self._detect_csv_tables(lines))

        return tables

    def _detect_pipe_tables(self, lines: list[str]) -> list[ContentTable]:
        tables: list[ContentTable] = []
        i = 0
        while i < len(lines):
            stripped = lines[i].strip()
            if "|" in stripped and stripped.count("|") >= 2:
                # Possible pipe table start
                table_lines: list[str] = []
                start = i
                while i < len(lines) and "|" in lines[i]:
                    table_lines.append(lines[i].strip())
                    i += 1
                table = self._parse_pipe_table(table_lines, lines, start)
                if table:
                    tables.append(table)
            else:
                i += 1
        return tables

    def _parse_pipe_table(
        self, table_lines: list[str], all_lines: list[str], start_idx: int
    ) -> ContentTable | None:
        if len(table_lines) < 2:
            return None

        # Filter out separator rows (|---|---|)
        data_lines = []
        for ln in table_lines:
            cleaned = ln.strip().strip("|").strip()
            if re.match(r"^[\s\-:|]+$", cleaned):
                continue
            data_lines.append(ln)

        if len(data_lines) < 2:
            return None

        def split_pipe(line: str) -> list[str]:
            parts = line.strip().strip("|").split("|")
            return [p.strip() for p in parts]

        headers = split_pipe(data_lines[0])
        if len(headers) < 2:
            return None

        rows = [split_pipe(ln) for ln in data_lines[1:]]
        # Filter rows that don't match header column count (±1)
        rows = [r for r in rows if abs(len(r) - len(headers)) <= 1]
        # Pad/trim rows to header length
        rows = [r[: len(headers)] + [""] * max(0, len(headers) - len(r)) for r in rows]

        if len(rows) < 1:
            return None

        title = self._find_table_title(all_lines, start_idx)
        return ContentTable(headers=headers, rows=rows, title=title, detection_method="pipe")

    def _detect_tab_tables(self, lines: list[str]) -> list[ContentTable]:
        tables: list[ContentTable] = []
        i = 0
        while i < len(lines):
            if "\t" in lines[i] and lines[i].count("\t") >= 1:
                tab_count = lines[i].count("\t")
                table_lines = [lines[i]]
                j = i + 1
                while j < len(lines) and "\t" in lines[j]:
                    if abs(lines[j].count("\t") - tab_count) <= 1:
                        table_lines.append(lines[j])
                        j += 1
                    else:
                        break
                if len(table_lines) >= 3:  # header + at least 2 data rows
                    headers = [c.strip() for c in table_lines[0].split("\t")]
                    if len(headers) >= 2:
                        rows = [[c.strip() for c in ln.split("\t")] for ln in table_lines[1:]]
                        rows = [
                            r[: len(headers)] + [""] * max(0, len(headers) - len(r)) for r in rows
                        ]
                        title = self._find_table_title(lines, i)
                        tables.append(
                            ContentTable(
                                headers=headers,
                                rows=rows,
                                title=title,
                                detection_method="tab",
                            )
                        )
                i = j if len(table_lines) >= 3 else i + 1
            else:
                i += 1
        return tables

    def _detect_csv_tables(self, lines: list[str]) -> list[ContentTable]:
        tables: list[ContentTable] = []
        i = 0
        while i < len(lines):
            stripped = lines[i].strip()
            if "," in stripped and stripped.count(",") >= 1:
                comma_count = stripped.count(",")
                # Check for consecutive lines with same comma count
                table_lines = [stripped]
                j = i + 1
                while j < len(lines):
                    next_stripped = lines[j].strip()
                    if not next_stripped:
                        break
                    if abs(next_stripped.count(",") - comma_count) <= 0:
                        table_lines.append(next_stripped)
                        j += 1
                    else:
                        break

                if len(table_lines) >= 3 and comma_count >= 1:
                    # Verify it's not just prose with commas
                    avg_words = sum(len(ln.split()) for ln in table_lines) / len(table_lines)
                    # CSV lines tend to be shorter and have fewer words per cell
                    if avg_words < 15:
                        headers = [c.strip() for c in table_lines[0].split(",")]
                        if len(headers) >= 2:
                            rows = [[c.strip() for c in ln.split(",")] for ln in table_lines[1:]]
                            rows = [
                                r[: len(headers)] + [""] * max(0, len(headers) - len(r))
                                for r in rows
                            ]
                            title = self._find_table_title(lines, i)
                            tables.append(
                                ContentTable(
                                    headers=headers,
                                    rows=rows,
                                    title=title,
                                    detection_method="csv",
                                )
                            )
                i = j if len(table_lines) >= 3 else i + 1
            else:
                i += 1
        return tables

    def _find_table_title(self, lines: list[str], table_start: int) -> str | None:
        """Look backward from table_start for a label line."""
        for k in range(table_start - 1, max(table_start - 4, -1), -1):
            if k < 0:
                break
            candidate = lines[k].strip()
            if candidate and len(candidate) < 80 and not re.match(r"^[-=|]", candidate):
                return candidate
        return None

    # ------------------------------------------------------------------
    # Diagram detection
    # ------------------------------------------------------------------

    _DIAGRAM_KEYWORDS: ClassVar[re.Pattern[str]] = re.compile(
        r"\b(figure|diagram|architecture|flow\s*chart|block\s*diagram|"
        r"schema|topology|sequence\s*diagram|data\s*flow|system\s*diagram)\b",
        re.IGNORECASE,
    )

    _TYPE_MAP: ClassVar[list[tuple[re.Pattern[str], str]]] = [
        (re.compile(r"architect|system|component", re.I), "architecture"),
        (re.compile(r"flow|process|workflow|pipeline|data\s*flow", re.I), "flow"),
        (re.compile(r"sequence|timeline", re.I), "sequence"),
    ]

    def _detect_diagrams(self, lines: list[str]) -> list[ContentDiagram]:
        diagrams: list[ContentDiagram] = []
        seen_titles: set[str] = set()

        for i, line in enumerate(lines):
            if self._DIAGRAM_KEYWORDS.search(line):
                title = line.strip().rstrip(":")
                if title in seen_titles:
                    continue
                seen_titles.add(title)

                diagram_type = "generic"
                for pattern, dtype in self._TYPE_MAP:
                    if pattern.search(line):
                        diagram_type = dtype
                        break

                # Gather context (5 lines before/after)
                context_start = max(0, i - 5)
                context_end = min(len(lines), i + 6)
                context = "\n".join(lines[context_start:context_end])

                components = self._extract_components(context)
                ascii_repr = self._build_ascii_diagram(components)
                description = self._build_diagram_description(title, diagram_type, components)

                diagrams.append(
                    ContentDiagram(
                        title=title,
                        description=description,
                        diagram_type=diagram_type,
                        ascii_representation=ascii_repr,
                    )
                )
        return diagrams

    def _extract_components(self, context: str) -> list[str]:
        """Extract component names from context around a diagram reference."""
        components: list[str] = []
        # Look for bullet-point items
        for match in re.finditer(r"[-•*]\s+([A-Z][A-Za-z0-9 ]+)", context):
            name = match.group(1).strip()
            if len(name) < 40:
                components.append(name)
        # Also look for capitalised noun phrases not already captured
        for match in re.finditer(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b", context):
            name = match.group(1).strip()
            if name not in components and len(name) < 40:
                components.append(name)
        # Deduplicate while preserving order
        seen: set[str] = set()
        unique: list[str] = []
        for c in components:
            if c not in seen:
                seen.add(c)
                unique.append(c)
        return unique[:9]  # Max 9 components (3x3 grid)

    def _build_ascii_diagram(self, components: list[str]) -> str:
        if not components:
            return ""
        max_width = max(len(c) for c in components)
        box_w = max_width + 4
        per_row = min(3, len(components))

        rows_of_components: list[list[str]] = []
        for idx in range(0, len(components), per_row):
            rows_of_components.append(components[idx : idx + per_row])

        output_lines: list[str] = []
        for row_idx, row in enumerate(rows_of_components):
            top = "     ".join(f"+{'-' * box_w}+" for _ in row)
            mid = "     ".join(f"| {c.center(box_w - 2)} |" for c in row)
            bot = "     ".join(f"+{'-' * box_w}+" for _ in row)
            output_lines.extend([top, mid, bot])

            # Add arrows between rows
            if row_idx < len(rows_of_components) - 1:
                # Horizontal arrow from first box
                arrow_pad = (box_w + 2) // 2
                output_lines.append(" " * arrow_pad + "|")
                output_lines.append(" " * arrow_pad + "v")

        return "\n".join(output_lines)

    def _build_diagram_description(
        self, title: str, diagram_type: str, components: list[str]
    ) -> str:
        desc = f"{title} ({diagram_type} diagram)"
        if components:
            desc += f" with components: {', '.join(components[:6])}"
            if len(components) > 6:
                desc += f" and {len(components) - 6} more"
        return desc

    # ------------------------------------------------------------------
    # Entity extraction
    # ------------------------------------------------------------------

    _ENTITY_PATTERNS: ClassVar[dict[str, re.Pattern[str]]] = {
        "dates": re.compile(r"(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}|\w+\s+\d{1,2},?\s*\d{4})"),
        "amounts": re.compile(r"(\$[\d,]+\.?\d*|[\d,]+\.?\d*\s*(?:USD|EUR|GBP))", re.IGNORECASE),
        "emails": re.compile(r"([\w.+\-]+@[\w\-]+\.[\w.]+)"),
        "phones": re.compile(r"(\+?1?\s*[-.(]?\d{3}[-.)]\s*\d{3}[-.\s]\d{4})"),
        "urls": re.compile(r"(https?://[^\s)]+)"),
        "percentages": re.compile(r"(\d+\.?\d*\s*%)"),
    }

    def _extract_entities(self, text: str) -> dict[str, list[str]]:
        entities: dict[str, list[str]] = {}
        for name, pattern in self._ENTITY_PATTERNS.items():
            matches = pattern.findall(text)
            # Deduplicate while preserving order
            seen: set[str] = set()
            unique: list[str] = []
            for m in matches:
                m_stripped = m.strip()
                if m_stripped and m_stripped not in seen:
                    seen.add(m_stripped)
                    unique.append(m_stripped)
            if unique:
                entities[name] = unique
        return entities

    # ------------------------------------------------------------------
    # Document type detection
    # ------------------------------------------------------------------

    _DOC_TYPE_RULES: ClassVar[list[tuple[str, list[str]]]] = [
        ("invoice", ["invoice", "bill to", "amount due", "inv-", "inv #"]),
        ("resume", ["resume", "curriculum vitae", "work experience", "skills:"]),
        ("receipt", ["receipt", "payment received", "transaction"]),
        ("contract", ["contract", "agreement", "hereby", "whereas"]),
        ("report", ["report", "executive summary", "findings", "quarterly"]),
        ("manual", ["manual", "instructions", "step 1", "user guide"]),
        ("memo", ["memorandum", "memo"]),
    ]

    def _detect_document_type(self, text: str, filename: str) -> str:
        lower_fn = filename.lower()
        lower_text = text[:3000].lower()

        # Check filename first
        for doc_type, keywords in self._DOC_TYPE_RULES:
            for kw in keywords:
                if kw in lower_fn:
                    return doc_type

        # Check text content
        for doc_type, keywords in self._DOC_TYPE_RULES:
            matches = sum(1 for kw in keywords if kw in lower_text)
            if matches >= 1:
                return doc_type

        # Special memo check: needs both to/from
        if "to:" in lower_text and "from:" in lower_text:
            return "memo"

        return "generic"

    # ------------------------------------------------------------------
    # Summary generation
    # ------------------------------------------------------------------

    def _generate_summary(
        self,
        text: str,
        _filename: str,
        result: AnalyzedContent,
        page_count: int,
    ) -> str:
        word_count = len(text.split())
        parts: list[str] = []

        doc_type = result.document_type
        parts.append(
            f"This {doc_type} document contains {word_count:,} words across {page_count} page(s)."
        )

        if result.sections:
            section_titles = [s.title for s in result.sections[:5]]
            joined = ", ".join(section_titles)
            parts.append(f"It is organized into {len(result.sections)} section(s): {joined}.")

        if result.tables:
            parts.append(f"The document includes {len(result.tables)} table(s).")

        if result.diagrams:
            parts.append(f"It references {len(result.diagrams)} diagram(s)/figure(s).")

        # Key entities summary
        entity_summary_parts: list[str] = []
        for name, values in result.entities.items():
            entity_summary_parts.append(f"{len(values)} {name}")
        if entity_summary_parts:
            parts.append(f"Key information includes {', '.join(entity_summary_parts)}.")

        # Preview from first section content
        if result.sections and result.sections[0].content:
            preview = result.sections[0].content[:200].strip()
            if preview:
                parts.append(f'Preview: "{preview}"')

        return " ".join(parts)
