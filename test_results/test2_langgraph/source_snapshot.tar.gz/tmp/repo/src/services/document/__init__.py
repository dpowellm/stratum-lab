"""Document service package."""

from src.services.document.repository import DocumentRepository

__all__ = ["DocumentRepository"]
