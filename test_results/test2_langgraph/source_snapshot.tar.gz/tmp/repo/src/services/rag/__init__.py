"""RAG (Retrieval Augmented Generation) services.

This module provides:
- Vector database integration (Qdrant)
- Embedding service (BGE-M3)
- Document chunking strategies
- Retrieval and indexing services
- ColPali multi-modal retrieval
- Hybrid search (dense + sparse)
- BGE reranking
- Conversational Q&A
"""

from src.services.rag.chunking import (
    Chunk,
    ChunkingResult,
    ChunkingStrategy,
    SemanticChunker,
)

# Advanced RAG
from src.services.rag.colpali import (
    ColPaliRetriever,
    ContentType,
    MultiModalContent,
    MultiModalDocument,
    MultiModalQuery,
)
from src.services.rag.conversational import (
    ConversationalQA,
    ConversationContext,
    QAResponse,
)
from src.services.rag.embedding import (
    BGEEmbeddingService,
    EmbeddingResult,
    EmbeddingServiceInterface,
)
from src.services.rag.hybrid import (
    DenseRetriever,
    HybridResult,
    HybridSearchService,
    SearchDocument,
    SearchMethod,
    SparseRetriever,
)
from src.services.rag.memory_store import InMemoryVectorStore
from src.services.rag.reranker import (
    BGEReranker,
    RerankedResult,
    RerankerConfig,
)
from src.services.rag.retrieval import (
    RankedChunk,
    RetrievalResult,
    RetrievalService,
)
from src.services.rag.vector_store import (
    QdrantVectorStore,
    SearchResult,
    VectorRecord,
    VectorStoreInterface,
)

__all__ = [
    "BGEEmbeddingService",
    # Reranker
    "BGEReranker",
    "Chunk",
    "ChunkingResult",
    # Chunking
    "ChunkingStrategy",
    # ColPali
    "ColPaliRetriever",
    "ContentType",
    "ConversationContext",
    # Conversational Q&A
    "ConversationalQA",
    "DenseRetriever",
    "EmbeddingResult",
    # Embedding
    "EmbeddingServiceInterface",
    "HybridResult",
    # Hybrid Search
    "HybridSearchService",
    "InMemoryVectorStore",
    "MultiModalContent",
    "MultiModalDocument",
    "MultiModalQuery",
    "QAResponse",
    "QdrantVectorStore",
    "RankedChunk",
    "RerankedResult",
    "RerankerConfig",
    "RetrievalResult",
    # Retrieval
    "RetrievalService",
    "SearchDocument",
    "SearchMethod",
    "SearchResult",
    "SemanticChunker",
    "SparseRetriever",
    "VectorRecord",
    # Vector Store
    "VectorStoreInterface",
]
