"""In-memory vector store for testing.

Provides a VectorStoreInterface implementation backed by
in-memory dictionaries, suitable for unit tests without Qdrant.
"""

import math
from typing import Any

from src.services.rag.vector_store import (
    SearchResult,
    VectorRecord,
    VectorStoreInterface,
)


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b, strict=False))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def _euclidean_distance(a: list[float], b: list[float]) -> float:
    """Compute euclidean distance between two vectors."""
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b, strict=False)))


def _dot_product(a: list[float], b: list[float]) -> float:
    """Compute dot product between two vectors."""
    return sum(x * y for x, y in zip(a, b, strict=False))


class InMemoryVectorStore(VectorStoreInterface):
    """In-memory vector store for testing.

    Stores vectors in plain Python dicts and computes similarity
    using brute-force search.  Not suitable for production, but
    perfect for unit tests that need a working VectorStoreInterface
    without running Qdrant.
    """

    def __init__(self) -> None:
        # collection_name -> { record_id -> VectorRecord }
        self._collections: dict[str, dict[str, VectorRecord]] = {}
        self._collection_config: dict[str, dict[str, Any]] = {}

    async def create_collection(
        self,
        name: str,
        dimension: int,
        distance: str = "cosine",
    ) -> bool:
        if name in self._collections:
            return False
        self._collections[name] = {}
        self._collection_config[name] = {
            "dimension": dimension,
            "distance": distance,
        }
        return True

    async def delete_collection(self, name: str) -> bool:
        if name not in self._collections:
            return False
        del self._collections[name]
        self._collection_config.pop(name, None)
        return True

    async def collection_exists(self, name: str) -> bool:
        return name in self._collections

    async def upsert(
        self,
        collection: str,
        records: list[VectorRecord],
    ) -> int:
        store = self._collections.get(collection)
        if store is None:
            raise ValueError(f"Collection '{collection}' does not exist")
        for record in records:
            store[record.id] = record
        return len(records)

    async def search(
        self,
        collection: str,
        query_vector: list[float],
        limit: int = 10,
        filter: dict[str, Any] | None = None,
        include_vectors: bool = False,
    ) -> list[SearchResult]:
        store = self._collections.get(collection)
        if store is None:
            return []

        distance = self._collection_config.get(collection, {}).get("distance", "cosine")

        scored: list[tuple[float, VectorRecord]] = []
        for record in store.values():
            if filter and not self._matches_filter(record, filter):
                continue

            if distance == "cosine":
                score = _cosine_similarity(query_vector, record.vector)
            elif distance == "euclidean":
                # Lower distance = more similar; invert for score
                dist = _euclidean_distance(query_vector, record.vector)
                score = 1.0 / (1.0 + dist)
            elif distance == "dot":
                score = _dot_product(query_vector, record.vector)
            else:
                score = _cosine_similarity(query_vector, record.vector)

            scored.append((score, record))

        # Sort descending by score
        scored.sort(key=lambda x: x[0], reverse=True)

        results = []
        for score, record in scored[:limit]:
            results.append(
                SearchResult(
                    id=record.id,
                    score=score,
                    payload=record.payload,
                    vector=record.vector if include_vectors else None,
                )
            )

        return results

    async def delete(
        self,
        collection: str,
        ids: list[str],
    ) -> int:
        store = self._collections.get(collection)
        if store is None:
            return 0
        deleted = 0
        for id_ in ids:
            if id_ in store:
                del store[id_]
                deleted += 1
        return deleted

    async def delete_by_filter(
        self,
        collection: str,
        filter: dict[str, Any],
    ) -> int:
        store = self._collections.get(collection)
        if store is None:
            return 0
        to_delete = [rid for rid, record in store.items() if self._matches_filter(record, filter)]
        for rid in to_delete:
            del store[rid]
        return len(to_delete)

    async def get(
        self,
        collection: str,
        ids: list[str],
        include_vectors: bool = False,
    ) -> list[VectorRecord]:
        store = self._collections.get(collection)
        if store is None:
            return []
        results = []
        for id_ in ids:
            record = store.get(id_)
            if record is not None:
                if include_vectors:
                    results.append(record)
                else:
                    results.append(
                        VectorRecord(
                            id=record.id,
                            vector=[],
                            payload=record.payload,
                        )
                    )
        return results

    async def count(
        self,
        collection: str,
        filter: dict[str, Any] | None = None,
    ) -> int:
        store = self._collections.get(collection)
        if store is None:
            return 0
        if filter is None:
            return len(store)
        return sum(1 for record in store.values() if self._matches_filter(record, filter))

    @staticmethod
    def _matches_filter(record: VectorRecord, filter: dict[str, Any]) -> bool:
        """Check if a record matches all filter conditions."""
        for key, value in filter.items():
            payload_value = record.payload.get(key)
            if isinstance(value, list):
                if payload_value not in value:
                    return False
            elif payload_value != value:
                return False
        return True
