"""Unified RAG service for document indexing and retrieval.

Integrates chunking, embedding, and vector store services into
a single service that can be used by the Q&A endpoint. Provides
graceful degradation when the vector store is unavailable.
"""

import asyncio
import re
from dataclasses import dataclass, field
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Text search (always-available, no external dependencies)
# ---------------------------------------------------------------------------


@dataclass
class TextMatch:
    """A match found via text search."""

    text: str
    score: float
    document_id: str
    field_name: str | None = None
    page: int | None = None
    context_before: str = ""
    context_after: str = ""


def _tokenize(text: str) -> list[str]:
    """Tokenize text into lowercase words, filtering stopwords and short tokens."""
    stopwords = frozenset(
        {
            "a",
            "an",
            "the",
            "is",
            "are",
            "was",
            "were",
            "be",
            "been",
            "being",
            "have",
            "has",
            "had",
            "do",
            "does",
            "did",
            "will",
            "would",
            "could",
            "should",
            "may",
            "might",
            "shall",
            "can",
            "need",
            "dare",
            "ought",
            "used",
            "to",
            "of",
            "in",
            "for",
            "on",
            "with",
            "at",
            "by",
            "from",
            "as",
            "into",
            "through",
            "during",
            "before",
            "after",
            "above",
            "below",
            "between",
            "out",
            "off",
            "over",
            "under",
            "again",
            "further",
            "then",
            "once",
            "here",
            "there",
            "when",
            "where",
            "why",
            "how",
            "all",
            "each",
            "every",
            "both",
            "few",
            "more",
            "most",
            "other",
            "some",
            "such",
            "no",
            "not",
            "only",
            "own",
            "same",
            "so",
            "than",
            "too",
            "very",
            "just",
            "because",
            "but",
            "and",
            "or",
            "if",
            "while",
            "about",
            "what",
            "which",
            "who",
            "whom",
            "this",
            "that",
            "these",
            "those",
            "it",
            "its",
        }
    )
    words = re.findall(r"[a-z0-9]+", text.lower())
    return [w for w in words if len(w) > 1 and w not in stopwords]


_GENERAL_QUESTION_PATTERNS = re.compile(
    r"(?i)^("
    r"what\s+is\s+this\s+(about|document|file)|"
    r"what\s+does\s+this\s+(say|contain|describe|cover)|"
    r"tell\s+me\s+about\s+this|"
    r"summarize|summary|"
    r"overview|"
    r"describe\s+this|"
    r"what\s+is\s+in\s+this|"
    r"what\s+are\s+the\s+(main|key)\s+(points|topics|themes)|"
    r"what\s+is\s+this\b"
    r")",
)


def _is_general_question(query: str) -> bool:
    """Detect general/overview questions that won't match specific tokens.

    Returns True for queries like "what is this about", "summarize",
    "overview", etc., or when tokenization yields zero tokens but the
    query has 3+ words (all-stopword heuristic).
    """
    stripped = query.strip().rstrip("?").strip()
    if _GENERAL_QUESTION_PATTERNS.search(stripped):
        return True
    # All-stopword heuristic: many words but none survive tokenization
    word_count = len(re.findall(r"[a-zA-Z]+", stripped))
    return bool(word_count >= 3 and not _tokenize(stripped))


def _compute_tf_idf_score(query_tokens: list[str], text: str) -> float:
    """Compute a TF-IDF-like relevance score between query tokens and text.

    Uses term frequency in the text weighted by inverse document frequency
    approximation (rarer query terms score higher).
    """
    if not query_tokens or not text:
        return 0.0

    text_lower = text.lower()
    text_tokens = _tokenize(text)
    if not text_tokens:
        return 0.0

    text_token_set = set(text_tokens)
    text_len = len(text_tokens)

    score = 0.0
    matched_tokens = 0

    for qt in query_tokens:
        if qt in text_token_set:
            # Term frequency: count occurrences in text
            tf = text_tokens.count(qt) / text_len
            # IDF approximation: shorter tokens are more common, weight longer ones more
            idf = 1.0 + len(qt) * 0.1
            score += tf * idf
            matched_tokens += 1

        # Bonus for substring matches (handles partial matches)
        elif qt in text_lower:
            score += 0.3 * (1.0 + len(qt) * 0.05)
            matched_tokens += 0.5

    # Coverage bonus: what fraction of query terms matched
    if query_tokens:
        coverage = matched_tokens / len(query_tokens)
        score *= 0.5 + 0.5 * coverage

    # Phrase match bonus: check if query appears as substring
    query_str = " ".join(query_tokens)
    if query_str in text_lower:
        score *= 1.5

    return min(score, 1.0)


def _extract_context_window(text: str, query_tokens: list[str], window_chars: int = 500) -> str:
    """Extract a context window around the best matching region in text."""
    if not text or not query_tokens:
        return text[:window_chars] if text else ""

    text_lower = text.lower()
    best_pos = -1
    best_density = 0.0

    # Slide a window and find the region with highest query token density
    step = max(1, window_chars // 4)
    for start in range(0, len(text), step):
        end = min(start + window_chars, len(text))
        window = text_lower[start:end]
        density = sum(1 for qt in query_tokens if qt in window) / len(query_tokens)
        if density > best_density:
            best_density = density
            best_pos = start

    if best_pos < 0:
        return text[:window_chars]

    # Expand to word boundaries
    start = max(0, best_pos)
    end = min(len(text), best_pos + window_chars)

    # Snap to word boundaries
    if start > 0:
        space_pos = text.rfind(" ", max(0, start - 50), start + 50)
        if space_pos > 0:
            start = space_pos + 1
    if end < len(text):
        space_pos = text.find(" ", end - 50, end + 50)
        if space_pos > 0:
            end = space_pos

    snippet = text[start:end].strip()
    prefix = "..." if start > 0 else ""
    suffix = "..." if end < len(text) else ""
    return f"{prefix}{snippet}{suffix}"


def _get_field_value(field_data: Any) -> str:
    """Extract string value from a field that may be a dict or plain value."""
    if isinstance(field_data, dict):
        return str(field_data.get("value", ""))
    if field_data is not None:
        return str(field_data)
    return ""


def _search_single_document(
    query: str,
    query_tokens: list[str],
    doc_id: str,
    fields: dict[str, Any],
) -> list[TextMatch]:
    """Search a single document's fields and text, returning scored matches."""
    matches: list[TextMatch] = []
    _SKIP_FIELDS = frozenset({"document_text", "summary", "sections", "tables", "diagrams"})

    # 1. Search full document text (highest priority)
    doc_text = _get_field_value(fields.get("document_text", {}))
    if doc_text and doc_text != "(no text extracted)":
        score = _compute_tf_idf_score(query_tokens, doc_text)
        if score > 0.01:
            context = _extract_context_window(doc_text, query_tokens, window_chars=600)
            matches.append(
                TextMatch(
                    text=context,
                    score=score * 1.2,
                    document_id=doc_id,
                    field_name="document_text",
                )
            )

    # 2. Search summary field
    summary = _get_field_value(fields.get("summary", {}))
    if summary:
        score = _compute_tf_idf_score(query_tokens, summary)
        if score > 0.01:
            matches.append(
                TextMatch(
                    text=summary[:500],
                    score=score * 1.1,
                    document_id=doc_id,
                    field_name="summary",
                )
            )

    # 3. Search individual extracted fields
    query_lower = query.lower()
    for field_name, field_data in fields.items():
        if field_name in _SKIP_FIELDS:
            continue
        value = _get_field_value(field_data)
        if not value:
            continue
        combined = f"{field_name.replace('_', ' ')}: {value}"
        score = _compute_tf_idf_score(query_tokens, combined)
        if field_name.replace("_", " ").lower() in query_lower:
            score = max(score, 0.5) * 1.3
        if score > 0.02:
            matches.append(
                TextMatch(
                    text=f"{field_name.replace('_', ' ').title()}: {value}",
                    score=score,
                    document_id=doc_id,
                    field_name=field_name,
                )
            )

    # 4. Search sections
    sections_raw = fields.get("sections", {})
    section_list = (
        sections_raw.get("value", [])
        if isinstance(sections_raw, dict)
        else sections_raw
        if isinstance(sections_raw, list)
        else []
    ) or []
    for section in section_list:
        if not isinstance(section, dict):
            continue
        section_text = f"{section.get('title', '')}\n{section.get('content', '')}"
        score = _compute_tf_idf_score(query_tokens, section_text)
        if score > 0.02:
            context = _extract_context_window(section_text, query_tokens, window_chars=400)
            matches.append(
                TextMatch(
                    text=context,
                    score=score * 1.05,
                    document_id=doc_id,
                    field_name="section",
                )
            )

    return matches


def search_document_text(
    query: str,
    doc_extractions: list[dict[str, Any]],
    top_k: int = 5,
) -> list[TextMatch]:
    """Search through document text and extracted fields using TF-IDF scoring.

    Searches both the full document text (stored in document_text field)
    and individual extracted fields, returning ranked matches.
    """
    query_tokens = _tokenize(query)
    if not query_tokens:
        return []

    matches: list[TextMatch] = []
    for doc_info in doc_extractions:
        matches.extend(
            _search_single_document(
                query=query,
                query_tokens=query_tokens,
                doc_id=doc_info["document_id"],
                fields=doc_info.get("fields", {}),
            )
        )

    matches.sort(key=lambda m: m.score, reverse=True)
    return matches[:top_k]


def build_answer_from_matches(
    question: str,
    matches: list[TextMatch],
    doc_extractions: list[dict[str, Any]],
) -> tuple[str, float, list[dict[str, Any]]]:
    """Build a comprehensive answer from text matches and extraction data.

    Returns (answer_text, confidence, sources).
    """
    if not matches and not doc_extractions:
        return (
            "I don't have any processed documents to answer your question. "
            "Try uploading a document first, and I'll be able to help you with it.",
            0.0,
            [],
        )

    # For general questions with no token matches, return document content
    if not matches and doc_extractions and _is_general_question(question):
        return _build_summary_answer(doc_extractions)

    sources: list[dict[str, Any]] = []
    answer_parts: list[str] = []
    seen_docs: set[str] = set()

    # Group matches by type
    field_matches = [
        m for m in matches if m.field_name not in ("document_text", "summary", "section")
    ]
    content_matches = [
        m for m in matches if m.field_name in ("document_text", "summary", "section")
    ]

    # Build answer from field matches (structured data)
    if field_matches:
        field_lines: list[str] = []
        for m in field_matches[:8]:
            field_lines.append(f"- {m.text}")
            if m.document_id not in seen_docs:
                filename = _get_filename(doc_extractions, m.document_id)
                sources.append(
                    {
                        "document_id": m.document_id,
                        "chunk_id": f"{m.document_id}_field_{m.field_name}",
                        "text_preview": f"{m.text} (from {filename})",
                        "page": m.page,
                        "score": round(m.score, 3),
                    }
                )
                seen_docs.add(m.document_id)

        if field_lines:
            answer_parts.append(
                "Here's what I found in the extracted data:\n\n" + "\n".join(field_lines)
            )

    # Build answer from content matches (document text)
    if content_matches:
        context_lines: list[str] = []
        for m in content_matches[:3]:
            context_lines.append(m.text)
            if m.document_id not in seen_docs:
                filename = _get_filename(doc_extractions, m.document_id)
                sources.append(
                    {
                        "document_id": m.document_id,
                        "chunk_id": f"{m.document_id}_{m.field_name}",
                        "text_preview": m.text[:150],
                        "page": m.page,
                        "score": round(m.score, 3),
                    }
                )
                seen_docs.add(m.document_id)

        if context_lines:
            if field_matches:
                answer_parts.append(
                    "I also found some relevant content in the documents:\n\n"
                    + "\n\n---\n\n".join(context_lines)
                )
            else:
                answer_parts.append(
                    "Here's what I found in the documents:\n\n"
                    + "\n\n---\n\n".join(context_lines)
                )

    if not answer_parts:
        # No strong matches found - provide summary
        return _build_fallback_answer(doc_extractions)

    # Compute confidence from match scores
    if matches:
        top_scores = [m.score for m in matches[:5]]
        avg_score = sum(top_scores) / len(top_scores)
        confidence = min(0.95, max(0.3, avg_score * 1.2))
    else:
        confidence = 0.3

    answer_text = "\n\n".join(answer_parts)
    return answer_text, round(confidence, 2), sources


def _get_filename(doc_extractions: list[dict[str, Any]], doc_id: str) -> str:
    """Get filename for a document ID from extraction data."""
    for doc_info in doc_extractions:
        if doc_info["document_id"] == doc_id:
            return doc_info.get("filename", "unknown")
    return "unknown"


def _build_fallback_answer(
    doc_extractions: list[dict[str, Any]],
) -> tuple[str, float, list[dict[str, Any]]]:
    """Build a fallback answer listing available document data."""
    if not doc_extractions:
        return (
            "I don't have any processed documents yet. "
            "Upload a document and I'll be able to answer questions about it.",
            0.0,
            [],
        )

    parts: list[str] = []
    sources: list[dict[str, Any]] = []

    for doc_info in doc_extractions:
        doc_id = doc_info["document_id"]
        filename = doc_info.get("filename", "unknown")
        fields = doc_info.get("fields", {})

        if not fields:
            continue

        # Show summary text prominently if available
        summary = _get_field_value(fields.get("summary", {}))

        # Show key fields, excluding large text fields
        field_lines = []
        if summary:
            field_lines.append(f"  - **Summary**: {summary[:200]}")
        for k, v in fields.items():
            if k in ("document_text", "sections", "tables", "diagrams", "summary"):
                continue
            value = v.get("value", v) if isinstance(v, dict) else v
            display_value = str(value)
            if len(display_value) > 100:
                display_value = display_value[:100] + "..."
            field_lines.append(f"  - **{k.replace('_', ' ').title()}**: {display_value}")

        if field_lines:
            parts.append(f"**{filename}**:\n" + "\n".join(field_lines))
            sources.append(
                {
                    "document_id": doc_id,
                    "chunk_id": f"{doc_id}_summary",
                    "text_preview": f"All extracted fields from {filename}",
                    "page": 1,
                    "score": 0.5,
                }
            )

    if not parts:
        return (
            "The documents have been processed, but I couldn't find extraction data "
            "related to your question. Try rephrasing or asking about a specific field.",
            0.2,
            [],
        )

    answer_text = (
        "I couldn't find a direct answer to your question, but here's "
        "what I have from the documents:\n\n" + "\n\n".join(parts)
    )
    return answer_text, 0.4, sources


def _build_summary_answer(
    doc_extractions: list[dict[str, Any]],
) -> tuple[str, float, list[dict[str, Any]]]:
    """Build an answer from document summaries and content for general questions.

    Prioritizes: summary → sections → document_text excerpt.
    """
    if not doc_extractions:
        return (
            "I don't have any processed documents yet. "
            "Upload a document and I'll be able to answer questions about it.",
            0.0,
            [],
        )

    parts: list[str] = []
    sources: list[dict[str, Any]] = []

    for doc_info in doc_extractions:
        doc_id = doc_info["document_id"]
        filename = doc_info.get("filename", "unknown")
        fields = doc_info.get("fields", {})
        if not fields:
            continue

        doc_parts: list[str] = []

        # 1. Summary
        summary = _get_field_value(fields.get("summary", {}))
        if summary:
            doc_parts.append(summary)

        # 2. Sections content
        sections_raw = fields.get("sections", {})
        section_list = (
            sections_raw.get("value", [])
            if isinstance(sections_raw, dict)
            else sections_raw
            if isinstance(sections_raw, list)
            else []
        ) or []
        for section in section_list[:5]:
            if not isinstance(section, dict):
                continue
            sec_title = section.get("title", "")
            sec_content = section.get("content", "")
            if sec_title and sec_content:
                doc_parts.append(f"**{sec_title}**: {sec_content[:300]}")
            elif sec_content:
                doc_parts.append(sec_content[:300])

        # 3. Document text excerpt (only if nothing else)
        if not doc_parts:
            doc_text = _get_field_value(fields.get("document_text", {}))
            if doc_text and doc_text != "(no text extracted)":
                doc_parts.append(doc_text[:600])

        if doc_parts:
            parts.append(f"**{filename}**:\n" + "\n\n".join(doc_parts))
            sources.append(
                {
                    "document_id": doc_id,
                    "chunk_id": f"{doc_id}_summary",
                    "text_preview": f"Summary and content from {filename}",
                    "page": 1,
                    "score": 0.6,
                }
            )

    if not parts:
        return _build_fallback_answer(doc_extractions)

    intro = (
        "Here's an overview of the documents:\n\n"
        if len(parts) > 1
        else "Here's what I found in the document:\n\n"
    )
    answer_text = intro + "\n\n".join(parts)
    return answer_text, 0.5, sources


# ---------------------------------------------------------------------------
# RAG Service (optional, requires vector store)
# ---------------------------------------------------------------------------


@dataclass
class RAGResult:
    """Result from RAG retrieval."""

    chunks: list[dict[str, Any]] = field(default_factory=list)
    total_found: int = 0
    method: str = "text_search"


class RAGService:
    """Unified RAG service integrating chunking, embedding, and retrieval.

    Provides graceful degradation: if the vector store is unavailable,
    falls back to text-based search on extraction data.
    """

    def __init__(self) -> None:
        self._retrieval_service: Any | None = None
        self._chunking_service: Any | None = None
        self._initialized = False
        self._init_lock = asyncio.Lock()

    async def initialize(self) -> bool:
        """Initialize RAG components. Returns True if vector store is available."""
        async with self._init_lock:
            if self._initialized:
                return self._retrieval_service is not None

            try:
                from src.config.settings import get_settings
                from src.services.rag.chunking import SemanticChunker
                from src.services.rag.embedding import BGEEmbeddingService
                from src.services.rag.memory_store import InMemoryVectorStore
                from src.services.rag.retrieval import RetrievalService

                settings = get_settings()

                # Use in-memory store for development, Qdrant for production
                if settings.is_development:
                    vector_store = InMemoryVectorStore()
                    await vector_store.create_collection(
                        name=settings.qdrant.collection_name,
                        dimension=settings.qdrant.vector_size,
                    )
                else:
                    from src.services.rag.vector_store import QdrantVectorStore

                    vector_store = QdrantVectorStore(
                        host=settings.qdrant.host,
                        port=settings.qdrant.port,
                    )

                embedding_service = BGEEmbeddingService(
                    model_name=settings.embedding.model,
                    device=settings.embedding.device,
                )

                self._retrieval_service = RetrievalService(
                    vector_store=vector_store,
                    embedding_service=embedding_service,
                    collection_name=settings.qdrant.collection_name,
                )
                self._chunking_service = SemanticChunker(
                    chunk_size=512,
                    chunk_overlap=128,
                )
                self._initialized = True
                logger.info("RAG service initialized successfully")
                return True

            except Exception as e:
                logger.warning(
                    "RAG service initialization failed, using text search fallback",
                    error=str(e),
                )
                self._initialized = True
                return False

    async def index_document(
        self,
        document_id: str,
        text: str,
        metadata: dict[str, Any] | None = None,
    ) -> int:
        """Index a document's text for RAG retrieval.

        Returns the number of chunks indexed.
        """
        if not self._retrieval_service or not self._chunking_service:
            return 0

        try:
            # Chunk the document
            result = self._chunking_service.chunk(
                text=text,
                document_id=document_id,
                metadata=metadata,
            )

            if not result.chunks:
                return 0

            # Index chunks
            chunk_dicts = [c.to_dict() for c in result.chunks]
            count = await self._retrieval_service.index_document(
                document_id=document_id,
                chunks=chunk_dicts,
            )

            logger.info(
                "Document indexed for RAG",
                document_id=document_id,
                chunk_count=count,
            )
            return count

        except Exception as e:
            logger.error(
                "Failed to index document for RAG",
                document_id=document_id,
                error=str(e),
            )
            return 0

    async def retrieve(
        self,
        query: str,
        document_ids: list[str] | None = None,
        top_k: int = 5,
    ) -> RAGResult:
        """Retrieve relevant chunks for a query.

        Falls back to empty result if vector store is unavailable.
        """
        if not self._retrieval_service:
            return RAGResult()

        try:
            if document_ids:
                result = await self._retrieval_service.retrieve_for_documents(
                    query=query,
                    document_ids=document_ids,
                    top_k=top_k,
                )
            else:
                result = await self._retrieval_service.retrieve(
                    query=query,
                    top_k=top_k,
                )

            return RAGResult(
                chunks=[c.to_dict() for c in result.chunks],
                total_found=result.total_found,
                method=result.search_method,
            )

        except Exception as e:
            logger.warning("RAG retrieval failed", error=str(e))
            return RAGResult()

    @property
    def is_available(self) -> bool:
        """Check if full RAG pipeline is available."""
        return self._retrieval_service is not None


# Singleton with thread-safe initialization
_rag_service: RAGService | None = None
_rag_lock = asyncio.Lock()


async def get_rag_service() -> RAGService:
    """Get or create the RAG service singleton."""
    global _rag_service
    if _rag_service is None:
        async with _rag_lock:
            if _rag_service is None:
                _rag_service = RAGService()
                await _rag_service.initialize()
    return _rag_service
