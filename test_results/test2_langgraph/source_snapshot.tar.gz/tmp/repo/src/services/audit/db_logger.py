"""
Database-backed audit logger.

Writes immutable audit log entries to the PostgreSQL audit_logs table.
Provides a simple API for recording events from any part of the system.
"""

from typing import Any

from src.core.logging import get_logger
from src.models.database.audit import AuditLog

logger = get_logger(__name__)


async def record_audit_event(
    session,
    event_type: str,
    action: str,
    outcome: str = "success",
    severity: str = "info",
    user_id: str | None = None,
    username: str | None = None,
    ip_address: str | None = None,
    resource_type: str | None = None,
    resource_id: str | None = None,
    details: dict[str, Any] | None = None,
    metadata: dict[str, Any] | None = None,
) -> AuditLog:
    """
    Record an audit event to the database.

    Args:
        session: AsyncSession for database access.
        event_type: Category of event (auth, document, extraction, council, security, admin).
        action: Specific action taken.
        outcome: Result of the action (success, failure, error).
        severity: Log severity (debug, info, warning, error, critical).
        user_id: ID of the user who performed the action.
        username: Username for readability.
        ip_address: Client IP address.
        resource_type: Type of resource affected (document, extraction, etc.).
        resource_id: ID of the affected resource.
        details: Additional event details.
        metadata: Extra metadata for the event.

    Returns:
        The created AuditLog entry.
    """
    entry = AuditLog(
        event_type=event_type,
        action=action,
        outcome=outcome,
        severity=severity,
        user_id=user_id,
        username=username,
        ip_address=ip_address,
        resource_type=resource_type,
        resource_id=resource_id,
        details=details,
        metadata_=metadata,
    )

    session.add(entry)

    logger.debug(
        "Audit event recorded",
        event_type=event_type,
        action=action,
        outcome=outcome,
        resource_type=resource_type,
        resource_id=resource_id,
    )

    return entry
