"""CSV and Excel export generators.

Generates tabular exports from extracted document data:
- CSV from tables or field key-value pairs
- Excel workbooks with formatted sheets
"""

from __future__ import annotations

import csv
import io
from dataclasses import dataclass
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class ExcelConfig:
    """Configuration for Excel generation."""

    include_council_data: bool = True
    format_cells: bool = True
    auto_width: bool = True


class CSVGenerator:
    """Generates CSV output from extraction data."""

    def generate_from_tables(self, tables: list[dict[str, Any]]) -> str:
        """Generate CSV from a list of table data.

        Args:
            tables: List of table dicts with cells/headers/rows.

        Returns:
            CSV string.
        """
        output = io.StringIO()
        writer = csv.writer(output)

        for i, table in enumerate(tables):
            if i > 0:
                writer.writerow([])  # Blank row between tables
                writer.writerow([f"--- Table {i + 1} ---"])

            # Handle cell-based tables (TableData format)
            if "cells" in table:
                rows = table.get("rows", 0)
                cols = table.get("cols", 0)
                grid = [["" for _ in range(cols)] for _ in range(rows)]
                for cell in table["cells"]:
                    r, c = cell.get("row", 0), cell.get("col", 0)
                    if 0 <= r < rows and 0 <= c < cols:
                        grid[r][c] = str(cell.get("text", ""))
                for row in grid:
                    writer.writerow(row)
            elif "headers" in table:
                writer.writerow(table["headers"])
                for row in table.get("rows", []):
                    writer.writerow([str(c) for c in row])

        return output.getvalue()

    def generate_from_fields(
        self,
        fields: dict[str, Any],
        confidence_scores: dict[str, float] | None = None,
    ) -> str:
        """Generate CSV from extracted field key-value pairs.

        Args:
            fields: Field name → value mapping.
            confidence_scores: Optional confidence per field.

        Returns:
            CSV string with field_name, value, confidence columns.
        """
        output = io.StringIO()
        writer = csv.writer(output)

        headers = ["Field Name", "Value", "Confidence"]
        writer.writerow(headers)

        confidence_scores = confidence_scores or {}

        for field_name, field_data in fields.items():
            value = field_data.get("value", "") if isinstance(field_data, dict) else field_data
            conf = confidence_scores.get(field_name, "")
            if isinstance(conf, float):
                conf = f"{conf:.2%}"

            writer.writerow([field_name, str(value), conf])

        return output.getvalue()


class ExcelGenerator:
    """Generates Excel workbooks from extraction data."""

    def __init__(self, config: ExcelConfig | None = None):
        self.config = config or ExcelConfig()

    def generate(
        self,
        extraction_data: dict[str, Any],
        tables: list[dict[str, Any]] | None = None,
    ) -> bytes:
        """Generate an Excel workbook from extraction data.

        Args:
            extraction_data: Extracted fields, confidence scores, votes.
            tables: Optional list of table data dicts.

        Returns:
            Excel file as bytes (.xlsx).
        """
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Alignment, Font, PatternFill
            from openpyxl.utils import get_column_letter
        except ImportError:
            logger.error("openpyxl not installed")
            return b""

        wb = Workbook()

        # Sheet 1: Extracted Fields
        ws = wb.active
        ws.title = "Extracted Fields"

        # Header styling
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")

        headers = ["Field Name", "Value", "Confidence", "Source"]
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center")

        fields = extraction_data.get("extracted_fields", extraction_data)
        confidence_scores = extraction_data.get("confidence_scores", {})
        row = 2

        for field_name, field_data in fields.items():
            if isinstance(field_data, dict):
                value = str(field_data.get("value", ""))
                source = str(field_data.get("source", ""))
            else:
                value = str(field_data)
                source = ""

            conf = confidence_scores.get(field_name, 0.0)

            ws.cell(row=row, column=1, value=field_name)
            ws.cell(row=row, column=2, value=value)

            conf_cell = ws.cell(row=row, column=3, value=conf)
            if self.config.format_cells:
                conf_cell.number_format = "0.0%"

            ws.cell(row=row, column=4, value=source)
            row += 1

        # Auto-width columns
        if self.config.auto_width:
            for col in range(1, len(headers) + 1):
                max_length = len(headers[col - 1])
                for r in range(2, row):
                    cell_value = str(ws.cell(row=r, column=col).value or "")
                    max_length = max(max_length, len(cell_value))
                ws.column_dimensions[get_column_letter(col)].width = min(max_length + 2, 50)

        # Sheet 2+: Tables
        tables = tables or []
        for i, table_data in enumerate(tables):
            ws_table = wb.create_sheet(title=f"Table {i + 1}")
            self._write_table_sheet(ws_table, table_data, header_font, header_fill)

        # Council Summary sheet
        if self.config.include_council_data:
            votes = extraction_data.get("council_votes") or extraction_data.get(
                "voting_summary", {}
            )
            if votes:
                ws_council = wb.create_sheet(title="Council Summary")
                self._write_council_sheet(ws_council, votes, header_font, header_fill)

        # Save to bytes
        output = io.BytesIO()
        wb.save(output)
        return output.getvalue()

    def _write_table_sheet(
        self,
        ws: Any,
        table_data: dict[str, Any],
        header_font: Any,
        header_fill: Any,
    ) -> None:
        """Write a table data sheet."""
        from openpyxl.styles import Alignment

        if "cells" in table_data:
            # Cell-based table
            rows_count = table_data.get("rows", 0)
            cols_count = table_data.get("cols", 0)
            grid = [["" for _ in range(cols_count)] for _ in range(rows_count)]

            for cell_data in table_data["cells"]:
                r, c = cell_data.get("row", 0), cell_data.get("col", 0)
                if 0 <= r < rows_count and 0 <= c < cols_count:
                    grid[r][c] = str(cell_data.get("text", ""))

            for r, row in enumerate(grid):
                for c, text in enumerate(row):
                    cell = ws.cell(row=r + 1, column=c + 1, value=text)
                    if r == 0:
                        cell.font = header_font
                        cell.fill = header_fill

                    # Right-align numeric values
                    data_type = ""
                    for cd in table_data["cells"]:
                        if cd.get("row") == r and cd.get("col") == c:
                            data_type = cd.get("data_type", "text")
                            break
                    if data_type in ("numeric", "currency", "percentage"):
                        cell.alignment = Alignment(horizontal="right")

        elif "headers" in table_data:
            headers = table_data["headers"]
            for c, header in enumerate(headers):
                cell = ws.cell(row=1, column=c + 1, value=str(header))
                cell.font = header_font
                cell.fill = header_fill

            for r, row_data in enumerate(table_data.get("rows", [])):
                for c, val in enumerate(row_data):
                    ws.cell(row=r + 2, column=c + 1, value=str(val))

    def _write_council_sheet(
        self,
        ws: Any,
        votes: dict[str, Any],
        header_font: Any,
        header_fill: Any,
    ) -> None:
        """Write council voting summary sheet."""
        headers = ["Model", "Vote", "Confidence"]
        for c, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=c, value=header)
            cell.font = header_font
            cell.fill = header_fill

        row = 2
        for model, vote_data in votes.items():
            if isinstance(vote_data, dict):
                ws.cell(row=row, column=1, value=model)
                ws.cell(row=row, column=2, value=str(vote_data.get("value", "")))
                conf_cell = ws.cell(row=row, column=3, value=vote_data.get("confidence", 0))
                conf_cell.number_format = "0.0%"
                row += 1


# Singletons
_csv_generator: CSVGenerator | None = None
_excel_generator: ExcelGenerator | None = None


def get_csv_generator() -> CSVGenerator:
    """Get or create CSV generator singleton."""
    global _csv_generator
    if _csv_generator is None:
        _csv_generator = CSVGenerator()
    return _csv_generator


def get_excel_generator() -> ExcelGenerator:
    """Get or create Excel generator singleton."""
    global _excel_generator
    if _excel_generator is None:
        _excel_generator = ExcelGenerator()
    return _excel_generator
