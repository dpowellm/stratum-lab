"""
DOCX Generation Service.

Task 3.2.2: Implements service for generating Word documents
from extraction results.
"""

from __future__ import annotations

import io
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Any

from docx import Document as DocxDoc
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

from src.core.logging import get_logger
from src.services.layout.font_mapper import FontMapper

if TYPE_CHECKING:
    from src.services.layout.models import DocumentLayout

logger = get_logger(__name__)


class DOCXStyle(StrEnum):
    """Document styles."""

    NORMAL = "Normal"
    HEADING_1 = "Heading 1"
    HEADING_2 = "Heading 2"
    HEADING_3 = "Heading 3"
    TITLE = "Title"
    SUBTITLE = "Subtitle"
    QUOTE = "Quote"
    LIST_BULLET = "List Bullet"
    LIST_NUMBER = "List Number"


@dataclass
class DOCXConfig:
    """DOCX generation configuration."""

    default_font: str = "Calibri"
    default_font_size: int = 11
    title_font_size: int = 24
    heading_font_size: int = 14
    include_toc: bool = True
    include_header: bool = True
    include_footer: bool = True
    page_width_inches: float = 8.5
    page_height_inches: float = 11.0
    margin_inches: float = 1.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "default_font": self.default_font,
            "default_font_size": self.default_font_size,
            "title_font_size": self.title_font_size,
            "heading_font_size": self.heading_font_size,
            "include_toc": self.include_toc,
            "include_header": self.include_header,
            "include_footer": self.include_footer,
        }


@dataclass
class DOCXParagraph:
    """A paragraph in a DOCX document."""

    text: str
    style: DOCXStyle = DOCXStyle.NORMAL
    bold: bool = False
    italic: bool = False
    alignment: str = "left"  # left, center, right, justify


@dataclass
class DOCXTable:
    """A table in a DOCX document."""

    headers: list[str]
    rows: list[list[Any]]
    title: str | None = None
    style: str = "Table Grid"


@dataclass
class DOCXDocument:
    """Generated DOCX document."""

    title: str
    paragraphs: list[DOCXParagraph]
    tables: list[DOCXTable] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    content_bytes: bytes | None = None

    @property
    def word_count(self) -> int:
        """Estimate word count."""
        return sum(len(p.text.split()) for p in self.paragraphs)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "title": self.title,
            "paragraph_count": len(self.paragraphs),
            "table_count": len(self.tables),
            "word_count": self.word_count,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
        }


def _unwrap(data: Any) -> Any:
    """Unwrap {"value": x, "confidence": y} → x, or return as-is."""
    if isinstance(data, dict) and "value" in data and "confidence" in data:
        return data["value"]
    return data


class DOCXGenerator:
    """
    DOCX Generation Service.

    Features:
    - Extraction result to DOCX conversion
    - Rich text formatting
    - Table formatting
    - Headers/footers
    """

    def __init__(
        self,
        config: DOCXConfig | None = None,
    ):
        """
        Initialize DOCX generator.

        Args:
            config: DOCX configuration
        """
        self.config = config or DOCXConfig()
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize the DOCX generator."""
        try:
            # In production, would initialize python-docx
            self._initialized = True
            logger.info("DOCX generator initialized")
            return True
        except Exception as e:
            logger.error("DOCX generator initialization failed", error=str(e))
            return False

    def generate(
        self,
        title: str,
        extraction_data: dict[str, Any],
        template_name: str | None = None,
    ) -> DOCXDocument:
        """
        Generate DOCX from extraction data.

        Args:
            title: Document title
            extraction_data: Extracted data to include
            template_name: Optional template name

        Returns:
            Generated DOCX document
        """
        if not self._initialized:
            self.initialize()

        paragraphs = self._create_paragraphs(title, extraction_data)
        tables = self._create_tables(extraction_data)
        content_bytes = self._render_docx(paragraphs, tables)

        doc = DOCXDocument(
            title=title,
            paragraphs=paragraphs,
            tables=tables,
            metadata={
                "template": template_name,
                "config": self.config.to_dict(),
            },
            content_bytes=content_bytes,
        )

        logger.info(
            "DOCX generated",
            title=title,
            paragraphs=len(paragraphs),
            word_count=doc.word_count,
        )

        return doc

    def _create_paragraphs(
        self,
        title: str,
        data: dict[str, Any],
    ) -> list[DOCXParagraph]:
        """Create paragraphs from data."""
        paragraphs: list[DOCXParagraph] = []

        # Title
        paragraphs.append(DOCXParagraph(text=title, style=DOCXStyle.TITLE, alignment="center"))

        self._add_summary_paragraphs(data, paragraphs)
        self._add_rich_section_paragraphs(data, paragraphs)
        self._add_diagram_paragraphs(data, paragraphs)
        self._add_entity_paragraphs(data, paragraphs)
        self._add_fallback_field_paragraphs(data, paragraphs)
        self._add_confidence_paragraphs(data, paragraphs)

        return paragraphs

    def _add_summary_paragraphs(
        self, data: dict[str, Any], paragraphs: list[DOCXParagraph]
    ) -> None:
        summary = _unwrap(data.get("summary"))
        if summary and isinstance(summary, str):
            paragraphs.append(DOCXParagraph(text=summary, style=DOCXStyle.SUBTITLE))
        elif "document_type" in data:
            paragraphs.append(
                DOCXParagraph(
                    text=f"Document Type: {_unwrap(data.get('document_type', 'Unknown'))}",
                    style=DOCXStyle.SUBTITLE,
                )
            )

    def _add_rich_section_paragraphs(
        self, data: dict[str, Any], paragraphs: list[DOCXParagraph]
    ) -> None:
        rich_sections = _unwrap(data.get("sections"))
        if not (rich_sections and isinstance(rich_sections, list)):
            return
        for sec in rich_sections:
            if not isinstance(sec, dict):
                continue
            level = sec.get("level", 2)
            heading_style = {
                1: DOCXStyle.HEADING_1,
                2: DOCXStyle.HEADING_2,
            }.get(level, DOCXStyle.HEADING_3)
            paragraphs.append(DOCXParagraph(text=sec.get("title", ""), style=heading_style))
            content = sec.get("content", "")
            if content:
                paragraphs.append(DOCXParagraph(text=content, style=DOCXStyle.NORMAL))

    def _add_diagram_paragraphs(
        self, data: dict[str, Any], paragraphs: list[DOCXParagraph]
    ) -> None:
        rich_diagrams = _unwrap(data.get("diagrams"))
        if not (rich_diagrams and isinstance(rich_diagrams, list)):
            return
        for diag in rich_diagrams:
            if not isinstance(diag, dict):
                continue
            paragraphs.append(
                DOCXParagraph(text=diag.get("title", "Diagram"), style=DOCXStyle.HEADING_2)
            )
            if diag.get("description"):
                paragraphs.append(DOCXParagraph(text=diag["description"], style=DOCXStyle.NORMAL))
            if diag.get("ascii_representation"):
                paragraphs.append(
                    DOCXParagraph(text=diag["ascii_representation"], style=DOCXStyle.QUOTE)
                )

    def _add_entity_paragraphs(self, data: dict[str, Any], paragraphs: list[DOCXParagraph]) -> None:
        rich_entities = _unwrap(data.get("entities"))
        if not (rich_entities and isinstance(rich_entities, dict)):
            return
        entity_lines = []
        for category, values in rich_entities.items():
            if isinstance(values, list) and values:
                entity_lines.append(f"{category}: {', '.join(str(v) for v in values[:10])}")
        if entity_lines:
            paragraphs.append(DOCXParagraph(text="Extracted Entities", style=DOCXStyle.HEADING_2))
            for line in entity_lines:
                paragraphs.append(DOCXParagraph(text=line, style=DOCXStyle.LIST_BULLET))

    def _add_fallback_field_paragraphs(
        self, data: dict[str, Any], paragraphs: list[DOCXParagraph]
    ) -> None:
        fields = data.get("fields", {})
        rich_sections = _unwrap(data.get("sections"))
        if not (fields and not rich_sections):
            return
        paragraphs.append(DOCXParagraph(text="Extracted Fields", style=DOCXStyle.HEADING_1))
        for field_name, field_value in fields.items():
            paragraphs.append(
                DOCXParagraph(text=f"{field_name}: {field_value}", style=DOCXStyle.NORMAL)
            )

    def _add_confidence_paragraphs(
        self, data: dict[str, Any], paragraphs: list[DOCXParagraph]
    ) -> None:
        if "confidence" not in data:
            return
        paragraphs.append(DOCXParagraph(text="Extraction Confidence", style=DOCXStyle.HEADING_2))
        paragraphs.append(
            DOCXParagraph(
                text=f"Overall confidence: {data['confidence']:.1%}",
                style=DOCXStyle.NORMAL,
            )
        )

    def _create_tables(
        self,
        data: dict[str, Any],
    ) -> list[DOCXTable]:
        """Create tables from data."""
        tables: list[DOCXTable] = []

        # Rich tables from content analysis
        rich_tables = _unwrap(data.get("tables"))
        if rich_tables and isinstance(rich_tables, list):
            for tbl in rich_tables:
                if isinstance(tbl, dict) and tbl.get("headers"):
                    tables.append(
                        DOCXTable(
                            headers=tbl["headers"],
                            rows=tbl.get("rows", []),
                            title=tbl.get("title"),
                        )
                    )

        # Line items
        line_items = data.get("line_items", [])
        if line_items and isinstance(line_items[0], dict):
            headers = list(line_items[0].keys())
            rows = [list(item.values()) for item in line_items]
            tables.append(
                DOCXTable(
                    headers=headers,
                    rows=rows,
                    title="Line Items",
                )
            )

        return tables

    def _render_docx(
        self,
        paragraphs: list[DOCXParagraph],
        tables: list[DOCXTable],
    ) -> bytes:
        """Render a real DOCX file using python-docx."""
        try:
            return self._render_docx_real(paragraphs, tables)
        except Exception as exc:
            logger.warning("python-docx rendering failed, using text fallback", error=str(exc))
            return self._render_docx_text(paragraphs, tables)

    def _render_docx_real(
        self,
        paragraphs: list[DOCXParagraph],
        tables: list[DOCXTable],
    ) -> bytes:
        """Render a real DOCX using python-docx."""
        doc = DocxDoc()

        # Map our styles to python-docx style names
        style_map = {
            DOCXStyle.TITLE: "Title",
            DOCXStyle.SUBTITLE: "Subtitle",
            DOCXStyle.HEADING_1: "Heading 1",
            DOCXStyle.HEADING_2: "Heading 2",
            DOCXStyle.HEADING_3: "Heading 3",
            DOCXStyle.NORMAL: "Normal",
            DOCXStyle.QUOTE: "Quote",
            DOCXStyle.LIST_BULLET: "List Bullet",
            DOCXStyle.LIST_NUMBER: "List Number",
        }

        align_map = {
            "left": WD_ALIGN_PARAGRAPH.LEFT,
            "center": WD_ALIGN_PARAGRAPH.CENTER,
            "right": WD_ALIGN_PARAGRAPH.RIGHT,
            "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
        }

        for para in paragraphs:
            docx_style = style_map.get(para.style, "Normal")
            p = doc.add_paragraph(style=docx_style)
            run = p.add_run(para.text)
            if para.bold:
                run.bold = True
            if para.italic:
                run.italic = True
            if para.alignment in align_map:
                p.alignment = align_map[para.alignment]

        for tbl in tables:
            if tbl.title:
                doc.add_paragraph(tbl.title, style="Heading 2")

            rows_count = len(tbl.rows) + 1  # +1 for header
            cols_count = len(tbl.headers)
            table = doc.add_table(rows=rows_count, cols=cols_count)
            table.style = "Table Grid"

            # Header row
            for i, header in enumerate(tbl.headers):
                cell = table.rows[0].cells[i]
                cell.text = str(header)
                for paragraph in cell.paragraphs:
                    for run in paragraph.runs:
                        run.bold = True
                        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                shading = OxmlElement("w:shd")
                shading.set(qn("w:fill"), "4472C4")
                cell._tc.get_or_add_tcPr().append(shading)

            # Data rows
            for row_idx, row_data in enumerate(tbl.rows):
                for col_idx, cell_val in enumerate(row_data):
                    table.rows[row_idx + 1].cells[col_idx].text = str(cell_val)

        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()

    def _render_docx_text(
        self,
        paragraphs: list[DOCXParagraph],
        tables: list[DOCXTable],
    ) -> bytes:
        """Fallback plain-text rendering when python-docx is unavailable."""
        content_parts = [
            f"Generated: {datetime.utcnow().isoformat()}\n\n",
        ]
        for para in paragraphs:
            style_marker = f"[{para.style.value}]" if para.style != DOCXStyle.NORMAL else ""
            content_parts.append(f"{style_marker} {para.text}\n")
        for table in tables:
            if table.title:
                content_parts.append(f"\n[Table: {table.title}]\n")
            content_parts.append(" | ".join(table.headers) + "\n")
            for row in table.rows:
                content_parts.append(" | ".join(str(cell) for cell in row) + "\n")
        return "".join(content_parts).encode("utf-8")

    def generate_from_layout(
        self,
        layout: DocumentLayout,
        title: str = "Extracted Region",
    ) -> DOCXDocument:
        """Generate a DOCX from layout data with run-level font/size/color preservation.

        Args:
            layout: DocumentLayout with page/block/line/span data.
            title: Document title.

        Returns:
            DOCXDocument with rendered content.
        """
        if not self._initialized:
            self.initialize()

        try:
            content_bytes = self._render_docx_from_layout(layout, title)
        except Exception as exc:
            logger.warning("Layout DOCX rendering failed, using fallback", error=str(exc))
            content_bytes = self._render_docx_from_layout_text(layout, title)

        doc = DOCXDocument(
            title=title,
            paragraphs=[],
            tables=[],
            metadata={"source": "layout_extraction"},
            content_bytes=content_bytes,
        )

        logger.info("DOCX generated from layout", title=title, pages=len(layout.pages))
        return doc

    def _render_docx_from_layout(
        self,
        layout: DocumentLayout,
        title: str,
    ) -> bytes:
        """Render DOCX from layout with table and heading support."""
        from src.services.layout.models import TableBlock

        doc = DocxDoc()

        # Title
        doc.add_heading(title, level=0)

        for page_layout in layout.pages:
            for block in page_layout.blocks:
                if isinstance(block, TableBlock):
                    self._add_table_block_to_docx(doc, block)
                elif block.block_type == "text":
                    self._add_text_block_to_docx(doc, block)

        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()

    @staticmethod
    def _add_table_block_to_docx(doc: Any, block: Any) -> None:
        """Render a TableBlock as a DOCX table with styled headers."""
        rows_count = len(block.rows) + 1
        cols_count = len(block.headers)
        if cols_count == 0:
            return
        table = doc.add_table(rows=rows_count, cols=cols_count)
        table.style = "Table Grid"

        for i, header in enumerate(block.headers):
            cell = table.rows[0].cells[i]
            cell.text = str(header)
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True
                    run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            shading = OxmlElement("w:shd")
            shading.set(qn("w:fill"), "4472C4")
            cell._tc.get_or_add_tcPr().append(shading)

        for row_idx, row_data in enumerate(block.rows):
            for col_idx, cell_val in enumerate(row_data):
                if col_idx < cols_count:
                    table.rows[row_idx + 1].cells[col_idx].text = str(cell_val)

    @staticmethod
    def _add_text_block_to_docx(doc: Any, block: Any) -> None:
        """Render a TextBlock with heading detection and run-level formatting."""
        for line in block.lines:
            max_size = max((span.font_size for span in line.spans), default=12.0)
            line_text = "".join(span.text for span in line.spans)
            if not line_text.strip():
                continue

            if max_size >= 18.0:
                doc.add_heading(line_text.strip(), level=1)
            elif max_size >= 14.0:
                doc.add_heading(line_text.strip(), level=2)
            else:
                para = doc.add_paragraph()
                for span in line.spans:
                    if not span.text:
                        continue
                    run = para.add_run(span.text)
                    run.font.name = FontMapper.to_docx(span.font_name)
                    run.font.size = Pt(span.font_size)
                    run.font.bold = span.bold
                    run.font.italic = span.italic
                    r, g, b = FontMapper.color_int_to_rgb(span.color)
                    run.font.color.rgb = RGBColor(r, g, b)

    def _render_docx_from_layout_text(
        self,
        layout: DocumentLayout,
        title: str,
    ) -> bytes:
        """Fallback text-based rendering for layout data using python-docx."""
        doc = DocxDoc()
        doc.add_heading(title, level=0)
        for page_layout in layout.pages:
            doc.add_heading(f"Page {page_layout.page_number + 1}", level=1)
            for block in page_layout.blocks:
                for line in block.lines:
                    line_text = "".join(span.text for span in line.spans)
                    if line_text.strip():
                        doc.add_paragraph(line_text)
        if not layout.pages:
            doc.add_paragraph("No content extracted for this region.")
        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()

    def render_structured_table(self, doc_obj: Any, table: Any) -> None:
        """Render a structured TableData as a python-docx table with merged cells and formatting.

        Args:
            doc_obj: python-docx Document object.
            table: TableData instance with typed cells.
        """
        from src.services.ocr.base import TableData

        if not isinstance(table, TableData) or not table.cells:
            return

        grid = table._build_grid()
        if not grid:
            return

        rows_count = len(grid)
        cols_count = len(grid[0]) if grid else 0
        tbl = doc_obj.add_table(rows=rows_count, cols=cols_count)
        tbl.style = "Table Grid"

        # Populate cells
        for r, row in enumerate(grid):
            for c, text in enumerate(row):
                tbl.rows[r].cells[c].text = str(text)

        self._style_structured_headers(tbl, table)
        self._align_structured_numerics(tbl, table)
        self._merge_structured_cells(tbl, table, rows_count, cols_count)

    @staticmethod
    def _style_structured_headers(tbl: Any, table: Any) -> None:
        """Apply header styling (bold white text, blue background) to header cells."""
        for cell in table.cells:
            if cell.is_header:
                docx_cell = tbl.rows[cell.row].cells[cell.col]
                for paragraph in docx_cell.paragraphs:
                    for run in paragraph.runs:
                        run.bold = True
                        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                shading = OxmlElement("w:shd")
                shading.set(qn("w:fill"), "4472C4")
                docx_cell._tc.get_or_add_tcPr().append(shading)

    @staticmethod
    def _align_structured_numerics(tbl: Any, table: Any) -> None:
        """Right-align cells with numeric, currency, or percentage data types."""
        from src.services.ocr.base import CellDataType

        for cell in table.cells:
            if cell.data_type in (
                CellDataType.NUMERIC,
                CellDataType.CURRENCY,
                CellDataType.PERCENTAGE,
            ):
                docx_cell = tbl.rows[cell.row].cells[cell.col]
                for paragraph in docx_cell.paragraphs:
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT

    @staticmethod
    def _merge_structured_cells(tbl: Any, table: Any, rows_count: int, cols_count: int) -> None:
        """Merge cells that span multiple rows or columns."""
        for cell in table.cells:
            if cell.row_span > 1 or cell.col_span > 1:
                start_cell = tbl.rows[cell.row].cells[cell.col]
                end_row = min(cell.row + cell.row_span - 1, rows_count - 1)
                end_col = min(cell.col + cell.col_span - 1, cols_count - 1)
                end_cell = tbl.rows[end_row].cells[end_col]
                start_cell.merge(end_cell)

    def add_image(
        self,
        document: DOCXDocument,
        caption: str | None = None,
    ) -> DOCXDocument:
        """Add an image to the document."""
        if caption:
            document.paragraphs.append(
                DOCXParagraph(
                    text=f"[Image: {caption}]",
                    style=DOCXStyle.NORMAL,
                    italic=True,
                )
            )

        document.metadata["has_images"] = True
        return document

    def add_table_of_contents(
        self,
        document: DOCXDocument,
    ) -> DOCXDocument:
        """Add table of contents."""
        if not self.config.include_toc:
            return document

        # Find headings
        headings = [
            p
            for p in document.paragraphs
            if p.style in [DOCXStyle.HEADING_1, DOCXStyle.HEADING_2, DOCXStyle.HEADING_3]
        ]

        if headings:
            toc_para = DOCXParagraph(
                text="Table of Contents",
                style=DOCXStyle.HEADING_1,
            )
            document.paragraphs.insert(1, toc_para)

            for h in headings:
                indent = "  " * (int(h.style.value[-1]) - 1) if h.style.value[-1].isdigit() else ""
                document.paragraphs.insert(
                    2, DOCXParagraph(text=f"{indent}• {h.text}", style=DOCXStyle.NORMAL)
                )

        return document

    def save_to_file(
        self,
        document: DOCXDocument,
        filepath: str,
    ) -> bool:
        """Save DOCX document to file."""
        try:
            if document.content_bytes:
                Path(filepath).write_bytes(document.content_bytes)
                return True
            return False
        except Exception as e:
            logger.error("Failed to save DOCX", error=str(e))
            return False


# Singleton instance
_docx_generator: DOCXGenerator | None = None


def get_docx_generator() -> DOCXGenerator:
    """Get or create DOCX generator singleton."""
    global _docx_generator
    if _docx_generator is None:
        _docx_generator = DOCXGenerator()
        _docx_generator.initialize()
    return _docx_generator
