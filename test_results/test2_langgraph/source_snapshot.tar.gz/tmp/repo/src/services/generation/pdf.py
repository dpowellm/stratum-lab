"""
PDF Generation Service.

Task 3.2.1: Implements service for generating PDF documents
from extraction results.
"""

from __future__ import annotations

import io
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Any

from reportlab.lib import colors
from reportlab.lib.pagesizes import A3, A4, LEGAL, LETTER, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from src.core.logging import get_logger
from src.services.layout.font_mapper import FontMapper

if TYPE_CHECKING:
    from src.services.layout.models import DocumentLayout

logger = get_logger(__name__)


class PageSize(StrEnum):
    """PDF page sizes."""

    A4 = "A4"
    LETTER = "LETTER"
    LEGAL = "LEGAL"
    A3 = "A3"


class PageOrientation(StrEnum):
    """Page orientation."""

    PORTRAIT = "portrait"
    LANDSCAPE = "landscape"


@dataclass
class PDFConfig:
    """PDF generation configuration."""

    page_size: PageSize = PageSize.A4
    orientation: PageOrientation = PageOrientation.PORTRAIT
    margin_top: float = 1.0  # inches
    margin_bottom: float = 1.0
    margin_left: float = 1.0
    margin_right: float = 1.0
    font_family: str = "Helvetica"
    font_size: int = 11
    include_header: bool = True
    include_footer: bool = True
    include_page_numbers: bool = True
    include_timestamp: bool = True

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "page_size": self.page_size.value,
            "orientation": self.orientation.value,
            "margin_top": self.margin_top,
            "margin_bottom": self.margin_bottom,
            "margin_left": self.margin_left,
            "margin_right": self.margin_right,
            "font_family": self.font_family,
            "font_size": self.font_size,
            "include_header": self.include_header,
            "include_footer": self.include_footer,
            "include_page_numbers": self.include_page_numbers,
            "include_timestamp": self.include_timestamp,
        }


@dataclass
class PDFSection:
    """A section in a PDF document."""

    title: str
    content: str
    level: int = 1  # Heading level (1-6)
    style: dict[str, Any] = field(default_factory=dict)


@dataclass
class PDFTable:
    """A table in a PDF document."""

    headers: list[str]
    rows: list[list[Any]]
    title: str | None = None
    style: dict[str, Any] = field(default_factory=dict)


@dataclass
class PDFDocument:
    """Generated PDF document."""

    title: str
    sections: list[PDFSection]
    tables: list[PDFTable] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    page_count: int = 0
    content_bytes: bytes | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "title": self.title,
            "section_count": len(self.sections),
            "table_count": len(self.tables),
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "page_count": self.page_count,
            "has_content": self.content_bytes is not None,
        }


def _unwrap(data: Any) -> Any:
    """Unwrap {"value": x, "confidence": y} → x, or return as-is."""
    if isinstance(data, dict) and "value" in data and "confidence" in data:
        return data["value"]
    return data


class PDFGenerator:
    """
    PDF Generation Service.

    Features:
    - Extraction result to PDF conversion
    - Table formatting
    - Header/footer customization
    - Multiple page sizes
    """

    def __init__(
        self,
        config: PDFConfig | None = None,
    ):
        """
        Initialize PDF generator.

        Args:
            config: PDF configuration
        """
        self.config = config or PDFConfig()
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize the PDF generator."""
        try:
            # In production, would initialize PDF library (reportlab, weasyprint, etc.)
            self._initialized = True
            logger.info("PDF generator initialized")
            return True
        except Exception as e:
            logger.error("PDF generator initialization failed", error=str(e))
            return False

    def generate(
        self,
        title: str,
        extraction_data: dict[str, Any],
        template_name: str | None = None,
    ) -> PDFDocument:
        """
        Generate PDF from extraction data.

        Args:
            title: Document title
            extraction_data: Extracted data to include
            template_name: Optional template name

        Returns:
            Generated PDF document
        """
        if not self._initialized:
            self.initialize()

        # Create sections from extraction data
        sections = self._create_sections(extraction_data)

        # Create tables if data has structured content
        tables = self._create_tables(extraction_data)

        # Generate PDF content
        content_bytes = self._render_pdf(title, sections, tables)

        doc = PDFDocument(
            title=title,
            sections=sections,
            tables=tables,
            metadata={
                "template": template_name,
                "config": self.config.to_dict(),
            },
            content_bytes=content_bytes,
            page_count=self._estimate_pages(sections, tables),
        )

        logger.info(
            "PDF generated",
            title=title,
            sections=len(sections),
            tables=len(tables),
        )

        return doc

    def _create_sections(
        self,
        data: dict[str, Any],
    ) -> list[PDFSection]:
        """Create PDF sections from data."""
        sections: list[PDFSection] = []
        self._add_summary_section(data, sections)
        self._add_rich_sections(data, sections)
        self._add_diagram_sections(data, sections)
        self._add_entity_section(data, sections)
        self._add_fallback_fields_section(data, sections)
        self._add_confidence_section(data, sections)
        return sections

    def _add_summary_section(self, data: dict[str, Any], sections: list[PDFSection]) -> None:
        summary = _unwrap(data.get("summary"))
        if summary and isinstance(summary, str):
            sections.append(PDFSection(title="Document Summary", content=summary, level=1))
        elif "document_type" in data:
            sections.append(
                PDFSection(
                    title="Document Summary",
                    content=f"Document Type: {_unwrap(data.get('document_type', 'Unknown'))}",
                    level=1,
                )
            )

    def _add_rich_sections(self, data: dict[str, Any], sections: list[PDFSection]) -> None:
        rich_sections = _unwrap(data.get("sections"))
        if rich_sections and isinstance(rich_sections, list):
            for sec in rich_sections:
                if isinstance(sec, dict):
                    sections.append(
                        PDFSection(
                            title=sec.get("title", ""),
                            content=sec.get("content", ""),
                            level=min(sec.get("level", 2), 3),
                        )
                    )

    def _add_diagram_sections(self, data: dict[str, Any], sections: list[PDFSection]) -> None:
        rich_diagrams = _unwrap(data.get("diagrams"))
        if rich_diagrams and isinstance(rich_diagrams, list):
            for diag in rich_diagrams:
                if isinstance(diag, dict):
                    content_parts = []
                    if diag.get("description"):
                        content_parts.append(diag["description"])
                    if diag.get("ascii_representation"):
                        content_parts.append(diag["ascii_representation"])
                    sections.append(
                        PDFSection(
                            title=diag.get("title", "Diagram"),
                            content="\n".join(content_parts),
                            level=2,
                        )
                    )

    def _add_entity_section(self, data: dict[str, Any], sections: list[PDFSection]) -> None:
        rich_entities = _unwrap(data.get("entities"))
        if rich_entities and isinstance(rich_entities, dict):
            lines = []
            for category, values in rich_entities.items():
                if isinstance(values, list) and values:
                    lines.append(f"• {category}: {', '.join(str(v) for v in values[:10])}")
            if lines:
                sections.append(
                    PDFSection(
                        title="Extracted Entities",
                        content="\n".join(lines),
                        level=2,
                    )
                )

    def _add_fallback_fields_section(
        self, data: dict[str, Any], sections: list[PDFSection]
    ) -> None:
        fields = data.get("fields", {})
        rich_sections = _unwrap(data.get("sections"))
        if fields and not rich_sections:
            field_content = "\n".join(f"• {key}: {value}" for key, value in fields.items())
            sections.append(
                PDFSection(
                    title="Extracted Fields",
                    content=field_content,
                    level=2,
                )
            )

    def _add_confidence_section(self, data: dict[str, Any], sections: list[PDFSection]) -> None:
        if "confidence" in data:
            sections.append(
                PDFSection(
                    title="Extraction Confidence",
                    content=f"Overall Confidence: {data['confidence']:.1%}",
                    level=2,
                )
            )

    def _create_tables(
        self,
        data: dict[str, Any],
    ) -> list[PDFTable]:
        """Create tables from data."""
        tables: list[PDFTable] = []

        # Rich tables from content analysis
        rich_tables = _unwrap(data.get("tables"))
        if rich_tables and isinstance(rich_tables, list):
            for tbl in rich_tables:
                if isinstance(tbl, dict) and tbl.get("headers"):
                    tables.append(
                        PDFTable(
                            headers=tbl["headers"],
                            rows=tbl.get("rows", []),
                            title=tbl.get("title"),
                        )
                    )

        # Line items table
        line_items = data.get("line_items", [])
        if line_items and isinstance(line_items, list) and isinstance(line_items[0], dict):
            headers = list(line_items[0].keys())
            rows = [list(item.values()) for item in line_items]
            tables.append(
                PDFTable(
                    headers=headers,
                    rows=rows,
                    title="Line Items",
                )
            )

        # Council votes table
        votes = data.get("council_votes", {})
        if votes:
            headers = ["Model", "Vote", "Confidence"]
            rows = [
                [model, str(vote_data.get("value")), f"{vote_data.get('confidence', 0):.1%}"]
                for model, vote_data in votes.items()
            ]
            if rows:
                tables.append(
                    PDFTable(
                        headers=headers,
                        rows=rows,
                        title="Council Votes",
                    )
                )

        return tables

    def _render_pdf(
        self,
        title: str,
        sections: list[PDFSection],
        tables: list[PDFTable],
    ) -> bytes:
        """Render a real PDF using reportlab."""
        try:
            return self._render_pdf_reportlab(title, sections, tables)
        except Exception as exc:
            logger.warning("reportlab rendering failed, using text fallback", error=str(exc))
            return self._render_pdf_text(title, sections, tables)

    def _render_pdf_reportlab(
        self,
        title: str,
        sections: list[PDFSection],
        tables: list[PDFTable],
    ) -> bytes:
        """Render a real PDF with reportlab."""
        buf = io.BytesIO()

        page_size_map = {
            PageSize.A4: A4,
            PageSize.LETTER: LETTER,
            PageSize.LEGAL: LEGAL,
            PageSize.A3: A3,
        }
        ps = page_size_map.get(self.config.page_size, A4)
        if self.config.orientation == PageOrientation.LANDSCAPE:
            ps = landscape(ps)

        doc = SimpleDocTemplate(
            buf,
            pagesize=ps,
            topMargin=self.config.margin_top * inch,
            bottomMargin=self.config.margin_bottom * inch,
            leftMargin=self.config.margin_left * inch,
            rightMargin=self.config.margin_right * inch,
        )

        styles = getSampleStyleSheet()
        story: list[Any] = []

        # Title
        story.append(Paragraph(title, styles["Title"]))
        story.append(Spacer(1, 12))

        if self.config.include_timestamp:
            story.append(
                Paragraph(
                    f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}",
                    styles["Normal"],
                )
            )
            story.append(Spacer(1, 12))

        # Sections
        heading_styles = {
            1: "Heading1",
            2: "Heading2",
            3: "Heading3",
        }
        for section in sections:
            style_name = heading_styles.get(section.level, "Heading3")
            if style_name in styles:
                story.append(Paragraph(section.title, styles[style_name]))
            else:
                story.append(Paragraph(section.title, styles["Heading3"]))
            story.append(Spacer(1, 6))
            # Split content by newlines for paragraphs
            for line in section.content.split("\n"):
                if line.strip():
                    story.append(Paragraph(line, styles["Normal"]))
            story.append(Spacer(1, 12))

        # Tables
        for tbl in tables:
            if tbl.title:
                story.append(Paragraph(tbl.title, styles["Heading2"]))
                story.append(Spacer(1, 6))

            data = [tbl.headers] + [[str(c) for c in row] for row in tbl.rows]
            t = Table(data)
            t.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4472C4")),
                        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                        (
                            "ROWBACKGROUNDS",
                            (0, 1),
                            (-1, -1),
                            [colors.white, colors.HexColor("#D9E2F3")],
                        ),
                        ("TOPPADDING", (0, 0), (-1, -1), 4),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    ]
                )
            )
            story.append(t)
            story.append(Spacer(1, 12))

        doc.build(story)
        return buf.getvalue()

    def _render_pdf_text(
        self,
        title: str,
        sections: list[PDFSection],
        tables: list[PDFTable],
    ) -> bytes:
        """Fallback plain-text rendering when reportlab is unavailable."""
        content_parts = [
            f"=== {title} ===\n",
            f"Generated: {datetime.utcnow().isoformat()}\n\n",
        ]
        for section in sections:
            heading_marker = "#" * section.level
            content_parts.append(f"{heading_marker} {section.title}\n")
            content_parts.append(f"{section.content}\n\n")
        for table in tables:
            if table.title:
                content_parts.append(f"## {table.title}\n")
            content_parts.append(" | ".join(table.headers) + "\n")
            content_parts.append("-" * 50 + "\n")
            for row in table.rows:
                content_parts.append(" | ".join(str(cell) for cell in row) + "\n")
            content_parts.append("\n")
        return "".join(content_parts).encode("utf-8")

    def _estimate_pages(
        self,
        sections: list[PDFSection],
        tables: list[PDFTable],
    ) -> int:
        """Estimate page count."""
        # Rough estimate: 1 page per 3 sections or tables
        total_elements = len(sections) + len(tables)
        return max(1, (total_elements + 2) // 3)

    def generate_from_layout(
        self,
        layout: DocumentLayout,
        title: str = "Extracted Region",
    ) -> PDFDocument:
        """Generate a PDF from layout data with format-preserving positioning.

        Uses reportlab canvas for absolute positioning of text spans,
        preserving font, size, color, and position from the source PDF.

        Args:
            layout: DocumentLayout with page/block/line/span data.
            title: Document title.

        Returns:
            PDFDocument with rendered content.
        """
        if not self._initialized:
            self.initialize()

        try:
            content_bytes = self._render_pdf_from_layout(layout, title)
        except Exception as exc:
            logger.warning("Layout PDF rendering failed, using fallback", error=str(exc))
            content_bytes = self._render_pdf_from_layout_text(layout, title)

        doc = PDFDocument(
            title=title,
            sections=[],
            tables=[],
            metadata={"source": "layout_extraction"},
            content_bytes=content_bytes,
            page_count=len(layout.pages) or 1,
        )

        logger.info("PDF generated from layout", title=title, pages=len(layout.pages))
        return doc

    def _render_pdf_from_layout(
        self,
        layout: DocumentLayout,
        title: str,
    ) -> bytes:
        """Render PDF from layout using flowables for document-flow rendering."""
        from src.services.layout.models import TableBlock

        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=A4, title=title)
        styles = getSampleStyleSheet()
        story: list[Any] = [Paragraph(title, styles["Title"]), Spacer(1, 12)]

        for page_layout in layout.pages:
            for block in page_layout.blocks:
                if isinstance(block, TableBlock):
                    self._add_table_block_to_story(story, block, styles)
                elif block.block_type == "text":
                    self._add_text_block_to_story(story, block, styles)

            story.append(Spacer(1, 12))

        if not layout.pages:
            story.append(Paragraph("No content extracted for this region.", styles["BodyText"]))

        doc.build(story)
        return buf.getvalue()

    @staticmethod
    def _add_table_block_to_story(
        story: list[Any],
        block: Any,
        styles: Any,  # noqa: ARG004
    ) -> None:
        """Render a TableBlock as a reportlab Table flowable."""
        data = [block.headers, *block.rows]
        t = Table(data)
        t.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4472C4")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                    (
                        "ROWBACKGROUNDS",
                        (0, 1),
                        (-1, -1),
                        [colors.white, colors.HexColor("#D9E2F3")],
                    ),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]
            )
        )
        story.append(t)
        story.append(Spacer(1, 12))

    @staticmethod
    def _add_text_block_to_story(
        story: list[Any],
        block: Any,
        styles: Any,
    ) -> None:
        """Render a TextBlock as Paragraph flowables with heading detection."""
        from xml.sax.saxutils import escape

        for line in block.lines:
            max_size = max((span.font_size for span in line.spans), default=12.0)
            parts: list[str] = []
            for span in line.spans:
                if not span.text:
                    continue
                text = escape(span.text)
                r, g, b = FontMapper.color_int_to_rgb(span.color)
                color_hex = f"#{r:02x}{g:02x}{b:02x}"
                if span.bold and span.italic:
                    text = f"<b><i>{text}</i></b>"
                elif span.bold:
                    text = f"<b>{text}</b>"
                elif span.italic:
                    text = f"<i>{text}</i>"
                if color_hex != "#000000":
                    text = f'<font color="{color_hex}">{text}</font>'
                parts.append(text)
            line_text = "".join(parts)
            if not line_text.strip():
                continue
            if max_size >= 18.0:
                story.append(Paragraph(line_text, styles["Heading1"]))
            elif max_size >= 14.0:
                story.append(Paragraph(line_text, styles["Heading2"]))
            else:
                story.append(Paragraph(line_text, styles["BodyText"]))

    def _render_pdf_from_layout_text(
        self,
        layout: DocumentLayout,
        title: str,
    ) -> bytes:
        """Fallback text-based rendering for layout data using reportlab."""
        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=A4, title=title)
        styles = getSampleStyleSheet()
        story: list[Any] = [Paragraph(title, styles["Title"]), Spacer(1, 12)]
        for page_layout in layout.pages:
            story.append(Paragraph(f"Page {page_layout.page_number + 1}", styles["Heading2"]))
            for block in page_layout.blocks:
                for line in block.lines:
                    line_text = "".join(span.text for span in line.spans)
                    if line_text.strip():
                        story.append(Paragraph(line_text, styles["BodyText"]))
            story.append(Spacer(1, 12))
        if not layout.pages:
            story.append(Paragraph("No content extracted for this region.", styles["BodyText"]))
        doc.build(story)
        return buf.getvalue()

    def render_structured_table(self, table: Any) -> list[Any]:
        """Render a structured TableData as reportlab flowable elements.

        Handles merged cells, header styling, data type alignment,
        and alternating row colors.

        Args:
            table: Structured TableData with typed cells.

        Returns:
            List of reportlab flowables (Table + optional title).
        """
        from src.services.ocr.base import CellDataType, TableData

        if not isinstance(table, TableData) or not table.cells:
            return []

        story: list[Any] = []

        # Build grid
        grid = table._build_grid()
        if not grid:
            return []

        # Build reportlab table data
        data = [[str(cell) for cell in row] for row in grid]
        t = Table(data)

        # Build style commands
        style_cmds: list[Any] = [
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ]

        # Header row styling
        header_rows = set()
        for cell in table.cells:
            if cell.is_header:
                header_rows.add(cell.row)

        for hr in header_rows:
            style_cmds.extend(
                [
                    ("BACKGROUND", (0, hr), (-1, hr), colors.HexColor("#4472C4")),
                    ("TEXTCOLOR", (0, hr), (-1, hr), colors.white),
                    ("FONTNAME", (0, hr), (-1, hr), "Helvetica-Bold"),
                ]
            )

        # Alternating row colors for data rows
        max_header_row = max(header_rows) if header_rows else -1
        style_cmds.append(
            (
                "ROWBACKGROUNDS",
                (0, max_header_row + 1),
                (-1, -1),
                [colors.white, colors.HexColor("#F2F2F2")],
            )
        )

        # Right-align numeric/currency columns
        for cell in table.cells:
            if cell.data_type in (
                CellDataType.NUMERIC,
                CellDataType.CURRENCY,
                CellDataType.PERCENTAGE,
            ):
                style_cmds.append(("ALIGN", (cell.col, cell.row), (cell.col, cell.row), "RIGHT"))

        # Handle merged cells with SPAN
        for cell in table.cells:
            if cell.row_span > 1 or cell.col_span > 1:
                end_row = min(cell.row + cell.row_span - 1, table.rows - 1)
                end_col = min(cell.col + cell.col_span - 1, table.cols - 1)
                style_cmds.append(("SPAN", (cell.col, cell.row), (end_col, end_row)))

        t.setStyle(TableStyle(style_cmds))
        story.append(t)
        story.append(Spacer(1, 12))

        return story

    def generate_from_template(
        self,
        template: str,
        data: dict[str, Any],
    ) -> PDFDocument:
        """
        Generate PDF using a template.

        Args:
            template: Template content
            data: Data to fill template

        Returns:
            Generated PDF document
        """
        # Fill template with data
        filled_content = template
        for key, value in data.items():
            placeholder = f"{{{{{key}}}}}"
            filled_content = filled_content.replace(placeholder, str(value))

        return self.generate(
            title=data.get("title", "Generated Document"),
            extraction_data={"content": filled_content},
        )

    def merge_pdfs(
        self,
        documents: list[PDFDocument],
        title: str = "Merged Document",
    ) -> PDFDocument:
        """
        Merge multiple PDF documents.

        Args:
            documents: PDFs to merge
            title: Title for merged document

        Returns:
            Merged PDF document
        """
        all_sections: list[PDFSection] = []
        all_tables: list[PDFTable] = []

        for doc in documents:
            all_sections.extend(doc.sections)
            all_tables.extend(doc.tables)

        merged_content = b"".join(doc.content_bytes or b"" for doc in documents)

        return PDFDocument(
            title=title,
            sections=all_sections,
            tables=all_tables,
            content_bytes=merged_content,
            page_count=sum(doc.page_count for doc in documents),
            metadata={"merged_from": [doc.title for doc in documents]},
        )

    def save_to_file(
        self,
        document: PDFDocument,
        filepath: str,
    ) -> bool:
        """Save PDF document to file."""
        try:
            if document.content_bytes:
                Path(filepath).write_bytes(document.content_bytes)
                return True
            return False
        except Exception as e:
            logger.error("Failed to save PDF", error=str(e))
            return False


# Singleton instance
_pdf_generator: PDFGenerator | None = None


def get_pdf_generator() -> PDFGenerator:
    """Get or create PDF generator singleton."""
    global _pdf_generator
    if _pdf_generator is None:
        _pdf_generator = PDFGenerator()
        _pdf_generator.initialize()
    return _pdf_generator
