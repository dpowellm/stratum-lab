"""Blog Generation Service.

Generates blog posts from document extraction data using a
template-based approach.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any

from src.core.logging import get_logger

if TYPE_CHECKING:
    from src.services.layout.models import DocumentLayout

logger = get_logger(__name__)


def _unwrap(data: Any) -> Any:
    """Unwrap {"value": x, "confidence": y} → x, or return as-is."""
    if isinstance(data, dict) and "value" in data and "confidence" in data:
        return data["value"]
    return data


@dataclass
class BlogDocument:
    """Generated blog document."""

    title: str
    content: str
    word_count: int = 0
    created_at: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "title": self.title,
            "content": self.content,
            "word_count": self.word_count,
            "created_at": self.created_at.isoformat(),
        }


def _resolve_document_text(fields: Any) -> str:
    """Extract the document_text value from fields (list or dict format)."""
    if isinstance(fields, list):
        for f in fields:
            if isinstance(f, dict) and f.get("name") == "document_text":
                return str(f.get("value", ""))
    elif isinstance(fields, dict):
        dt = fields.get("document_text")
        if isinstance(dt, dict):
            return str(dt.get("value", ""))
        if isinstance(dt, str):
            return dt
    return ""


def _render_fields_section(fields: Any) -> list[str]:
    """Render extraction fields as bullet-point lines."""
    lines: list[str] = []
    if isinstance(fields, list):
        for f in fields:
            if not isinstance(f, dict) or f.get("name") == "document_text":
                continue
            name = f.get("name", "")
            value = f.get("value", "")
            conf = f.get("confidence", 0.0)
            lines.append(f"- **{name}**: {value} (confidence: {conf:.0%})")
    elif isinstance(fields, dict):
        for name, val in fields.items():
            if name == "document_text":
                continue
            if isinstance(val, dict):
                lines.append(
                    f"- **{name}**: {val.get('value', val)} "
                    f"(confidence: {val.get('confidence', 0):.0%})"
                )
            else:
                lines.append(f"- **{name}**: {val}")
    return lines or ["No structured fields were extracted."]


class BlogGenerator:
    """Generate blog posts from extraction data."""

    def generate_from_layout(
        self,
        layout: DocumentLayout,
        title: str = "Extracted Region",
    ) -> BlogDocument:
        """Generate a blog post from layout data.

        Wraps layout content in blog structure with introduction and conclusion.

        Args:
            layout: DocumentLayout with page/block/line/span data.
            title: Blog title.

        Returns:
            BlogDocument with rendered blog content.
        """
        blog_title = title.replace(".pdf", "").replace("_", " ").replace("-", " ").title()

        parts: list[str] = [f"# {blog_title}", ""]

        # Introduction
        parts.append("## Introduction")
        parts.append("")
        parts.append(
            f"This blog summarises the key content extracted from selected regions of **{title}**."
        )
        parts.append("")

        # Content sections from layout
        parts.append("## Extracted Content")
        parts.append("")

        for page_layout in layout.pages:
            if len(layout.pages) > 1:
                parts.append(f"### Page {page_layout.page_number + 1}")
                parts.append("")

            for block in page_layout.blocks:
                if hasattr(block, "headers") and block.block_type == "table":
                    parts.append(self._render_table_block(block))
                    parts.append("")
                elif block.block_type == "text":
                    for line in block.lines:
                        max_size = max(
                            (span.font_size for span in line.spans), default=12.0
                        )
                        line_text = self._format_line_spans(line.spans)

                        if not line_text.strip():
                            continue

                        if max_size >= 18.0:
                            parts.append(f"### {line_text.strip()}")
                        elif max_size >= 14.0:
                            parts.append(f"#### {line_text.strip()}")
                        else:
                            parts.append(line_text)

                    parts.append("")

        # Conclusion
        parts.append("## Conclusion")
        parts.append("")
        parts.append("This blog was automatically generated from the document extraction pipeline.")
        parts.append("")

        content = "\n".join(parts)
        word_count = len(content.split())

        logger.info("Blog generated from layout", title=blog_title, word_count=word_count)

        return BlogDocument(title=blog_title, content=content, word_count=word_count)

    @staticmethod
    def _format_line_spans(spans: list) -> str:
        """Format a list of TextSpans into a markdown line with bold/italic."""
        parts = []
        for span in spans:
            text = span.text
            if not text:
                continue
            if span.bold and span.italic:
                text = f"***{text}***"
            elif span.bold:
                text = f"**{text}**"
            elif span.italic:
                text = f"*{text}*"
            parts.append(text)
        return "".join(parts)

    @staticmethod
    def _render_table_block(block: Any) -> str:
        """Render a TableBlock as a markdown pipe table."""
        lines = []
        lines.append("| " + " | ".join(str(h) for h in block.headers) + " |")
        lines.append("| " + " | ".join("---" for _ in block.headers) + " |")
        for row in block.rows:
            lines.append("| " + " | ".join(str(cell) for cell in row) + " |")
        return "\n".join(lines)

    def generate(
        self,
        title: str,
        extraction_data: dict[str, Any],
        instructions: str = "",
    ) -> BlogDocument:
        """Generate a blog post from extraction data.

        Args:
            title: Document title / blog title.
            extraction_data: The extracted data dict from the pipeline.
            instructions: User instructions for blog tone / focus.

        Returns:
            A BlogDocument with the rendered markdown content.
        """
        # extraction_data may be the raw JSONB dict {field: {value, confidence}}
        # or it may contain a nested "fields" key from the API response.
        fields = extraction_data.get("fields") if "fields" in extraction_data else extraction_data
        document_text = _resolve_document_text(fields)
        if not document_text:
            # Also check top level in case it's stored directly
            document_text = _resolve_document_text(extraction_data)
        confidence = extraction_data.get("confidence", 0.0)

        # Rich content
        summary = _unwrap(fields.get("summary")) if isinstance(fields, dict) else None
        rich_sections = _unwrap(fields.get("sections")) if isinstance(fields, dict) else None
        rich_tables = _unwrap(fields.get("tables")) if isinstance(fields, dict) else None
        rich_diagrams = _unwrap(fields.get("diagrams")) if isinstance(fields, dict) else None

        blog_title = title.replace(".pdf", "").replace("_", " ").replace("-", " ").title()

        parts: list[str] = [f"# {blog_title}", ""]

        if instructions:
            parts += [f"*{instructions}*", ""]

        # Introduction — prefer summary over raw text preview
        parts += ["## Introduction", ""]
        if summary and isinstance(summary, str):
            parts.append(summary)
        elif document_text:
            preview = document_text[:300].strip()
            parts.append(
                f"This blog is generated from the document **{title}**. "
                f"The document begins with:\n\n> {preview}..."
            )
        else:
            parts.append(f"This blog summarises the key information extracted from **{title}**.")
        parts.append("")

        # Rich sections
        if rich_sections and isinstance(rich_sections, list):
            for sec in rich_sections:
                if isinstance(sec, dict):
                    level = min(sec.get("level", 2) + 1, 6)
                    heading = "#" * level
                    parts.append(f"{heading} {sec.get('title', '')}")
                    parts.append("")
                    content = sec.get("content", "")
                    if content:
                        parts.append(content)
                        parts.append("")
        else:
            # Legacy: Key findings from flat fields
            parts += ["## Key Findings", ""]
            parts += _render_fields_section(fields)
            parts.append("")

            # Document text body
            if document_text and len(document_text) > 100:
                body = document_text[:2000].strip()
                parts += ["## Document Content", "", body]
                if len(document_text) > 2000:
                    parts.append("\n*(Content truncated for brevity.)*")
                parts.append("")

        # Rich tables
        if rich_tables and isinstance(rich_tables, list):
            for tbl in rich_tables:
                if isinstance(tbl, dict) and tbl.get("headers"):
                    if tbl.get("title"):
                        parts.append(f"### {tbl['title']}")
                        parts.append("")
                    headers = tbl["headers"]
                    parts.append("| " + " | ".join(str(h) for h in headers) + " |")
                    parts.append("| " + " | ".join("---" for _ in headers) + " |")
                    for row in tbl.get("rows", []):
                        parts.append("| " + " | ".join(str(c) for c in row) + " |")
                    parts.append("")

        # Rich diagrams
        if rich_diagrams and isinstance(rich_diagrams, list):
            for diag in rich_diagrams:
                if isinstance(diag, dict):
                    parts.append(f"### {diag.get('title', 'Diagram')}")
                    parts.append("")
                    if diag.get("description"):
                        parts.append(diag["description"])
                        parts.append("")
                    if diag.get("ascii_representation"):
                        parts.append("```text")
                        parts.append(diag["ascii_representation"])
                        parts.append("```")
                        parts.append("")

        # Conclusion
        parts += ["## Conclusion", ""]
        if confidence > 0:
            parts.append(f"The extraction achieved an overall confidence of **{confidence:.0%}**. ")
        parts.append("This blog was automatically generated from the document extraction pipeline.")
        parts.append("")

        content = "\n".join(parts)
        word_count = len(content.split())

        logger.info("Blog generated", title=blog_title, word_count=word_count)

        return BlogDocument(title=blog_title, content=content, word_count=word_count)
