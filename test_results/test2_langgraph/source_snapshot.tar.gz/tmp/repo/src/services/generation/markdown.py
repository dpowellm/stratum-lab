"""
Markdown Generation Service.

Task 3.2.3: Implements service for generating Markdown documents.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Any

from src.core.logging import get_logger

if TYPE_CHECKING:
    from src.services.layout.models import DocumentLayout

logger = get_logger(__name__)


class MarkdownStyle(StrEnum):
    """Markdown styling options."""

    GITHUB = "github"  # GitHub-flavored markdown
    COMMONMARK = "commonmark"
    PANDOC = "pandoc"


@dataclass
class MarkdownConfig:
    """Markdown generation configuration."""

    style: MarkdownStyle = MarkdownStyle.GITHUB
    include_toc: bool = True
    include_frontmatter: bool = True
    code_fence_style: str = "```"
    table_style: str = "pipe"  # pipe or html
    max_heading_level: int = 6
    wrap_width: int = 80

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "style": self.style.value,
            "include_toc": self.include_toc,
            "include_frontmatter": self.include_frontmatter,
            "code_fence_style": self.code_fence_style,
            "table_style": self.table_style,
        }


@dataclass
class MarkdownSection:
    """A section in a Markdown document."""

    title: str
    content: str
    level: int = 1  # Heading level (1-6)


@dataclass
class MarkdownTable:
    """A table in Markdown format."""

    headers: list[str]
    rows: list[list[Any]]
    alignment: list[str] | None = None  # left, center, right


@dataclass
class MarkdownDocument:
    """Generated Markdown document."""

    title: str
    content: str
    sections: list[MarkdownSection] = field(default_factory=list)
    tables: list[MarkdownTable] = field(default_factory=list)
    frontmatter: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)

    @property
    def word_count(self) -> int:
        """Estimate word count."""
        return len(self.content.split())

    @property
    def line_count(self) -> int:
        """Count lines."""
        return len(self.content.split("\n"))

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "title": self.title,
            "section_count": len(self.sections),
            "table_count": len(self.tables),
            "word_count": self.word_count,
            "line_count": self.line_count,
            "frontmatter": self.frontmatter,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
        }


def _unwrap(data: Any) -> Any:
    """Unwrap {"value": x, "confidence": y} → x, or return as-is."""
    if isinstance(data, dict) and "value" in data and "confidence" in data:
        return data["value"]
    return data


class MarkdownGenerator:
    """
    Markdown Generation Service.

    Features:
    - Multiple markdown styles
    - Table generation
    - TOC generation
    - Frontmatter support
    """

    def __init__(
        self,
        config: MarkdownConfig | None = None,
    ):
        """
        Initialize Markdown generator.

        Args:
            config: Markdown configuration
        """
        self.config = config or MarkdownConfig()
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize the Markdown generator."""
        self._initialized = True
        logger.info("Markdown generator initialized")
        return True

    def generate(
        self,
        title: str,
        extraction_data: dict[str, Any],
        template_name: str | None = None,
    ) -> MarkdownDocument:
        """
        Generate Markdown from extraction data.

        Args:
            title: Document title
            extraction_data: Extracted data to include
            template_name: Optional template name

        Returns:
            Generated Markdown document
        """
        if not self._initialized:
            self.initialize()

        sections = self._create_sections(extraction_data)
        tables = self._create_tables(extraction_data)
        frontmatter = self._create_frontmatter(title, extraction_data)
        content = self._render_markdown(title, sections, tables, frontmatter)

        doc = MarkdownDocument(
            title=title,
            content=content,
            sections=sections,
            tables=tables,
            frontmatter=frontmatter,
            metadata={
                "template": template_name,
                "config": self.config.to_dict(),
            },
        )

        logger.info(
            "Markdown generated",
            title=title,
            sections=len(sections),
            word_count=doc.word_count,
        )

        return doc

    def _create_sections(
        self,
        data: dict[str, Any],
    ) -> list[MarkdownSection]:
        """Create sections from data."""
        sections = []

        # Summary from rich analysis
        summary = _unwrap(data.get("summary"))
        if summary and isinstance(summary, str):
            sections.append(MarkdownSection(title="Summary", content=summary, level=2))
        elif "document_type" in data:
            sections.append(
                MarkdownSection(
                    title="Summary",
                    content=f"**Document Type:** {_unwrap(data.get('document_type', 'Unknown'))}",
                    level=2,
                )
            )

        # Rich sections from content analysis
        rich_sections = _unwrap(data.get("sections"))
        if rich_sections and isinstance(rich_sections, list):
            for sec in rich_sections:
                if isinstance(sec, dict):
                    sections.append(
                        MarkdownSection(
                            title=sec.get("title", ""),
                            content=sec.get("content", ""),
                            level=min(sec.get("level", 2) + 1, 6),  # offset by 1 under summary
                        )
                    )

        # Diagrams as sections
        rich_diagrams = _unwrap(data.get("diagrams"))
        if rich_diagrams and isinstance(rich_diagrams, list):
            for diag in rich_diagrams:
                if isinstance(diag, dict):
                    content_parts = []
                    if diag.get("description"):
                        content_parts.append(diag["description"])
                    if diag.get("ascii_representation"):
                        content_parts.append(f"\n```text\n{diag['ascii_representation']}\n```")
                    sections.append(
                        MarkdownSection(
                            title=diag.get("title", "Diagram"),
                            content="\n\n".join(content_parts),
                            level=3,
                        )
                    )

        # Entities section
        rich_entities = _unwrap(data.get("entities"))
        if rich_entities and isinstance(rich_entities, dict):
            lines = []
            for category, values in rich_entities.items():
                if isinstance(values, list) and values:
                    lines.append(f"- **{category}:** {', '.join(str(v) for v in values[:10])}")
            if lines:
                sections.append(
                    MarkdownSection(
                        title="Extracted Entities",
                        content="\n".join(lines),
                        level=2,
                    )
                )

        # Fallback: flat fields (legacy)
        fields = data.get("fields", {})
        if fields and not rich_sections:
            field_lines = [f"- **{key}:** {value}" for key, value in fields.items()]
            sections.append(
                MarkdownSection(
                    title="Extracted Fields",
                    content="\n".join(field_lines),
                    level=2,
                )
            )

        # Confidence
        if "confidence" in data:
            sections.append(
                MarkdownSection(
                    title="Confidence",
                    content=f"Overall extraction confidence: **{data['confidence']:.1%}**",
                    level=2,
                )
            )

        return sections

    def _create_tables(
        self,
        data: dict[str, Any],
    ) -> list[MarkdownTable]:
        """Create tables from data."""
        tables = []

        # Rich tables from content analysis
        rich_tables = _unwrap(data.get("tables"))
        if rich_tables and isinstance(rich_tables, list):
            for tbl in rich_tables:
                if isinstance(tbl, dict) and tbl.get("headers"):
                    tables.append(
                        MarkdownTable(
                            headers=tbl["headers"],
                            rows=tbl.get("rows", []),
                        )
                    )

        # Line items
        line_items = data.get("line_items", [])
        if line_items and isinstance(line_items[0], dict):
            headers = list(line_items[0].keys())
            rows = [list(item.values()) for item in line_items]
            tables.append(MarkdownTable(headers=headers, rows=rows))

        return tables

    def _create_frontmatter(
        self,
        title: str,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        """Create YAML frontmatter."""
        if not self.config.include_frontmatter:
            return {}

        return {
            "title": title,
            "date": datetime.utcnow().isoformat(),
            "document_type": data.get("document_type", "unknown"),
            "confidence": data.get("confidence", 0.0),
        }

    def _render_markdown(
        self,
        title: str,
        sections: list[MarkdownSection],
        tables: list[MarkdownTable],
        frontmatter: dict[str, Any],
    ) -> str:
        """Render complete Markdown content."""
        parts = []

        # Frontmatter
        if frontmatter:
            parts.append("---")
            for key, value in frontmatter.items():
                parts.append(f"{key}: {value}")
            parts.append("---")
            parts.append("")

        # Title
        parts.append(f"# {title}")
        parts.append("")

        # TOC
        if self.config.include_toc and sections:
            parts.append("## Table of Contents")
            parts.append("")
            for section in sections:
                indent = "  " * (section.level - 2) if section.level > 2 else ""
                anchor = section.title.lower().replace(" ", "-")
                parts.append(f"{indent}- [{section.title}](#{anchor})")
            parts.append("")

        # Sections
        for section in sections:
            heading = "#" * section.level
            parts.append(f"{heading} {section.title}")
            parts.append("")
            parts.append(section.content)
            parts.append("")

        # Tables
        for table in tables:
            parts.append(self._render_table(table))
            parts.append("")

        return "\n".join(parts)

    def _render_table(self, table: MarkdownTable) -> str:
        """Render a Markdown table."""
        lines = []

        # Header
        lines.append("| " + " | ".join(str(h) for h in table.headers) + " |")

        # Separator
        alignments = table.alignment or ["left"] * len(table.headers)
        separators = []
        for align in alignments:
            if align == "center":
                separators.append(":---:")
            elif align == "right":
                separators.append("---:")
            else:
                separators.append("---")
        lines.append("| " + " | ".join(separators) + " |")

        # Rows
        for row in table.rows:
            lines.append("| " + " | ".join(str(cell) for cell in row) + " |")

        return "\n".join(lines)

    def render_structured_table(self, table: Any) -> str:
        """Render a structured TableData as a Markdown pipe table.

        Handles column alignment based on cell data types.
        For complex tables with merged cells, falls back to HTML table.

        Args:
            table: TableData instance with typed cells.

        Returns:
            Markdown table string.
        """
        from src.services.ocr.base import CellDataType, TableData

        if not isinstance(table, TableData) or not table.cells:
            return ""

        grid = table._build_grid()
        if not grid:
            return ""

        # Check for merged cells — if any, use HTML table fallback
        has_merged = any(c.row_span > 1 or c.col_span > 1 for c in table.cells)
        if has_merged:
            return self._render_structured_table_html(table, grid)

        # Determine column alignment from cell data types
        cols_count = len(grid[0]) if grid else 0
        alignments = ["left"] * cols_count
        for cell in table.cells:
            if cell.data_type in (
                CellDataType.NUMERIC,
                CellDataType.CURRENCY,
                CellDataType.PERCENTAGE,
            ):
                if cell.col < cols_count:
                    alignments[cell.col] = "right"

        # Build pipe table
        lines = []

        # Header row
        header = grid[0] if grid else []
        lines.append("| " + " | ".join(str(h) for h in header) + " |")

        # Separator with alignment
        seps = []
        for align in alignments:
            if align == "center":
                seps.append(":---:")
            elif align == "right":
                seps.append("---:")
            else:
                seps.append("---")
        lines.append("| " + " | ".join(seps) + " |")

        # Data rows
        for row in grid[1:]:
            lines.append("| " + " | ".join(str(c) for c in row) + " |")

        return "\n".join(lines)

    def _render_structured_table_html(self, table: Any, grid: list[list]) -> str:
        """Render a structured table with merged cells as HTML table in Markdown."""
        lines = ["<table>"]
        for r, row in enumerate(grid):
            lines.append("  <tr>")
            for _c, text in enumerate(row):
                tag = "th" if r == 0 else "td"
                lines.append(f"    <{tag}>{text}</{tag}>")
            lines.append("  </tr>")
        lines.append("</table>")
        return "\n".join(lines)

    def generate_from_layout(
        self,
        layout: DocumentLayout,
        title: str = "Extracted Region",
    ) -> MarkdownDocument:
        """Generate Markdown from layout data with heading/bold/italic heuristics.

        Heading detection:
        - font_size >= 18pt -> ## heading
        - font_size >= 14pt -> ### heading
        - Bold/italic -> ** and * wrappers

        Args:
            layout: DocumentLayout with page/block/line/span data.
            title: Document title.

        Returns:
            MarkdownDocument with rendered content.
        """
        if not self._initialized:
            self.initialize()

        from src.services.layout.models import TableBlock

        parts: list[str] = []

        # Title
        parts.append(f"# {title}")
        parts.append("")

        for page_layout in layout.pages:
            for block in page_layout.blocks:
                if isinstance(block, TableBlock):
                    table = MarkdownTable(
                        headers=block.headers,
                        rows=block.rows,
                    )
                    parts.append(self._render_table(table))
                    parts.append("")
                elif block.block_type == "text":
                    for line in block.lines:
                        # Check if the line is a heading based on max font size
                        max_size = max(
                            (span.font_size for span in line.spans), default=12.0
                        )
                        line_text = self._format_line_spans(line.spans)

                        if not line_text.strip():
                            continue

                        if max_size >= 18.0:
                            parts.append(f"## {line_text.strip()}")
                        elif max_size >= 14.0:
                            parts.append(f"### {line_text.strip()}")
                        else:
                            parts.append(line_text)

                    # Blank line between blocks
                    parts.append("")

        content = "\n".join(parts)

        doc = MarkdownDocument(
            title=title,
            content=content,
            sections=[],
            tables=[],
            metadata={"source": "layout_extraction"},
        )

        logger.info("Markdown generated from layout", title=title, pages=len(layout.pages))
        return doc

    @staticmethod
    def _format_line_spans(spans: list) -> str:
        """Format a list of TextSpans into a markdown line with bold/italic."""
        parts = []
        for span in spans:
            text = span.text
            if not text:
                continue
            if span.bold and span.italic:
                text = f"***{text}***"
            elif span.bold:
                text = f"**{text}**"
            elif span.italic:
                text = f"*{text}*"
            parts.append(text)
        return "".join(parts)

    def add_code_block(
        self,
        content: str,
        language: str = "",
    ) -> str:
        """Create a code block."""
        fence = self.config.code_fence_style
        return f"{fence}{language}\n{content}\n{fence}"

    def add_image(
        self,
        alt_text: str,
        url: str,
        title: str = "",
    ) -> str:
        """Create an image reference."""
        if title:
            return f'![{alt_text}]({url} "{title}")'
        return f"![{alt_text}]({url})"

    def add_link(
        self,
        text: str,
        url: str,
    ) -> str:
        """Create a link."""
        return f"[{text}]({url})"

    def save_to_file(
        self,
        document: MarkdownDocument,
        filepath: str,
    ) -> bool:
        """Save Markdown document to file."""
        try:
            with Path(filepath).open("w", encoding="utf-8") as f:
                f.write(document.content)
            return True
        except Exception as e:
            logger.error("Failed to save Markdown", error=str(e))
            return False


# Singleton instance
_markdown_generator: MarkdownGenerator | None = None


def get_markdown_generator() -> MarkdownGenerator:
    """Get or create Markdown generator singleton."""
    global _markdown_generator
    if _markdown_generator is None:
        _markdown_generator = MarkdownGenerator()
        _markdown_generator.initialize()
    return _markdown_generator
