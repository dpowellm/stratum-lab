"""Document Generation services package."""

from src.services.generation.blog import (
    BlogDocument,
    BlogGenerator,
)
from src.services.generation.docx import (
    DOCXConfig,
    DOCXDocument,
    DOCXGenerator,
)
from src.services.generation.markdown import (
    MarkdownConfig,
    MarkdownDocument,
    MarkdownGenerator,
)
from src.services.generation.pdf import (
    PDFConfig,
    PDFDocument,
    PDFGenerator,
)
from src.services.generation.templates import (
    Template,
    TemplateManager,
    TemplateType,
    TemplateVariable,
)

__all__ = [
    "BlogDocument",
    # Blog
    "BlogGenerator",
    "DOCXConfig",
    "DOCXDocument",
    # DOCX
    "DOCXGenerator",
    "MarkdownConfig",
    "MarkdownDocument",
    # Markdown
    "MarkdownGenerator",
    "PDFConfig",
    "PDFDocument",
    # PDF
    "PDFGenerator",
    "Template",
    # Templates
    "TemplateManager",
    "TemplateType",
    "TemplateVariable",
]
