"""
Performance Tuning Service.

Task 4.2.4: Implement performance tuning and optimization utilities.
"""

import contextlib
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class ResourceType(StrEnum):
    """Types of system resources."""

    CPU = "cpu"
    MEMORY = "memory"
    GPU = "gpu"
    DISK = "disk"
    NETWORK = "network"


class TuningParameter(StrEnum):
    """Tunable parameters."""

    BATCH_SIZE = "batch_size"
    WORKER_THREADS = "worker_threads"
    CACHE_SIZE = "cache_size"
    QUEUE_SIZE = "queue_size"
    TIMEOUT = "timeout"
    PREFETCH_SIZE = "prefetch_size"
    CONNECTION_POOL_SIZE = "connection_pool_size"


class OptimizationStrategy(StrEnum):
    """Optimization strategies."""

    THROUGHPUT = "throughput"  # Maximize documents per second
    LATENCY = "latency"  # Minimize response time
    MEMORY = "memory"  # Minimize memory usage
    BALANCED = "balanced"  # Balance all factors


@dataclass
class TuningConfig:
    """Configuration for performance tuning."""

    strategy: OptimizationStrategy = OptimizationStrategy.BALANCED
    auto_tune: bool = True
    tune_interval_seconds: int = 60
    sample_window_seconds: int = 300
    target_cpu_utilization: float = 0.80
    target_memory_utilization: float = 0.75
    target_latency_ms: float = 1000.0
    min_throughput: float = 10.0  # Documents per second

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "strategy": self.strategy.value,
            "auto_tune": self.auto_tune,
            "tune_interval_seconds": self.tune_interval_seconds,
            "sample_window_seconds": self.sample_window_seconds,
            "target_cpu_utilization": self.target_cpu_utilization,
            "target_memory_utilization": self.target_memory_utilization,
            "target_latency_ms": self.target_latency_ms,
            "min_throughput": self.min_throughput,
        }


@dataclass
class ResourceMetrics:
    """Metrics for a specific resource."""

    resource_type: ResourceType
    current_utilization: float = 0.0
    peak_utilization: float = 0.0
    average_utilization: float = 0.0
    available: float = 0.0
    total: float = 0.0
    timestamp: datetime = field(default_factory=datetime.utcnow)

    @property
    def utilization_percent(self) -> float:
        """Get utilization as percentage."""
        return self.current_utilization * 100

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "resource_type": self.resource_type.value,
            "current_utilization": self.current_utilization,
            "peak_utilization": self.peak_utilization,
            "average_utilization": self.average_utilization,
            "utilization_percent": self.utilization_percent,
            "available": self.available,
            "total": self.total,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class PerformanceMetrics:
    """Overall performance metrics."""

    throughput: float = 0.0  # Items per second
    latency_p50_ms: float = 0.0
    latency_p90_ms: float = 0.0
    latency_p99_ms: float = 0.0
    error_rate: float = 0.0
    queue_depth: int = 0
    active_workers: int = 0
    resources: dict[str, ResourceMetrics] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "throughput": self.throughput,
            "latency_p50_ms": self.latency_p50_ms,
            "latency_p90_ms": self.latency_p90_ms,
            "latency_p99_ms": self.latency_p99_ms,
            "error_rate": self.error_rate,
            "queue_depth": self.queue_depth,
            "active_workers": self.active_workers,
            "resources": {k: v.to_dict() for k, v in self.resources.items()},
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class TuningRecommendation:
    """A performance tuning recommendation."""

    parameter: TuningParameter
    current_value: Any
    recommended_value: Any
    expected_improvement: str
    confidence: float  # 0-1
    reason: str
    priority: int = 1  # 1 = highest

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "parameter": self.parameter.value,
            "current_value": self.current_value,
            "recommended_value": self.recommended_value,
            "expected_improvement": self.expected_improvement,
            "confidence": self.confidence,
            "reason": self.reason,
            "priority": self.priority,
        }


@dataclass
class TuningResult:
    """Result of a tuning operation."""

    parameter: TuningParameter
    old_value: Any
    new_value: Any
    applied_at: datetime = field(default_factory=datetime.utcnow)
    metrics_before: PerformanceMetrics | None = None
    metrics_after: PerformanceMetrics | None = None
    improvement: float = 0.0
    success: bool = True

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "parameter": self.parameter.value,
            "old_value": self.old_value,
            "new_value": self.new_value,
            "applied_at": self.applied_at.isoformat(),
            "improvement": self.improvement,
            "success": self.success,
        }


class PerformanceTuner:
    """
    Performance Tuning Service.

    Features:
    - Resource monitoring
    - Performance metrics collection
    - Auto-tuning
    - Recommendation generation
    - A/B testing support
    """

    def __init__(self, config: TuningConfig | None = None):
        """Initialize performance tuner."""
        self.config = config or TuningConfig()
        self._metrics_history: deque[PerformanceMetrics] = deque(maxlen=1000)
        self._latency_samples: deque[float] = deque(maxlen=10000)
        self._tuning_history: list[TuningResult] = []
        self._current_params: dict[TuningParameter, Any] = {}
        self._lock = threading.RLock()
        self._initialized = False
        self._tuning_thread: threading.Thread | None = None
        self._running = False

    def initialize(self) -> bool:
        """Initialize the performance tuner."""
        # Set default parameters
        self._current_params = {
            TuningParameter.BATCH_SIZE: 50,
            TuningParameter.WORKER_THREADS: 8,
            TuningParameter.CACHE_SIZE: 1024,
            TuningParameter.QUEUE_SIZE: 1000,
            TuningParameter.TIMEOUT: 30000,
            TuningParameter.PREFETCH_SIZE: 10,
            TuningParameter.CONNECTION_POOL_SIZE: 20,
        }

        self._initialized = True
        logger.info(
            "Performance tuner initialized",
            strategy=self.config.strategy.value,
            auto_tune=self.config.auto_tune,
        )
        return True

    def start_auto_tuning(self) -> None:
        """Start auto-tuning background thread."""
        if self._running:
            return

        self._running = True
        self._tuning_thread = threading.Thread(target=self._auto_tune_loop, daemon=True)
        self._tuning_thread.start()

    def stop_auto_tuning(self) -> None:
        """Stop auto-tuning."""
        self._running = False
        if self._tuning_thread:
            self._tuning_thread.join(timeout=5.0)

    def _auto_tune_loop(self) -> None:
        """Background auto-tuning loop."""
        while self._running:
            try:
                recommendations = self.get_recommendations()
                for rec in recommendations[:1]:  # Apply one at a time
                    if rec.confidence >= 0.7:
                        self.apply_recommendation(rec)
            except Exception as e:
                logger.error("Auto-tuning error", error=str(e))

            time.sleep(self.config.tune_interval_seconds)

    def record_latency(self, latency_ms: float) -> None:
        """Record a latency sample."""
        with self._lock:
            self._latency_samples.append(latency_ms)

    def record_metrics(self, metrics: PerformanceMetrics) -> None:
        """Record performance metrics."""
        with self._lock:
            self._metrics_history.append(metrics)

    def get_current_metrics(self) -> PerformanceMetrics:
        """Get current performance metrics."""
        with self._lock:
            # Calculate latency percentiles
            latencies = sorted(self._latency_samples)
            p50 = self._percentile(latencies, 50)
            p90 = self._percentile(latencies, 90)
            p99 = self._percentile(latencies, 99)

            # Simulate resource metrics
            cpu_metrics = ResourceMetrics(
                resource_type=ResourceType.CPU,
                current_utilization=0.65,
                peak_utilization=0.85,
                average_utilization=0.60,
                available=35.0,
                total=100.0,
            )

            memory_metrics = ResourceMetrics(
                resource_type=ResourceType.MEMORY,
                current_utilization=0.70,
                peak_utilization=0.80,
                average_utilization=0.65,
                available=8192.0,
                total=32768.0,
            )

            gpu_metrics = ResourceMetrics(
                resource_type=ResourceType.GPU,
                current_utilization=0.50,
                peak_utilization=0.90,
                average_utilization=0.55,
                available=4096.0,
                total=8192.0,
            )

            # Calculate throughput from recent metrics
            throughput = 0.0
            if self._metrics_history:
                recent = list(self._metrics_history)[-10:]
                throughput = sum(m.throughput for m in recent) / len(recent)

            return PerformanceMetrics(
                throughput=throughput,
                latency_p50_ms=p50,
                latency_p90_ms=p90,
                latency_p99_ms=p99,
                error_rate=0.02,
                queue_depth=100,
                active_workers=self._current_params.get(TuningParameter.WORKER_THREADS, 8),
                resources={
                    ResourceType.CPU.value: cpu_metrics,
                    ResourceType.MEMORY.value: memory_metrics,
                    ResourceType.GPU.value: gpu_metrics,
                },
            )

    def _percentile(self, sorted_data: list[float], p: int) -> float:
        """Calculate percentile from sorted data."""
        if not sorted_data:
            return 0.0
        index = int(len(sorted_data) * p / 100)
        index = min(index, len(sorted_data) - 1)
        return sorted_data[index]

    def get_recommendations(self) -> list[TuningRecommendation]:
        """Get performance tuning recommendations."""
        recommendations = []
        metrics = self.get_current_metrics()

        # Check CPU utilization
        cpu = metrics.resources.get(ResourceType.CPU.value)
        if cpu and cpu.current_utilization > self.config.target_cpu_utilization:
            current_workers = self._current_params.get(TuningParameter.WORKER_THREADS, 8)
            recommendations.append(
                TuningRecommendation(
                    parameter=TuningParameter.WORKER_THREADS,
                    current_value=current_workers,
                    recommended_value=max(2, current_workers - 2),
                    expected_improvement="10-20% CPU reduction",
                    confidence=0.8,
                    reason=f"CPU utilization ({cpu.utilization_percent:.1f}%) exceeds target",
                    priority=1,
                )
            )

        # Check memory utilization
        memory = metrics.resources.get(ResourceType.MEMORY.value)
        if memory and memory.current_utilization > self.config.target_memory_utilization:
            current_cache = self._current_params.get(TuningParameter.CACHE_SIZE, 1024)
            recommendations.append(
                TuningRecommendation(
                    parameter=TuningParameter.CACHE_SIZE,
                    current_value=current_cache,
                    recommended_value=int(current_cache * 0.75),
                    expected_improvement="15-25% memory reduction",
                    confidence=0.75,
                    reason=f"Memory utilization ({memory.utilization_percent:.1f}%) exceeds target",
                    priority=2,
                )
            )

        # Check latency
        if metrics.latency_p90_ms > self.config.target_latency_ms:
            current_batch = self._current_params.get(TuningParameter.BATCH_SIZE, 50)
            recommendations.append(
                TuningRecommendation(
                    parameter=TuningParameter.BATCH_SIZE,
                    current_value=current_batch,
                    recommended_value=max(10, current_batch - 10),
                    expected_improvement="20-30% latency reduction",
                    confidence=0.7,
                    reason=f"P90 latency ({metrics.latency_p90_ms:.1f}ms) exceeds target",
                    priority=1,
                )
            )

        # Check throughput
        if metrics.throughput < self.config.min_throughput:
            current_workers = self._current_params.get(TuningParameter.WORKER_THREADS, 8)
            current_batch = self._current_params.get(TuningParameter.BATCH_SIZE, 50)
            recommendations.append(
                TuningRecommendation(
                    parameter=TuningParameter.WORKER_THREADS,
                    current_value=current_workers,
                    recommended_value=min(32, current_workers + 4),
                    expected_improvement="30-50% throughput increase",
                    confidence=0.85,
                    reason=f"Throughput ({metrics.throughput:.1f}/s) below minimum",
                    priority=1,
                )
            )
            recommendations.append(
                TuningRecommendation(
                    parameter=TuningParameter.BATCH_SIZE,
                    current_value=current_batch,
                    recommended_value=min(200, current_batch + 20),
                    expected_improvement="15-25% throughput increase",
                    confidence=0.8,
                    reason=f"Throughput ({metrics.throughput:.1f}/s) below minimum",
                    priority=2,
                )
            )

        # Strategy-specific recommendations
        if self.config.strategy == OptimizationStrategy.THROUGHPUT:
            current_prefetch = self._current_params.get(TuningParameter.PREFETCH_SIZE, 10)
            if current_prefetch < 20:
                recommendations.append(
                    TuningRecommendation(
                        parameter=TuningParameter.PREFETCH_SIZE,
                        current_value=current_prefetch,
                        recommended_value=20,
                        expected_improvement="10-15% throughput increase",
                        confidence=0.6,
                        reason="Optimize for throughput strategy",
                        priority=3,
                    )
                )

        # Sort by priority
        recommendations.sort(key=lambda x: x.priority)
        return recommendations

    def apply_recommendation(self, recommendation: TuningRecommendation) -> TuningResult:
        """Apply a tuning recommendation."""
        metrics_before = self.get_current_metrics()

        with self._lock:
            old_value = self._current_params.get(recommendation.parameter)
            self._current_params[recommendation.parameter] = recommendation.recommended_value

        # Simulate applying the change
        time.sleep(0.1)

        metrics_after = self.get_current_metrics()

        result = TuningResult(
            parameter=recommendation.parameter,
            old_value=old_value,
            new_value=recommendation.recommended_value,
            metrics_before=metrics_before,
            metrics_after=metrics_after,
            success=True,
        )

        self._tuning_history.append(result)

        logger.info(
            "Applied tuning recommendation",
            parameter=recommendation.parameter.value,
            old_value=old_value,
            new_value=recommendation.recommended_value,
        )

        return result

    def get_parameter(self, parameter: TuningParameter) -> Any:
        """Get current value of a tuning parameter."""
        return self._current_params.get(parameter)

    def set_parameter(self, parameter: TuningParameter, value: Any) -> TuningResult:
        """Set a tuning parameter value."""
        with self._lock:
            old_value = self._current_params.get(parameter)
            self._current_params[parameter] = value

        result = TuningResult(
            parameter=parameter,
            old_value=old_value,
            new_value=value,
            success=True,
        )

        self._tuning_history.append(result)
        return result

    def get_tuning_history(self, limit: int = 100) -> list[TuningResult]:
        """Get tuning history."""
        return self._tuning_history[-limit:]

    def benchmark(
        self,
        test_func: callable,
        iterations: int = 100,
    ) -> dict[str, Any]:
        """
        Run a benchmark.

        Args:
            test_func: Function to benchmark
            iterations: Number of iterations

        Returns:
            Benchmark results
        """
        latencies = []

        for _ in range(iterations):
            start = time.time()
            with contextlib.suppress(Exception):
                test_func()
            latencies.append((time.time() - start) * 1000)

        sorted_latencies = sorted(latencies)

        return {
            "iterations": iterations,
            "min_ms": min(latencies),
            "max_ms": max(latencies),
            "mean_ms": sum(latencies) / len(latencies),
            "p50_ms": self._percentile(sorted_latencies, 50),
            "p90_ms": self._percentile(sorted_latencies, 90),
            "p99_ms": self._percentile(sorted_latencies, 99),
            "throughput": iterations / (sum(latencies) / 1000),
        }

    def profile_memory(self) -> dict[str, Any]:
        """Profile memory usage."""
        import sys

        return {
            "latency_samples_count": len(self._latency_samples),
            "metrics_history_count": len(self._metrics_history),
            "tuning_history_count": len(self._tuning_history),
            "estimated_memory_mb": (
                sys.getsizeof(self._latency_samples)
                + sys.getsizeof(self._metrics_history)
                + sys.getsizeof(self._tuning_history)
            )
            / 1024
            / 1024,
        }

    def generate_report(self) -> dict[str, Any]:
        """Generate a performance tuning report."""
        metrics = self.get_current_metrics()
        recommendations = self.get_recommendations()

        return {
            "current_metrics": metrics.to_dict(),
            "current_parameters": {p.value: v for p, v in self._current_params.items()},
            "recommendations": [r.to_dict() for r in recommendations],
            "recent_tuning": [t.to_dict() for t in self._tuning_history[-10:]],
            "memory_profile": self.profile_memory(),
            "config": self.config.to_dict(),
        }


# Singleton instance
_performance_tuner: PerformanceTuner | None = None


def get_performance_tuner(config: TuningConfig | None = None) -> PerformanceTuner:
    """Get or create performance tuner singleton."""
    global _performance_tuner
    if _performance_tuner is None:
        _performance_tuner = PerformanceTuner(config)
        _performance_tuner.initialize()
    return _performance_tuner
