"""
Document Type Router.

Task 2.2.4: Creates system that automatically classifies documents
and routes to appropriate schema.
"""

import re
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class RouterConfig:
    """Configuration for document router."""

    confidence_threshold: float = 0.6
    fallback_type: str = "document"
    enable_new_type_detection: bool = True
    min_confidence_for_routing: float = 0.5


@dataclass
class ClassifierVote:
    """Vote from a single classifier."""

    classifier_name: str
    document_type: str
    confidence: float
    features_used: list[str] = field(default_factory=list)


@dataclass
class DocumentClassification:
    """Result of document classification."""

    document_type: str
    confidence: float
    classifier_votes: list[ClassifierVote] = field(default_factory=list)
    alternative_types: list[tuple[str, float]] = field(default_factory=list)
    potentially_new_type: bool = False
    features_detected: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "document_type": self.document_type,
            "confidence": self.confidence,
            "alternative_types": [{"type": t, "confidence": c} for t, c in self.alternative_types],
            "potentially_new_type": self.potentially_new_type,
        }


# Type for classifier functions
ClassifierFunc = Callable[[dict[str, Any]], float]


class DocumentRouter:
    """
    Document Type Router.

    Features:
    - Multi-model classification
    - Confidence scoring
    - Fallback handling
    - New type detection
    - Extensible design
    """

    def __init__(self, config: RouterConfig | None = None):
        """
        Initialize document router.

        Args:
            config: Router configuration
        """
        self.config = config or RouterConfig()

        # Built-in classifiers
        self._classifiers: dict[str, ClassifierFunc] = {
            "invoice": self._classify_invoice,
            "receipt": self._classify_receipt,
            "contract": self._classify_contract,
            "form": self._classify_form,
            "letter": self._classify_letter,
            "report": self._classify_report,
        }

        # Classification weights
        self._weights = {
            "text_match": 0.5,
            "structure_match": 0.3,
            "visual_match": 0.2,
        }

    def classify(self, features: dict[str, Any]) -> DocumentClassification:
        """
        Classify a document based on features.

        Args:
            features: Document features

        Returns:
            DocumentClassification with type and confidence
        """
        votes: list[ClassifierVote] = []
        type_scores: dict[str, float] = defaultdict(float)

        # Run all classifiers
        for doc_type, classifier in self._classifiers.items():
            try:
                confidence = classifier(features)
                if confidence > 0:
                    vote = ClassifierVote(
                        classifier_name=f"{doc_type}_classifier",
                        document_type=doc_type,
                        confidence=confidence,
                    )
                    votes.append(vote)
                    type_scores[doc_type] = max(type_scores[doc_type], confidence)
            except Exception as e:
                logger.warning(
                    f"Classifier {doc_type} failed",
                    error=str(e),
                )

        # Find best match
        if not type_scores:
            return DocumentClassification(
                document_type=self.config.fallback_type,
                confidence=0.0,
                classifier_votes=votes,
                potentially_new_type=self.config.enable_new_type_detection,
            )

        sorted_types = sorted(
            type_scores.items(),
            key=lambda x: x[1],
            reverse=True,
        )

        best_type, best_confidence = sorted_types[0]

        # Check if potentially new type
        potentially_new = (
            self.config.enable_new_type_detection
            and best_confidence < self.config.confidence_threshold
        )

        # Use fallback if confidence too low
        if best_confidence < self.config.min_confidence_for_routing:
            best_type = self.config.fallback_type

        # Build alternatives list
        alternatives = [(t, c) for t, c in sorted_types[1:4] if c >= 0.3]

        # Detect features
        features_detected = self._detect_features(features)

        return DocumentClassification(
            document_type=best_type,
            confidence=best_confidence,
            classifier_votes=votes,
            alternative_types=alternatives,
            potentially_new_type=potentially_new,
            features_detected=features_detected,
        )

    def add_classifier(
        self,
        doc_type: str,
        classifier: ClassifierFunc,
    ) -> None:
        """
        Add a custom classifier.

        Args:
            doc_type: Document type name
            classifier: Classifier function
        """
        self._classifiers[doc_type] = classifier
        logger.info(f"Added classifier for {doc_type}")

    def remove_classifier(self, doc_type: str) -> bool:
        """Remove a classifier."""
        if doc_type in self._classifiers:
            del self._classifiers[doc_type]
            return True
        return False

    def _classify_invoice(self, features: dict[str, Any]) -> float:
        """Classify as invoice."""
        score = 0.0
        text = features.get("text_content", "").lower()

        # Text keywords
        invoice_keywords = [
            "invoice",
            "inv#",
            "invoice number",
            "invoice no",
            "bill to",
            "ship to",
            "due date",
            "payment terms",
            "subtotal",
            "total due",
            "amount due",
        ]

        keyword_matches = sum(1 for kw in invoice_keywords if kw in text)
        score += min(keyword_matches / 5, 1.0) * 0.5

        # Structure features
        if features.get("has_table") or features.get("has_line_items"):
            score += 0.2

        if features.get("has_total"):
            score += 0.15

        # Specific patterns
        if re.search(r"invoice\s*#?\s*\d+", text):
            score += 0.15

        return min(score, 1.0)

    def _classify_receipt(self, features: dict[str, Any]) -> float:
        """Classify as receipt."""
        score = 0.0
        text = features.get("text_content", "").lower()

        # Text keywords
        receipt_keywords = [
            "receipt",
            "thank you",
            "purchase",
            "transaction",
            "cashier",
            "register",
            "change",
            "subtotal",
            "tax",
            "total",
            "payment received",
        ]

        keyword_matches = sum(1 for kw in receipt_keywords if kw in text)
        score += min(keyword_matches / 5, 1.0) * 0.5

        # Usually shorter than invoices
        if features.get("page_count", 1) == 1:
            score += 0.1

        # Has date and time
        if features.get("has_date") and features.get("has_time"):
            score += 0.15

        if features.get("has_total"):
            score += 0.15

        # Receipt-specific patterns
        if re.search(r"(visa|mastercard|cash|credit|debit)", text):
            score += 0.1

        return min(score, 1.0)

    def _classify_contract(self, features: dict[str, Any]) -> float:
        """Classify as contract."""
        score = 0.0
        text = features.get("text_content", "").lower()

        # Text keywords
        contract_keywords = [
            "agreement",
            "contract",
            "parties",
            "whereas",
            "hereby",
            "terms and conditions",
            "obligations",
            "effective date",
            "termination",
            "governing law",
            "witness",
            "signature",
            "executed",
        ]

        keyword_matches = sum(1 for kw in contract_keywords if kw in text)
        score += min(keyword_matches / 5, 1.0) * 0.5

        # Usually multi-page
        if features.get("page_count", 1) > 2:
            score += 0.1

        # Has signature blocks
        if features.get("has_signature_block"):
            score += 0.2

        # Legal language patterns
        if re.search(r"(shall|herein|thereof|pursuant)", text):
            score += 0.15

        # Parties identified
        if re.search(r"between.*and", text):
            score += 0.15

        return min(score, 1.0)

    def _classify_form(self, features: dict[str, Any]) -> float:
        """Classify as form."""
        score = 0.0
        text = features.get("text_content", "").lower()

        # Text keywords
        form_keywords = [
            "form",
            "application",
            "please fill",
            "required",
            "name:",
            "address:",
            "date of birth",
            "signature:",
            "check all",
            "select one",
        ]

        keyword_matches = sum(1 for kw in form_keywords if kw in text)
        score += min(keyword_matches / 5, 1.0) * 0.5

        # Has checkboxes or radio buttons
        if features.get("has_checkboxes") or features.get("has_radio"):
            score += 0.25

        # Has form fields (underlines, boxes)
        if features.get("has_form_fields"):
            score += 0.2

        # Label:value pattern
        if len(re.findall(r"\w+:\s*_+", text)) > 2:
            score += 0.15

        return min(score, 1.0)

    def _classify_letter(self, features: dict[str, Any]) -> float:
        """Classify as letter."""
        score = 0.0
        text = features.get("text_content", "").lower()

        # Text keywords
        letter_keywords = [
            "dear",
            "sincerely",
            "regards",
            "to whom",
            "re:",
            "subject:",
            "yours truly",
            "best regards",
        ]

        keyword_matches = sum(1 for kw in letter_keywords if kw in text)
        score += min(keyword_matches / 4, 1.0) * 0.5

        # Usually single page
        if features.get("page_count", 1) <= 2:
            score += 0.1

        # Salutation pattern
        if re.search(r"dear\s+[a-z]+", text):
            score += 0.2

        # Closing pattern
        if re.search(r"(sincerely|regards|yours|best)", text):
            score += 0.2

        return min(score, 1.0)

    def _classify_report(self, features: dict[str, Any]) -> float:
        """Classify as report."""
        score = 0.0
        text = features.get("text_content", "").lower()

        # Text keywords
        report_keywords = [
            "report",
            "summary",
            "analysis",
            "findings",
            "conclusion",
            "executive summary",
            "table of contents",
            "introduction",
            "methodology",
            "results",
        ]

        keyword_matches = sum(1 for kw in report_keywords if kw in text)
        score += min(keyword_matches / 5, 1.0) * 0.5

        # Usually multi-page
        if features.get("page_count", 1) > 3:
            score += 0.15

        # Has sections/headers
        if features.get("has_headers") or features.get("has_sections"):
            score += 0.15

        # Has charts/graphs
        if features.get("has_charts"):
            score += 0.1

        # Section numbers
        if re.search(r"\d+\.\d*\s+[A-Z]", text):
            score += 0.1

        return min(score, 1.0)

    def _detect_features(self, features: dict[str, Any]) -> dict[str, Any]:
        """Detect document features for classification."""
        detected = {}

        text = features.get("text_content", "")

        # Has dates
        detected["has_dates"] = bool(re.search(r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}", text))

        # Has amounts/currency
        detected["has_amounts"] = bool(re.search(r"[$€£¥]\s*[\d,]+\.?\d*", text))

        # Has table-like structure
        detected["has_table_structure"] = bool(re.search(r"\d+\s+\$?\d+\.\d{2}", text))

        # Has signatures
        detected["has_signatures"] = bool(re.search(r"(signature|sign here|x_+)", text.lower()))

        return detected

    def get_schema_for_type(self, doc_type: str) -> type | None:
        """
        Get the appropriate schema class for a document type.

        Args:
            doc_type: Document type

        Returns:
            Schema class or None
        """
        from src.models.schemas.contract import ContractSchema
        from src.models.schemas.form import FormSchema
        from src.models.schemas.receipt import ReceiptSchema

        schema_map = {
            "receipt": ReceiptSchema,
            "form": FormSchema,
            "contract": ContractSchema,
        }

        return schema_map.get(doc_type)


# Singleton instance
_router: DocumentRouter | None = None


def get_document_router() -> DocumentRouter:
    """Get or create the document router singleton."""
    global _router
    if _router is None:
        _router = DocumentRouter()
    return _router
