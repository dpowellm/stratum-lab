"""S3-compatible storage service implementation."""

import hashlib
from datetime import datetime, timedelta
from typing import BinaryIO, AsyncIterator
import io

import aioboto3
from botocore.exceptions import ClientError

from src.services.storage.base import (
    StorageServiceInterface,
    StorageType,
    StorageMetadata,
    StorageObject,
    PresignedURL,
    ListResult,
    StorageError,
    ObjectNotFoundError,
    BucketNotFoundError,
    UploadError,
    DownloadError,
)


class S3StorageService(StorageServiceInterface):
    """S3/MinIO storage service implementation.

    Supports both AWS S3 and MinIO (S3-compatible).
    """

    def __init__(
        self,
        endpoint_url: str | None = None,
        access_key: str | None = None,
        secret_key: str | None = None,
        region: str = "us-east-1",
        default_bucket: str = "documents",
        use_ssl: bool = True,
    ):
        """Initialize S3 storage service.

        Args:
            endpoint_url: Custom endpoint for MinIO (None for AWS S3)
            access_key: AWS access key ID
            secret_key: AWS secret access key
            region: AWS region
            default_bucket: Default bucket name
            use_ssl: Whether to use SSL
        """
        self._endpoint_url = endpoint_url
        self._access_key = access_key
        self._secret_key = secret_key
        self._region = region
        self._default_bucket = default_bucket
        self._use_ssl = use_ssl
        self._session = aioboto3.Session()

    @property
    def storage_type(self) -> StorageType:
        """Get the storage type."""
        if self._endpoint_url:
            return StorageType.MINIO
        return StorageType.S3

    def _get_bucket(self, bucket: str | None) -> str:
        """Get bucket name, using default if not specified."""
        return bucket or self._default_bucket

    def _get_client_config(self) -> dict:
        """Get boto3 client configuration."""
        config = {
            "service_name": "s3",
            "region_name": self._region,
        }

        if self._endpoint_url:
            config["endpoint_url"] = self._endpoint_url

        if self._access_key and self._secret_key:
            config["aws_access_key_id"] = self._access_key
            config["aws_secret_access_key"] = self._secret_key

        config["config"] = {
            "signature_version": "s3v4",
        }

        return config

    async def upload(
        self,
        key: str,
        content: bytes | BinaryIO,
        bucket: str | None = None,
        content_type: str = "application/octet-stream",
        metadata: dict[str, str] | None = None,
    ) -> StorageMetadata:
        """Upload an object to S3."""
        bucket_name = self._get_bucket(bucket)

        # Convert bytes to file-like object
        if isinstance(content, bytes):
            file_obj = io.BytesIO(content)
            size = len(content)
            checksum = hashlib.sha256(content).hexdigest()
        else:
            # Read content to get size and checksum
            content_bytes = content.read()
            file_obj = io.BytesIO(content_bytes)
            size = len(content_bytes)
            checksum = hashlib.sha256(content_bytes).hexdigest()

        extra_args = {
            "ContentType": content_type,
        }

        if metadata:
            extra_args["Metadata"] = metadata

        try:
            async with self._session.client(**self._get_client_config()) as s3:
                await s3.upload_fileobj(
                    file_obj,
                    bucket_name,
                    key,
                    ExtraArgs=extra_args,
                )

                # Get the uploaded object metadata
                response = await s3.head_object(Bucket=bucket_name, Key=key)

                return StorageMetadata(
                    key=key,
                    bucket=bucket_name,
                    size=size,
                    content_type=content_type,
                    etag=response.get("ETag", "").strip('"'),
                    last_modified=response.get("LastModified"),
                    checksum=checksum,
                    custom_metadata=metadata or {},
                )

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "NoSuchBucket":
                raise BucketNotFoundError(f"Bucket '{bucket_name}' not found")
            raise UploadError(f"Upload failed: {e}")

    async def download(
        self,
        key: str,
        bucket: str | None = None,
    ) -> StorageObject:
        """Download an object from S3."""
        bucket_name = self._get_bucket(bucket)

        try:
            async with self._session.client(**self._get_client_config()) as s3:
                response = await s3.get_object(Bucket=bucket_name, Key=key)

                content = await response["Body"].read()

                metadata = StorageMetadata(
                    key=key,
                    bucket=bucket_name,
                    size=response.get("ContentLength", len(content)),
                    content_type=response.get("ContentType", "application/octet-stream"),
                    etag=response.get("ETag", "").strip('"'),
                    last_modified=response.get("LastModified"),
                    custom_metadata=response.get("Metadata", {}),
                )

                return StorageObject(content=content, metadata=metadata)

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code in ("NoSuchKey", "404"):
                raise ObjectNotFoundError(f"Object '{key}' not found in bucket '{bucket_name}'")
            if error_code == "NoSuchBucket":
                raise BucketNotFoundError(f"Bucket '{bucket_name}' not found")
            raise DownloadError(f"Download failed: {e}")

    async def download_stream(
        self,
        key: str,
        bucket: str | None = None,
        chunk_size: int = 8192,
    ) -> AsyncIterator[bytes]:
        """Download an object as a stream."""
        bucket_name = self._get_bucket(bucket)

        try:
            async with self._session.client(**self._get_client_config()) as s3:
                response = await s3.get_object(Bucket=bucket_name, Key=key)

                async for chunk in response["Body"].iter_chunks(chunk_size=chunk_size):
                    yield chunk

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code in ("NoSuchKey", "404"):
                raise ObjectNotFoundError(f"Object '{key}' not found")
            raise DownloadError(f"Download failed: {e}")

    async def delete(
        self,
        key: str,
        bucket: str | None = None,
    ) -> bool:
        """Delete an object from S3."""
        bucket_name = self._get_bucket(bucket)

        try:
            async with self._session.client(**self._get_client_config()) as s3:
                # Check if object exists first
                try:
                    await s3.head_object(Bucket=bucket_name, Key=key)
                except ClientError as e:
                    if e.response.get("Error", {}).get("Code") in ("404", "NoSuchKey"):
                        raise ObjectNotFoundError(f"Object '{key}' not found")
                    raise

                await s3.delete_object(Bucket=bucket_name, Key=key)
                return True

        except ObjectNotFoundError:
            raise
        except ClientError as e:
            raise StorageError(f"Delete failed: {e}")

    async def delete_many(
        self,
        keys: list[str],
        bucket: str | None = None,
    ) -> dict[str, bool]:
        """Delete multiple objects."""
        bucket_name = self._get_bucket(bucket)
        results = {}

        try:
            async with self._session.client(**self._get_client_config()) as s3:
                objects = [{"Key": key} for key in keys]
                response = await s3.delete_objects(
                    Bucket=bucket_name,
                    Delete={"Objects": objects},
                )

                # Mark successfully deleted
                for deleted in response.get("Deleted", []):
                    results[deleted["Key"]] = True

                # Mark failed deletions
                for error in response.get("Errors", []):
                    results[error["Key"]] = False

                # Mark any keys not in response as failed
                for key in keys:
                    if key not in results:
                        results[key] = False

                return results

        except ClientError as e:
            # Return all as failed
            return {key: False for key in keys}

    async def exists(
        self,
        key: str,
        bucket: str | None = None,
    ) -> bool:
        """Check if an object exists."""
        bucket_name = self._get_bucket(bucket)

        try:
            async with self._session.client(**self._get_client_config()) as s3:
                await s3.head_object(Bucket=bucket_name, Key=key)
                return True

        except ClientError as e:
            if e.response.get("Error", {}).get("Code") in ("404", "NoSuchKey"):
                return False
            raise StorageError(f"Exists check failed: {e}")

    async def get_metadata(
        self,
        key: str,
        bucket: str | None = None,
    ) -> StorageMetadata:
        """Get object metadata without downloading content."""
        bucket_name = self._get_bucket(bucket)

        try:
            async with self._session.client(**self._get_client_config()) as s3:
                response = await s3.head_object(Bucket=bucket_name, Key=key)

                return StorageMetadata(
                    key=key,
                    bucket=bucket_name,
                    size=response.get("ContentLength", 0),
                    content_type=response.get("ContentType", "application/octet-stream"),
                    etag=response.get("ETag", "").strip('"'),
                    last_modified=response.get("LastModified"),
                    custom_metadata=response.get("Metadata", {}),
                )

        except ClientError as e:
            if e.response.get("Error", {}).get("Code") in ("404", "NoSuchKey"):
                raise ObjectNotFoundError(f"Object '{key}' not found")
            raise StorageError(f"Get metadata failed: {e}")

    async def list_objects(
        self,
        prefix: str | None = None,
        bucket: str | None = None,
        max_keys: int = 1000,
        continuation_token: str | None = None,
    ) -> ListResult:
        """List objects in S3."""
        bucket_name = self._get_bucket(bucket)

        try:
            async with self._session.client(**self._get_client_config()) as s3:
                params = {
                    "Bucket": bucket_name,
                    "MaxKeys": max_keys,
                }

                if prefix:
                    params["Prefix"] = prefix

                if continuation_token:
                    params["ContinuationToken"] = continuation_token

                response = await s3.list_objects_v2(**params)

                objects = []
                for obj in response.get("Contents", []):
                    objects.append(
                        StorageMetadata(
                            key=obj["Key"],
                            bucket=bucket_name,
                            size=obj.get("Size", 0),
                            content_type="application/octet-stream",  # Not returned in list
                            etag=obj.get("ETag", "").strip('"'),
                            last_modified=obj.get("LastModified"),
                        )
                    )

                return ListResult(
                    objects=objects,
                    prefix=prefix,
                    continuation_token=response.get("NextContinuationToken"),
                    is_truncated=response.get("IsTruncated", False),
                )

        except ClientError as e:
            if e.response.get("Error", {}).get("Code") == "NoSuchBucket":
                raise BucketNotFoundError(f"Bucket '{bucket_name}' not found")
            raise StorageError(f"List objects failed: {e}")

    async def generate_presigned_url(
        self,
        key: str,
        bucket: str | None = None,
        method: str = "GET",
        expires_in: int = 3600,
        content_type: str | None = None,
    ) -> PresignedURL:
        """Generate a presigned URL."""
        bucket_name = self._get_bucket(bucket)

        client_method = "get_object" if method.upper() == "GET" else "put_object"

        params = {
            "Bucket": bucket_name,
            "Key": key,
        }

        if content_type and method.upper() == "PUT":
            params["ContentType"] = content_type

        try:
            async with self._session.client(**self._get_client_config()) as s3:
                url = await s3.generate_presigned_url(
                    client_method,
                    Params=params,
                    ExpiresIn=expires_in,
                )

                expires_at = datetime.utcnow() + timedelta(seconds=expires_in)

                headers = {}
                if content_type and method.upper() == "PUT":
                    headers["Content-Type"] = content_type

                return PresignedURL(
                    url=url,
                    method=method.upper(),
                    expires_at=expires_at,
                    headers=headers,
                )

        except ClientError as e:
            raise StorageError(f"Generate presigned URL failed: {e}")

    async def copy(
        self,
        source_key: str,
        dest_key: str,
        source_bucket: str | None = None,
        dest_bucket: str | None = None,
    ) -> StorageMetadata:
        """Copy an object within S3."""
        src_bucket = self._get_bucket(source_bucket)
        dst_bucket = self._get_bucket(dest_bucket)

        try:
            async with self._session.client(**self._get_client_config()) as s3:
                copy_source = {"Bucket": src_bucket, "Key": source_key}

                await s3.copy_object(
                    CopySource=copy_source,
                    Bucket=dst_bucket,
                    Key=dest_key,
                )

                # Get metadata of the copied object
                return await self.get_metadata(dest_key, dst_bucket)

        except ClientError as e:
            if e.response.get("Error", {}).get("Code") in ("404", "NoSuchKey"):
                raise ObjectNotFoundError(f"Source object '{source_key}' not found")
            raise StorageError(f"Copy failed: {e}")

    async def move(
        self,
        source_key: str,
        dest_key: str,
        source_bucket: str | None = None,
        dest_bucket: str | None = None,
    ) -> StorageMetadata:
        """Move an object within S3."""
        # Copy then delete
        metadata = await self.copy(source_key, dest_key, source_bucket, dest_bucket)
        await self.delete(source_key, source_bucket)
        return metadata

    async def create_bucket(
        self,
        bucket: str,
        region: str | None = None,
    ) -> bool:
        """Create a new bucket."""
        try:
            async with self._session.client(**self._get_client_config()) as s3:
                create_params = {"Bucket": bucket}

                # Only add LocationConstraint for non-us-east-1 regions
                bucket_region = region or self._region
                if bucket_region and bucket_region != "us-east-1":
                    create_params["CreateBucketConfiguration"] = {
                        "LocationConstraint": bucket_region
                    }

                await s3.create_bucket(**create_params)
                return True

        except ClientError as e:
            if e.response.get("Error", {}).get("Code") == "BucketAlreadyOwnedByYou":
                return True  # Already exists
            raise StorageError(f"Create bucket failed: {e}")

    async def bucket_exists(self, bucket: str) -> bool:
        """Check if a bucket exists."""
        try:
            async with self._session.client(**self._get_client_config()) as s3:
                await s3.head_bucket(Bucket=bucket)
                return True

        except ClientError as e:
            if e.response.get("Error", {}).get("Code") in ("404", "NoSuchBucket"):
                return False
            raise StorageError(f"Bucket exists check failed: {e}")

    async def list_buckets(self) -> list[str]:
        """List all buckets."""
        try:
            async with self._session.client(**self._get_client_config()) as s3:
                response = await s3.list_buckets()
                return [b["Name"] for b in response.get("Buckets", [])]

        except ClientError as e:
            raise StorageError(f"List buckets failed: {e}")
