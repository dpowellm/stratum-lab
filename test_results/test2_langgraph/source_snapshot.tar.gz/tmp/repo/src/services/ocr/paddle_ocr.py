"""PaddleOCR Service Implementation.

Provides OCR extraction using PaddleOCR library.
This is the speed specialist in the OCR council.
"""

import io
import time

import numpy as np
from PIL import Image

from src.core.logging import get_logger
from src.services.ocr.base import (
    BlockType,
    BoundingBox,
    Capability,
    OCRResult,
    OCRServiceInterface,
    TableCell,
    TableData,
    TextBlock,
)

logger = get_logger(__name__)


class PaddleOCRService(OCRServiceInterface):
    """PaddleOCR Service - Fast, local OCR processing.

    Strengths:
    - Fast inference (local processing)
    - Good table extraction
    - Multilingual support
    - No API costs
    - Batch processing support

    Weaknesses:
    - Less accurate on complex layouts
    - Limited semantic understanding
    - May struggle with handwriting
    """

    def __init__(
        self,
        use_gpu: bool = False,
        lang: str = "en",
        det_model_dir: str | None = None,
        rec_model_dir: str | None = None,
        cls_model_dir: str | None = None,
        confidence_threshold: float = 0.5,
    ):
        """Initialize PaddleOCR service.

        Args:
            use_gpu: Whether to use GPU acceleration
            lang: Language for OCR (en, ch, ja, etc.)
            det_model_dir: Custom detection model directory
            rec_model_dir: Custom recognition model directory
            cls_model_dir: Custom classification model directory
            confidence_threshold: Minimum confidence threshold
        """
        self._use_gpu = use_gpu
        self._lang = lang
        self._det_model_dir = det_model_dir
        self._rec_model_dir = rec_model_dir
        self._cls_model_dir = cls_model_dir
        self._confidence_threshold = confidence_threshold
        self._ocr = None
        self._table_engine = None
        self._initialized = False

    @property
    def model_name(self) -> str:
        """Get model name."""
        return "paddleocr"

    @property
    def model_version(self) -> str:
        """Get model version."""
        return "2.8.0"

    @property
    def capabilities(self) -> list[Capability]:
        """Get model capabilities."""
        return [
            Capability.FAST_EXTRACTION,
            Capability.TABLES,
            Capability.MULTILINGUAL,
            Capability.LONG_DOCUMENTS,
            Capability.MULTIPAGE,
        ]

    async def _ensure_initialized(self) -> None:
        """Ensure the service is initialized."""
        if self._initialized:
            return

        logger.info(
            "Initializing PaddleOCR service",
            use_gpu=self._use_gpu,
            lang=self._lang,
        )

        try:
            from paddleocr import PaddleOCR, PPStructure

            # Initialize main OCR
            self._ocr = PaddleOCR(
                use_angle_cls=True,
                use_gpu=self._use_gpu,
                lang=self._lang,
                det_model_dir=self._det_model_dir,
                rec_model_dir=self._rec_model_dir,
                cls_model_dir=self._cls_model_dir,
            )

            # Initialize table detection
            self._table_engine = PPStructure(
                use_gpu=self._use_gpu,
                image_orientation=True,
            )

            self._initialized = True
            logger.info("PaddleOCR service initialized successfully")
        except ImportError as e:
            logger.error("PaddleOCR not installed", error=str(e))
            raise RuntimeError("PaddleOCR library not installed") from e
        except Exception as e:
            logger.error("Failed to initialize PaddleOCR", error=str(e))
            raise

    async def extract_text(self, image: bytes) -> OCRResult:
        """Extract text from a single image.

        Args:
            image: Image bytes (PNG, JPEG, etc.)

        Returns:
            OCRResult with extracted text and confidence
        """
        start_time = time.time()
        await self._ensure_initialized()

        try:
            # Convert bytes to PIL Image
            img = Image.open(io.BytesIO(image))
            img_array = np.array(img)

            # Run OCR
            result = self._ocr.ocr(img_array, cls=True)

            # Parse results
            blocks = []
            full_text_parts = []
            confidences = []

            if result:
                for line in result:
                    if line:
                        for item in line:
                            # item structure: [[x1,y1], [x2,y2], [x3,y3], [x4,y4]], (text, confidence)
                            points, text_confidence = item
                            text, confidence = text_confidence

                            # Create bounding box
                            bbox = BoundingBox.from_points(points)

                            # Create text block
                            block = TextBlock(
                                text=text,
                                confidence=confidence,
                                bbox=bbox,
                                block_type=BlockType.TEXT,
                                page_number=1,
                                metadata={
                                    "points": points,
                                },
                            )

                            if confidence >= self._confidence_threshold:
                                blocks.append(block)
                                full_text_parts.append(text)
                                confidences.append(confidence)

            full_text = " ".join(full_text_parts)
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0

            processing_time_ms = (time.time() - start_time) * 1000

            return OCRResult(
                blocks=blocks,
                full_text=full_text,
                confidence=avg_confidence,
                page_count=1,
                language=self._lang,
                model_name=self.model_name,
                model_version=self.model_version,
                processing_time_ms=processing_time_ms,
            )

        except Exception as e:
            logger.error(
                "Text extraction failed",
                error=str(e),
                processing_time_ms=(time.time() - start_time) * 1000,
            )
            return OCRResult(
                blocks=[],
                full_text="",
                confidence=0.0,
                page_count=1,
                model_name=self.model_name,
                model_version=self.model_version,
                processing_time_ms=(time.time() - start_time) * 1000,
                metadata={"error": str(e)},
            )

    async def extract_from_pdf(
        self,
        pdf_bytes: bytes,
        pages: list[int] | None = None,
    ) -> list[OCRResult]:
        """Extract text from a PDF document.

        Args:
            pdf_bytes: PDF file bytes
            pages: Optional list of page numbers to process (1-indexed).
                   If None, process all pages.

        Returns:
            List of OCRResult, one per page
        """
        await self._ensure_initialized()

        try:
            import pdf2image

            # Convert PDF to images
            images = pdf2image.convert_from_bytes(pdf_bytes)

            # Determine which pages to process
            if pages is None:
                pages_to_process = list(range(len(images)))
            else:
                pages_to_process = [p - 1 for p in pages if 1 <= p <= len(images)]

            # Process selected pages
            results = []
            for page_idx in pages_to_process:
                if 0 <= page_idx < len(images):
                    img = images[page_idx]
                    img_bytes = io.BytesIO()
                    img.save(img_bytes, format="PNG")
                    img_bytes.seek(0)

                    result = await self.extract_text(img_bytes.getvalue())
                    result.page_count = len(images)
                    result.page_number = page_idx + 1  # type: ignore

                    results.append(result)

            return results

        except ImportError as e:
            logger.error("pdf2image not installed", error=str(e))
            return [
                OCRResult(
                    blocks=[],
                    full_text="",
                    confidence=0.0,
                    page_count=0,
                    model_name=self.model_name,
                    model_version=self.model_version,
                    metadata={"error": "pdf2image not installed"},
                )
            ]
        except Exception as e:
            logger.error("PDF extraction failed", error=str(e))
            return [
                OCRResult(
                    blocks=[],
                    full_text="",
                    confidence=0.0,
                    page_count=0,
                    model_name=self.model_name,
                    model_version=self.model_version,
                    metadata={"error": str(e)},
                )
            ]

    async def extract_tables(self, image: bytes) -> list[TableData]:
        """Extract tables from an image.

        Args:
            image: Image bytes

        Returns:
            List of TableData with extracted table structures
        """
        start_time = time.time()
        await self._ensure_initialized()

        try:
            # Convert bytes to PIL Image
            img = Image.open(io.BytesIO(image))
            img_array = np.array(img)

            if self._table_engine is None:
                logger.warning("Table engine not initialized")
                return []

            # Run table detection
            result = self._table_engine(img_array)

            tables = []

            # Parse table results
            if result and isinstance(result, list):
                for item in result:
                    if isinstance(item, dict) and "res" in item:
                        table_info = item["res"]

                        # Extract table cells
                        cells = []
                        max_row = 0
                        max_col = 0

                        for row_idx, row_data in enumerate(table_info):
                            if isinstance(row_data, list):
                                for col_idx, cell_data in enumerate(row_data):
                                    if isinstance(cell_data, dict):
                                        text = cell_data.get("text", "")
                                        confidence = cell_data.get("confidence", 1.0)
                                        cell_data.get("bbox")

                                        cell = TableCell(
                                            text=text,
                                            row=row_idx,
                                            col=col_idx,
                                            confidence=confidence,
                                            is_header=(row_idx == 0),
                                        )
                                        cells.append(cell)

                                        max_row = max(max_row, row_idx)
                                        max_col = max(max_col, col_idx)

                        if cells:
                            table = TableData(
                                cells=cells,
                                rows=max_row + 1,
                                cols=max_col + 1,
                                page_number=1,
                            )
                            tables.append(table)

            processing_time_ms = (time.time() - start_time) * 1000
            logger.info(
                "Table extraction completed",
                table_count=len(tables),
                processing_time_ms=processing_time_ms,
            )

            return tables

        except Exception as e:
            logger.error("Table extraction failed", error=str(e))
            return []

    async def health_check(self) -> bool:
        """Check if the service is healthy."""
        try:
            await self._ensure_initialized()
            return self._ocr is not None
        except Exception:
            return False

    def get_expertise_weight(self, capability: Capability) -> float:
        """Get expertise weight for a capability.

        PaddleOCR excels at fast extraction and tables.
        """
        weights = {
            Capability.FAST_EXTRACTION: 0.95,
            Capability.TABLES: 0.85,
            Capability.MULTILINGUAL: 0.75,
            Capability.LONG_DOCUMENTS: 0.70,
            Capability.MULTIPAGE: 0.80,
        }
        return weights.get(capability, 0.0)
