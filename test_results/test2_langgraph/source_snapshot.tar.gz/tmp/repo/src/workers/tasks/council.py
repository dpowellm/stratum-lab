"""Council-related Celery tasks.

These tasks handle the LLM Council voting and consensus processes.

Tasks:
- run_council_extraction: Main task that orchestrates extraction + consensus
- run_council_session: Consensus calculation from existing votes
- collect_member_vote: Get vote from single council member
- collect_member_votes: Collect all votes in parallel
- calculate_consensus: Calculate consensus from votes
- escalate_to_judge: Escalate conflicts to judge model
- flag_for_human_review: Flag document for human review

Pipeline functions (async, testable without Celery):
- run_council_session_pipeline: Full council session with DB persistence
"""

import asyncio
import time
import uuid
from datetime import datetime
from typing import Any
from uuid import uuid4

from celery import group
from celery.utils.log import get_task_logger

from src.config.settings import get_settings
from src.council.consensus import (
    ConflictLevel,
    ConsensusEngine,
    ConsensusResult,
    MemberVote,
    VotingStrategy,
)
from src.council.members.base import CouncilMember, ExtractionResult
from src.workers.celery_app import celery_app

logger = get_task_logger(__name__)


@celery_app.task(
    bind=True,
    name="src.workers.tasks.council.run_council_extraction",
    queue="council",
    max_retries=2,
    default_retry_delay=120,
    time_limit=900,  # 15 minutes
    soft_time_limit=840,  # 14 minutes
)
def run_council_extraction(
    self,
    document_id: str,
    file_key: str,
    document_type: str | None = None,
    critical_fields: list[str] | None = None,
) -> dict[str, Any]:
    """Run council extraction on a document from storage.

    This is the main extraction task that:
    1. Downloads the document from storage
    2. Runs all council members for field extraction
    3. Calculates consensus
    4. Optionally escalates to judge if conflicts remain
    5. Flags for human review if needed

    This is the primary entry point for council-based extraction.

    Args:
        document_id: Document identifier
        file_key: Storage key/path to the document
        document_type: Type of document (invoice, contract, etc.)
        critical_fields: Fields requiring unanimous agreement

    Returns:
        Council extraction result with consensus and flagging

    Raises:
        Retries on failure with exponential backoff
    """
    session_id = str(uuid4())

    logger.info(
        "Starting council extraction",
        extra={
            "session_id": session_id,
            "document_id": document_id,
            "file_key": file_key,
            "document_type": document_type,
            "task_id": self.request.id,
        },
    )

    try:
        # Step 1: Collect votes from all council members in parallel
        # This includes downloading the file and running extraction
        member_tasks = group(
            collect_member_vote.s(
                session_id=session_id,
                document_id=document_id,
                file_key=file_key,
                member_name="paddle_ocr",
                document_type=document_type,
            ),
            collect_member_vote.s(
                session_id=session_id,
                document_id=document_id,
                file_key=file_key,
                member_name="olmocr",
                document_type=document_type,
            ),
            collect_member_vote.s(
                session_id=session_id,
                document_id=document_id,
                file_key=file_key,
                member_name="qwen_vlm",
                document_type=document_type,
            ),
            collect_member_vote.s(
                session_id=session_id,
                document_id=document_id,
                file_key=file_key,
                member_name="colpali",
                document_type=document_type,
            ),
        )

        # Execute member voting in parallel
        logger.info(
            "Collecting votes from council members",
            extra={
                "session_id": session_id,
                "document_id": document_id,
            },
        )
        member_results = member_tasks.apply_async()
        votes = member_results.get(timeout=600)  # 10 minute timeout

        # Step 2: Calculate consensus
        consensus_result = calculate_consensus.delay(
            session_id=session_id,
            votes=votes,
            critical_fields=critical_fields or [],
            voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED.value,
        )

        consensus = consensus_result.get(timeout=60)

        logger.info(
            "Consensus calculated",
            extra={
                "session_id": session_id,
                "conflict_level": consensus.get("conflict_level"),
            },
        )

        # Step 3: Check if judge escalation is needed
        final_result = consensus
        if consensus.get("requires_judge"):
            logger.info(
                "Escalating to judge for conflict resolution",
                extra={
                    "session_id": session_id,
                    "conflict_level": consensus.get("conflict_level"),
                },
            )

            judge_result = escalate_to_judge.delay(
                session_id=session_id,
                document_id=document_id,
                consensus=consensus,
                file_key=file_key,
            )

            final_result = judge_result.get(timeout=180)

        # Step 4: Check if human review is needed
        requires_review = (
            final_result.get("requires_human_review", False)
            or consensus.get("conflict_level") == ConflictLevel.SEVERE.value
        )

        if requires_review:
            logger.info(
                "Flagging for human review",
                extra={
                    "session_id": session_id,
                    "document_id": document_id,
                },
            )

            review_result = flag_for_human_review.delay(
                session_id=session_id,
                document_id=document_id,
                reason=f"Council extraction requires review (conflict level: {consensus.get('conflict_level')})",
                fields=consensus.get("conflicting_fields", []),
            )
            review_result.get(timeout=30)

        return {
            "session_id": session_id,
            "document_id": document_id,
            "status": "extraction_complete",
            "extraction_result": final_result,
            "requires_human_review": requires_review,
            "conflict_level": consensus.get("conflict_level"),
        }

    except Exception as exc:
        logger.error(
            "Council extraction failed",
            extra={
                "session_id": session_id,
                "document_id": document_id,
                "error": str(exc),
            },
        )
        raise self.retry(exc=exc) from exc


@celery_app.task(
    bind=True,
    name="src.workers.tasks.council.run_council_session",
    queue="council",
    max_retries=2,
    default_retry_delay=120,
    time_limit=600,  # 10 minutes
    soft_time_limit=540,  # 9 minutes
)
def run_council_session(
    self,
    document_id: str,
    extracted_text: dict[str, Any],
    document_type: str | None = None,
    critical_fields: list[str] | None = None,
) -> dict[str, Any]:
    """Run a full council session for a document.

    Orchestrates the voting process across all council members,
    collects votes, and calculates consensus.

    Args:
        document_id: Document identifier
        extracted_text: Text extracted from document
        document_type: Type of document (invoice, contract, etc.)
        critical_fields: Fields requiring unanimous agreement

    Returns:
        Council session result with consensus
    """
    session_id = str(uuid4())

    logger.info(
        "Starting council session",
        extra={
            "session_id": session_id,
            "document_id": document_id,
            "document_type": document_type,
            "task_id": self.request.id,
        },
    )

    try:
        # Step 1: Collect votes from all council members in parallel
        member_tasks = group(
            collect_member_vote.s(
                session_id=session_id,
                document_id=document_id,
                extracted_text=extracted_text,
                member_name="paddle_ocr",
            ),
            collect_member_vote.s(
                session_id=session_id,
                document_id=document_id,
                extracted_text=extracted_text,
                member_name="olmocr",
            ),
            collect_member_vote.s(
                session_id=session_id,
                document_id=document_id,
                extracted_text=extracted_text,
                member_name="qwen_vlm",
            ),
            collect_member_vote.s(
                session_id=session_id,
                document_id=document_id,
                extracted_text=extracted_text,
                member_name="colpali",
            ),
        )

        # Execute member voting in parallel
        member_results = member_tasks.apply_async()
        votes = member_results.get(timeout=300)  # 5 minute timeout

        # Step 2: Calculate consensus
        consensus_result = calculate_consensus.delay(
            session_id=session_id,
            votes=votes,
            critical_fields=critical_fields or [],
            voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED.value,
        )

        consensus = consensus_result.get(timeout=60)

        # Step 3: Check if judge escalation is needed
        if consensus.get("requires_judge"):
            logger.info(
                "Escalating to judge model",
                extra={
                    "session_id": session_id,
                    "conflict_level": consensus.get("conflict_level"),
                },
            )

            judge_result = escalate_to_judge.delay(
                session_id=session_id,
                document_id=document_id,
                consensus=consensus,
                extracted_text=extracted_text,
            )

            final_result = judge_result.get(timeout=120)
        else:
            final_result = consensus

        return {
            "session_id": session_id,
            "document_id": document_id,
            "status": "completed",
            "result": final_result,
            "requires_human_review": final_result.get("requires_human_review", False),
        }

    except Exception as exc:
        logger.error(
            "Council session failed",
            extra={
                "session_id": session_id,
                "document_id": document_id,
                "error": str(exc),
            },
        )
        raise self.retry(exc=exc) from exc


@celery_app.task(
    bind=True,
    name="src.workers.tasks.council.collect_member_vote",
    queue="council",
    max_retries=2,
    default_retry_delay=60,
    time_limit=300,  # 5 minutes
    soft_time_limit=270,  # 4.5 minutes
)
def collect_member_vote(
    self,
    session_id: str,
    document_id: str,
    member_name: str,
    file_key: str | None = None,
    _extracted_text: dict[str, Any] | None = None,
    document_type: str | None = None,
) -> dict[str, Any]:
    """Collect vote from a single council member.

    Calls the appropriate OCR/VLM service to extract fields
    and returns votes with confidence scores.

    Supports both:
    - Real extraction: file_key provided, downloads file and extracts
    - Reference extraction: extracted_text provided, reranks existing extraction

    Args:
        session_id: Council session identifier
        document_id: Document identifier
        member_name: Name of the council member
        file_key: Storage key to document (for real extraction)
        _extracted_text: Pre-extracted text (reserved for future use)
        document_type: Type of document (for context)

    Returns:
        Member's votes for each field with confidence scores
    """
    logger.info(
        "Collecting vote from council member",
        extra={
            "session_id": session_id,
            "document_id": document_id,
            "member_name": member_name,
            "has_file": file_key is not None,
            "task_id": self.request.id,
        },
    )

    try:
        # Member-specific extraction would happen here
        # For now, return mock votes

        return {
            "member_name": member_name,
            "session_id": session_id,
            "document_id": document_id,
            "votes": {},  # Would contain field extractions with confidence
            "processing_time_ms": 0,
            "model_version": _get_model_version(member_name),
            "document_type": document_type,
        }

    except Exception as exc:
        logger.error(
            "Failed to collect member vote",
            extra={
                "session_id": session_id,
                "member_name": member_name,
                "error": str(exc),
            },
        )
        raise self.retry(exc=exc) from exc


@celery_app.task(
    name="src.workers.tasks.council.collect_member_votes",
    queue="council",
)
def collect_member_votes(
    session_id: str,
    document_id: str,
    extracted_text: dict[str, Any],
) -> list[dict[str, Any]]:
    """Collect votes from all council members.

    This is a convenience task that wraps the parallel collection.

    Args:
        session_id: Council session identifier
        document_id: Document identifier
        extracted_text: Pre-extracted text

    Returns:
        List of all member votes
    """
    member_tasks = group(
        collect_member_vote.s(
            session_id=session_id,
            document_id=document_id,
            extracted_text=extracted_text,
            member_name=member,
        )
        for member in ["paddle_ocr", "olmocr", "qwen_vlm", "colpali"]
    )

    result = member_tasks.apply_async()
    return result.get(timeout=300)


@celery_app.task(
    name="src.workers.tasks.council.calculate_consensus",
    queue="council",
    time_limit=60,
)
def calculate_consensus(
    session_id: str,
    votes: list[dict[str, Any]],
    critical_fields: list[str] | None = None,
    voting_strategy: str = "confidence_weighted",
) -> dict[str, Any]:
    """Calculate consensus from council member votes.

    Uses the ConsensusEngine to determine agreed values
    and identify conflicts.

    Args:
        session_id: Council session identifier
        votes: List of member votes
        critical_fields: Fields requiring unanimous agreement
        voting_strategy: Strategy for vote calculation

    Returns:
        Consensus result with agreed values and conflicts
    """
    logger.info(
        "Calculating consensus",
        extra={
            "session_id": session_id,
            "num_votes": len(votes),
            "voting_strategy": voting_strategy,
        },
    )

    engine = ConsensusEngine()

    # Convert votes to format expected by engine
    extracted_fields: dict[str, dict[str, MemberVote]] = {}

    for member_vote in votes:
        member_name = member_vote["member_name"]
        for field_name, field_data in member_vote.get("votes", {}).items():
            if field_name not in extracted_fields:
                extracted_fields[field_name] = {}

            extracted_fields[field_name][member_name] = MemberVote(
                member_name=member_name,
                value=field_data.get("value"),
                confidence=field_data.get("confidence", 0.0),
            )

    # Calculate consensus
    strategy = VotingStrategy(voting_strategy)
    result = engine.calculate_consensus(
        session_id=session_id,
        member_results={v["member_name"]: v for v in votes},
        extracted_fields=extracted_fields,
        voting_strategy=strategy,
        critical_fields=critical_fields,
    )

    return result.to_dict()


@celery_app.task(
    bind=True,
    name="src.workers.tasks.council.escalate_to_judge",
    queue="council",
    max_retries=2,
    default_retry_delay=60,
    time_limit=300,  # 5 minutes
    soft_time_limit=270,  # 4.5 minutes
)
def escalate_to_judge(
    self,
    session_id: str,
    document_id: str,
    consensus: dict[str, Any],
    _file_key: str | None = None,
    _extracted_text: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Escalate unresolved conflicts to the judge model.

    Uses a more powerful model (Gemini, GPT-4, Claude) to
    resolve conflicts that couldn't be resolved by consensus.

    Args:
        session_id: Council session identifier
        document_id: Document identifier
        consensus: Current consensus result with conflicts
        _file_key: Storage key to document (reserved for future use)
        _extracted_text: Original extracted text (reserved for future use)

    Returns:
        Updated consensus with judge decisions

    Raises:
        Retries on failure with exponential backoff
    """
    logger.info(
        "Escalating to judge model",
        extra={
            "session_id": session_id,
            "document_id": document_id,
            "conflict_level": consensus.get("conflict_level"),
            "task_id": self.request.id,
        },
    )

    try:
        settings = get_settings()

        # Judge model would process here
        # For now, return the consensus with judge flag
        judge_model = settings.judge.model_name

        return {
            **consensus,
            "judge_invoked": True,
            "judge_model": judge_model,
            "judge_resolution": {},  # Would contain judge's decisions
        }

    except Exception as exc:
        logger.error(
            "Judge escalation failed",
            extra={
                "session_id": session_id,
                "document_id": document_id,
                "error": str(exc),
            },
        )
        raise self.retry(exc=exc) from exc


@celery_app.task(
    name="src.workers.tasks.council.flag_for_human_review",
    queue="council",
)
def flag_for_human_review(
    session_id: str,
    document_id: str,
    reason: str,
    fields: list[str],
) -> dict[str, Any]:
    """Flag a document for human review.

    Called when automated resolution fails or confidence
    is below acceptable thresholds.

    Args:
        session_id: Council session identifier
        document_id: Document identifier
        reason: Reason for flagging
        fields: Fields requiring review

    Returns:
        Review request details
    """
    logger.info(
        "Flagging document for human review",
        extra={
            "session_id": session_id,
            "document_id": document_id,
            "reason": reason,
            "fields": fields,
        },
    )

    return {
        "session_id": session_id,
        "document_id": document_id,
        "status": "pending_review",
        "reason": reason,
        "fields_to_review": fields,
    }


def _get_model_version(member_name: str) -> str:
    """Get model version for a council member."""
    versions = {
        "paddle_ocr": "paddleocr-2.8.0",
        "olmocr": "olmocr-2-7b",
        "qwen_vlm": "qwen2-vl-7b",
        "colpali": "colpali-v1.3",
    }
    return versions.get(member_name, "unknown")


def _record_learning_events(
    consensus: ConsensusResult,
    document_type: str | None,
) -> None:
    """Record learning events from consensus field votes.

    Each member vote is compared against the final consensus value
    to determine correctness, then fed into the learning system.

    Args:
        consensus: The consensus result containing field votes.
        document_type: Document type hint (falls back to ``"unknown"``).
    """
    try:
        from src.council.learning import LearningEvent, get_learning_system

        learning = get_learning_system()
        for fc in consensus.fields:
            for vote in fc.all_votes:
                was_correct = str(vote.value) == str(fc.final_value)
                learning.record_event(
                    LearningEvent(
                        model_name=vote.member_name,
                        document_type=document_type or "unknown",
                        field_name=fc.field_name,
                        was_correct=was_correct,
                        confidence=vote.confidence,
                        timestamp=datetime.utcnow(),
                    )
                )
    except Exception as exc:
        logger.warning("Failed to record learning events", extra={"error": str(exc)})


# ---------------------------------------------------------------------------
# Async pipeline functions (testable without Celery broker)
# ---------------------------------------------------------------------------


async def _collect_member_extraction(
    member: CouncilMember,
    image_data: bytes,
    document_type: str | None = None,
) -> ExtractionResult | None:
    """Run extraction on a single council member, handling failures.

    Args:
        member: Council member instance
        image_data: Document image bytes
        document_type: Document type hint

    Returns:
        ExtractionResult on success, None on failure
    """
    try:
        if not member.is_initialized:
            await member.initialize()
        return await member.extract(
            image_data=image_data,
            document_type=document_type,
        )
    except Exception:
        return None


async def run_council_session_pipeline(
    document_id: str,
    image_data: list[bytes],
    members: list[CouncilMember],
    session,
    document_type: str | None = None,
    critical_fields: list[str] | None = None,
    consensus_threshold: float = 0.85,
) -> dict[str, Any]:
    """Run a full council session with DB persistence.

    This is the async, testable version of the council flow:
    1. Initialize all council members
    2. Run extraction on each member (handling failures)
    3. Build consensus from member votes
    4. Store CouncilSession and MemberVote records in DB
    5. Store Extraction record in DB
    6. Update Document status

    Args:
        document_id: Document UUID string
        image_data: List of page images as bytes
        members: List of CouncilMember instances
        session: Database session
        document_type: Type of document (invoice, etc.)
        critical_fields: Fields requiring unanimous agreement
        consensus_threshold: Minimum consensus score

    Returns:
        Dict with session results, consensus, and status
    """
    from src.models.database.council_session import (
        ConflictLevel as DBConflictLevel,
        CouncilSession as DBCouncilSession,
        VotingStrategy as DBVotingStrategy,
    )
    from src.models.database.document import ProcessingStatus
    from src.services.document.repository import DocumentRepository

    doc_uuid = uuid.UUID(document_id)
    repo = DocumentRepository(session)

    # Update document status
    await repo.update_status(doc_uuid, ProcessingStatus.COUNCIL_DELIBERATING, progress=40)
    await session.commit()

    # Use first page for extraction (multi-page support would iterate)
    primary_image = image_data[0] if image_data else b""

    # Step 1: Run all members concurrently
    start_time = time.time()
    tasks = [_collect_member_extraction(member, primary_image, document_type) for member in members]
    results = await asyncio.gather(*tasks)

    # Separate successes and failures
    successful_results: list[ExtractionResult] = []
    failed_members: list[str] = []
    for member, result in zip(members, results, strict=False):
        if result is not None:
            successful_results.append(result)
        else:
            failed_members.append(member.name)

    # Step 2: Build consensus from successful results
    engine = ConsensusEngine(consensus_threshold=consensus_threshold)
    member_results = {}
    extracted_fields: dict[str, dict[str, MemberVote]] = {}

    for extraction in successful_results:
        member_results[extraction.member_name] = extraction.to_dict()
        votes = extraction.to_votes()
        for field_name, field_data in votes.items():
            if field_name not in extracted_fields:
                extracted_fields[field_name] = {}
            extracted_fields[field_name][extraction.member_name] = MemberVote(
                member_name=extraction.member_name,
                value=field_data["value"],
                confidence=field_data["confidence"],
                processing_time_ms=float(extraction.processing_time_ms),
            )

    participating_members = [r.member_name for r in successful_results]

    consensus = engine.calculate_consensus(
        session_id="pending",  # Will be replaced with DB ID
        member_results=member_results,
        extracted_fields=extracted_fields,
        voting_strategy=VotingStrategy.CONFIDENCE_WEIGHTED,
        critical_fields=critical_fields,
    )

    total_time_ms = (time.time() - start_time) * 1000

    # Step 3: Create CouncilSession DB record
    db_session_record = DBCouncilSession(
        document_id=doc_uuid,
        voting_strategy=DBVotingStrategy.CONFIDENCE_WEIGHTED,
        consensus_threshold=consensus_threshold,
        participating_members=participating_members,
        total_processing_time_ms=total_time_ms,
    )
    session.add(db_session_record)
    await session.flush()
    await session.refresh(db_session_record)

    # Step 4: Store member votes
    for extraction in successful_results:
        votes_dict = extraction.to_votes()
        field_confidences = {f.field_name: f.confidence for f in extraction.fields}
        db_session_record.add_member_vote(
            member_name=extraction.member_name,
            extracted_fields=votes_dict,
            overall_confidence=sum(f.confidence for f in extraction.fields)
            / max(len(extraction.fields), 1),
            field_confidences=field_confidences,
            processing_time_ms=float(extraction.processing_time_ms),
            member_version=extraction.model_version,
        )

    # Store failed member votes with error flag
    for failed_name in failed_members:
        db_session_record.add_member_vote(
            member_name=failed_name,
            extracted_fields={},
            overall_confidence=0.0,
            field_confidences={},
            processing_time_ms=0.0,
        )
        # Mark the vote as errored
        last_vote = db_session_record.member_votes[-1]
        last_vote.had_error = True
        last_vote.error_message = "Extraction failed"

    # Step 5: Record consensus results on the session
    unified_extraction = {f.field_name: f.final_value for f in consensus.fields}
    db_session_record.record_consensus(
        consensus_score=consensus.consensus_score,
        agreed_fields=consensus.agreed_fields,
        disputed_fields=consensus.disputed_fields,
        total_fields=consensus.total_fields,
        unified_extraction=unified_extraction,
        final_confidence=consensus.overall_confidence,
    )

    # Map conflict level
    conflict_map = {
        ConflictLevel.NONE: DBConflictLevel.NONE,
        ConflictLevel.MINOR: DBConflictLevel.MINOR,
        ConflictLevel.MODERATE: DBConflictLevel.MODERATE,
        ConflictLevel.MAJOR: DBConflictLevel.MAJOR,
    }
    db_session_record.conflict_level = conflict_map.get(
        consensus.conflict_level, DBConflictLevel.NONE
    )

    if consensus.requires_human_review:
        db_session_record.flag_for_human_review("Consensus below threshold or major conflict")

    await session.flush()

    # Step 6: Create Extraction record
    extraction_record = await repo.create_extraction(
        document_id=doc_uuid,
        overall_confidence=consensus.overall_confidence,
        extracted_data=unified_extraction,
        council_session_id=db_session_record.id,
    )

    # Step 7: Update document status
    doc = await repo.get_by_id(doc_uuid)
    if doc:
        if consensus.requires_human_review:
            doc.flag_for_human_review("Council requires human review")
        else:
            doc.complete(consensus_score=consensus.consensus_score)
        doc.council_session_id = db_session_record.id
        doc.consensus_score = consensus.consensus_score

    await session.commit()

    # Record learning events from consensus
    _record_learning_events(consensus, document_type)

    return {
        "status": "completed",
        "document_id": document_id,
        "council_session_id": str(db_session_record.id),
        "consensus_score": consensus.consensus_score,
        "overall_confidence": consensus.overall_confidence,
        "agreed_fields": consensus.agreed_fields,
        "disputed_fields": consensus.disputed_fields,
        "total_fields": consensus.total_fields,
        "conflict_level": consensus.conflict_level.value,
        "requires_human_review": consensus.requires_human_review,
        "requires_judge": consensus.requires_judge,
        "failed_members": failed_members,
        "participating_members": participating_members,
        "extraction_id": str(extraction_record.id),
    }
