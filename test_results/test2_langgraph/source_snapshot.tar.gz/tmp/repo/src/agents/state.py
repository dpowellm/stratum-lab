"""Agent State Schema for LangGraph workflow.

Defines the shared state that flows through the agent pipeline
during document processing.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Annotated, Any
from uuid import uuid4

from langgraph.graph import add_messages


class ProcessingStage(StrEnum):
    """Current stage in the processing pipeline."""

    INITIALIZED = "initialized"
    PLANNING = "planning"
    EXTRACTING = "extracting"
    COUNCIL_VOTING = "council_voting"
    CONSENSUS_BUILDING = "consensus_building"
    JUDGE_REVIEWING = "judge_reviewing"
    VALIDATING = "validating"
    CORRECTING = "correcting"
    INDEXING = "indexing"
    COMPLETED = "completed"
    FAILED = "failed"
    HUMAN_REVIEW = "human_review"


class DocumentClassification(StrEnum):
    """Document type classification."""

    INVOICE = "invoice"
    RECEIPT = "receipt"
    CONTRACT = "contract"
    FORM = "form"
    REPORT = "report"
    LETTER = "letter"
    ID_DOCUMENT = "id_document"
    FINANCIAL = "financial"
    MEDICAL = "medical"
    LEGAL = "legal"
    UNKNOWN = "unknown"


@dataclass
class DocumentMetadata:
    """Metadata about the document being processed."""

    document_id: str
    filename: str
    file_type: str
    file_size: int
    page_count: int = 1
    classification: DocumentClassification = DocumentClassification.UNKNOWN
    language: str = "en"
    upload_timestamp: str = ""
    checksum: str = ""
    storage_path: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "document_id": self.document_id,
            "filename": self.filename,
            "file_type": self.file_type,
            "file_size": self.file_size,
            "page_count": self.page_count,
            "classification": self.classification.value,
            "language": self.language,
            "upload_timestamp": self.upload_timestamp,
            "checksum": self.checksum,
            "storage_path": self.storage_path,
        }


@dataclass
class ExtractionField:
    """A single extracted field with metadata."""

    name: str
    value: Any
    confidence: float
    source: str
    page: int = 1
    bounding_box: dict[str, int] | None = None
    alternatives: list[dict[str, Any]] = field(default_factory=list)
    validated: bool = False
    corrected: bool = False
    original_value: Any = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "value": self.value,
            "confidence": self.confidence,
            "source": self.source,
            "page": self.page,
            "bounding_box": self.bounding_box,
            "alternatives": self.alternatives,
            "validated": self.validated,
            "corrected": self.corrected,
            "original_value": self.original_value,
        }


@dataclass
class CouncilVote:
    """A vote from a council member."""

    member_name: str
    field_name: str
    value: Any
    confidence: float
    reasoning: str = ""
    processing_time_ms: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "member_name": self.member_name,
            "field_name": self.field_name,
            "value": self.value,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "processing_time_ms": self.processing_time_ms,
        }


@dataclass
class ConflictResolution:
    """Resolution of a field conflict."""

    field_name: str
    final_value: Any
    resolved_by: str  # consensus, judge, human
    confidence: float
    reasoning: str
    dissenting_votes: list[CouncilVote] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "field_name": self.field_name,
            "final_value": self.final_value,
            "resolved_by": self.resolved_by,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "dissenting_votes": [v.to_dict() for v in self.dissenting_votes],
        }


@dataclass
class ValidationResult:
    """Result of field validation."""

    field_name: str
    is_valid: bool
    validation_type: str  # format, range, business_rule, cross_reference
    error_message: str = ""
    suggested_correction: Any = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "field_name": self.field_name,
            "is_valid": self.is_valid,
            "validation_type": self.validation_type,
            "error_message": self.error_message,
            "suggested_correction": self.suggested_correction,
        }


@dataclass
class ProcessingMetrics:
    """Metrics for the processing pipeline."""

    start_time: datetime = field(default_factory=datetime.utcnow)
    end_time: datetime | None = None
    stage_times: dict[str, int] = field(default_factory=dict)  # stage -> ms
    total_api_calls: int = 0
    total_tokens_used: int = 0
    retries: int = 0
    errors: list[str] = field(default_factory=list)

    @property
    def total_processing_time_ms(self) -> int:
        if self.end_time:
            return int((self.end_time - self.start_time).total_seconds() * 1000)
        return int((datetime.utcnow() - self.start_time).total_seconds() * 1000)

    def to_dict(self) -> dict[str, Any]:
        return {
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "total_processing_time_ms": self.total_processing_time_ms,
            "stage_times": self.stage_times,
            "total_api_calls": self.total_api_calls,
            "total_tokens_used": self.total_tokens_used,
            "retries": self.retries,
            "errors": self.errors,
        }


@dataclass
class AgentState:
    """Shared state for the agent workflow.

    This state is passed between agents in the LangGraph pipeline.
    """

    # Session info
    session_id: str = field(default_factory=lambda: str(uuid4()))

    # Current stage
    stage: ProcessingStage = ProcessingStage.INITIALIZED

    # Document info
    document: DocumentMetadata | None = None
    raw_image_data: bytes | None = None
    extracted_text: str = ""

    # Processing plan
    processing_plan: dict[str, Any] = field(default_factory=dict)
    target_fields: list[str] = field(default_factory=list)
    critical_fields: list[str] = field(default_factory=list)

    # Council voting
    council_votes: list[CouncilVote] = field(default_factory=list)
    voting_strategy: str = "confidence_weighted"
    consensus_threshold: float = 0.85

    # Extraction results
    extracted_fields: list[ExtractionField] = field(default_factory=list)
    conflict_resolutions: list[ConflictResolution] = field(default_factory=list)

    # Validation
    validation_results: list[ValidationResult] = field(default_factory=list)
    requires_correction: bool = False

    # Output
    final_extraction: dict[str, Any] = field(default_factory=dict)
    confidence_score: float = 0.0

    # Human review
    requires_human_review: bool = False
    human_review_reason: str = ""
    human_review_fields: list[str] = field(default_factory=list)

    # Metrics
    metrics: ProcessingMetrics = field(default_factory=ProcessingMetrics)

    # Messages (for LangGraph)
    messages: Annotated[list, add_messages] = field(default_factory=list)

    # Error handling
    error: str | None = None
    error_stage: ProcessingStage | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert state to dictionary for serialization."""
        return {
            "session_id": self.session_id,
            "stage": self.stage.value,
            "document": self.document.to_dict() if self.document else None,
            "processing_plan": self.processing_plan,
            "target_fields": self.target_fields,
            "critical_fields": self.critical_fields,
            "council_votes": [v.to_dict() for v in self.council_votes],
            "voting_strategy": self.voting_strategy,
            "consensus_threshold": self.consensus_threshold,
            "extracted_fields": [f.to_dict() for f in self.extracted_fields],
            "conflict_resolutions": [r.to_dict() for r in self.conflict_resolutions],
            "validation_results": [v.to_dict() for v in self.validation_results],
            "requires_correction": self.requires_correction,
            "final_extraction": self.final_extraction,
            "confidence_score": self.confidence_score,
            "requires_human_review": self.requires_human_review,
            "human_review_reason": self.human_review_reason,
            "human_review_fields": self.human_review_fields,
            "metrics": self.metrics.to_dict(),
            "error": self.error,
            "error_stage": self.error_stage.value if self.error_stage else None,
        }

    def get_field(self, name: str) -> ExtractionField | None:
        """Get an extracted field by name."""
        for ext_field in self.extracted_fields:
            if ext_field.name == name:
                return ext_field
        return None

    def get_votes_for_field(self, name: str) -> list[CouncilVote]:
        """Get all council votes for a specific field."""
        return [v for v in self.council_votes if v.field_name == name]

    def update_stage(self, stage: ProcessingStage, elapsed_ms: int = 0) -> None:
        """Update the processing stage and record timing."""
        if elapsed_ms > 0:
            self.metrics.stage_times[self.stage.value] = elapsed_ms
        self.stage = stage

    def add_error(self, error: str) -> None:
        """Add an error to the metrics."""
        self.metrics.errors.append(error)
        self.error = error
        self.error_stage = self.stage

    def mark_completed(self) -> None:
        """Mark processing as completed."""
        self.stage = ProcessingStage.COMPLETED
        self.metrics.end_time = datetime.utcnow()

    def mark_failed(self, error: str) -> None:
        """Mark processing as failed."""
        self.add_error(error)
        self.stage = ProcessingStage.FAILED
        self.metrics.end_time = datetime.utcnow()

    def mark_for_human_review(self, reason: str, fields: list[str]) -> None:
        """Mark for human review."""
        self.requires_human_review = True
        self.human_review_reason = reason
        self.human_review_fields = fields
        self.stage = ProcessingStage.HUMAN_REVIEW


# Type aliases for LangGraph
StateType = dict[str, Any]


def state_to_dict(state: AgentState) -> StateType:
    """Convert AgentState to dict for LangGraph."""
    return state.to_dict()


def dict_to_state(data: StateType) -> AgentState:
    """Convert dict to AgentState from LangGraph."""
    state = AgentState()

    state.session_id = data.get("session_id", state.session_id)
    state.stage = ProcessingStage(data.get("stage", "initialized"))

    # Restore document metadata
    if data.get("document"):
        doc_data = data["document"]
        state.document = DocumentMetadata(
            document_id=doc_data["document_id"],
            filename=doc_data["filename"],
            file_type=doc_data["file_type"],
            file_size=doc_data["file_size"],
            page_count=doc_data.get("page_count", 1),
            classification=DocumentClassification(doc_data.get("classification", "unknown")),
            language=doc_data.get("language", "en"),
            upload_timestamp=doc_data.get("upload_timestamp", ""),
            checksum=doc_data.get("checksum", ""),
            storage_path=doc_data.get("storage_path", ""),
        )

    state.processing_plan = data.get("processing_plan", {})
    state.target_fields = data.get("target_fields", [])
    state.critical_fields = data.get("critical_fields", [])
    state.voting_strategy = data.get("voting_strategy", "confidence_weighted")
    state.consensus_threshold = data.get("consensus_threshold", 0.85)

    # Restore council votes
    for vote_data in data.get("council_votes", []):
        state.council_votes.append(
            CouncilVote(
                member_name=vote_data["member_name"],
                field_name=vote_data["field_name"],
                value=vote_data["value"],
                confidence=vote_data["confidence"],
                reasoning=vote_data.get("reasoning", ""),
                processing_time_ms=vote_data.get("processing_time_ms", 0),
            )
        )

    # Restore extracted fields
    for field_data in data.get("extracted_fields", []):
        state.extracted_fields.append(
            ExtractionField(
                name=field_data["name"],
                value=field_data["value"],
                confidence=field_data["confidence"],
                source=field_data["source"],
                page=field_data.get("page", 1),
                bounding_box=field_data.get("bounding_box"),
                alternatives=field_data.get("alternatives", []),
                validated=field_data.get("validated", False),
                corrected=field_data.get("corrected", False),
                original_value=field_data.get("original_value"),
            )
        )

    state.final_extraction = data.get("final_extraction", {})
    state.confidence_score = data.get("confidence_score", 0.0)
    state.requires_human_review = data.get("requires_human_review", False)
    state.human_review_reason = data.get("human_review_reason", "")
    state.human_review_fields = data.get("human_review_fields", [])
    state.error = data.get("error")

    return state
