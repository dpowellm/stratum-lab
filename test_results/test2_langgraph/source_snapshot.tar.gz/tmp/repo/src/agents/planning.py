"""Planning Agent for document processing workflow.

The Planning Agent analyzes documents and creates an extraction plan:
- Classifies the document type
- Identifies target fields based on document type
- Determines which council members to invoke
- Sets confidence thresholds and voting strategy
"""

import time
from typing import Any

from src.agents.state import (
    AgentState,
    DocumentClassification,
    ProcessingStage,
)
from src.core.logging import get_logger

logger = get_logger(__name__)


# Document type to target fields mapping
DOCUMENT_FIELD_TEMPLATES = {
    DocumentClassification.INVOICE: {
        "fields": [
            "invoice_number",
            "invoice_date",
            "due_date",
            "vendor_name",
            "vendor_address",
            "customer_name",
            "customer_address",
            "subtotal",
            "tax_amount",
            "total_amount",
            "currency",
            "payment_terms",
            "line_items",
        ],
        "critical_fields": ["invoice_number", "total_amount", "vendor_name"],
        "voting_strategy": "confidence_weighted",
        "consensus_threshold": 0.85,
        "field_weights": {
            "total_amount": 2.5,
            "invoice_number": 2.0,
            "subtotal": 1.8,
            "tax_amount": 1.5,
            "vendor_name": 1.5,
            "invoice_date": 1.3,
            "due_date": 1.0,
            "customer_name": 1.0,
            "currency": 0.8,
            "payment_terms": 0.8,
            "vendor_address": 0.6,
            "customer_address": 0.6,
            "line_items": 1.5,
        },
    },
    DocumentClassification.RECEIPT: {
        "fields": [
            "merchant_name",
            "merchant_address",
            "date",
            "time",
            "subtotal",
            "tax",
            "total",
            "payment_method",
            "card_last_four",
            "line_items",
        ],
        "critical_fields": ["total", "merchant_name", "date"],
        "voting_strategy": "confidence_weighted",
        "consensus_threshold": 0.80,
        "field_weights": {
            "total": 2.5,
            "merchant_name": 2.0,
            "date": 1.5,
            "subtotal": 1.5,
            "tax": 1.3,
            "payment_method": 1.0,
            "time": 0.8,
            "card_last_four": 0.8,
            "merchant_address": 0.6,
            "line_items": 1.2,
        },
    },
    DocumentClassification.CONTRACT: {
        "fields": [
            "contract_title",
            "contract_date",
            "effective_date",
            "expiration_date",
            "party_a_name",
            "party_a_address",
            "party_b_name",
            "party_b_address",
            "contract_value",
            "payment_terms",
            "governing_law",
            "signatures",
        ],
        "critical_fields": ["contract_date", "party_a_name", "party_b_name", "contract_value"],
        "voting_strategy": "unanimous",
        "consensus_threshold": 0.90,
        "field_weights": {
            "contract_value": 2.5,
            "party_a_name": 2.0,
            "party_b_name": 2.0,
            "contract_date": 1.8,
            "effective_date": 1.5,
            "expiration_date": 1.5,
            "payment_terms": 1.2,
            "governing_law": 1.0,
            "contract_title": 0.8,
            "signatures": 1.0,
            "party_a_address": 0.6,
            "party_b_address": 0.6,
        },
    },
    DocumentClassification.FORM: {
        "fields": [],  # Dynamic based on form structure
        "critical_fields": [],
        "voting_strategy": "confidence_weighted",
        "consensus_threshold": 0.85,
    },
    DocumentClassification.ID_DOCUMENT: {
        "fields": [
            "full_name",
            "date_of_birth",
            "document_number",
            "issue_date",
            "expiration_date",
            "issuing_authority",
            "nationality",
            "address",
            "photo",
        ],
        "critical_fields": ["full_name", "document_number", "date_of_birth"],
        "voting_strategy": "unanimous",
        "field_weights": {
            "document_number": 2.5,
            "full_name": 2.0,
            "date_of_birth": 2.0,
            "expiration_date": 1.5,
            "issue_date": 1.3,
            "issuing_authority": 1.0,
            "nationality": 0.8,
            "address": 0.6,
            "photo": 0.5,
        },
        "consensus_threshold": 0.95,
    },
    DocumentClassification.FINANCIAL: {
        "fields": [
            "account_number",
            "account_holder",
            "statement_date",
            "opening_balance",
            "closing_balance",
            "total_credits",
            "total_debits",
            "transactions",
        ],
        "critical_fields": ["account_number", "closing_balance"],
        "voting_strategy": "confidence_weighted",
        "consensus_threshold": 0.90,
        "field_weights": {
            "closing_balance": 2.5,
            "account_number": 2.0,
            "opening_balance": 1.8,
            "total_credits": 1.5,
            "total_debits": 1.5,
            "statement_date": 1.3,
            "account_holder": 1.0,
            "transactions": 1.2,
        },
    },
    DocumentClassification.UNKNOWN: {
        "fields": [],  # Will be determined dynamically
        "critical_fields": [],
        "voting_strategy": "confidence_weighted",
        "consensus_threshold": 0.85,
    },
}


class PlanningAgent:
    """Planning Agent for document processing.

    Analyzes documents and creates extraction plans.
    """

    def __init__(
        self,
        classifier_model: str | None = None,
        default_threshold: float = 0.85,
    ):
        """Initialize Planning Agent.

        Args:
            classifier_model: Model for document classification (optional)
            default_threshold: Default consensus threshold
        """
        self._classifier_model = classifier_model
        self._default_threshold = default_threshold

    async def plan(self, state: AgentState) -> AgentState:
        """Create an extraction plan for the document.

        Args:
            state: Current agent state

        Returns:
            Updated state with processing plan
        """
        start_time = time.time()

        logger.info(
            "Planning extraction",
            session_id=state.session_id,
            document_id=state.document.document_id if state.document else None,
        )

        state.update_stage(ProcessingStage.PLANNING)

        try:
            # Step 1: Classify document type
            classification = await self._classify_document(state)

            if state.document:
                state.document.classification = classification

            # Step 2: Get field template for document type
            template = DOCUMENT_FIELD_TEMPLATES.get(
                classification,
                DOCUMENT_FIELD_TEMPLATES[DocumentClassification.UNKNOWN],
            )

            # Step 3: Build processing plan
            plan = {
                "classification": classification.value,
                "extraction_strategy": self._determine_extraction_strategy(state, classification),
                "council_members": self._select_council_members(classification),
                "preprocessing": self._determine_preprocessing(state),
                "postprocessing": self._determine_postprocessing(classification),
            }

            state.processing_plan = plan
            state.target_fields = template["fields"]
            state.critical_fields = template["critical_fields"]
            state.voting_strategy = template["voting_strategy"]
            state.consensus_threshold = template["consensus_threshold"]

            elapsed_ms = int((time.time() - start_time) * 1000)
            state.update_stage(ProcessingStage.EXTRACTING, elapsed_ms)

            logger.info(
                "Extraction plan created",
                session_id=state.session_id,
                classification=classification.value,
                num_fields=len(state.target_fields),
                elapsed_ms=elapsed_ms,
            )

            return state

        except Exception as e:
            logger.error(
                "Planning failed",
                session_id=state.session_id,
                error=str(e),
            )
            state.add_error(f"Planning failed: {e}")
            return state

    async def _classify_document(
        self,
        state: AgentState,
    ) -> DocumentClassification:
        """Classify the document type.

        Uses file type hints and optional ML classifier.
        """
        # Simple heuristic classification based on file type and content
        if state.document:
            filename = state.document.filename.lower()

            # Check filename patterns
            if any(x in filename for x in ["invoice", "inv"]):
                return DocumentClassification.INVOICE
            elif any(x in filename for x in ["receipt", "rcpt"]):
                return DocumentClassification.RECEIPT
            elif any(x in filename for x in ["contract", "agreement"]):
                return DocumentClassification.CONTRACT
            elif any(x in filename for x in ["form", "application"]):
                return DocumentClassification.FORM
            elif any(x in filename for x in ["passport", "license", "id"]):
                return DocumentClassification.ID_DOCUMENT
            elif any(x in filename for x in ["statement", "bank", "financial"]):
                return DocumentClassification.FINANCIAL

        # If we have extracted text, try to classify from content
        if state.extracted_text:
            text_lower = state.extracted_text.lower()

            if "invoice" in text_lower and "total" in text_lower:
                return DocumentClassification.INVOICE
            elif "receipt" in text_lower or "thank you for your purchase" in text_lower:
                return DocumentClassification.RECEIPT
            elif "agreement" in text_lower or "whereas" in text_lower:
                return DocumentClassification.CONTRACT

        # Default to unknown — try VLM fallback for ambiguous documents
        classification = DocumentClassification.UNKNOWN

        if classification == DocumentClassification.UNKNOWN and state.extracted_text:
            classification = await self._vlm_classify(state.extracted_text)

        return classification

    async def _vlm_classify(self, text: str) -> "DocumentClassification":
        """Use VLM to classify ambiguous documents.

        Falls back to UNKNOWN if VLM is not available.
        """
        try:
            from src.config.settings import get_settings
            from src.council.members.factory import create_council_members

            settings = get_settings()
            members = create_council_members(settings, use_mock=False)

            if not members:
                return DocumentClassification.UNKNOWN

            # Use fastest available member
            member = members[0]
            if not member.is_initialized:
                await member.initialize()

            # Use text-based classification prompt
            prompt_text = (
                "Classify this document into one of: invoice, receipt, contract,"
                " form, id_document, financial."
                f" Document text: {text[:500]}"
            )

            result = await member.extract(
                prompt_text.encode("utf-8"),
                document_type=None,
                options={"classification_mode": True},
            )

            # Try to map result to classification
            for extracted_field in result.fields:
                val = str(extracted_field.value).lower()
                for cls in DocumentClassification:
                    if cls.value in val:
                        return cls

            return DocumentClassification.UNKNOWN
        except Exception:
            return DocumentClassification.UNKNOWN

    def _determine_extraction_strategy(
        self,
        _state: AgentState,
        classification: DocumentClassification,
    ) -> dict[str, Any]:
        """Determine the extraction strategy."""
        strategy = {
            "use_ocr": True,
            "use_layout_analysis": True,
            "use_table_extraction": True,
            "parallel_extraction": True,
            "retry_on_low_confidence": True,
            "max_retries": 2,
        }

        # Adjust based on document type
        if classification == DocumentClassification.CONTRACT:
            strategy["use_layout_analysis"] = True
            strategy["focus_on_sections"] = True

        elif classification == DocumentClassification.ID_DOCUMENT:
            strategy["use_face_detection"] = True
            strategy["use_mrz_reader"] = True  # Machine Readable Zone

        elif classification in (DocumentClassification.INVOICE, DocumentClassification.RECEIPT):
            strategy["use_table_extraction"] = True
            strategy["extract_line_items"] = True

        return strategy

    def _select_council_members(
        self,
        classification: DocumentClassification,
    ) -> list[str]:
        """Select which council members to use."""
        # Default: all members
        members = ["paddle_ocr", "olmocr", "qwen_vlm", "colpali"]

        # For speed-critical simple documents, might use fewer
        if classification == DocumentClassification.RECEIPT:
            members = ["paddle_ocr", "olmocr"]

        # For complex documents, always use full council
        if classification in (
            DocumentClassification.CONTRACT,
            DocumentClassification.ID_DOCUMENT,
            DocumentClassification.LEGAL,
        ):
            members = ["paddle_ocr", "olmocr", "qwen_vlm", "colpali"]

        return members

    def _determine_preprocessing(
        self,
        state: AgentState,
    ) -> list[str]:
        """Determine preprocessing steps."""
        steps = []

        if state.document:
            file_type = state.document.file_type

            if file_type == "application/pdf":
                steps.append("pdf_to_images")

            if file_type in ("image/tiff",):
                steps.append("tiff_to_images")

        # Common preprocessing
        steps.extend(
            [
                "deskew",
                "normalize_contrast",
                "remove_noise",
            ]
        )

        return steps

    def _determine_postprocessing(
        self,
        classification: DocumentClassification,
    ) -> list[str]:
        """Determine postprocessing steps."""
        steps = ["normalize_whitespace", "format_numbers"]

        if classification == DocumentClassification.INVOICE:
            steps.extend(
                [
                    "validate_totals",
                    "normalize_currency",
                    "extract_dates",
                ]
            )

        elif classification == DocumentClassification.CONTRACT:
            steps.extend(
                [
                    "extract_dates",
                    "normalize_names",
                    "identify_parties",
                ]
            )

        elif classification == DocumentClassification.ID_DOCUMENT:
            steps.extend(
                [
                    "validate_document_number",
                    "validate_dates",
                    "format_names",
                ]
            )

        return steps


# LangGraph node function
async def planning_node(state: dict[str, Any]) -> dict[str, Any]:
    """LangGraph node for planning.

    Args:
        state: Current graph state

    Returns:
        Updated state dict
    """
    from src.agents.state import dict_to_state, state_to_dict

    agent_state = dict_to_state(state)
    agent = PlanningAgent()

    updated_state = await agent.plan(agent_state)

    return state_to_dict(updated_state)
