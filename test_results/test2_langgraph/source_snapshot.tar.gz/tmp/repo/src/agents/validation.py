"""Validation Agent for extracted field validation.

The Validation Agent validates extracted fields against:
- Format rules (date formats, number formats, etc.)
- Business rules (totals must add up, dates must be in order)
- Cross-field validation (referenced fields must exist)
- Document-specific rules
"""

import re
import time
from collections.abc import Callable
from typing import Any

from src.agents.state import (
    AgentState,
    DocumentClassification,
    ProcessingStage,
    ValidationResult,
)
from src.core.logging import get_logger

logger = get_logger(__name__)


# Validation rule type
ValidationRule = Callable[[Any, AgentState], ValidationResult]


class ValidationAgent:
    """Validation Agent for field validation."""

    def __init__(self):
        """Initialize Validation Agent."""
        self._rules: dict[str, list[ValidationRule]] = {}
        self._format_validators: dict[str, Callable] = {
            "date": self._validate_date,
            "currency": self._validate_currency,
            "email": self._validate_email,
            "phone": self._validate_phone,
            "number": self._validate_number,
        }

    async def validate(self, state: AgentState) -> AgentState:
        """Validate all extracted fields.

        Args:
            state: State with extracted fields

        Returns:
            Updated state with validation results
        """
        start_time = time.time()

        logger.info(
            "Starting field validation",
            session_id=state.session_id,
            num_fields=len(state.extracted_fields),
        )

        state.update_stage(ProcessingStage.VALIDATING)

        try:
            validation_results = []
            requires_correction = False

            # Get document-specific rules
            doc_rules = self._get_document_rules(
                state.document.classification if state.document else DocumentClassification.UNKNOWN
            )

            # Validate each field
            for field in state.extracted_fields:
                field_results = []

                # Format validation
                format_result = self._validate_field_format(field.name, field.value)
                if format_result:
                    field_results.append(format_result)
                    if not format_result.is_valid:
                        requires_correction = True

                # Document-specific rules
                for rule_name, rule_func in doc_rules.items():
                    if rule_name.startswith(field.name) or rule_name == "cross_field":
                        result = rule_func(field, state)
                        if result:
                            field_results.append(result)
                            if not result.is_valid:
                                requires_correction = True

                validation_results.extend(field_results)

            # Cross-field validation
            cross_field_results = self._validate_cross_fields(state)
            validation_results.extend(cross_field_results)

            for result in cross_field_results:
                if not result.is_valid:
                    requires_correction = True

            state.validation_results = validation_results
            state.requires_correction = requires_correction

            # Update field validation status
            for field in state.extracted_fields:
                field_valid = all(
                    r.is_valid for r in validation_results if r.field_name == field.name
                )
                field.validated = field_valid

            elapsed_ms = int((time.time() - start_time) * 1000)

            if requires_correction:
                state.update_stage(ProcessingStage.CORRECTING, elapsed_ms)
            else:
                state.update_stage(ProcessingStage.COMPLETED, elapsed_ms)

            logger.info(
                "Validation completed",
                session_id=state.session_id,
                total_validations=len(validation_results),
                requires_correction=requires_correction,
                elapsed_ms=elapsed_ms,
            )

            return state

        except Exception as e:
            logger.error(
                "Validation failed",
                session_id=state.session_id,
                error=str(e),
            )
            state.add_error(f"Validation failed: {e}")
            return state

    def _validate_field_format(
        self,
        field_name: str,
        value: Any,
    ) -> ValidationResult | None:
        """Validate field format based on field name."""
        if value is None:
            return None

        # Determine expected format from field name
        field_lower = field_name.lower()

        if "date" in field_lower:
            return self._validate_date(field_name, value)

        elif any(x in field_lower for x in ["amount", "total", "price", "cost", "subtotal", "tax"]):
            return self._validate_currency(field_name, value)

        elif "email" in field_lower:
            return self._validate_email(field_name, value)

        elif "phone" in field_lower or "tel" in field_lower:
            return self._validate_phone(field_name, value)

        return None

    def _validate_date(self, field_name: str, value: Any) -> ValidationResult:
        """Validate date format."""
        if not value:
            return ValidationResult(
                field_name=field_name,
                is_valid=True,
                validation_type="format",
            )

        value_str = str(value)

        # Try common date formats
        date_patterns = [
            r"\d{4}-\d{2}-\d{2}",  # YYYY-MM-DD
            r"\d{2}/\d{2}/\d{4}",  # MM/DD/YYYY
            r"\d{2}-\d{2}-\d{4}",  # MM-DD-YYYY
            r"\d{1,2}/\d{1,2}/\d{2,4}",  # M/D/YY or M/D/YYYY
            r"[A-Z][a-z]+ \d{1,2},? \d{4}",  # Month DD, YYYY
        ]

        for pattern in date_patterns:
            if re.match(pattern, value_str):
                return ValidationResult(
                    field_name=field_name,
                    is_valid=True,
                    validation_type="format",
                )

        return ValidationResult(
            field_name=field_name,
            is_valid=False,
            validation_type="format",
            error_message=f"Invalid date format: {value}",
            suggested_correction=None,
        )

    def _validate_currency(self, field_name: str, value: Any) -> ValidationResult:
        """Validate currency/money format."""
        if not value:
            return ValidationResult(
                field_name=field_name,
                is_valid=True,
                validation_type="format",
            )

        value_str = str(value)

        # Currency patterns
        currency_pattern = r"^[$€£¥]?\s*[\d,]+\.?\d*$|^\d+\.?\d*\s*[$€£¥]?$"

        if re.match(currency_pattern, value_str.strip()):
            return ValidationResult(
                field_name=field_name,
                is_valid=True,
                validation_type="format",
            )

        return ValidationResult(
            field_name=field_name,
            is_valid=False,
            validation_type="format",
            error_message=f"Invalid currency format: {value}",
        )

    def _validate_email(self, field_name: str, value: Any) -> ValidationResult:
        """Validate email format."""
        if not value:
            return ValidationResult(
                field_name=field_name,
                is_valid=True,
                validation_type="format",
            )

        email_pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"

        if re.match(email_pattern, str(value).strip()):
            return ValidationResult(
                field_name=field_name,
                is_valid=True,
                validation_type="format",
            )

        return ValidationResult(
            field_name=field_name,
            is_valid=False,
            validation_type="format",
            error_message=f"Invalid email format: {value}",
        )

    def _validate_phone(self, field_name: str, value: Any) -> ValidationResult:
        """Validate phone number format."""
        if not value:
            return ValidationResult(
                field_name=field_name,
                is_valid=True,
                validation_type="format",
            )

        # Remove common separators and check for digits
        digits = re.sub(r"[\s\-\(\)\+\.]", "", str(value))

        if digits.isdigit() and 7 <= len(digits) <= 15:
            return ValidationResult(
                field_name=field_name,
                is_valid=True,
                validation_type="format",
            )

        return ValidationResult(
            field_name=field_name,
            is_valid=False,
            validation_type="format",
            error_message=f"Invalid phone format: {value}",
        )

    def _validate_number(self, field_name: str, value: Any) -> ValidationResult:
        """Validate number format."""
        if not value:
            return ValidationResult(
                field_name=field_name,
                is_valid=True,
                validation_type="format",
            )

        try:
            # Remove currency symbols and commas
            cleaned = re.sub(r"[$€£¥,]", "", str(value))
            float(cleaned)
            return ValidationResult(
                field_name=field_name,
                is_valid=True,
                validation_type="format",
            )
        except ValueError:
            return ValidationResult(
                field_name=field_name,
                is_valid=False,
                validation_type="format",
                error_message=f"Invalid number format: {value}",
            )

    def _get_document_rules(
        self,
        classification: DocumentClassification,
    ) -> dict[str, Callable]:
        """Get validation rules for a document type."""
        rules = {}

        if classification == DocumentClassification.INVOICE:
            rules["cross_field"] = self._validate_invoice_totals
            rules["invoice_number"] = self._validate_invoice_number
            rules["due_date"] = self._validate_due_date

        elif classification == DocumentClassification.RECEIPT:
            rules["cross_field"] = self._validate_receipt_totals

        elif classification == DocumentClassification.CONTRACT:
            rules["cross_field"] = self._validate_contract_dates

        return rules

    def _validate_invoice_totals(self, field, state: AgentState) -> ValidationResult | None:
        """Validate that invoice totals add up."""
        subtotal = None
        tax = None
        total = None

        for f in state.extracted_fields:
            if "subtotal" in f.name.lower():
                subtotal = self._parse_currency(f.value)
            elif "tax" in f.name.lower() and "total" not in f.name.lower():
                tax = self._parse_currency(f.value)
            elif f.name.lower() in ("total", "total_amount"):
                total = self._parse_currency(f.value)

        if subtotal is not None and tax is not None and total is not None:
            expected = subtotal + tax
            if abs(expected - total) > 0.01:
                return ValidationResult(
                    field_name="total_amount",
                    is_valid=False,
                    validation_type="business_rule",
                    error_message=f"Total ({total}) doesn't match subtotal + tax ({expected})",
                    suggested_correction=expected,
                )

        return None

    def _validate_receipt_totals(self, field, state: AgentState) -> ValidationResult | None:
        """Validate receipt totals."""
        return self._validate_invoice_totals(field, state)

    def _validate_contract_dates(self, field, state: AgentState) -> ValidationResult | None:
        """Validate contract date sequence."""
        effective_date = None
        expiration_date = None

        for f in state.extracted_fields:
            if "effective" in f.name.lower():
                effective_date = f.value
            elif "expir" in f.name.lower():
                expiration_date = f.value

        if effective_date and expiration_date:
            # Simple string comparison for dates in ISO format
            if str(effective_date) > str(expiration_date):
                return ValidationResult(
                    field_name="expiration_date",
                    is_valid=False,
                    validation_type="business_rule",
                    error_message="Expiration date is before effective date",
                )

        return None

    def _validate_invoice_number(self, field, state: AgentState) -> ValidationResult | None:
        """Validate invoice number format."""
        if not field.value:
            return ValidationResult(
                field_name="invoice_number",
                is_valid=False,
                validation_type="required",
                error_message="Invoice number is required",
            )
        return None

    def _validate_due_date(self, field, state: AgentState) -> ValidationResult | None:
        """Validate due date is after invoice date."""
        invoice_date = None
        due_date = None

        for f in state.extracted_fields:
            if f.name == "invoice_date":
                invoice_date = f.value
            elif f.name == "due_date":
                due_date = f.value

        if invoice_date and due_date and str(due_date) < str(invoice_date):
            return ValidationResult(
                field_name="due_date",
                is_valid=False,
                validation_type="business_rule",
                error_message="Due date is before invoice date",
            )

        return None

    def _validate_cross_fields(self, state: AgentState) -> list[ValidationResult]:
        """Run cross-field validations."""
        results = []

        # Check required fields based on document type
        if state.document:
            classification = state.document.classification
            required = self._get_required_fields(classification)

            field_names = {f.name for f in state.extracted_fields}

            for req_field in required:
                if req_field not in field_names:
                    results.append(
                        ValidationResult(
                            field_name=req_field,
                            is_valid=False,
                            validation_type="required",
                            error_message=f"Required field '{req_field}' is missing",
                        )
                    )

        return results

    def _get_required_fields(self, classification: DocumentClassification) -> list[str]:
        """Get required fields for a document type."""
        required = {
            DocumentClassification.INVOICE: ["invoice_number", "total_amount"],
            DocumentClassification.RECEIPT: ["total", "date"],
            DocumentClassification.CONTRACT: ["contract_date", "party_a_name", "party_b_name"],
            DocumentClassification.ID_DOCUMENT: ["full_name", "document_number"],
        }
        return required.get(classification, [])

    def _parse_currency(self, value: Any) -> float | None:
        """Parse a currency string to float."""
        if value is None:
            return None
        try:
            cleaned = re.sub(r"[$€£¥,]", "", str(value))
            return float(cleaned)
        except (ValueError, TypeError):
            return None


# LangGraph node function
async def validation_node(state: dict[str, Any]) -> dict[str, Any]:
    """LangGraph node for validation."""
    from src.agents.state import dict_to_state, state_to_dict

    agent_state = dict_to_state(state)
    agent = ValidationAgent()

    updated_state = await agent.validate(agent_state)

    return state_to_dict(updated_state)
