"""
Agentic Document Extraction System

An enterprise-grade document extraction system leveraging LLM Council Architecture
where multiple AI models collaborate, deliberate, and reach consensus on document
extraction tasks.
"""

__version__ = "0.1.0"
__author__ = "Development Team"
