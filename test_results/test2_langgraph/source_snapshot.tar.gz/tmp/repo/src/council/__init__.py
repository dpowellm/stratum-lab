"""LLM Council module for document extraction.

This module implements the multi-model council architecture where
multiple OCR/VLM models "vote" on extracted fields to achieve
high accuracy through consensus.

Council Members:
- PaddleOCR: Speed Expert - Fast, local OCR
- olmOCR: Efficiency Expert - Purpose-built OCR (qwen2vl architecture)
- Qwen VLM: Reasoning Expert - Multi-modal understanding

The ConsensusEngine determines final values based on voting
strategies and confidence thresholds. The CouncilOrchestrator
coordinates all aspects of council deliberation from parallel
extraction through final synthesis.
"""

# Consensus
# Conflict Resolution
from src.council.conflict_resolver import (
    ConflictDetail,
    ConflictResolver,
    ResolutionResult,
    ResolutionStrategy,
)
from src.council.consensus import (
    ConflictLevel,
    ConsensusEngine,
    ConsensusResult,
    FieldConsensus,
    MemberVote,
    VotingStrategy,
    get_consensus_engine,
)

# Judge
from src.council.judge import (
    ConflictContext,
    GeminiJudge,
    JudgeDecision,
    JudgeInterface,
    JudgeModel,
    JudgeResult,
    OpenAIJudge,
    get_judge,
)

# Orchestrator
from src.council.orchestrator import (
    CouncilDecision,
    CouncilOrchestrator,
    CouncilPhase,
    CouncilSession,
)

# Voting
from src.council.voting import (
    VotingEngine,
    VotingResult,
    VotingStrategy as VotingStrategyEnum,
)

__all__ = [
    "ConflictContext",
    "ConflictDetail",
    "ConflictLevel",
    # Conflict Resolution
    "ConflictResolver",
    # Consensus
    "ConsensusEngine",
    "ConsensusResult",
    "CouncilDecision",
    # Orchestrator
    "CouncilOrchestrator",
    "CouncilPhase",
    "CouncilSession",
    "FieldConsensus",
    "GeminiJudge",
    "JudgeDecision",
    # Judge
    "JudgeInterface",
    "JudgeModel",
    "JudgeResult",
    "MemberVote",
    "OpenAIJudge",
    "ResolutionResult",
    "ResolutionStrategy",
    # Voting
    "VotingEngine",
    "VotingResult",
    "VotingStrategy",
    "VotingStrategyEnum",
    "get_consensus_engine",
    "get_judge",
]
