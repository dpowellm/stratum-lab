"""
OCR Post-Processing Layer.

Corrects common OCR misreads using regex rules, dictionary lookup,
and field-type-specific normalization.

Common misreads:
- O ↔ 0, l ↔ 1, S ↔ $, B ↔ 8
- Currency formatting issues
- Date format normalization
"""

import re
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


# Common character substitutions in numeric contexts
_NUMERIC_CHAR_MAP = {
    "O": "0",
    "o": "0",
    "l": "1",
    "I": "1",
    "S": "5",
    "s": "5",
    "B": "8",
    "G": "6",
    "Z": "2",
    "z": "2",
}

# Field name patterns that indicate numeric values
_AMOUNT_PATTERNS = re.compile(
    r"(amount|total|subtotal|tax|price|cost|fee|balance|payment|rate|quantity|qty|sum|discount)",
    re.IGNORECASE,
)

# Field name patterns that indicate date values
_DATE_PATTERNS = re.compile(
    r"(date|dated|day|month|year|period|due|issued|expires|effective|start|end)",
    re.IGNORECASE,
)

# Field name patterns that indicate identifier values
_ID_PATTERNS = re.compile(
    r"(id|number|num|no|code|reference|ref|account|invoice|order|receipt|vin|ssn|ein|tin)",
    re.IGNORECASE,
)


class OCRPostProcessor:
    """
    Post-processes OCR output to fix common misreads.

    Applies field-type-aware corrections:
    - Amounts: character substitution (O→0, l→1), currency symbol normalization
    - Dates: format normalization, common misread fixes
    - Identifiers: whitespace cleanup, character substitution
    - General text: smart quote normalization, ligature expansion
    """

    def correct(self, field_name: str, value: Any) -> Any:
        """
        Correct a single field value based on its field type.

        Args:
            field_name: Name of the field (used to infer type).
            value: Raw extracted value.

        Returns:
            Corrected value (same type as input if possible).
        """
        if value is None:
            return value

        if isinstance(value, (int, float, bool)):
            return value

        if isinstance(value, list):
            return [self.correct(field_name, item) for item in value]

        if isinstance(value, dict):
            return {k: self.correct(k, v) for k, v in value.items()}

        text = str(value)
        if not text.strip():
            return value

        # Always normalize unicode
        text = self._normalize_unicode(text)

        # Apply field-type-specific corrections
        if _AMOUNT_PATTERNS.search(field_name):
            text = self._correct_amount(text)
        elif _DATE_PATTERNS.search(field_name):
            text = self._correct_date(text)
        elif _ID_PATTERNS.search(field_name):
            text = self._correct_identifier(text)

        return text

    def _normalize_unicode(self, text: str) -> str:
        """Normalize common Unicode issues from OCR."""
        # Smart quotes → straight quotes
        text = text.replace("\u2018", "'").replace("\u2019", "'")
        text = text.replace("\u201c", '"').replace("\u201d", '"')
        # Em/en dash → hyphen
        text = text.replace("\u2013", "-").replace("\u2014", "-")
        # Non-breaking space → space
        text = text.replace("\u00a0", " ")
        # Common ligatures
        text = text.replace("\ufb01", "fi").replace("\ufb02", "fl")
        return text.strip()

    def _correct_amount(self, text: str) -> str:
        """Correct common OCR errors in monetary amounts."""
        # Normalize currency prefix
        text = re.sub(r"^[$S]\s*", "$", text)

        # Strip currency symbols for processing, then re-add
        has_dollar = text.startswith("$")
        cleaned = text.lstrip("$").strip()

        # Fix common character misreads in numeric context
        result = []
        for char in cleaned:
            if char in _NUMERIC_CHAR_MAP and not char.isdigit():
                result.append(_NUMERIC_CHAR_MAP[char])
            else:
                result.append(char)
        cleaned = "".join(result)

        # Fix common patterns: "1,23A" → "1,234", trailing letters
        cleaned = re.sub(r"(\d),(\d{2})[A-Za-z]$", r"\1,\2", cleaned)

        # Remove any remaining non-numeric chars except . , - and space
        cleaned = re.sub(r"[^\d.,\-\s]", "", cleaned)

        # Fix doubled decimal points
        parts = cleaned.split(".")
        if len(parts) > 2:
            cleaned = parts[0] + "." + "".join(parts[1:])

        return f"${cleaned}" if has_dollar else cleaned

    def _correct_date(self, text: str) -> str:
        """Correct common OCR errors in dates."""
        # Fix common misreads in date digits
        result = []
        for char in text:
            if char in ("O", "o") and any(c.isdigit() for c in text):
                result.append("0")
            elif char == "l" and any(c.isdigit() for c in text):
                result.append("1")
            else:
                result.append(char)
        text = "".join(result)

        # Normalize separators
        text = text.replace("\\", "/").replace("—", "-")

        return text

    def _correct_identifier(self, text: str) -> str:
        """Correct common OCR errors in identifiers (invoice numbers, etc.)."""
        # Remove extra whitespace within identifiers
        text = re.sub(r"\s+", " ", text).strip()

        # Don't do character substitution for identifiers since they can contain
        # both letters and numbers intentionally
        return text
