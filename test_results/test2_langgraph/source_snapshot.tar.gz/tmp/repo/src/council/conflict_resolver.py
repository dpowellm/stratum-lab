"""
Conflict Resolution for Council Disagreements.

Handles three levels of conflicts:
- Minor conflicts: 2 agree, 1 differs -> majority wins
- Moderate conflicts: all different -> judge decides
- Major conflicts: critical field -> human review required
"""

import asyncio
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger
from src.council.consensus import ConflictLevel, FieldConsensus, MemberVote

logger = get_logger(__name__)


class ResolutionStrategy(StrEnum):
    """Available conflict resolution strategies."""

    MAJORITY_WINS = "majority_wins"
    JUDGE_DECIDES = "judge_decides"
    HUMAN_REVIEW = "human_review"
    FALLBACK_HIGHEST_CONFIDENCE = "fallback_highest_confidence"


@dataclass
class ConflictDetail:
    """Details about a conflict."""

    field_name: str
    conflict_level: ConflictLevel
    member_votes: dict[str, MemberVote]
    is_critical: bool = False
    document_context: str | None = None
    image_data: bytes | None = None
    additional_context: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "field_name": self.field_name,
            "conflict_level": self.conflict_level.value,
            "votes": {
                name: {"value": vote.value, "confidence": vote.confidence}
                for name, vote in self.member_votes.items()
            },
            "is_critical": self.is_critical,
            "has_context": self.document_context is not None,
        }


@dataclass
class ResolutionResult:
    """Result of conflict resolution."""

    field_name: str
    final_value: Any
    confidence: float
    resolution_strategy: ResolutionStrategy
    reasoning: str
    requires_human_review: bool = False
    judge_involved: bool = False
    processing_time_ms: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "field_name": self.field_name,
            "final_value": self.final_value,
            "confidence": self.confidence,
            "strategy": self.resolution_strategy.value,
            "reasoning": self.reasoning,
            "requires_human_review": self.requires_human_review,
            "judge_involved": self.judge_involved,
            "processing_time_ms": self.processing_time_ms,
        }


class ConflictResolver:
    """
    Resolves conflicts between council members.

    Implements a hierarchical resolution strategy:
    1. Minor conflicts (2-1): Majority wins, no escalation
    2. Moderate conflicts (all different): Judge Model arbitrates
    3. Major conflicts (critical field): Human review required
    """

    def __init__(
        self,
        judge_interface: Any | None = None,
        enable_judge: bool = True,
        enable_human_escalation: bool = True,
        always_use_judge: bool = False,
    ):
        """
        Initialize conflict resolver.

        Args:
            judge_interface: Optional judge model for arbitration
            enable_judge: Whether to use judge for moderate conflicts
            enable_human_escalation: Whether to escalate to human for major conflicts
            always_use_judge: When true, use judge for MINOR conflicts too
        """
        self.judge_interface = judge_interface
        self.enable_judge = enable_judge
        self.enable_human_escalation = enable_human_escalation
        self.always_use_judge = always_use_judge
        self._conflict_history: list[ConflictDetail] = []

    async def resolve_conflict(
        self,
        conflict: ConflictDetail,
    ) -> ResolutionResult:
        """
        Resolve a single conflict.

        Args:
            conflict: Conflict details

        Returns:
            ResolutionResult
        """
        import time

        start_time = time.time()

        # Determine resolution strategy based on conflict level
        if conflict.conflict_level == ConflictLevel.NONE:
            # No conflict, shouldn't be here
            result = self._handle_no_conflict(conflict)
        elif conflict.conflict_level == ConflictLevel.MINOR:
            # Minor conflict: majority wins, or judge if always_use_judge is set
            if self.always_use_judge and self.enable_judge and self.judge_interface:
                result = await self._resolve_moderate_conflict_with_judge(conflict)
            else:
                result = self._resolve_minor_conflict(conflict)
        elif conflict.conflict_level == ConflictLevel.MODERATE:
            # Moderate conflict: try judge
            if self.enable_judge and self.judge_interface:
                result = await self._resolve_moderate_conflict_with_judge(conflict)
            else:
                result = self._resolve_moderate_conflict_fallback(conflict)
        else:  # MAJOR
            # Major conflict: human review
            result = self._resolve_major_conflict(conflict)

        result.processing_time_ms = int((time.time() - start_time) * 1000)

        # Track conflict for learning
        self._conflict_history.append(conflict)

        return result

    async def resolve_conflicts(
        self,
        conflicts: list[ConflictDetail],
    ) -> list[ResolutionResult]:
        """
        Resolve multiple conflicts concurrently.

        Args:
            conflicts: List of conflicts to resolve

        Returns:
            List of resolution results
        """
        tasks = [self.resolve_conflict(c) for c in conflicts]
        return await asyncio.gather(*tasks)

    def _handle_no_conflict(self, conflict: ConflictDetail) -> ResolutionResult:
        """Handle case where there's no conflict."""
        # This shouldn't happen, but handle it gracefully
        votes = list(conflict.member_votes.values())
        if votes:
            best_vote = max(votes, key=lambda v: v.confidence)
            return ResolutionResult(
                field_name=conflict.field_name,
                final_value=best_vote.value,
                confidence=best_vote.confidence,
                resolution_strategy=ResolutionStrategy.MAJORITY_WINS,
                reasoning="No conflict detected; using highest confidence vote",
            )
        else:
            return ResolutionResult(
                field_name=conflict.field_name,
                final_value=None,
                confidence=0.0,
                resolution_strategy=ResolutionStrategy.FALLBACK_HIGHEST_CONFIDENCE,
                reasoning="No votes available",
                requires_human_review=True,
            )

    def _resolve_minor_conflict(self, conflict: ConflictDetail) -> ResolutionResult:
        """
        Resolve minor conflict (2 agree, 1 differs).

        Majority wins, no escalation needed.
        """
        votes = list(conflict.member_votes.values())

        # Group by value
        value_groups: dict[str, list[MemberVote]] = {}
        for vote in votes:
            key = str(vote.value)
            if key not in value_groups:
                value_groups[key] = []
            value_groups[key].append(vote)

        # Find majority
        majority_value_key = max(value_groups.keys(), key=lambda k: len(value_groups[k]))
        majority_votes = value_groups[majority_value_key]
        majority_vote = max(majority_votes, key=lambda v: v.confidence)

        # Build reasoning
        dissenting = [v.member_name for v in votes if str(v.value) != majority_value_key]
        reasoning = (
            f"Minor conflict resolved by majority: {len(majority_votes)} members agree "
            f"on '{majority_vote.value}', {len(dissenting)} member(s) dissent "
            f"({', '.join(dissenting)})"
        )

        return ResolutionResult(
            field_name=conflict.field_name,
            final_value=majority_vote.value,
            confidence=max(v.confidence for v in majority_votes),
            resolution_strategy=ResolutionStrategy.MAJORITY_WINS,
            reasoning=reasoning,
            requires_human_review=False,
        )

    async def _resolve_moderate_conflict_with_judge(
        self,
        conflict: ConflictDetail,
    ) -> ResolutionResult:
        """
        Resolve moderate conflict using judge model.

        All members disagree, judge arbitrates.
        """
        try:
            # Convert to judge context
            from src.council.judge import ConflictContext as JudgeContext

            judge_context = JudgeContext(
                field_name=conflict.field_name,
                member_votes=conflict.member_votes,
                conflict_level=conflict.conflict_level,
                is_critical=conflict.is_critical,
                document_context=conflict.document_context,
                image_data=conflict.image_data,
            )

            # Call judge
            judge_decision = await self.judge_interface.resolve_conflict(judge_context)

            reasoning = (
                f"Judge Model arbitration: {judge_decision.reasoning} "
                f"(supporting evidence: {', '.join(judge_decision.supporting_evidence)})"
            )

            return ResolutionResult(
                field_name=conflict.field_name,
                final_value=judge_decision.final_value,
                confidence=judge_decision.confidence,
                resolution_strategy=ResolutionStrategy.JUDGE_DECIDES,
                reasoning=reasoning,
                requires_human_review=judge_decision.requires_human_review,
                judge_involved=True,
            )

        except Exception as e:
            logger.error(
                "Judge resolution failed",
                field=conflict.field_name,
                error=str(e),
            )
            # Fallback to highest confidence
            return self._resolve_moderate_conflict_fallback(conflict)

    def _resolve_moderate_conflict_fallback(
        self,
        conflict: ConflictDetail,
    ) -> ResolutionResult:
        """Fallback for moderate conflict when judge unavailable."""
        votes = list(conflict.member_votes.values())
        best_vote = max(votes, key=lambda v: v.confidence)

        reasoning = (
            f"Moderate conflict resolved by fallback: "
            f"selected highest confidence vote from {best_vote.member_name} "
            f"({best_vote.confidence:.2f}). "
            f"All {len(votes)} members disagreed on value."
        )

        return ResolutionResult(
            field_name=conflict.field_name,
            final_value=best_vote.value,
            confidence=best_vote.confidence * 0.8,  # Reduce confidence due to fallback
            resolution_strategy=ResolutionStrategy.FALLBACK_HIGHEST_CONFIDENCE,
            reasoning=reasoning,
            requires_human_review=conflict.is_critical or len(votes) > 3,
        )

    def _resolve_major_conflict(self, conflict: ConflictDetail) -> ResolutionResult:
        """
        Resolve major conflict.

        Critical field with disagreement -> escalate to human review.
        """
        votes = list(conflict.member_votes.values())
        best_vote = max(votes, key=lambda v: v.confidence)

        reasoning = (
            f"Major conflict requiring human review: "
            f"critical field with {len(votes)} differing opinions. "
            f"Provisionally using {best_vote.member_name}'s value "
            f"({best_vote.confidence:.2f} confidence) pending human review."
        )

        return ResolutionResult(
            field_name=conflict.field_name,
            final_value=best_vote.value,
            confidence=best_vote.confidence,
            resolution_strategy=ResolutionStrategy.HUMAN_REVIEW,
            reasoning=reasoning,
            requires_human_review=True,
        )

    def detect_conflict_level(
        self,
        field_consensus: FieldConsensus,
        is_critical: bool = False,
    ) -> ConflictLevel:
        """
        Detect the level of conflict.

        Args:
            field_consensus: Field consensus result
            is_critical: Whether this is a critical field

        Returns:
            ConflictLevel
        """
        if field_consensus.conflict_level == ConflictLevel.NONE:
            return ConflictLevel.NONE

        if is_critical:
            # Critical fields are always escalated to at least moderate
            if field_consensus.conflict_level == ConflictLevel.MINOR:
                return ConflictLevel.MODERATE
            else:
                return ConflictLevel.MAJOR

        return field_consensus.conflict_level

    def get_conflict_history(self, limit: int | None = None) -> list[ConflictDetail]:
        """Get conflict history for learning."""
        if limit:
            return self._conflict_history[-limit:]
        return self._conflict_history.copy()

    def get_conflict_statistics(self) -> dict[str, Any]:
        """Get statistics about conflicts."""
        if not self._conflict_history:
            return {
                "total_conflicts": 0,
                "by_level": {},
                "fields_with_conflicts": [],
            }

        level_counts = {}
        field_names = set()

        for conflict in self._conflict_history:
            level = conflict.conflict_level.value
            level_counts[level] = level_counts.get(level, 0) + 1
            field_names.add(conflict.field_name)

        return {
            "total_conflicts": len(self._conflict_history),
            "by_level": level_counts,
            "fields_with_conflicts": list(field_names),
            "unique_fields_with_conflicts": len(field_names),
            "critical_conflicts": sum(1 for c in self._conflict_history if c.is_critical),
        }
