"""Judge Model for Council Conflict Resolution.

The Judge Model is a more powerful LLM (Gemini, GPT-4, Claude) that
resolves conflicts when the council members cannot reach consensus.

It receives:
- The conflicting extractions from each council member
- The original document context
- Field-specific requirements

And produces a final decision with reasoning.
"""

import asyncio
import base64
import json
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger
from src.council.consensus import ConflictLevel, MemberVote

logger = get_logger(__name__)


class JudgeModel(StrEnum):
    """Available judge models."""

    GEMINI_PRO = "gemini-pro"
    GEMINI_FLASH = "gemini-1.5-flash"
    GPT4_VISION = "gpt-4-vision-preview"
    GPT4O = "gpt-4o"
    CLAUDE_SONNET = "claude-3-sonnet"
    CLAUDE_OPUS = "claude-3-opus"


@dataclass
class ConflictContext:
    """Context for a field conflict requiring judge resolution."""

    field_name: str
    member_votes: dict[str, MemberVote]
    conflict_level: ConflictLevel
    is_critical: bool = False
    document_context: str | None = None
    image_data: bytes | None = None
    extraction_history: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "field_name": self.field_name,
            "votes": {
                name: {"value": vote.value, "confidence": vote.confidence}
                for name, vote in self.member_votes.items()
            },
            "conflict_level": self.conflict_level.value,
            "is_critical": self.is_critical,
            "has_document_context": self.document_context is not None,
            "has_image": self.image_data is not None,
        }


@dataclass
class JudgeDecision:
    """Decision made by the judge model."""

    field_name: str
    final_value: Any
    confidence: float
    reasoning: str
    supporting_evidence: list[str]
    dissenting_members: list[str]
    requires_human_review: bool = False
    processing_time_ms: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "field_name": self.field_name,
            "final_value": self.final_value,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "supporting_evidence": self.supporting_evidence,
            "dissenting_members": self.dissenting_members,
            "requires_human_review": self.requires_human_review,
            "processing_time_ms": self.processing_time_ms,
        }


@dataclass
class JudgeResult:
    """Result of judge deliberation."""

    session_id: str
    decisions: list[JudgeDecision]
    total_conflicts_resolved: int
    escalated_to_human: int
    judge_model: str
    total_processing_time_ms: int

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "session_id": self.session_id,
            "decisions": [d.to_dict() for d in self.decisions],
            "total_conflicts_resolved": self.total_conflicts_resolved,
            "escalated_to_human": self.escalated_to_human,
            "judge_model": self.judge_model,
            "total_processing_time_ms": self.total_processing_time_ms,
        }


class JudgeInterface(ABC):
    """Abstract interface for judge models."""

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Get the model name."""
        pass

    @abstractmethod
    async def resolve_conflict(
        self,
        context: ConflictContext,
    ) -> JudgeDecision:
        """Resolve a single field conflict.

        Args:
            context: Conflict context with votes and document info

        Returns:
            JudgeDecision with final value and reasoning
        """
        pass

    @abstractmethod
    async def resolve_conflicts(
        self,
        session_id: str,
        conflicts: list[ConflictContext],
    ) -> JudgeResult:
        """Resolve multiple conflicts in a session.

        Args:
            session_id: Council session identifier
            conflicts: List of conflicts to resolve

        Returns:
            JudgeResult with all decisions
        """
        pass


class GeminiJudge(JudgeInterface):
    """Google Gemini as judge model."""

    def __init__(
        self,
        api_key: str,
        model: JudgeModel = JudgeModel.GEMINI_FLASH,
        temperature: float = 0.1,
        max_tokens: int = 4096,
    ):
        """Initialize Gemini judge.

        Args:
            api_key: Google AI API key
            model: Gemini model to use
            temperature: Sampling temperature
            max_tokens: Maximum response tokens
        """
        self._api_key = api_key
        self._model = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._client = None

    @property
    def model_name(self) -> str:
        """Get the model name."""
        return self._model.value

    async def _ensure_client(self) -> None:
        """Ensure client is initialized."""
        if self._client is None:
            import google.generativeai as genai

            genai.configure(api_key=self._api_key)
            self._client = genai.GenerativeModel(self._model.value)

    async def resolve_conflict(
        self,
        context: ConflictContext,
    ) -> JudgeDecision:
        """Resolve a single conflict using Gemini."""
        await self._ensure_client()
        start_time = time.time()

        # Build prompt
        prompt = self._build_prompt(context)

        try:
            # Prepare content
            content = [prompt]

            if context.image_data:
                import io

                import PIL.Image

                image = PIL.Image.open(io.BytesIO(context.image_data))
                content.insert(0, image)

            # Generate response
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._client.generate_content(
                    content,
                    generation_config={
                        "temperature": self._temperature,
                        "max_output_tokens": self._max_tokens,
                    },
                ),
            )

            # Parse response
            decision = self._parse_response(
                context.field_name,
                response.text,
                context.member_votes,
            )

            decision.processing_time_ms = int((time.time() - start_time) * 1000)
            return decision

        except Exception as e:
            logger.error(
                "Gemini judge failed",
                field=context.field_name,
                error=str(e),
            )
            return JudgeDecision(
                field_name=context.field_name,
                final_value=None,
                confidence=0.0,
                reasoning=f"Judge failed: {e}",
                supporting_evidence=[],
                dissenting_members=list(context.member_votes.keys()),
                requires_human_review=True,
                processing_time_ms=int((time.time() - start_time) * 1000),
            )

    async def resolve_conflicts(
        self,
        session_id: str,
        conflicts: list[ConflictContext],
    ) -> JudgeResult:
        """Resolve multiple conflicts."""
        start_time = time.time()
        decisions = []
        escalated = 0

        # Process conflicts concurrently with limit
        semaphore = asyncio.Semaphore(3)

        async def resolve_with_limit(ctx: ConflictContext) -> JudgeDecision:
            async with semaphore:
                return await self.resolve_conflict(ctx)

        tasks = [resolve_with_limit(ctx) for ctx in conflicts]
        decisions = await asyncio.gather(*tasks)

        # Count escalations
        for d in decisions:
            if d.requires_human_review:
                escalated += 1

        return JudgeResult(
            session_id=session_id,
            decisions=list(decisions),
            total_conflicts_resolved=len(decisions) - escalated,
            escalated_to_human=escalated,
            judge_model=self.model_name,
            total_processing_time_ms=int((time.time() - start_time) * 1000),
        )

    def _build_prompt(self, context: ConflictContext) -> str:
        """Build the judge prompt."""
        votes_text = "\n".join(
            [
                f"- {name}: '{vote.value}' (confidence: {vote.confidence:.2f})"
                for name, vote in context.member_votes.items()
            ]
        )

        prompt = f"""You are an expert judge resolving conflicts in document extraction.

## Field: {context.field_name}
## Conflict Level: {context.conflict_level.value}
## Is Critical Field: {context.is_critical}

## Council Member Votes:
{votes_text}

"""

        if context.document_context:
            prompt += f"""## Document Context:
{context.document_context}

"""

        prompt += """## Your Task:
Analyze the conflicting extractions and determine the correct value.

Respond in JSON format:
{
    "final_value": "the correct value",
    "confidence": 0.95,
    "reasoning": "detailed explanation of your decision",
    "supporting_evidence": ["evidence 1", "evidence 2"],
    "dissenting_members": ["member1"],
    "requires_human_review": false
}

Consider:
1. Which extraction is most consistent with document context?
2. Which member has higher confidence?
3. Are there OCR errors or formatting differences?
4. For critical fields, err on the side of human review if uncertain.

Return only the JSON object."""

        return prompt

    def _parse_response(
        self,
        field_name: str,
        response: str,
        member_votes: dict[str, MemberVote],
    ) -> JudgeDecision:
        """Parse judge response."""
        try:
            # Extract JSON from response
            if "```json" in response:
                json_str = response.split("```json")[1].split("```")[0]
            elif "```" in response:
                json_str = response.split("```")[1].split("```")[0]
            else:
                json_str = response

            data = json.loads(json_str.strip())

            return JudgeDecision(
                field_name=field_name,
                final_value=data.get("final_value"),
                confidence=data.get("confidence", 0.8),
                reasoning=data.get("reasoning", ""),
                supporting_evidence=data.get("supporting_evidence", []),
                dissenting_members=data.get("dissenting_members", []),
                requires_human_review=data.get("requires_human_review", False),
            )

        except json.JSONDecodeError:
            # Fall back to selecting highest confidence vote
            best_vote = max(
                member_votes.values(),
                key=lambda v: v.confidence,
            )

            return JudgeDecision(
                field_name=field_name,
                final_value=best_vote.value,
                confidence=best_vote.confidence * 0.8,  # Reduce confidence
                reasoning="Failed to parse judge response, using highest confidence vote",
                supporting_evidence=[],
                dissenting_members=[
                    name for name, vote in member_votes.items() if vote.value != best_vote.value
                ],
                requires_human_review=True,
            )


class OpenAIJudge(JudgeInterface):
    """OpenAI GPT-4 as judge model."""

    def __init__(
        self,
        api_key: str,
        model: JudgeModel = JudgeModel.GPT4O,
        temperature: float = 0.1,
        max_tokens: int = 4096,
    ):
        """Initialize OpenAI judge."""
        self._api_key = api_key
        self._model = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._client = None

    @property
    def model_name(self) -> str:
        return self._model.value

    async def _ensure_client(self) -> None:
        """Ensure client is initialized."""
        if self._client is None:
            from openai import AsyncOpenAI

            self._client = AsyncOpenAI(api_key=self._api_key)

    async def resolve_conflict(
        self,
        context: ConflictContext,
    ) -> JudgeDecision:
        """Resolve a single conflict using GPT-4."""
        await self._ensure_client()
        start_time = time.time()

        # Build messages
        messages = self._build_messages(context)

        try:
            response = await self._client.chat.completions.create(
                model=self._model.value,
                messages=messages,
                temperature=self._temperature,
                max_tokens=self._max_tokens,
            )

            decision = self._parse_response(
                context.field_name,
                response.choices[0].message.content,
                context.member_votes,
            )

            decision.processing_time_ms = int((time.time() - start_time) * 1000)
            return decision

        except Exception as e:
            logger.error(
                "OpenAI judge failed",
                field=context.field_name,
                error=str(e),
            )
            return JudgeDecision(
                field_name=context.field_name,
                final_value=None,
                confidence=0.0,
                reasoning=f"Judge failed: {e}",
                supporting_evidence=[],
                dissenting_members=list(context.member_votes.keys()),
                requires_human_review=True,
                processing_time_ms=int((time.time() - start_time) * 1000),
            )

    async def resolve_conflicts(
        self,
        session_id: str,
        conflicts: list[ConflictContext],
    ) -> JudgeResult:
        """Resolve multiple conflicts."""
        start_time = time.time()
        decisions = []
        escalated = 0

        semaphore = asyncio.Semaphore(5)

        async def resolve_with_limit(ctx: ConflictContext) -> JudgeDecision:
            async with semaphore:
                return await self.resolve_conflict(ctx)

        tasks = [resolve_with_limit(ctx) for ctx in conflicts]
        decisions = await asyncio.gather(*tasks)

        for d in decisions:
            if d.requires_human_review:
                escalated += 1

        return JudgeResult(
            session_id=session_id,
            decisions=list(decisions),
            total_conflicts_resolved=len(decisions) - escalated,
            escalated_to_human=escalated,
            judge_model=self.model_name,
            total_processing_time_ms=int((time.time() - start_time) * 1000),
        )

    def _build_messages(self, context: ConflictContext) -> list[dict]:
        """Build chat messages for GPT-4."""
        votes_text = "\n".join(
            [
                f"- {name}: '{vote.value}' (confidence: {vote.confidence:.2f})"
                for name, vote in context.member_votes.items()
            ]
        )

        system_prompt = """You are an expert judge resolving conflicts in document extraction.
Your job is to analyze conflicting values from multiple OCR/extraction systems
and determine the most likely correct value.

Always respond with a JSON object containing:
- final_value: the correct value
- confidence: your confidence (0-1)
- reasoning: explanation
- supporting_evidence: list of evidence
- dissenting_members: list of members you disagree with
- requires_human_review: boolean"""

        user_content = [
            {
                "type": "text",
                "text": f"""Field: {context.field_name}
Conflict Level: {context.conflict_level.value}
Is Critical: {context.is_critical}

Council Votes:
{votes_text}

{"Document Context: " + context.document_context if context.document_context else ""}

Determine the correct value and explain your reasoning.""",
            }
        ]

        if context.image_data:
            image_b64 = base64.b64encode(context.image_data).decode("utf-8")
            user_content.insert(
                0,
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{image_b64}"},
                },
            )

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]

    def _parse_response(
        self,
        field_name: str,
        response: str,
        member_votes: dict[str, MemberVote],
    ) -> JudgeDecision:
        """Parse judge response."""
        try:
            if "```json" in response:
                json_str = response.split("```json")[1].split("```")[0]
            elif "```" in response:
                json_str = response.split("```")[1].split("```")[0]
            else:
                json_str = response

            data = json.loads(json_str.strip())

            return JudgeDecision(
                field_name=field_name,
                final_value=data.get("final_value"),
                confidence=data.get("confidence", 0.8),
                reasoning=data.get("reasoning", ""),
                supporting_evidence=data.get("supporting_evidence", []),
                dissenting_members=data.get("dissenting_members", []),
                requires_human_review=data.get("requires_human_review", False),
            )

        except json.JSONDecodeError:
            best_vote = max(member_votes.values(), key=lambda v: v.confidence)

            return JudgeDecision(
                field_name=field_name,
                final_value=best_vote.value,
                confidence=best_vote.confidence * 0.8,
                reasoning="Failed to parse judge response",
                supporting_evidence=[],
                dissenting_members=[
                    name for name, vote in member_votes.items() if vote.value != best_vote.value
                ],
                requires_human_review=True,
            )


class AnthropicJudge(JudgeInterface):
    """Anthropic Claude as judge model."""

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-20250514",
        temperature: float = 0.1,
        max_tokens: int = 4096,
    ):
        """Initialize Anthropic judge."""
        self._api_key = api_key
        self._model_name = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._client = None

    @property
    def model_name(self) -> str:
        return self._model_name

    async def _ensure_client(self) -> None:
        """Ensure client is initialized."""
        if self._client is None:
            from anthropic import AsyncAnthropic

            self._client = AsyncAnthropic(api_key=self._api_key)

    async def resolve_conflict(
        self,
        context: ConflictContext,
    ) -> JudgeDecision:
        """Resolve a single conflict using Claude."""
        await self._ensure_client()
        start_time = time.time()

        system_prompt = (
            "You are an expert judge resolving conflicts in document extraction.\n"
            "Your job is to analyze conflicting values from multiple OCR/extraction "
            "systems and determine the most likely correct value.\n\n"
            "Always respond with a JSON object containing:\n"
            "- final_value: the correct value\n"
            "- confidence: your confidence (0-1)\n"
            "- reasoning: explanation\n"
            "- supporting_evidence: list of evidence\n"
            "- dissenting_members: list of members you disagree with\n"
            "- requires_human_review: boolean"
        )

        votes_text = "\n".join(
            f"- {name}: '{vote.value}' (confidence: {vote.confidence:.2f})"
            for name, vote in context.member_votes.items()
        )

        user_text = (
            f"Field: {context.field_name}\n"
            f"Conflict Level: {context.conflict_level.value}\n"
            f"Is Critical: {context.is_critical}\n\n"
            f"Council Votes:\n{votes_text}\n\n"
        )
        if context.document_context:
            user_text += f"Document Context: {context.document_context}\n\n"
        user_text += "Determine the correct value and explain your reasoning."

        content: list[dict] = []
        if context.image_data:
            image_b64 = base64.b64encode(context.image_data).decode("utf-8")
            content.append(
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/png",
                        "data": image_b64,
                    },
                }
            )
        content.append({"type": "text", "text": user_text})

        try:
            response = await self._client.messages.create(
                model=self._model_name,
                max_tokens=self._max_tokens,
                temperature=self._temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": content}],
            )

            response_text = response.content[0].text
            decision = self._parse_response(context.field_name, response_text, context.member_votes)
            decision.processing_time_ms = int((time.time() - start_time) * 1000)
            return decision

        except Exception as e:
            logger.error("Anthropic judge failed", field=context.field_name, error=str(e))
            return JudgeDecision(
                field_name=context.field_name,
                final_value=None,
                confidence=0.0,
                reasoning=f"Judge failed: {e}",
                supporting_evidence=[],
                dissenting_members=list(context.member_votes.keys()),
                requires_human_review=True,
                processing_time_ms=int((time.time() - start_time) * 1000),
            )

    async def resolve_conflicts(
        self,
        session_id: str,
        conflicts: list[ConflictContext],
    ) -> JudgeResult:
        """Resolve multiple conflicts."""
        start_time = time.time()
        escalated = 0

        semaphore = asyncio.Semaphore(3)

        async def resolve_with_limit(ctx: ConflictContext) -> JudgeDecision:
            async with semaphore:
                return await self.resolve_conflict(ctx)

        tasks = [resolve_with_limit(ctx) for ctx in conflicts]
        decisions = await asyncio.gather(*tasks)

        for d in decisions:
            if d.requires_human_review:
                escalated += 1

        return JudgeResult(
            session_id=session_id,
            decisions=list(decisions),
            total_conflicts_resolved=len(decisions) - escalated,
            escalated_to_human=escalated,
            judge_model=self.model_name,
            total_processing_time_ms=int((time.time() - start_time) * 1000),
        )

    def _parse_response(
        self,
        field_name: str,
        response: str,
        member_votes: dict[str, MemberVote],
    ) -> JudgeDecision:
        """Parse judge response."""
        try:
            if "```json" in response:
                json_str = response.split("```json")[1].split("```")[0]
            elif "```" in response:
                json_str = response.split("```")[1].split("```")[0]
            else:
                json_str = response

            data = json.loads(json_str.strip())

            return JudgeDecision(
                field_name=field_name,
                final_value=data.get("final_value"),
                confidence=data.get("confidence", 0.8),
                reasoning=data.get("reasoning", ""),
                supporting_evidence=data.get("supporting_evidence", []),
                dissenting_members=data.get("dissenting_members", []),
                requires_human_review=data.get("requires_human_review", False),
            )

        except json.JSONDecodeError:
            best_vote = max(member_votes.values(), key=lambda v: v.confidence)
            return JudgeDecision(
                field_name=field_name,
                final_value=best_vote.value,
                confidence=best_vote.confidence * 0.8,
                reasoning="Failed to parse judge response",
                supporting_evidence=[],
                dissenting_members=[
                    name for name, vote in member_votes.items() if vote.value != best_vote.value
                ],
                requires_human_review=True,
            )


def get_judge(
    model: JudgeModel,
    api_key: str,
    **kwargs,
) -> JudgeInterface:
    """Factory function to get appropriate judge.

    Args:
        model: Judge model to use
        api_key: API key for the model
        **kwargs: Additional configuration

    Returns:
        JudgeInterface implementation
    """
    if model in (JudgeModel.GEMINI_PRO, JudgeModel.GEMINI_FLASH):
        return GeminiJudge(api_key=api_key, model=model, **kwargs)
    elif model in (JudgeModel.GPT4_VISION, JudgeModel.GPT4O):
        return OpenAIJudge(api_key=api_key, model=model, **kwargs)
    elif model in (JudgeModel.CLAUDE_SONNET, JudgeModel.CLAUDE_OPUS):
        return AnthropicJudge(api_key=api_key, model=model.value, **kwargs)
    else:
        raise ValueError(f"Unsupported judge model: {model}")


def get_judge_for_provider(
    provider: str,
    model_name: str,
    api_key: str,
    **kwargs,
) -> JudgeInterface:
    """Create a judge instance for a given provider and model name.

    Args:
        provider: Provider name (openai, anthropic, gemini).
        model_name: Model identifier string.
        api_key: API key.

    Returns:
        JudgeInterface implementation.
    """
    if provider == "openai":
        return OpenAIJudge(api_key=api_key, model=JudgeModel.GPT4O, **kwargs)
    elif provider == "anthropic":
        return AnthropicJudge(api_key=api_key, model=model_name, **kwargs)
    elif provider == "gemini":
        return GeminiJudge(api_key=api_key, model=JudgeModel.GEMINI_FLASH, **kwargs)
    else:
        raise ValueError(f"Unsupported provider: {provider}")
