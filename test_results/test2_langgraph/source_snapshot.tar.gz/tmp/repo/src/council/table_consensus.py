"""Table-level consensus engine for council-powered table extraction.

Compares table structures across council members and performs cell-level
voting to produce the most accurate table extraction.
"""

from dataclasses import dataclass, field
from typing import Any

from src.core.logging import get_logger
from src.council.value_matching import ValueMatcher, value_distance
from src.services.ocr.base import CellDataType, CellType, TableCell, TableData

logger = get_logger(__name__)


@dataclass
class CellVote:
    """Vote from a council member for a single cell."""

    member_name: str
    text: str
    confidence: float


@dataclass
class CellConsensus:
    """Consensus result for a single table cell."""

    row: int
    col: int
    final_text: str
    confidence: float
    source_member: str
    agreement_count: int
    total_votes: int


@dataclass
class TableConsensusResult:
    """Result of table-level consensus across council members."""

    rows: int
    cols: int
    cell_consensuses: list[CellConsensus]
    overall_confidence: float
    structure_agreement: bool
    table_data: TableData
    metadata: dict[str, Any] = field(default_factory=dict)


class TableConsensusEngine:
    """Compares table structures across council members and votes per-cell."""

    def __init__(self, min_confidence: float = 0.5):
        self.min_confidence = min_confidence
        self._matcher = ValueMatcher()

    def build_consensus(
        self,
        member_tables: dict[str, TableData],
    ) -> TableConsensusResult | None:
        """Build consensus from tables extracted by multiple members.

        Args:
            member_tables: Mapping of member_name -> TableData.

        Returns:
            TableConsensusResult or None if no tables provided.
        """
        if not member_tables:
            return None

        tables = list(member_tables.values())
        member_names = list(member_tables.keys())

        # Step 1: Agree on structure (row/col count)
        rows, cols, structure_agreement = self._consensus_structure(tables)

        # Step 2: Cell-level voting
        cell_consensuses = self._vote_cells(member_tables, rows, cols)

        # Step 3: Build final TableData
        final_cells = []
        total_confidence = 0.0
        for cc in cell_consensuses:
            cell = TableCell(
                text=cc.final_text,
                row=cc.row,
                col=cc.col,
                confidence=cc.confidence,
                cell_type=CellType.HEADER if cc.row == 0 else CellType.DATA,
                is_header=cc.row == 0,
                data_type=self._detect_data_type(cc.final_text),
            )
            final_cells.append(cell)
            total_confidence += cc.confidence

        overall_confidence = total_confidence / len(cell_consensuses) if cell_consensuses else 0.0

        table_data = TableData(
            cells=final_cells,
            rows=rows,
            cols=cols,
        )

        return TableConsensusResult(
            rows=rows,
            cols=cols,
            cell_consensuses=cell_consensuses,
            overall_confidence=overall_confidence,
            structure_agreement=structure_agreement,
            table_data=table_data,
            metadata={
                "participating_members": member_names,
                "total_cells": len(cell_consensuses),
            },
        )

    def chart_consensus(
        self,
        member_charts: dict[str, dict[str, Any]],
    ) -> dict[str, Any] | None:
        """Build consensus on chart data from multiple VLM extractions.

        Args:
            member_charts: Mapping of member_name -> chart_data dict.

        Returns:
            Consensus chart data or None.
        """
        if not member_charts:
            return None

        charts = list(member_charts.values())
        members = list(member_charts.keys())

        # Vote on chart_type (majority)
        type_votes: dict[str, int] = {}
        for chart in charts:
            ct = chart.get("chart_type", "unknown")
            type_votes[ct] = type_votes.get(ct, 0) + 1
        chart_type = max(type_votes, key=lambda k: type_votes[k])

        # Vote on title
        title_votes: dict[str, int] = {}
        for chart in charts:
            t = chart.get("title", "")
            if t:
                title_votes[t] = title_votes.get(t, 0) + 1
        title = max(title_votes, key=lambda k: title_votes[k]) if title_votes else ""

        # Vote on data points using confidence-weighted voting
        consensus_series = self._vote_data_series(member_charts)

        return {
            "chart_type": chart_type,
            "title": title,
            "data_series": consensus_series,
            "participating_members": members,
            "confidence": 1.0 / max(1, len(set(type_votes.values()))),
        }

    def _consensus_structure(self, tables: list[TableData]) -> tuple[int, int, bool]:
        """Determine consensus on table structure (rows, cols)."""
        row_votes: dict[int, int] = {}
        col_votes: dict[int, int] = {}

        for table in tables:
            row_votes[table.rows] = row_votes.get(table.rows, 0) + 1
            col_votes[table.cols] = col_votes.get(table.cols, 0) + 1

        rows = max(row_votes, key=lambda k: row_votes[k])
        cols = max(col_votes, key=lambda k: col_votes[k])

        # Check if all agree on structure
        structure_agreement = len(row_votes) == 1 and len(col_votes) == 1

        return rows, cols, structure_agreement

    def _vote_cells(
        self,
        member_tables: dict[str, TableData],
        rows: int,
        cols: int,
    ) -> list[CellConsensus]:
        """Vote on each cell's content across members."""
        results: list[CellConsensus] = []

        for r in range(rows):
            for c in range(cols):
                votes: list[CellVote] = []

                for member_name, table in member_tables.items():
                    cell = self._get_cell(table, r, c)
                    if cell is not None:
                        votes.append(
                            CellVote(
                                member_name=member_name,
                                text=cell.text,
                                confidence=cell.confidence,
                            )
                        )

                if not votes:
                    results.append(
                        CellConsensus(
                            row=r,
                            col=c,
                            final_text="",
                            confidence=0.0,
                            source_member="",
                            agreement_count=0,
                            total_votes=0,
                        )
                    )
                    continue

                # Confidence-weighted voting with value distance penalty
                best_vote = votes[0]
                best_score = 0.0

                # Group by normalized value
                groups: dict[str, list[CellVote]] = {}
                for vote in votes:
                    key = self._matcher.group_key(vote.text)
                    if key not in groups:
                        groups[key] = []
                    groups[key].append(vote)

                for _key, group in groups.items():
                    score = sum(v.confidence for v in group)
                    if score > best_score:
                        best_score = score
                        best_vote = max(group, key=lambda v: v.confidence)

                # Count agreements
                best_key = self._matcher.group_key(best_vote.text)
                agreement = sum(1 for v in votes if self._matcher.group_key(v.text) == best_key)

                # Apply divergence penalty
                max_dist = 0.0
                for vote in votes:
                    if self._matcher.group_key(vote.text) != best_key:
                        dist = value_distance(best_vote.text, vote.text)
                        max_dist = max(max_dist, dist)

                conf = best_vote.confidence
                if max_dist > 0.1:
                    conf *= max(0.5, 1.0 - max_dist * 0.5)

                results.append(
                    CellConsensus(
                        row=r,
                        col=c,
                        final_text=best_vote.text,
                        confidence=conf,
                        source_member=best_vote.member_name,
                        agreement_count=agreement,
                        total_votes=len(votes),
                    )
                )

        return results

    def _get_cell(self, table: TableData, row: int, col: int) -> TableCell | None:
        """Get cell at position from table, or None."""
        for cell in table.cells:
            if cell.row == row and cell.col == col:
                return cell
        return None

    def _detect_data_type(self, text: str) -> CellDataType:
        """Detect the data type of a cell value."""
        import re

        s = text.strip()
        if not s:
            return CellDataType.TEXT

        # Currency
        if re.match(r"^\$[\d,]+\.?\d*$", s) or re.match(r"^[\d,]+\.?\d*\s*USD$", s):
            return CellDataType.CURRENCY

        # Percentage
        if re.match(r"^[\d.]+%$", s):
            return CellDataType.PERCENTAGE

        # Date
        if re.match(r"^\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}$", s):
            return CellDataType.DATE
        if re.match(r"^\d{4}[/\-]\d{1,2}[/\-]\d{1,2}$", s):
            return CellDataType.DATE

        # Numeric
        cleaned = s.replace(",", "").replace(" ", "")
        try:
            float(cleaned)
            return CellDataType.NUMERIC
        except ValueError:
            pass

        return CellDataType.TEXT

    def _vote_data_series(self, member_charts: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
        """Vote on chart data series across members."""
        # Collect all series from all members
        all_series: dict[str, list[dict[str, Any]]] = {}

        for member_name, chart in member_charts.items():
            series_list = chart.get("data_series") or chart.get("series", [])
            if not isinstance(series_list, list):
                continue
            for series in series_list:
                name = series.get("name", "default")
                if name not in all_series:
                    all_series[name] = []
                all_series[name].append(
                    {
                        "member": member_name,
                        "points": series.get("data_points") or series.get("points", []),
                    }
                )

        # For each series, vote on data points
        consensus_series = []
        for series_name, member_data in all_series.items():
            # Collect all data points by label
            point_votes: dict[str, list[tuple[str, float]]] = {}
            for md in member_data:
                for point in md["points"]:
                    label = str(point.get("label", ""))
                    value = point.get("value", 0)
                    if isinstance(value, (int, float)):
                        if label not in point_votes:
                            point_votes[label] = []
                        point_votes[label].append((md["member"], float(value)))

            # Average values for each label (simple mean consensus)
            consensus_points = []
            for label, votes in point_votes.items():
                values = [v for _, v in votes]
                avg_value = sum(values) / len(values) if values else 0.0
                consensus_points.append(
                    {
                        "label": label,
                        "value": avg_value,
                        "vote_count": len(votes),
                    }
                )

            consensus_series.append(
                {
                    "name": series_name,
                    "data_points": consensus_points,
                }
            )

        return consensus_series
