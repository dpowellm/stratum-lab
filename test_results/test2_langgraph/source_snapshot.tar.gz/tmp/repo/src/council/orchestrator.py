"""
LLM Council Orchestrator.

Main coordinator for the council architecture. Orchestrates:
1. Parallel extraction from all council members
2. Consensus deliberation via voting mechanisms
3. Conflict resolution (judge or human review)
4. Final decision synthesis

This is the main entry point for using the LLM Council.
"""

import asyncio
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from src.core.logging import get_logger
from src.council.circuit_breaker import CircuitBreaker
from src.council.conflict_resolver import ConflictDetail, ConflictResolver, ResolutionResult
from src.council.consensus import (
    ConflictLevel,
    ConsensusEngine,
    ConsensusResult,
    MemberVote,
    VotingStrategy,
)
from src.council.cross_field_validator import CrossFieldValidator
from src.council.members.base import CouncilMember, ExtractionResult
from src.council.ocr_postprocessor import OCRPostProcessor
from src.council.semantic_validator import SemanticValidator
from src.council.voting import VotingEngine
from src.services.evals.calibration import CalibrationTracker, get_calibration_tracker

logger = get_logger(__name__)


class CouncilPhase(StrEnum):
    """Phases of council deliberation."""

    EXTRACTION = "extraction"
    VOTING = "voting"
    DELIBERATION = "deliberation"
    CONFLICT_RESOLUTION = "conflict_resolution"
    SYNTHESIS = "synthesis"
    COMPLETE = "complete"


@dataclass
class CouncilSession:
    """A single council session for one document."""

    session_id: str
    document_id: str | None = None
    document_type: str | None = None
    current_phase: CouncilPhase = CouncilPhase.EXTRACTION
    extraction_results: dict[str, ExtractionResult] = field(default_factory=dict)
    consensus_result: ConsensusResult | None = None
    resolution_results: dict[str, ResolutionResult] = field(default_factory=dict)
    final_result: dict[str, Any] | None = None
    critical_fields: list[str] = field(default_factory=list)
    start_time: float = 0.0
    phase_times: dict[str, float] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def elapsed_time_ms(self) -> float:
        """Get elapsed time in milliseconds."""
        return (time.time() - self.start_time) * 1000 if self.start_time else 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "session_id": self.session_id,
            "document_id": self.document_id,
            "document_type": self.document_type,
            "current_phase": self.current_phase.value,
            "extraction_members": list(self.extraction_results.keys()),
            "has_consensus": self.consensus_result is not None,
            "resolutions_count": len(self.resolution_results),
            "elapsed_time_ms": self.elapsed_time_ms(),
        }


@dataclass
class CouncilDecision:
    """Final council decision."""

    session_id: str
    extracted_fields: dict[str, dict[str, Any]]
    confidence_scores: dict[str, float]
    overall_confidence: float
    consensus_rate: float
    agreed_fields: int
    disputed_fields: int
    total_fields: int
    requires_human_review: bool
    processing_time_ms: float
    council_members: list[str]
    voting_strategy: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "session_id": self.session_id,
            "extracted_fields": self.extracted_fields,
            "confidence_scores": self.confidence_scores,
            "overall_confidence": self.overall_confidence,
            "consensus_rate": self.consensus_rate,
            "agreed_fields": self.agreed_fields,
            "disputed_fields": self.disputed_fields,
            "total_fields": self.total_fields,
            "requires_human_review": self.requires_human_review,
            "processing_time_ms": self.processing_time_ms,
            "council_members": self.council_members,
            "voting_strategy": self.voting_strategy,
        }


class CouncilOrchestrator:
    """
    Main orchestrator for the LLM Council.

    Coordinates all aspects of council deliberation:
    - Parallel extraction from members
    - Consensus voting
    - Conflict resolution
    - Final synthesis
    """

    def __init__(
        self,
        council_members: list[CouncilMember],
        consensus_engine: ConsensusEngine | None = None,
        voting_engine: VotingEngine | None = None,
        conflict_resolver: ConflictResolver | None = None,
        judge_interface: Any | None = None,
        circuit_breaker: CircuitBreaker | None = None,
        cross_field_validator: CrossFieldValidator | None = None,
        semantic_validator: SemanticValidator | None = None,
        calibration_tracker: CalibrationTracker | None = None,
        ocr_postprocessor: OCRPostProcessor | None = None,
    ):
        """
        Initialize the orchestrator.

        Args:
            council_members: List of council members
            consensus_engine: Optional consensus engine
            voting_engine: Optional voting engine
            conflict_resolver: Optional conflict resolver
            judge_interface: Optional judge for arbitration
            circuit_breaker: Optional circuit breaker for fault tolerance
            cross_field_validator: Optional cross-field validator
            semantic_validator: Optional semantic validator
            calibration_tracker: Optional calibration tracker for Platt scaling
            ocr_postprocessor: Optional OCR post-processor for common misread fixes
        """
        self.council_members = council_members
        self.calibration_tracker = calibration_tracker or get_calibration_tracker()
        self.consensus_engine = consensus_engine or ConsensusEngine(
            calibrator=self.calibration_tracker,
        )
        self.voting_engine = voting_engine or VotingEngine()
        self.conflict_resolver = conflict_resolver or ConflictResolver(
            judge_interface=judge_interface,
        )
        self.circuit_breaker = circuit_breaker
        self.cross_field_validator = cross_field_validator or CrossFieldValidator()
        self.semantic_validator = semantic_validator or SemanticValidator()
        self.ocr_postprocessor = ocr_postprocessor or OCRPostProcessor()
        self._sessions: dict[str, CouncilSession] = {}
        # Document context for multi-page consistency
        self._document_contexts: dict[str, dict[str, Any]] = {}

    async def deliberate(
        self,
        session_id: str,
        image_data: bytes,
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        critical_fields: list[str] | None = None,
        voting_strategy: VotingStrategy = VotingStrategy.CONFIDENCE_WEIGHTED,
        document_id: str | None = None,
    ) -> CouncilDecision:
        """
        Run full council deliberation on a document.

        Args:
            session_id: Unique session identifier
            image_data: Document image as bytes
            document_type: Type of document (invoice, contract, etc.)
            target_fields: Specific fields to extract
            critical_fields: Fields requiring unanimous agreement
            voting_strategy: Strategy for consensus
            document_id: Optional document ID for tracking

        Returns:
            CouncilDecision with final extracted fields and confidence
        """
        # Create session
        session = CouncilSession(
            session_id=session_id,
            document_id=document_id,
            document_type=document_type,
            critical_fields=critical_fields or [],
        )
        session.start_time = time.time()
        self._sessions[session_id] = session

        try:
            # Phase 1: Parallel extraction
            logger.info(
                "Starting council extraction", session=session_id, members=len(self.council_members)
            )
            session.current_phase = CouncilPhase.EXTRACTION
            extraction_results = await self._extraction_phase(
                session_id,
                image_data,
                document_type,
                target_fields,
            )
            session.extraction_results = extraction_results
            session.phase_times["extraction"] = session.elapsed_time_ms()

            # Phase 1.5: OCR post-processing (fix common misreads)
            if self.ocr_postprocessor:
                for member_name, result in extraction_results.items():
                    if result.status == "success":
                        for extracted_field in result.fields:
                            corrected = self.ocr_postprocessor.correct(
                                extracted_field.field_name,
                                extracted_field.value,
                            )
                            if corrected != extracted_field.value:
                                logger.debug(
                                    "OCR post-processing corrected value",
                                    member=member_name,
                                    field=extracted_field.field_name,
                                    original=extracted_field.value,
                                    corrected=corrected,
                                )
                                extracted_field.value = corrected

            # Phase 2: Voting and consensus
            logger.info("Starting council voting", session=session_id)
            session.current_phase = CouncilPhase.VOTING
            member_votes = self._prepare_member_votes(extraction_results, target_fields)
            session.phase_times["voting"] = session.elapsed_time_ms() - session.phase_times.get(
                "extraction", 0
            )

            # Phase 3: Deliberation (consensus)
            logger.info("Starting council deliberation", session=session_id)
            session.current_phase = CouncilPhase.DELIBERATION
            consensus_result = self.consensus_engine.calculate_consensus(
                session_id=session_id,
                member_results=extraction_results,
                extracted_fields=member_votes,
                voting_strategy=voting_strategy,
                critical_fields=critical_fields,
            )
            session.consensus_result = consensus_result
            session.phase_times["deliberation"] = (
                session.elapsed_time_ms() - session.phase_times.get("voting", 0)
            )

            # Phase 3.5: Cross-field validation (after deliberation, before conflicts)
            if self.cross_field_validator:
                field_values = {fc.field_name: fc.final_value for fc in consensus_result.fields}
                cf_issues = self.cross_field_validator.validate_field_consistency(
                    field_values, document_type
                )
                if cf_issues:
                    logger.info(
                        "Cross-field issues found",
                        session=session_id,
                        issue_count=len(cf_issues),
                    )
                    # Apply confidence penalties
                    for issue in cf_issues:
                        for fc in consensus_result.fields:
                            if fc.field_name in issue.fields:
                                fc.confidence = max(0.0, fc.confidence - issue.confidence_penalty)

            # Phase 4: Conflict resolution
            conflicts = [
                f for f in consensus_result.fields if f.conflict_level != ConflictLevel.NONE
            ]

            if conflicts:
                logger.info(
                    "Resolving conflicts", session=session_id, conflict_count=len(conflicts)
                )
                session.current_phase = CouncilPhase.CONFLICT_RESOLUTION
                resolutions = await self._resolve_conflicts(
                    session_id,
                    consensus_result,
                    document_type,
                )
                session.resolution_results = resolutions
                session.phase_times["conflict_resolution"] = session.elapsed_time_ms() - sum(
                    session.phase_times.values()
                )

            # Phase 5: Synthesis with semantic validation
            logger.info("Synthesizing council decision", session=session_id)
            session.current_phase = CouncilPhase.SYNTHESIS
            decision = self._synthesize_decision(
                session_id,
                consensus_result,
                session.resolution_results,
            )

            # Apply semantic validation penalties
            if self.semantic_validator:
                for field_name, field_data in decision.extracted_fields.items():
                    value = field_data.get("value") if isinstance(field_data, dict) else field_data
                    check = self.semantic_validator.validate_value(field_name, value, document_type)
                    if not check.is_valid:
                        current_conf = decision.confidence_scores.get(field_name, 1.0)
                        decision.confidence_scores[field_name] = max(
                            0.0, current_conf - check.confidence_penalty
                        )
                        if current_conf - check.confidence_penalty < 0.7:
                            decision.requires_human_review = True
            session.final_result = decision.to_dict()
            session.phase_times["synthesis"] = session.elapsed_time_ms() - sum(
                session.phase_times.values()
            )

            # Record predictions for calibration tracking
            if self.calibration_tracker:
                for fc in consensus_result.fields:
                    for vote in fc.all_votes:
                        # Record each member's vote vs consensus (was it the chosen value?)
                        was_chosen = vote.value == fc.final_value
                        self.calibration_tracker.record_prediction(
                            confidence=vote.confidence,
                            was_correct=was_chosen,
                            model_name=vote.member_name,
                            field_name=fc.field_name,
                        )

            session.current_phase = CouncilPhase.COMPLETE
            logger.info(
                "Council deliberation complete",
                session=session_id,
                consensus_rate=f"{consensus_result.consensus_score:.2%}",
                required_human_review=decision.requires_human_review,
            )

            return decision

        except Exception as e:
            logger.error("Council deliberation failed", session=session_id, error=str(e))
            raise

    async def _extraction_phase(
        self,
        session_id: str,
        image_data: bytes,
        document_type: str | None,
        target_fields: list[str] | None,
    ) -> dict[str, ExtractionResult]:
        """
        Phase 1: Parallel extraction from all council members.

        Args:
            session_id: Session identifier
            image_data: Document image
            document_type: Document type hint
            target_fields: Target fields to extract

        Returns:
            Dictionary of extraction results by member name
        """
        # Filter members by circuit breaker availability
        available_members = self.council_members
        if self.circuit_breaker:
            available_members = [
                m for m in self.council_members if self.circuit_breaker.is_available(m.name)
            ]
            skipped = len(self.council_members) - len(available_members)
            if skipped > 0:
                logger.warning(
                    "Skipping unavailable members",
                    session=session_id,
                    skipped_count=skipped,
                )

        tasks = [
            member.extract(
                image_data=image_data,
                document_type=document_type,
                target_fields=target_fields,
            )
            for member in available_members
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        extraction_results = {}
        for member, result in zip(available_members, results, strict=False):
            if isinstance(result, Exception):
                logger.error(
                    "Member extraction failed",
                    session=session_id,
                    member=member.name,
                    error=str(result),
                )
                if self.circuit_breaker:
                    self.circuit_breaker.record_failure(member.name)
                # Create error result
                extraction_results[member.name] = ExtractionResult(
                    member_name=member.name,
                    model_version=member.model_version,
                    fields=[],
                    processing_time_ms=0,
                    page_count=0,
                    status="error",
                    error_message=str(result),
                )
            else:
                if self.circuit_breaker:
                    self.circuit_breaker.record_success(member.name)
                extraction_results[member.name] = result
                logger.info(
                    "Member extraction complete",
                    session=session_id,
                    member=member.name,
                    field_count=len(result.fields),
                    time_ms=result.processing_time_ms,
                )

        return extraction_results

    def _prepare_member_votes(
        self,
        extraction_results: dict[str, ExtractionResult],
        target_fields: list[str] | None,
    ) -> dict[str, dict[str, MemberVote]]:
        """
        Prepare votes from extraction results.

        Args:
            extraction_results: Results from all members
            target_fields: Fields to include

        Returns:
            Dictionary mapping field names to member votes
        """
        member_votes: dict[str, dict[str, MemberVote]] = {}

        for member_name, result in extraction_results.items():
            if result.status != "success":
                continue

            for extracted_field in result.fields:
                if target_fields and extracted_field.field_name not in target_fields:
                    continue

                if extracted_field.field_name not in member_votes:
                    member_votes[extracted_field.field_name] = {}

                member_votes[extracted_field.field_name][member_name] = MemberVote(
                    member_name=member_name,
                    value=extracted_field.value,
                    confidence=extracted_field.confidence,
                    raw_output=extracted_field,
                    processing_time_ms=result.processing_time_ms,
                    metadata={
                        "page": extracted_field.page_number,
                        "bbox": extracted_field.bounding_box,
                    },
                )

        return member_votes

    async def _resolve_conflicts(
        self,
        session_id: str,
        consensus_result: ConsensusResult,
        document_type: str | None,
    ) -> dict[str, ResolutionResult]:
        """
        Phase 4: Resolve conflicts.

        Args:
            session_id: Session identifier
            consensus_result: Consensus result with conflicts
            document_type: Document type

        Returns:
            Dictionary of resolution results by field name
        """
        conflicts: list[ConflictDetail] = []

        for field_consensus in consensus_result.fields:
            if field_consensus.conflict_level != ConflictLevel.NONE:
                member_votes = {v.member_name: v for v in field_consensus.all_votes}

                conflict = ConflictDetail(
                    field_name=field_consensus.field_name,
                    conflict_level=field_consensus.conflict_level,
                    member_votes=member_votes,
                    is_critical=field_consensus.field_name
                    in (self._sessions[session_id].critical_fields),
                    additional_context={"document_type": document_type},
                )
                conflicts.append(conflict)

        if not conflicts:
            return {}

        # Resolve conflicts
        resolutions = await self.conflict_resolver.resolve_conflicts(conflicts)

        resolution_results = {}
        for resolution in resolutions:
            resolution_results[resolution.field_name] = resolution

        return resolution_results

    def _synthesize_decision(
        self,
        session_id: str,
        consensus_result: ConsensusResult,
        resolution_results: dict[str, ResolutionResult],
    ) -> CouncilDecision:
        """
        Phase 5: Synthesize final decision.

        Args:
            session_id: Session identifier
            consensus_result: Consensus result
            resolution_results: Any resolution results

        Returns:
            CouncilDecision with final values
        """
        extracted_fields = {}
        confidence_scores = {}
        requires_human_review = False

        for field_consensus in consensus_result.fields:
            # Check if there's a resolution for this field
            if field_consensus.field_name in resolution_results:
                resolution = resolution_results[field_consensus.field_name]
                extracted_fields[field_consensus.field_name] = {
                    "value": resolution.final_value,
                    "source": "conflict_resolution",
                    "strategy": resolution.resolution_strategy.value,
                }
                confidence_scores[field_consensus.field_name] = resolution.confidence
                if resolution.requires_human_review:
                    requires_human_review = True
            else:
                # Use consensus result
                extracted_fields[field_consensus.field_name] = {
                    "value": field_consensus.final_value,
                    "source": field_consensus.source_member,
                    "agreement_count": field_consensus.agreement_count,
                }
                confidence_scores[field_consensus.field_name] = field_consensus.confidence

        # Calculate overall metrics
        requires_human_review = (
            requires_human_review
            or consensus_result.requires_human_review
            or consensus_result.consensus_score < 0.85
        )

        session = self._sessions[session_id]

        return CouncilDecision(
            session_id=session_id,
            extracted_fields=extracted_fields,
            confidence_scores=confidence_scores,
            overall_confidence=consensus_result.overall_confidence,
            consensus_rate=consensus_result.consensus_score,
            agreed_fields=consensus_result.agreed_fields,
            disputed_fields=consensus_result.disputed_fields,
            total_fields=consensus_result.total_fields,
            requires_human_review=requires_human_review,
            processing_time_ms=session.elapsed_time_ms(),
            council_members=consensus_result.participating_members,
            voting_strategy=consensus_result.voting_strategy.value,
            metadata={
                "phase_times": session.phase_times,
                "conflict_count": len(resolution_results),
                "document_type": session.document_type,
            },
        )

    def get_session(self, session_id: str) -> CouncilSession | None:
        """Get a session by ID."""
        return self._sessions.get(session_id)

    def get_session_history(self, limit: int | None = None) -> list[CouncilSession]:
        """Get session history."""
        sessions = list(self._sessions.values())
        if limit:
            return sessions[-limit:]
        return sessions

    def get_council_statistics(self) -> dict[str, Any]:
        """Get overall council statistics."""
        sessions = list(self._sessions.values())

        if not sessions:
            return {
                "total_sessions": 0,
                "average_processing_time_ms": 0,
                "consensus_rate": 0,
            }

        total_time = sum(s.elapsed_time_ms() for s in sessions)
        avg_time = total_time / len(sessions)

        consensus_rates = [
            s.consensus_result.consensus_score for s in sessions if s.consensus_result
        ]
        avg_consensus = sum(consensus_rates) / len(consensus_rates) if consensus_rates else 0

        return {
            "total_sessions": len(sessions),
            "average_processing_time_ms": avg_time,
            "consensus_rate": avg_consensus,
            "human_reviews_required": sum(
                1
                for s in sessions
                if s.consensus_result and s.consensus_result.requires_human_review
            ),
            "conflict_count": sum(len(s.resolution_results) for s in sessions),
        }
