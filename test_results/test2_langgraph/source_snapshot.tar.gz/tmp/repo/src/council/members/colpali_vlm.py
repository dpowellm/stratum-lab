"""ColPali VLM Council Member implementation.

ColPali is the "Visual Document Expert" in the council - a PaliGemma-based
vision-language model that processes documents directly from images without
a separate OCR pipeline.

Strengths:
- Excellent visual document understanding
- Strong at complex layouts and mixed content
- Handles charts, diagrams, and forms well
- Direct image-to-text without OCR pipeline

Weaknesses:
- Slower inference than OCR-first approaches
- GGUF-only (no API/vLLM/transformers fallback)
- Higher memory requirements
"""

import asyncio
import base64
import json
import time
from typing import Any

from src.core.logging import get_logger
from src.council.members.base import (
    CouncilMember,
    ExtractionResult,
    FieldExtraction,
    MemberCapability,
)

logger = get_logger(__name__)


class ColPaliVLMMember(CouncilMember):
    """ColPali VLM council member - Visual Document Expert.

    Uses ColPali (PaliGemma-based) for visual document understanding.
    GGUF-only backend via llama.cpp.
    """

    def __init__(
        self,
        gguf_path: str | None = None,
        mmproj_path: str | None = None,
        max_tokens: int = 4096,
        n_gpu_layers: int = -1,
        temperature: float = 0.0,
        confidence_threshold: float = 0.6,
    ):
        """Initialize ColPali VLM member.

        Args:
            gguf_path: Path to GGUF model file (required for inference)
            mmproj_path: Path to multimodal projector GGUF
            max_tokens: Maximum tokens in response
            n_gpu_layers: GPU layers for llama.cpp (-1 = all)
            temperature: Sampling temperature
            confidence_threshold: Minimum confidence threshold
        """
        super().__init__(
            name="colpali",
            model_version="colpali-v1.3",
            capabilities=[
                MemberCapability.TEXT_EXTRACTION,
                MemberCapability.LAYOUT_ANALYSIS,
                MemberCapability.FORM_UNDERSTANDING,
                MemberCapability.TABLE_EXTRACTION,
                MemberCapability.CHART_UNDERSTANDING,
                MemberCapability.DIAGRAM_ANALYSIS,
                MemberCapability.IMAGE_REASONING,
                MemberCapability.LOCAL_PROCESSING,
            ],
            confidence_threshold=confidence_threshold,
        )

        self._gguf_path = gguf_path
        self._mmproj_path = mmproj_path
        self._max_tokens = max_tokens
        self._n_gpu_layers = n_gpu_layers
        self._temperature = temperature
        self._llamacpp = None

    async def initialize(self) -> None:
        """Initialize ColPali VLM via llama.cpp.

        Raises:
            RuntimeError: If no gguf_path is provided (GGUF-only backend).
        """
        if self._initialized:
            return

        if not self._gguf_path:
            raise RuntimeError(
                "ColPali requires a GGUF model path. Download with: "
                "python scripts/download_models.py --model colpali"
            )

        logger.info(
            "Initializing ColPali VLM",
            gguf_path=self._gguf_path,
            n_gpu_layers=self._n_gpu_layers,
        )

        try:
            from llama_cpp import Llama

            kwargs: dict[str, Any] = {
                "model_path": self._gguf_path,
                "n_ctx": self._max_tokens,
                "n_gpu_layers": self._n_gpu_layers,
                "verbose": False,
            }

            if self._mmproj_path:
                from llama_cpp.llama_chat_format import Llava16ChatHandler

                kwargs["chat_handler"] = Llava16ChatHandler(
                    clip_model_path=self._mmproj_path,
                    verbose=False,
                )

            loop = asyncio.get_running_loop()
            self._llamacpp = await loop.run_in_executor(
                None,
                lambda: Llama(**kwargs),
            )

            self._initialized = True
            logger.info("ColPali VLM initialized successfully")

        except ImportError as e:
            logger.error("Required package not installed", error=str(e))
            raise RuntimeError(f"Required package not installed: {e}") from e
        except Exception as e:
            logger.error("Failed to initialize ColPali VLM", error=str(e))
            raise

    async def shutdown(self) -> None:
        """Shutdown ColPali VLM and release resources."""
        if self._llamacpp:
            del self._llamacpp
            self._llamacpp = None

        self._initialized = False
        logger.info("ColPali VLM shutdown complete")

    async def extract(
        self,
        image_data: bytes,
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> ExtractionResult:
        """Extract text and fields from a document image.

        Args:
            image_data: Document image as bytes
            document_type: Type hint for extraction
            target_fields: Specific fields to extract
            options: Additional options

        Returns:
            ExtractionResult with extracted fields
        """
        if not self._initialized:
            await self.initialize()

        start_time = time.time()

        try:
            prompt = self._build_extraction_prompt(document_type, target_fields)
            response = await self._call_llamacpp(image_data, prompt)
            fields = self._parse_response(response, document_type)
            fields = self._filter_by_confidence(fields)

            elapsed_ms = int((time.time() - start_time) * 1000)

            return ExtractionResult(
                member_name=self._name,
                model_version=self._model_version,
                fields=fields,
                processing_time_ms=elapsed_ms,
                page_count=1,
                raw_response={"text": response},
            )

        except Exception as e:
            elapsed_ms = int((time.time() - start_time) * 1000)
            logger.error("ColPali VLM extraction failed", error=str(e))

            return ExtractionResult(
                member_name=self._name,
                model_version=self._model_version,
                fields=[],
                processing_time_ms=elapsed_ms,
                page_count=0,
                status="error",
                error_message=str(e),
            )

    async def extract_batch(
        self,
        images: list[bytes],
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> list[ExtractionResult]:
        """Extract from multiple images sequentially (local model)."""
        results = []
        for img in images:
            result = await self.extract(img, document_type, target_fields, options)
            results.append(result)
        return results

    def _build_extraction_prompt(
        self,
        document_type: str | None,
        target_fields: list[str] | None,
    ) -> str:
        """Build the visual-first extraction prompt."""
        base_prompt = """You are an expert visual document analyst. Analyze this document image directly and extract all relevant information from the visual layout.

Please provide your response as a JSON object with this structure:
{
    "fields": [
        {
            "name": "field_name",
            "value": "extracted_value",
            "confidence": 0.95,
            "reasoning": "brief explanation"
        }
    ],
    "document_type": "detected_type",
    "layout_analysis": {
        "structure": "description of document structure",
        "key_regions": ["list of important regions"]
    },
    "summary": "comprehensive summary of document content"
}
"""

        if document_type:
            base_prompt += f"\nDocument Type: This appears to be a {document_type}."

        if target_fields:
            fields_str = ", ".join(target_fields)
            base_prompt += f"\n\nPriority Fields: Please focus on extracting: {fields_str}"

        base_prompt += """

Important Guidelines:
1. Analyze the visual layout directly - pay attention to spatial relationships
2. Be precise with values - extract exactly what you see
3. For numbers, include currency symbols and formatting
4. For dates, preserve the original format
5. Confidence should reflect your certainty (0.0-1.0)
6. If a field is unclear, still extract with lower confidence

Return only the JSON object, no additional text."""

        return base_prompt

    async def _call_llamacpp(self, image_data: bytes, prompt: str) -> str:
        """Call llama.cpp model for inference."""
        image_b64 = base64.b64encode(image_data).decode("utf-8")

        if self._mmproj_path:
            messages = [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{image_b64}",
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ]
        else:
            messages = [{"role": "user", "content": prompt}]

        loop = asyncio.get_running_loop()
        response = await loop.run_in_executor(
            None,
            lambda: self._llamacpp.create_chat_completion(
                messages=messages,
                max_tokens=self._max_tokens // 2,
                temperature=self._temperature if self._temperature > 0 else 0.0,
            ),
        )

        return response["choices"][0]["message"]["content"]

    def _parse_response(
        self,
        response: str,
        document_type: str | None,
    ) -> list[FieldExtraction]:
        """Parse model response into field extractions."""
        fields = []

        try:
            if "```json" in response:
                json_str = response.split("```json")[1].split("```")[0]
            elif "```" in response:
                json_str = response.split("```")[1].split("```")[0]
            else:
                json_str = response

            data = json.loads(json_str.strip())

            for field_data in data.get("fields", []):
                fields.append(
                    FieldExtraction(
                        field_name=field_data.get("name", "unknown"),
                        value=field_data.get("value"),
                        confidence=field_data.get("confidence", 0.8),
                        extraction_method="colpali_vlm",
                        raw_text=field_data.get("reasoning"),
                    )
                )

            if data.get("layout_analysis"):
                fields.append(
                    FieldExtraction(
                        field_name="layout_analysis",
                        value=data["layout_analysis"],
                        confidence=0.9,
                        extraction_method="colpali_vlm_analysis",
                    )
                )

            if data.get("document_type"):
                fields.append(
                    FieldExtraction(
                        field_name="detected_document_type",
                        value=data["document_type"],
                        confidence=0.9,
                        extraction_method="colpali_vlm",
                    )
                )

            if data.get("summary"):
                fields.append(
                    FieldExtraction(
                        field_name="document_summary",
                        value=data["summary"],
                        confidence=0.85,
                        extraction_method="colpali_vlm_analysis",
                    )
                )

        except json.JSONDecodeError:
            logger.warning("Failed to parse JSON response, using text extraction")
            fields.append(
                FieldExtraction(
                    field_name="raw_extraction",
                    value=response,
                    confidence=0.7,
                    extraction_method="colpali_vlm_text",
                )
            )

        return fields
