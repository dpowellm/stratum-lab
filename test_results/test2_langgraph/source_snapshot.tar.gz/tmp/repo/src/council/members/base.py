"""Base council member interface.

Defines the contract that all council members (OCR/VLM models) must implement.
"""

import asyncio
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any


class MemberCapability(Enum):
    """Capabilities that a council member may have."""

    # Core OCR
    TEXT_EXTRACTION = auto()
    HANDWRITING = auto()
    MULTILINGUAL = auto()

    # Layout understanding
    TABLE_EXTRACTION = auto()
    FORM_UNDERSTANDING = auto()
    LAYOUT_ANALYSIS = auto()

    # Visual understanding
    CHART_UNDERSTANDING = auto()
    DIAGRAM_ANALYSIS = auto()
    IMAGE_REASONING = auto()

    # Document types
    INVOICE_SPECIALIST = auto()
    CONTRACT_SPECIALIST = auto()
    RECEIPT_SPECIALIST = auto()

    # Performance
    FAST_INFERENCE = auto()
    LOCAL_PROCESSING = auto()
    BATCH_PROCESSING = auto()


@dataclass
class FieldExtraction:
    """A single field extracted by a council member."""

    field_name: str
    value: Any
    confidence: float
    bounding_box: dict[str, int] | None = None
    page_number: int = 1
    extraction_method: str = "ocr"
    raw_text: str | None = None
    alternatives: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "field_name": self.field_name,
            "value": self.value,
            "confidence": self.confidence,
            "bounding_box": self.bounding_box,
            "page_number": self.page_number,
            "extraction_method": self.extraction_method,
            "raw_text": self.raw_text,
            "alternatives": self.alternatives,
        }


@dataclass
class ExtractionResult:
    """Result of a council member's extraction."""

    member_name: str
    model_version: str
    fields: list[FieldExtraction]
    processing_time_ms: int
    page_count: int
    status: str = "success"
    error_message: str | None = None
    raw_response: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "member_name": self.member_name,
            "model_version": self.model_version,
            "fields": [f.to_dict() for f in self.fields],
            "processing_time_ms": self.processing_time_ms,
            "page_count": self.page_count,
            "status": self.status,
            "error_message": self.error_message,
        }

    def get_field(self, field_name: str) -> FieldExtraction | None:
        """Get a specific field extraction."""
        for f in self.fields:
            if f.field_name == field_name:
                return f
        return None

    def to_votes(self) -> dict[str, dict[str, Any]]:
        """Convert to vote format for consensus engine."""
        return {
            field.field_name: {
                "value": field.value,
                "confidence": field.confidence,
                "source": self.member_name,
            }
            for field in self.fields
        }


class CouncilMember(ABC):
    """Abstract base class for council members.

    Each council member wraps an OCR/VLM model and provides
    a consistent interface for document extraction.
    """

    def __init__(
        self,
        name: str,
        model_version: str,
        capabilities: list[MemberCapability],
        confidence_threshold: float = 0.6,
    ):
        """Initialize council member.

        Args:
            name: Unique member name
            model_version: Version of underlying model
            capabilities: List of member capabilities
            confidence_threshold: Minimum confidence to report
        """
        self._name = name
        self._model_version = model_version
        self._capabilities = set(capabilities)
        self._confidence_threshold = confidence_threshold
        self._initialized = False

    @property
    def name(self) -> str:
        """Get member name."""
        return self._name

    @property
    def model_version(self) -> str:
        """Get model version."""
        return self._model_version

    @property
    def capabilities(self) -> set[MemberCapability]:
        """Get member capabilities."""
        return self._capabilities

    @property
    def is_initialized(self) -> bool:
        """Check if member is initialized."""
        return self._initialized

    def has_capability(self, capability: MemberCapability) -> bool:
        """Check if member has a specific capability."""
        return capability in self._capabilities

    @abstractmethod
    async def initialize(self) -> None:
        """Initialize the member (load model, warm up, etc.)."""
        pass

    @abstractmethod
    async def shutdown(self) -> None:
        """Shutdown the member (release resources)."""
        pass

    @abstractmethod
    async def extract(
        self,
        image_data: bytes,
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> ExtractionResult:
        """Extract fields from a document image.

        Args:
            image_data: Document image as bytes
            document_type: Type hint for extraction (invoice, contract, etc.)
            target_fields: Specific fields to extract (None = all)
            options: Model-specific options. May include:
                - layout_context: DocumentLayout dict with regions, tables, headings
                  for spatial-aware extraction
                - classification_mode: bool to indicate document classification

        Returns:
            ExtractionResult with extracted fields
        """
        pass

    @abstractmethod
    async def extract_batch(
        self,
        images: list[bytes],
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> list[ExtractionResult]:
        """Extract fields from multiple document images.

        Args:
            images: List of document images as bytes
            document_type: Type hint for extraction
            target_fields: Specific fields to extract
            options: Model-specific options

        Returns:
            List of ExtractionResults
        """
        pass

    async def health_check(self) -> dict[str, Any]:
        """Check member health status.

        Returns:
            Health status information
        """
        return {
            "name": self._name,
            "initialized": self._initialized,
            "model_version": self._model_version,
            "capabilities": [c.name for c in self._capabilities],
        }

    def _timed_operation(self, func):
        """Decorator to time operations."""

        async def wrapper(*args, **kwargs):
            start = time.time()
            result = await func(*args, **kwargs)
            elapsed_ms = int((time.time() - start) * 1000)
            return result, elapsed_ms

        return wrapper

    def _filter_by_confidence(
        self,
        fields: list[FieldExtraction],
    ) -> list[FieldExtraction]:
        """Filter fields below confidence threshold."""
        return [f for f in fields if f.confidence >= self._confidence_threshold]


class MockCouncilMember(CouncilMember):
    """Mock council member for testing."""

    def __init__(
        self,
        name: str = "mock_member",
        model_version: str = "mock-1.0",
    ):
        super().__init__(
            name=name,
            model_version=model_version,
            capabilities=[
                MemberCapability.TEXT_EXTRACTION,
                MemberCapability.FAST_INFERENCE,
            ],
        )
        self._mock_fields: dict[str, Any] = {}

    def set_mock_fields(self, fields: dict[str, Any]) -> None:
        """Set mock fields to return."""
        self._mock_fields = fields

    async def initialize(self) -> None:
        """Initialize mock member."""
        self._initialized = True

    async def shutdown(self) -> None:
        """Shutdown mock member."""
        self._initialized = False

    async def extract(
        self,
        image_data: bytes,
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> ExtractionResult:
        """Extract mock fields."""
        fields = []
        for field_name, field_data in self._mock_fields.items():
            if target_fields and field_name not in target_fields:
                continue

            fields.append(
                FieldExtraction(
                    field_name=field_name,
                    value=field_data.get("value"),
                    confidence=field_data.get("confidence", 0.9),
                )
            )

        return ExtractionResult(
            member_name=self._name,
            model_version=self._model_version,
            fields=fields,
            processing_time_ms=10,
            page_count=1,
        )

    async def extract_batch(
        self,
        images: list[bytes],
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> list[ExtractionResult]:
        """Extract mock fields from batch."""
        return [await self.extract(img, document_type, target_fields, options) for img in images]


async def _safe_extract(
    member: Any,
    image_data: bytes,
    document_type: str | None = None,
    target_fields: list[str] | None = None,
    options: dict[str, Any] | None = None,
    timeout_seconds: float = 120.0,
) -> ExtractionResult:
    """Run member.extract() with timeout and error handling.

    Returns an ExtractionResult with status='error' if the extraction
    times out or raises an exception, rather than propagating the error.

    Args:
        member: Council member (or any object with .extract(), .name, .model_version)
        image_data: Document image bytes
        document_type: Document type hint
        target_fields: Fields to extract
        options: Model-specific options
        timeout_seconds: Maximum seconds to wait

    Returns:
        ExtractionResult — either from the member or a synthetic error result.
    """
    member_name = getattr(member, "name", "unknown")
    model_version = getattr(member, "model_version", "unknown")
    start_time = time.time()
    try:
        result = await asyncio.wait_for(
            member.extract(
                image_data=image_data,
                document_type=document_type,
                target_fields=target_fields,
                options=options,
            ),
            timeout=timeout_seconds,
        )
        return result
    except TimeoutError:
        elapsed_ms = int((time.time() - start_time) * 1000)
        return ExtractionResult(
            member_name=member_name,
            model_version=model_version,
            fields=[],
            processing_time_ms=elapsed_ms,
            page_count=0,
            status="error",
            error_message=f"Extraction timeout after {timeout_seconds}s",
        )
    except Exception as exc:
        elapsed_ms = int((time.time() - start_time) * 1000)
        return ExtractionResult(
            member_name=member_name,
            model_version=model_version,
            fields=[],
            processing_time_ms=elapsed_ms,
            page_count=0,
            status="error",
            error_message=str(exc),
        )
