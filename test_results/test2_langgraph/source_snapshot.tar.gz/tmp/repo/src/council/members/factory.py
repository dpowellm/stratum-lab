"""Config-driven council member construction.

Creates real or mock council members based on settings, with per-member
error handling so one failing member doesn't break the whole pipeline.

Initialized members are cached as singletons to avoid reloading
multi-GB models on every document upload.
"""

import asyncio
import struct
from pathlib import Path
from typing import Any

from src.core.logging import get_logger
from src.council.members.base import CouncilMember, MockCouncilMember

logger = get_logger(__name__)

# Default cache directory used by scripts/download_models.py
_DEFAULT_CACHE = Path.home() / ".cache" / "agentic-doc-extraction" / "models"

# Map member key → GGUF subdirectory name
_GGUF_MEMBER_DIRS: dict[str, str] = {
    "olmocr": "olmocr",
    "qwen_vlm": "qwen",
    "colpali": "colpali",
}

# Singleton cache: member name → initialized CouncilMember (or None if init failed)
_initialized_members: dict[str, CouncilMember | None] = {}
_warmup_done: bool = False

# Map member key → model status key for ModelStatusService
_MEMBER_STATUS_KEYS: dict[str, str] = {
    "paddle_ocr": "paddle",
    "olmocr": "olmocr",
    "qwen_vlm": "qwen",
    "colpali": "colpali",
}

# Timeout for initializing a single member (seconds)
_INIT_TIMEOUT = 120


def create_council_members(
    settings: Any,
    use_mock: bool = False,
) -> list[CouncilMember]:
    """Create council members based on settings.

    Args:
        settings: Application settings instance (or mock with .council attrs)
        use_mock: Force mock members (for dev/testing)

    Returns:
        List of initialized CouncilMember instances.
        Members that fail to construct are skipped with a warning.
    """
    council = settings.council
    members: list[CouncilMember] = []

    member_configs = _get_enabled_member_configs(council)

    for name, config in member_configs.items():
        try:
            if use_mock:
                member = _create_mock_member(name)
            else:
                # Return cached member if already initialized
                if name in _initialized_members:
                    cached = _initialized_members[name]
                    if cached is not None:
                        members.append(cached)
                    continue
                member = _create_real_member(name, config, council)
            if member is not None:
                members.append(member)
        except Exception as exc:
            logger.warning(
                "Failed to create council member, skipping",
                member=name,
                error=str(exc),
            )

    return members


def get_ready_members() -> list[CouncilMember]:
    """Return only members that have been warmed up and are ready.

    Use this from the pipeline to get pre-initialized members without
    triggering model loading.
    """
    return [m for m in _initialized_members.values() if m is not None]


async def warmup_members(settings: Any) -> dict[str, bool]:
    """Initialize all enabled real members sequentially in the background.

    Loads one model at a time to avoid OOM.  Each member gets a timeout.
    Results are cached in ``_initialized_members`` and reflected in
    ``ModelStatusService``.

    This should be called once at startup, after ``check_downloaded()``.
    """
    global _warmup_done

    council = settings.council
    member_configs = _get_enabled_member_configs(council)
    results: dict[str, bool] = {}

    # Try to get the model status service (non-fatal if unavailable)
    status_svc = None
    try:
        from src.services.models.status import ModelStatus, get_model_status_service

        status_svc = get_model_status_service()
    except Exception:
        logger.debug("ModelStatusService not available during warmup")

    for name, config in member_configs.items():
        if name in _initialized_members:
            results[name] = _initialized_members[name] is not None
            continue

        try:
            member = _create_real_member(name, config, council)
            if member is None:
                _initialized_members[name] = None
                results[name] = False
                continue

            # Mark as loading
            status_key = _MEMBER_STATUS_KEYS.get(name)
            if status_svc and status_key:
                status_svc.set_status(status_key, ModelStatus.LOADING)

            # Initialize with timeout — run in executor to avoid GIL blocking
            logger.info("Warming up council member", member=name)
            loop = asyncio.get_running_loop()
            await asyncio.wait_for(
                loop.run_in_executor(None, _init_member_sync, member),
                timeout=_INIT_TIMEOUT,
            )

            _initialized_members[name] = member
            results[name] = True

            if status_svc and status_key:
                status_svc.set_status(status_key, ModelStatus.READY)

            logger.info("Council member warmed up", member=name)

        except TimeoutError:
            _initialized_members[name] = None
            results[name] = False
            if status_svc and status_key:
                status_svc.set_error(status_key, f"Initialization timed out ({_INIT_TIMEOUT}s)")
            logger.warning("Council member init timed out", member=name)

        except Exception as exc:
            _initialized_members[name] = None
            results[name] = False
            if status_svc and status_key:
                status_svc.set_error(status_key, str(exc))
            logger.warning("Council member warmup failed", member=name, error=str(exc))

    _warmup_done = True
    ready = sum(1 for v in results.values() if v)
    logger.info("Council warmup complete", ready=ready, total=len(results))
    return results


def _init_member_sync(member: CouncilMember) -> None:
    """Initialize a member synchronously (runs in thread executor).

    Members' initialize() methods are async, so we need a private
    event loop inside the thread.
    """
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(member.initialize())
    finally:
        loop.close()


def is_warmup_done() -> bool:
    """Check if model warm-up has completed."""
    return _warmup_done


# Architectures known to work with llama.cpp (llama-cpp-python 0.3.x)
_SUPPORTED_GGUF_ARCHITECTURES: set[str] = {
    "llama",
    "falcon",
    "gpt2",
    "gptj",
    "gptneox",
    "mpt",
    "baichuan",
    "starcoder",
    "refact",
    "bert",
    "bloom",
    "stablelm",
    "qwen",
    "qwen2",
    "qwen2vl",
    "phi2",
    "phi3",
    "plamo",
    "codeshell",
    "orion",
    "internlm2",
    "minicpm",
    "gemma",
    "gemma2",
    "starcoder2",
    "mamba",
    "command-r",
    "dbrx",
    "olmo",
    "openelm",
    "arctic",
    "deepseek",
    "deepseek2",
    "chatglm",
    "bitnet",
    "t5",
    "t5encoder",
    "jais",
    "nemotron",
    "exaone",
    "rwkv6",
    "granite",
    "chameleon",
    "wavtokenizer",
    "paligemma",
}


def _validate_gguf_architecture(path: Path) -> str | None:
    """Read the architecture string from a GGUF file header.

    Returns the architecture string if it's supported by llama.cpp,
    or ``None`` if the file is unreadable or uses an unsupported architecture.
    """
    try:
        with path.open("rb") as f:
            magic = f.read(4)
            if magic != b"GGUF":
                logger.warning("Not a valid GGUF file", path=str(path))
                return None

            # GGUF header: magic(4) + version(4) + tensor_count(8) + kv_count(8)
            version = struct.unpack("<I", f.read(4))[0]
            if version < 2:
                logger.warning("Unsupported GGUF version", version=version, path=str(path))
                return None

            _tensor_count = struct.unpack("<Q", f.read(8))[0]
            kv_count = struct.unpack("<Q", f.read(8))[0]

            # Scan KV pairs for "general.architecture"
            for _ in range(kv_count):
                # Read key: length(8 bytes) + string
                key_len = struct.unpack("<Q", f.read(8))[0]
                key = f.read(key_len).decode("utf-8", errors="replace")

                # Read value type (4 bytes)
                value_type = struct.unpack("<I", f.read(4))[0]

                if key == "general.architecture" and value_type == 8:  # 8 = string
                    val_len = struct.unpack("<Q", f.read(8))[0]
                    arch = f.read(val_len).decode("utf-8", errors="replace")

                    if arch.lower() in _SUPPORTED_GGUF_ARCHITECTURES:
                        return arch
                    else:
                        logger.warning(
                            "GGUF architecture not supported by llama.cpp",
                            architecture=arch,
                            path=str(path),
                        )
                        return None
                else:
                    # Skip this value — we only need to read enough to skip
                    _skip_gguf_value(f, value_type)

    except Exception as exc:
        logger.warning("Failed to validate GGUF file", path=str(path), error=str(exc))
    return None


def _skip_gguf_value(f: Any, value_type: int) -> None:
    """Skip over a GGUF metadata value based on its type."""
    # GGUF value types: 0=u8, 1=i8, 2=u16, 3=i16, 4=u32, 5=i32,
    # 6=f32, 7=bool, 8=string, 9=array, 10=u64, 11=i64, 12=f64
    fixed_sizes = {0: 1, 1: 1, 2: 2, 3: 2, 4: 4, 5: 4, 6: 4, 7: 1, 10: 8, 11: 8, 12: 8}
    if value_type in fixed_sizes:
        f.read(fixed_sizes[value_type])
    elif value_type == 8:  # string
        slen = struct.unpack("<Q", f.read(8))[0]
        f.read(slen)
    elif value_type == 9:  # array
        arr_type = struct.unpack("<I", f.read(4))[0]
        arr_len = struct.unpack("<Q", f.read(8))[0]
        for _ in range(arr_len):
            _skip_gguf_value(f, arr_type)


def _discover_gguf_path(member_key: str) -> str | None:
    """Auto-discover a downloaded GGUF model file for a member.

    Scans the default download cache at
    ``~/.cache/agentic-doc-extraction/models/gguf/{key}/`` for ``.gguf``
    files.  Validates that the GGUF architecture is supported by llama.cpp.
    Returns the first valid model file found (skips mmproj files),
    or ``None`` if nothing is present or compatible.
    """
    subdir = _GGUF_MEMBER_DIRS.get(member_key)
    if not subdir:
        return None
    gguf_dir = _DEFAULT_CACHE / "gguf" / subdir
    if not gguf_dir.exists():
        return None
    # Prefer main model file (skip mmproj projector files)
    for path in sorted(gguf_dir.rglob("*.gguf")):
        if "mmproj" not in path.name:
            arch = _validate_gguf_architecture(path)
            if arch is not None:
                logger.info(
                    "Auto-discovered GGUF model",
                    member=member_key,
                    path=str(path),
                    architecture=arch,
                )
                return str(path)
            else:
                logger.warning(
                    "Skipping incompatible GGUF model",
                    member=member_key,
                    path=str(path),
                )
    return None


def _discover_mmproj_path(member_key: str) -> str | None:
    """Auto-discover a downloaded multimodal projector GGUF file."""
    subdir = _GGUF_MEMBER_DIRS.get(member_key)
    if not subdir:
        return None
    gguf_dir = _DEFAULT_CACHE / "gguf" / subdir
    if not gguf_dir.exists():
        return None
    for path in sorted(gguf_dir.rglob("*.gguf")):
        if "mmproj" in path.name:
            return str(path)
    return None


def _get_enabled_member_configs(council: Any) -> dict[str, dict[str, Any]]:
    """Build config dicts for each enabled member.

    When a GGUF path is not explicitly configured, attempts to discover
    models that were downloaded by ``scripts/download_models.py``.
    """
    configs: dict[str, dict[str, Any]] = {}

    if council.paddle_ocr_enabled:
        configs["paddle_ocr"] = {
            "model_dir": getattr(council, "paddle_ocr_model_dir", None),
        }

    if council.olmocr_enabled:
        gguf_path = getattr(council, "olmocr_gguf_path", None)
        if not gguf_path:
            gguf_path = _discover_gguf_path("olmocr")
        configs["olmocr"] = {
            "gguf_path": gguf_path,
            "vllm_url": getattr(council, "olmocr_vllm_url", None),
        }

    if council.qwen_enabled:
        gguf_path = getattr(council, "qwen_gguf_path", None)
        if not gguf_path:
            gguf_path = _discover_gguf_path("qwen_vlm")
        configs["qwen_vlm"] = {
            "gguf_path": gguf_path,
            "mmproj_path": _discover_mmproj_path("qwen_vlm") if gguf_path else None,
            "vllm_url": getattr(council, "qwen_vllm_url", None),
        }

    if council.colpali_enabled:
        gguf_path = getattr(council, "colpali_gguf_path", None)
        if not gguf_path:
            gguf_path = _discover_gguf_path("colpali")
        configs["colpali"] = {
            "gguf_path": gguf_path,
            "mmproj_path": _discover_mmproj_path("colpali") if gguf_path else None,
        }

    return configs


def _create_mock_member(name: str) -> MockCouncilMember:
    """Create a mock member with the right name and version."""
    versions = {
        "paddle_ocr": "paddleocr-2.8.0",
        "olmocr": "olmocr-2-7b",
        "qwen_vlm": "qwen2.5-vl-7b",
        "colpali": "colpali-v1.3",
    }
    return MockCouncilMember(name=name, model_version=versions.get(name, "mock-1.0"))


def _create_olmocr_member(config: dict[str, Any]) -> CouncilMember | None:
    """Create an olmOCR member if a viable backend is available."""
    gguf_path = config.get("gguf_path")
    vllm_url = config.get("vllm_url")
    if not gguf_path and not vllm_url:
        logger.warning("olmOCR has no viable backend (no GGUF path, no vLLM URL), skipping")
        return None

    from src.council.members.olmocr import OlmOCRMember

    return OlmOCRMember(
        gguf_path=gguf_path,
        vllm_url=vllm_url,
    )


def _create_real_member(
    name: str,
    config: dict[str, Any],
    _council: Any,
) -> CouncilMember | None:
    """Create a real council member instance.

    Returns None if the member cannot be created (e.g. missing GGUF path
    for a GGUF-only member and no fallback available).
    """
    if name == "paddle_ocr":
        from src.council.members.paddle_ocr import PaddleOCRMember

        kwargs: dict[str, Any] = {}
        if config.get("model_dir"):
            kwargs["det_model_dir"] = config["model_dir"]
        return PaddleOCRMember(**kwargs)

    if name == "olmocr":
        return _create_olmocr_member(config)

    if name == "qwen_vlm":
        from src.council.members.qwen_vlm import QwenVLMMember

        return QwenVLMMember(
            gguf_path=config.get("gguf_path"),
            mmproj_path=config.get("mmproj_path"),
            vllm_url=config.get("vllm_url"),
        )

    if name == "colpali":
        from src.council.members.colpali_vlm import ColPaliVLMMember

        gguf_path = config.get("gguf_path")
        if not gguf_path:
            logger.warning("ColPali requires GGUF path but none provided, skipping")
            return None
        return ColPaliVLMMember(
            gguf_path=gguf_path,
            mmproj_path=config.get("mmproj_path"),
        )

    logger.warning("Unknown council member name", member=name)
    return None
