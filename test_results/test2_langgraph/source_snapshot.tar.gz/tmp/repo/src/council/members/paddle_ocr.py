"""PaddleOCR Council Member implementation.

PaddleOCR is the "Speed Expert" in the council - a fast, local OCR
model that excels at text extraction and table recognition.

Strengths:
- Fast inference (local processing)
- Good table extraction
- Multilingual support
- No API costs

Weaknesses:
- Less accurate on complex layouts
- Limited reasoning capability
- May struggle with handwriting
"""

import asyncio
import io
import time
from typing import Any

import numpy as np
from PIL import Image

from src.core.logging import get_logger
from src.council.members.base import (
    CouncilMember,
    ExtractionResult,
    FieldExtraction,
    MemberCapability,
)

logger = get_logger(__name__)


class PaddleOCRMember(CouncilMember):
    """PaddleOCR council member - Speed Expert.

    Uses PaddleOCR for fast, local OCR processing.
    """

    def __init__(
        self,
        use_gpu: bool = False,
        lang: str = "en",
        det_model_dir: str | None = None,
        rec_model_dir: str | None = None,
        cls_model_dir: str | None = None,
        confidence_threshold: float = 0.6,
    ):
        """Initialize PaddleOCR member.

        Args:
            use_gpu: Whether to use GPU acceleration
            lang: Language for OCR (en, ch, etc.)
            det_model_dir: Custom detection model directory
            rec_model_dir: Custom recognition model directory
            cls_model_dir: Custom classification model directory
            confidence_threshold: Minimum confidence threshold
        """
        super().__init__(
            name="paddle_ocr",
            model_version="paddleocr-2.8.0",
            capabilities=[
                MemberCapability.TEXT_EXTRACTION,
                MemberCapability.TABLE_EXTRACTION,
                MemberCapability.MULTILINGUAL,
                MemberCapability.FAST_INFERENCE,
                MemberCapability.LOCAL_PROCESSING,
                MemberCapability.BATCH_PROCESSING,
            ],
            confidence_threshold=confidence_threshold,
        )

        self._use_gpu = use_gpu
        self._lang = lang
        self._det_model_dir = det_model_dir
        self._rec_model_dir = rec_model_dir
        self._cls_model_dir = cls_model_dir
        self._ocr = None
        self._table_engine = None

    async def initialize(self) -> None:
        """Initialize PaddleOCR models.

        Model loading is CPU-heavy so it runs in a thread executor to avoid
        blocking the asyncio event loop.
        """
        if self._initialized:
            return

        logger.info(
            "Initializing PaddleOCR",
            use_gpu=self._use_gpu,
            lang=self._lang,
        )

        try:
            loop = asyncio.get_running_loop()
            self._ocr, self._table_engine = await loop.run_in_executor(None, self._load_models)

            self._initialized = True
            logger.info("PaddleOCR initialized successfully")

        except ImportError as e:
            logger.error("PaddleOCR not installed", error=str(e))
            raise RuntimeError("PaddleOCR is required but not installed") from e
        except Exception as e:
            logger.error("Failed to initialize PaddleOCR", error=str(e))
            raise

    def _load_models(self):
        """Load PaddleOCR models synchronously (called from thread executor)."""
        from paddleocr import PaddleOCR, PPStructure

        ocr = PaddleOCR(
            use_angle_cls=True,
            lang=self._lang,
            use_gpu=self._use_gpu,
            det_model_dir=self._det_model_dir,
            rec_model_dir=self._rec_model_dir,
            cls_model_dir=self._cls_model_dir,
            show_log=False,
        )

        table_engine = PPStructure(
            use_gpu=self._use_gpu,
            show_log=False,
            table=True,
            ocr=True,
        )

        return ocr, table_engine

    async def shutdown(self) -> None:
        """Shutdown PaddleOCR."""
        self._ocr = None
        self._table_engine = None
        self._initialized = False
        logger.info("PaddleOCR shutdown complete")

    async def extract(
        self,
        image_data: bytes,
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> ExtractionResult:
        """Extract text and fields from a document image.

        Args:
            image_data: Document image as bytes
            document_type: Type hint for extraction
            target_fields: Specific fields to extract
            options: Additional options
                - extract_tables: bool - Extract tables (default: True)
                - detect_layout: bool - Detect layout structure (default: True)

        Returns:
            ExtractionResult with extracted fields
        """
        if not self._initialized:
            await self.initialize()

        options = options or {}
        start_time = time.time()

        try:
            # Convert bytes to numpy array
            image = Image.open(io.BytesIO(image_data))
            img_array = np.array(image)

            # Run OCR
            ocr_result = await asyncio.get_running_loop().run_in_executor(
                None, self._ocr.ocr, img_array, True
            )

            # Extract text blocks
            fields = []
            full_text_lines = []

            for page_result in ocr_result:
                if page_result is None:
                    continue

                for line in page_result:
                    if len(line) < 2:
                        continue

                    bbox, (text, confidence) = line
                    full_text_lines.append(text)

                    # Create field extraction for each text block
                    fields.append(
                        FieldExtraction(
                            field_name=f"text_block_{len(fields)}",
                            value=text,
                            confidence=confidence,
                            bounding_box=_bbox_to_dict(bbox),
                            extraction_method="paddle_ocr",
                        )
                    )

            # Extract structured fields based on document type
            if document_type:
                structured_fields = await self._extract_structured_fields(
                    full_text_lines,
                    document_type,
                    target_fields,
                )
                fields.extend(structured_fields)

            # Extract tables if requested
            if options.get("extract_tables", True):
                table_fields = await self._extract_tables(img_array)
                fields.extend(table_fields)

            # Filter by confidence
            fields = self._filter_by_confidence(fields)

            elapsed_ms = int((time.time() - start_time) * 1000)

            return ExtractionResult(
                member_name=self._name,
                model_version=self._model_version,
                fields=fields,
                processing_time_ms=elapsed_ms,
                page_count=1,
            )

        except Exception as e:
            elapsed_ms = int((time.time() - start_time) * 1000)
            logger.error("PaddleOCR extraction failed", error=str(e))

            return ExtractionResult(
                member_name=self._name,
                model_version=self._model_version,
                fields=[],
                processing_time_ms=elapsed_ms,
                page_count=0,
                status="error",
                error_message=str(e),
            )

    async def extract_batch(
        self,
        images: list[bytes],
        document_type: str | None = None,
        target_fields: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> list[ExtractionResult]:
        """Extract from multiple images in batch."""
        results = []

        for image_data in images:
            result = await self.extract(
                image_data,
                document_type,
                target_fields,
                options,
            )
            results.append(result)

        return results

    async def _extract_tables(
        self,
        img_array: np.ndarray,
    ) -> list[FieldExtraction]:
        """Extract tables from image using PPStructure."""
        if self._table_engine is None:
            return []

        try:
            from src.services.document.table_parser import parse_html_table

            result = await asyncio.get_running_loop().run_in_executor(
                None, self._table_engine, img_array
            )

            fields = []
            for idx, item in enumerate(result):
                if item.get("type") == "table":
                    html = item.get("res", {}).get("html", "")
                    parsed = parse_html_table(html)
                    fields.append(
                        FieldExtraction(
                            field_name=f"table_{idx}",
                            value=parsed if parsed["rows"] else html,
                            confidence=0.9,  # Tables don't have confidence
                            bounding_box=_bbox_to_dict(item.get("bbox")),
                            extraction_method="paddle_structure",
                        )
                    )

            return fields

        except Exception as e:
            logger.warning("Table extraction failed", error=str(e))
            return []

    async def _extract_structured_fields(
        self,
        text_lines: list[str],
        document_type: str,
        target_fields: list[str] | None,
    ) -> list[FieldExtraction]:
        """Extract structured fields based on document type.

        Uses pattern matching and heuristics for common fields.
        """
        fields = []
        full_text = "\n".join(text_lines)

        # Field extraction patterns by document type
        patterns = EXTRACTION_PATTERNS.get(document_type, {})

        for field_name, pattern_func in patterns.items():
            if target_fields and field_name not in target_fields:
                continue

            try:
                value, confidence = pattern_func(full_text, text_lines)
                if value:
                    fields.append(
                        FieldExtraction(
                            field_name=field_name,
                            value=value,
                            confidence=confidence,
                            extraction_method="pattern_match",
                        )
                    )
            except Exception:
                logger.debug("Pattern extraction failed", field_name=field_name)

        return fields


def _bbox_to_dict(bbox: list | None) -> dict[str, int] | None:
    """Convert PaddleOCR bbox to dict format."""
    if bbox is None or len(bbox) < 4:
        return None

    # PaddleOCR returns [[x1,y1], [x2,y2], [x3,y3], [x4,y4]]
    try:
        points = np.array(bbox)
        x_min = int(points[:, 0].min())
        y_min = int(points[:, 1].min())
        x_max = int(points[:, 0].max())
        y_max = int(points[:, 1].max())

        return {
            "x": x_min,
            "y": y_min,
            "width": x_max - x_min,
            "height": y_max - y_min,
        }
    except Exception:
        return None


# Pattern extraction functions for different document types
def _extract_invoice_number(text: str, _lines: list[str]) -> tuple[str | None, float]:
    """Extract invoice number from text."""
    import re

    patterns = [
        r"invoice\s*#?\s*:?\s*([A-Z0-9-]+)",
        r"inv\s*#?\s*:?\s*([A-Z0-9-]+)",
        r"#\s*([A-Z0-9-]{5,})",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1), 0.85

    return None, 0.0


def _extract_total_amount(text: str, _lines: list[str]) -> tuple[str | None, float]:
    """Extract total amount from text."""
    import re

    patterns = [
        r"total\s*:?\s*\$?\s*([\d,]+\.?\d*)",
        r"amount\s*due\s*:?\s*\$?\s*([\d,]+\.?\d*)",
        r"grand\s*total\s*:?\s*\$?\s*([\d,]+\.?\d*)",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            amount = match.group(1).replace(",", "")
            return f"${amount}", 0.85

    return None, 0.0


def _extract_date(text: str, _lines: list[str]) -> tuple[str | None, float]:
    """Extract date from text."""
    import re

    patterns = [
        r"date\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
        r"(\d{1,2}[/-]\d{1,2}[/-]\d{4})",
        r"(\w+\s+\d{1,2},?\s+\d{4})",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1), 0.80

    return None, 0.0


def _extract_vendor_name(_text: str, lines: list[str]) -> tuple[str | None, float]:
    """Extract vendor/company name from text."""
    # Usually the first non-empty line is the company name
    for line in lines[:5]:  # Check first 5 lines
        stripped_line = line.strip()
        if len(stripped_line) > 3 and not stripped_line.isdigit():
            return stripped_line, 0.70

    return None, 0.0


# Extraction patterns by document type
EXTRACTION_PATTERNS = {
    "invoice": {
        "invoice_number": _extract_invoice_number,
        "total_amount": _extract_total_amount,
        "date": _extract_date,
        "vendor_name": _extract_vendor_name,
    },
    "receipt": {
        "total_amount": _extract_total_amount,
        "date": _extract_date,
        "vendor_name": _extract_vendor_name,
    },
}
