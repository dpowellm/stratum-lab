"""Circuit breaker pattern for council member fault tolerance.

Prevents cascading failures by tracking member health and temporarily
disabling members that are consistently failing.

States:
- CLOSED: Normal operation, failures counted
- OPEN: Member disabled, no requests sent
- HALF_OPEN: Trial request allowed after recovery timeout
"""

import time
from dataclasses import dataclass
from enum import StrEnum

from src.core.logging import get_logger

logger = get_logger(__name__)


class CircuitState(StrEnum):
    """Circuit breaker state."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class MemberCircuit:
    """Circuit breaker state for a single council member."""

    member_name: str
    state: CircuitState = CircuitState.CLOSED
    failure_count: int = 0
    success_count: int = 0
    last_failure_time: float = 0.0
    last_success_time: float = 0.0
    opened_at: float = 0.0


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker behavior."""

    failure_threshold: int = 3
    recovery_timeout_s: float = 300.0  # 5 minutes
    success_threshold: int = 2  # Successes needed in HALF_OPEN to close
    half_open_max_calls: int = 1


class CircuitBreaker:
    """Manages circuit breaker state for all council members."""

    def __init__(self, config: CircuitBreakerConfig | None = None):
        self.config = config or CircuitBreakerConfig()
        self._circuits: dict[str, MemberCircuit] = {}

    def get_circuit(self, member_name: str) -> MemberCircuit:
        """Get or create circuit for a member."""
        if member_name not in self._circuits:
            self._circuits[member_name] = MemberCircuit(member_name=member_name)
        return self._circuits[member_name]

    def is_available(self, member_name: str) -> bool:
        """Check if a member is available for requests.

        Returns True if circuit is CLOSED or HALF_OPEN (trial allowed).
        """
        circuit = self.get_circuit(member_name)

        if circuit.state == CircuitState.CLOSED:
            return True

        if circuit.state == CircuitState.OPEN:
            # Check if recovery timeout has elapsed
            elapsed = time.time() - circuit.opened_at
            if elapsed >= self.config.recovery_timeout_s:
                circuit.state = CircuitState.HALF_OPEN
                circuit.success_count = 0
                logger.info(
                    "Circuit breaker half-open",
                    member=member_name,
                    elapsed_s=elapsed,
                )
                return True
            return False

        # HALF_OPEN: allow limited calls
        return True

    def record_success(self, member_name: str) -> None:
        """Record a successful call to a member."""
        circuit = self.get_circuit(member_name)
        circuit.last_success_time = time.time()

        if circuit.state == CircuitState.HALF_OPEN:
            circuit.success_count += 1
            if circuit.success_count >= self.config.success_threshold:
                circuit.state = CircuitState.CLOSED
                circuit.failure_count = 0
                circuit.success_count = 0
                logger.info("Circuit breaker closed", member=member_name)
        elif circuit.state == CircuitState.CLOSED:
            # Reset failure count on success
            circuit.failure_count = 0

    def record_failure(self, member_name: str) -> None:
        """Record a failed call to a member."""
        circuit = self.get_circuit(member_name)
        circuit.failure_count += 1
        circuit.last_failure_time = time.time()

        if circuit.state == CircuitState.HALF_OPEN:
            # Failure in half-open → back to open
            circuit.state = CircuitState.OPEN
            circuit.opened_at = time.time()
            logger.warning(
                "Circuit breaker re-opened",
                member=member_name,
                failure_count=circuit.failure_count,
            )
        elif (
            circuit.state == CircuitState.CLOSED
            and circuit.failure_count >= self.config.failure_threshold
        ):
            circuit.state = CircuitState.OPEN
            circuit.opened_at = time.time()
            logger.warning(
                "Circuit breaker opened",
                member=member_name,
                failure_count=circuit.failure_count,
            )

    def get_available_members(self, member_names: list[str]) -> list[str]:
        """Filter list to only available members."""
        return [m for m in member_names if self.is_available(m)]

    def get_status(self) -> dict[str, dict]:
        """Get status of all circuits."""
        return {
            name: {
                "state": circuit.state.value,
                "failure_count": circuit.failure_count,
                "success_count": circuit.success_count,
            }
            for name, circuit in self._circuits.items()
        }


# Singleton
_circuit_breaker: CircuitBreaker | None = None


def get_circuit_breaker() -> CircuitBreaker:
    """Get or create the circuit breaker singleton."""
    global _circuit_breaker
    if _circuit_breaker is None:
        _circuit_breaker = CircuitBreaker()
    return _circuit_breaker
