"""
Extraction model for storing extraction results with field-level confidence.

This module defines models for:
- Extraction results
- Extracted fields with confidence scores
- Field-level source model attribution
- Human corrections tracking
"""

import enum
import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any

from sqlalchemy import (
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.models.database.base import Base

if TYPE_CHECKING:
    from src.models.database.council_session import CouncilSession
    from src.models.database.document import Document


class ValidationStatus(str, enum.Enum):
    """Validation status for extractions."""

    PENDING = "pending"
    VALID = "valid"
    INVALID = "invalid"
    CORRECTED = "corrected"
    HUMAN_VERIFIED = "human_verified"


class FieldType(str, enum.Enum):
    """Data type of extracted field."""

    TEXT = "text"
    NUMBER = "number"
    DATE = "date"
    CURRENCY = "currency"
    PERCENTAGE = "percentage"
    EMAIL = "email"
    PHONE = "phone"
    ADDRESS = "address"
    TABLE = "table"
    LIST = "list"
    BOOLEAN = "boolean"
    UNKNOWN = "unknown"


class ExtractedField(Base):
    """
    Individual extracted field with confidence and source tracking.

    Stores each extracted field separately to enable:
    - Field-level confidence tracking
    - Source model attribution
    - Individual field corrections
    - Validation status per field
    """

    __tablename__ = "extracted_fields"

    # Extraction reference
    extraction_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("extractions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Field information
    field_name: Mapped[str] = mapped_column(
        String(256),
        nullable=False,
        index=True,
    )
    field_type: Mapped[FieldType] = mapped_column(
        Enum(FieldType, values_callable=lambda x: [e.value for e in x], create_type=False),
        default=FieldType.TEXT,
        nullable=False,
    )

    # Extracted value (stored as JSON to support complex types)
    value: Mapped[Any] = mapped_column(
        JSONB,
        nullable=True,
    )
    raw_value: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    # Confidence and source
    confidence: Mapped[float] = mapped_column(
        Float,
        nullable=False,
    )
    source_model: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
    )
    alternative_values: Mapped[list[dict[str, Any]] | None] = mapped_column(
        JSONB,
        nullable=True,
    )  # Values from other models

    # Position in document (for highlighting)
    page_number: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
    )
    bounding_box: Mapped[dict[str, float] | None] = mapped_column(
        JSONB,
        nullable=True,
    )  # {x, y, width, height}

    # Validation
    validation_status: Mapped[ValidationStatus] = mapped_column(
        Enum(ValidationStatus, values_callable=lambda x: [e.value for e in x], create_type=False),
        default=ValidationStatus.PENDING,
        nullable=False,
    )
    validation_errors: Mapped[list[str] | None] = mapped_column(
        JSONB,
        nullable=True,
    )

    # Correction tracking
    was_corrected: Mapped[bool] = mapped_column(
        default=False,
        nullable=False,
    )
    original_value: Mapped[Any | None] = mapped_column(
        JSONB,
        nullable=True,
    )
    correction_source: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True,
    )  # 'judge', 'human', 'auto'
    corrected_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    corrected_by: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,
    )

    # Relationship
    extraction: Mapped["Extraction"] = relationship(
        "Extraction",
        back_populates="fields",
    )

    def correct(
        self,
        new_value: Any,
        source: str,
        corrected_by: str | None = None,
    ) -> None:
        """Apply a correction to this field."""
        if not self.was_corrected:
            self.original_value = self.value
        self.value = new_value
        self.was_corrected = True
        self.correction_source = source
        self.corrected_at = datetime.utcnow()
        self.corrected_by = corrected_by
        self.validation_status = ValidationStatus.CORRECTED

    def validate(self, is_valid: bool, errors: list[str] | None = None) -> None:
        """Set validation status for this field."""
        if is_valid:
            self.validation_status = ValidationStatus.VALID
            self.validation_errors = None
        else:
            self.validation_status = ValidationStatus.INVALID
            self.validation_errors = errors

    def human_verify(self, reviewer_id: str) -> None:
        """Mark field as human verified."""
        self.validation_status = ValidationStatus.HUMAN_VERIFIED
        self.corrected_by = reviewer_id
        self.corrected_at = datetime.utcnow()


class Extraction(Base):
    """
    Extraction result containing all extracted fields.

    Links to a document and council session, containing
    the final extraction result after council deliberation.
    """

    __tablename__ = "extractions"

    # Document reference
    document_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("documents.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Council session reference
    council_session_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("council_sessions.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    # Version tracking
    version: Mapped[int] = mapped_column(
        Integer,
        default=1,
        nullable=False,
    )
    is_latest: Mapped[bool] = mapped_column(
        default=True,
        nullable=False,
        index=True,
    )
    previous_version_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("extractions.id", ondelete="SET NULL"),
        nullable=True,
    )

    # Overall extraction metadata
    overall_confidence: Mapped[float] = mapped_column(
        Float,
        nullable=False,
    )
    field_count: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )

    # Validation status
    validation_status: Mapped[ValidationStatus] = mapped_column(
        Enum(ValidationStatus, values_callable=lambda x: [e.value for e in x], create_type=False),
        default=ValidationStatus.PENDING,
        nullable=False,
        index=True,
    )
    validation_errors: Mapped[list[dict[str, Any]] | None] = mapped_column(
        JSONB,
        nullable=True,
    )
    validated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # Human review tracking
    human_reviewed: Mapped[bool] = mapped_column(
        default=False,
        nullable=False,
    )
    human_reviewer_id: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,
    )
    human_reviewed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    human_corrections_count: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )

    # Structured extraction data (denormalized for quick access)
    extracted_data: Mapped[dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
    )

    # Extraction metadata
    extraction_metadata: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB,
        nullable=True,
        default=dict,
    )

    # Relationships
    document: Mapped["Document"] = relationship(
        "Document",
        back_populates="extractions",
    )
    council_session: Mapped["CouncilSession | None"] = relationship(
        "CouncilSession",
        back_populates="extraction",
    )
    fields: Mapped[list["ExtractedField"]] = relationship(
        "ExtractedField",
        back_populates="extraction",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    previous_version: Mapped["Extraction | None"] = relationship(
        "Extraction",
        remote_side="Extraction.id",
        uselist=False,
    )

    def add_field(
        self,
        field_name: str,
        value: Any,
        confidence: float,
        source_model: str,
        field_type: FieldType = FieldType.TEXT,
        raw_value: str | None = None,
        page_number: int | None = None,
        bounding_box: dict[str, float] | None = None,
        alternative_values: list[dict[str, Any]] | None = None,
    ) -> ExtractedField:
        """Add an extracted field to this extraction."""
        field = ExtractedField(
            extraction_id=self.id,
            field_name=field_name,
            field_type=field_type,
            value=value,
            raw_value=raw_value,
            confidence=confidence,
            source_model=source_model,
            page_number=page_number,
            bounding_box=bounding_box,
            alternative_values=alternative_values,
        )
        self.fields.append(field)
        self.field_count = len(self.fields)

        # Update denormalized data
        self.extracted_data[field_name] = value

        return field

    def validate_all(self) -> None:
        """Run validation on all fields and update status."""
        all_valid = True
        errors = []

        for field in self.fields:
            if field.validation_status == ValidationStatus.INVALID:
                all_valid = False
                if field.validation_errors:
                    errors.append({
                        "field": field.field_name,
                        "errors": field.validation_errors,
                    })

        if all_valid:
            self.validation_status = ValidationStatus.VALID
            self.validation_errors = None
        else:
            self.validation_status = ValidationStatus.INVALID
            self.validation_errors = errors

        self.validated_at = datetime.utcnow()

    def complete_human_review(self, reviewer_id: str) -> None:
        """Mark extraction as human reviewed."""
        self.human_reviewed = True
        self.human_reviewer_id = reviewer_id
        self.human_reviewed_at = datetime.utcnow()
        self.validation_status = ValidationStatus.HUMAN_VERIFIED

        # Count corrections
        self.human_corrections_count = sum(
            1 for field in self.fields if field.was_corrected
        )

    def create_new_version(self) -> "Extraction":
        """Create a new version of this extraction."""
        # Mark current as not latest
        self.is_latest = False

        # Create new version
        new_extraction = Extraction(
            document_id=self.document_id,
            council_session_id=self.council_session_id,
            version=self.version + 1,
            is_latest=True,
            previous_version_id=self.id,
            overall_confidence=self.overall_confidence,
            field_count=self.field_count,
            extracted_data=self.extracted_data.copy(),
            extraction_metadata=self.extraction_metadata,
        )

        return new_extraction

    def get_field(self, field_name: str) -> ExtractedField | None:
        """Get a specific field by name."""
        for field in self.fields:
            if field.field_name == field_name:
                return field
        return None

    @property
    def low_confidence_fields(self) -> list[ExtractedField]:
        """Get fields with confidence below threshold."""
        threshold = 0.85  # Could be configurable
        return [f for f in self.fields if f.confidence < threshold]

    @property
    def corrected_fields(self) -> list[ExtractedField]:
        """Get all corrected fields."""
        return [f for f in self.fields if f.was_corrected]
