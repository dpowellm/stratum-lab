"""
Council Session model for storing LLM Council deliberation sessions.

This module defines models for:
- Council deliberation sessions
- Individual member votes
- Conflict resolution details
- Processing metrics
"""

import enum
import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any

from sqlalchemy import (
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.models.database.base import Base

if TYPE_CHECKING:
    from src.models.database.document import Document
    from src.models.database.extraction import Extraction


class VotingStrategy(str, enum.Enum):
    """Voting strategy used by the council."""

    CONFIDENCE_WEIGHTED = "confidence_weighted"
    UNANIMOUS = "unanimous"
    EXPERTISE_DELEGATION = "expertise_delegation"
    CASCADING = "cascading"


class ConflictLevel(str, enum.Enum):
    """Conflict severity level."""

    NONE = "none"
    MINOR = "minor"  # 2 agree, 1 differs
    MODERATE = "moderate"  # All different
    MAJOR = "major"  # Critical field conflict


class ConflictResolution(str, enum.Enum):
    """How the conflict was resolved."""

    NOT_APPLICABLE = "not_applicable"
    MAJORITY_VOTE = "majority_vote"
    JUDGE_DECISION = "judge_decision"
    HUMAN_REVIEW = "human_review"


class MemberVote(Base):
    """
    Individual council member vote/result.

    Stores the extraction result from each council member
    for a specific council session.
    """

    __tablename__ = "member_votes"

    # Council session reference
    council_session_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("council_sessions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Member information
    member_name: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        index=True,
    )
    member_version: Mapped[str | None] = mapped_column(
        String(32),
        nullable=True,
    )

    # Extraction result
    extracted_fields: Mapped[dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
    )
    overall_confidence: Mapped[float] = mapped_column(
        Float,
        nullable=False,
    )
    field_confidences: Mapped[dict[str, float]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
    )

    # Processing metrics
    processing_time_ms: Mapped[float] = mapped_column(
        Float,
        nullable=False,
    )
    tokens_used: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
    )

    # Raw output (for debugging/audit)
    raw_output: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    # Error tracking
    had_error: Mapped[bool] = mapped_column(
        default=False,
        nullable=False,
    )
    error_message: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    # Relationship
    council_session: Mapped["CouncilSession"] = relationship(
        "CouncilSession",
        back_populates="member_votes",
    )


class CouncilSession(Base):
    """
    Council deliberation session.

    Records the complete deliberation process including:
    - Which council members participated
    - Individual member votes
    - Consensus calculation
    - Conflict resolution details
    - Final unified result
    """

    __tablename__ = "council_sessions"

    # Document reference
    document_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("documents.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Council configuration
    voting_strategy: Mapped[VotingStrategy] = mapped_column(
        Enum(VotingStrategy, values_callable=lambda x: [e.value for e in x], create_type=False),
        nullable=False,
        default=VotingStrategy.CONFIDENCE_WEIGHTED,
    )
    consensus_threshold: Mapped[float] = mapped_column(
        Float,
        nullable=False,
        default=0.85,
    )
    participating_members: Mapped[list[str]] = mapped_column(
        JSONB,
        nullable=False,
        default=list,
    )

    # Consensus results
    consensus_score: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
    )
    agreed_fields: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )
    disputed_fields: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )
    total_fields: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )

    # Conflict information
    conflict_level: Mapped[ConflictLevel] = mapped_column(
        Enum(ConflictLevel, values_callable=lambda x: [e.value for e in x], create_type=False),
        default=ConflictLevel.NONE,
        nullable=False,
    )
    conflict_details: Mapped[list[dict[str, Any]] | None] = mapped_column(
        JSONB,
        nullable=True,
    )
    resolution_method: Mapped[ConflictResolution] = mapped_column(
        Enum(ConflictResolution, values_callable=lambda x: [e.value for e in x], create_type=False),
        default=ConflictResolution.NOT_APPLICABLE,
        nullable=False,
    )

    # Judge model information (if used)
    judge_invoked: Mapped[bool] = mapped_column(
        default=False,
        nullable=False,
    )
    judge_model: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,
    )
    judge_reasoning: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )
    judge_confidence: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
    )

    # Human review
    human_review_required: Mapped[bool] = mapped_column(
        default=False,
        nullable=False,
    )
    human_review_reason: Mapped[str | None] = mapped_column(
        String(512),
        nullable=True,
    )
    human_reviewed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    human_reviewer_id: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,
    )

    # Processing metrics
    total_processing_time_ms: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
    )
    consensus_calculation_time_ms: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
    )

    # Final unified result
    unified_extraction: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB,
        nullable=True,
    )
    final_confidence: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
    )

    # Session metadata
    session_metadata: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB,
        nullable=True,
        default=dict,
    )

    # Relationships
    document: Mapped["Document"] = relationship(
        "Document",
        foreign_keys=[document_id],
        viewonly=True,
    )
    member_votes: Mapped[list["MemberVote"]] = relationship(
        "MemberVote",
        back_populates="council_session",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    extraction: Mapped["Extraction | None"] = relationship(
        "Extraction",
        back_populates="council_session",
        uselist=False,
    )

    def add_member_vote(
        self,
        member_name: str,
        extracted_fields: dict[str, Any],
        overall_confidence: float,
        field_confidences: dict[str, float],
        processing_time_ms: float,
        member_version: str | None = None,
        tokens_used: int | None = None,
        raw_output: str | None = None,
    ) -> MemberVote:
        """Add a member vote to the session."""
        vote = MemberVote(
            council_session_id=self.id,
            member_name=member_name,
            member_version=member_version,
            extracted_fields=extracted_fields,
            overall_confidence=overall_confidence,
            field_confidences=field_confidences,
            processing_time_ms=processing_time_ms,
            tokens_used=tokens_used,
            raw_output=raw_output,
        )
        self.member_votes.append(vote)
        return vote

    def record_consensus(
        self,
        consensus_score: float,
        agreed_fields: int,
        disputed_fields: int,
        total_fields: int,
        unified_extraction: dict[str, Any],
        final_confidence: float,
    ) -> None:
        """Record the consensus result."""
        self.consensus_score = consensus_score
        self.agreed_fields = agreed_fields
        self.disputed_fields = disputed_fields
        self.total_fields = total_fields
        self.unified_extraction = unified_extraction
        self.final_confidence = final_confidence

    def record_conflict(
        self,
        conflict_level: ConflictLevel,
        conflict_details: list[dict[str, Any]],
    ) -> None:
        """Record conflict information."""
        self.conflict_level = conflict_level
        self.conflict_details = conflict_details

    def record_judge_decision(
        self,
        judge_model: str,
        reasoning: str,
        confidence: float,
    ) -> None:
        """Record judge model decision."""
        self.judge_invoked = True
        self.judge_model = judge_model
        self.judge_reasoning = reasoning
        self.judge_confidence = confidence
        self.resolution_method = ConflictResolution.JUDGE_DECISION

    def flag_for_human_review(self, reason: str) -> None:
        """Flag session for human review."""
        self.human_review_required = True
        self.human_review_reason = reason
        self.resolution_method = ConflictResolution.HUMAN_REVIEW

    def complete_human_review(self, reviewer_id: str) -> None:
        """Mark human review as complete."""
        self.human_reviewed_at = datetime.utcnow()
        self.human_reviewer_id = reviewer_id

    @property
    def consensus_achieved(self) -> bool:
        """Check if consensus was achieved."""
        if self.consensus_score is None:
            return False
        return self.consensus_score >= self.consensus_threshold

    @property
    def member_count(self) -> int:
        """Get number of participating members."""
        return len(self.participating_members)
