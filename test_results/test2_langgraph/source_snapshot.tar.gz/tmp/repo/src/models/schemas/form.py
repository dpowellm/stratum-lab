"""
Form Extraction Schema.

Task 2.2.2: Creates schema and extraction logic for form documents.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class FieldType(str, Enum):
    """Form field types."""

    TEXT = "text"
    NUMBER = "number"
    DATE = "date"
    EMAIL = "email"
    PHONE = "phone"
    CHECKBOX = "checkbox"
    RADIO = "radio"
    SELECT = "select"
    TEXTAREA = "textarea"
    SIGNATURE = "signature"
    FILE = "file"
    UNKNOWN = "unknown"


@dataclass
class FormField:
    """Individual field on a form."""

    label: str
    value: Any = None
    field_type: FieldType = FieldType.TEXT
    required: bool = False
    options: list[str] = field(default_factory=list)
    is_handwritten: bool = False
    confidence: float = 0.0
    bounding_box: dict[str, float] | None = None
    validation_pattern: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def is_filled(self) -> bool:
        """Check if field has a value."""
        if self.field_type == FieldType.CHECKBOX:
            return self.value is True
        return self.value is not None and str(self.value).strip() != ""


@dataclass
class FormSection:
    """Section within a form."""

    title: str
    fields: list[FormField] = field(default_factory=list)
    description: str | None = None


@dataclass
class FormSchema:
    """
    Schema for form documents.

    Features:
    - Field label detection
    - Checkbox/radio recognition
    - Handwriting support
    - Signature detection
    """

    # Form identification
    form_title: str | None = None
    form_id: str | None = None
    form_version: str | None = None

    # Fields
    fields: list[FormField] = field(default_factory=list)
    sections: list[FormSection] = field(default_factory=list)

    # Form features
    has_signature: bool = False
    has_handwriting: bool = False
    has_checkboxes: bool = False
    has_tables: bool = False

    # Metadata
    page_count: int = 1
    language: str = "en"
    confidence: float = 0.0
    raw_text: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def get_field_by_label(self, label: str) -> FormField | None:
        """Get a field by its label."""
        for field in self.fields:
            if field.label.lower() == label.lower():
                return field
        return None

    def get_filled_fields(self) -> list[FormField]:
        """Get all filled fields."""
        return [f for f in self.fields if f.is_filled()]

    def get_required_empty_fields(self) -> list[FormField]:
        """Get required fields that are empty."""
        return [f for f in self.fields if f.required and not f.is_filled()]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "form_title": self.form_title,
            "form_id": self.form_id,
            "fields": [
                {
                    "label": f.label,
                    "value": f.value,
                    "field_type": f.field_type.value,
                    "required": f.required,
                    "is_handwritten": f.is_handwritten,
                    "confidence": f.confidence,
                }
                for f in self.fields
            ],
            "has_signature": self.has_signature,
            "has_handwriting": self.has_handwriting,
            "confidence": self.confidence,
        }


@dataclass
class FormValidationResult:
    """Result of form validation."""

    is_valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    missing_required: list[str] = field(default_factory=list)


def validate_form(data: dict[str, Any]) -> FormValidationResult:
    """
    Validate form data.

    Args:
        data: Form data dictionary

    Returns:
        FormValidationResult with validation status
    """
    errors = []
    warnings = []
    missing_required = []

    fields = data.get("fields", [])

    for field_data in fields:
        label = field_data.get("label", "Unknown")
        value = field_data.get("value")
        required = field_data.get("required", False)
        field_type = field_data.get("field_type", "text")

        # Check required fields
        if required:
            if value is None or (isinstance(value, str) and not value.strip()):
                missing_required.append(label)
                errors.append(f"Required field '{label}' is empty")

        # Validate email format
        if field_type == "email" and value:
            import re
            if not re.match(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", str(value)):
                errors.append(f"Invalid email format in '{label}'")

        # Validate phone format
        if field_type == "phone" and value:
            import re
            digits = re.sub(r"[\s\-\(\)\+\.]", "", str(value))
            if not (digits.isdigit() and 7 <= len(digits) <= 15):
                warnings.append(f"Unusual phone format in '{label}'")

    return FormValidationResult(
        is_valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        missing_required=missing_required,
    )


def detect_field_type(label: str, value: Any) -> FieldType:
    """
    Detect field type from label and value.

    Args:
        label: Field label
        value: Field value

    Returns:
        Detected FieldType
    """
    label_lower = label.lower()

    # Check value type first
    if isinstance(value, bool):
        return FieldType.CHECKBOX

    # Check label keywords
    if any(kw in label_lower for kw in ["email", "e-mail"]):
        return FieldType.EMAIL

    if any(kw in label_lower for kw in ["phone", "tel", "mobile", "cell"]):
        return FieldType.PHONE

    if any(kw in label_lower for kw in ["date", "dob", "birth"]):
        return FieldType.DATE

    if any(kw in label_lower for kw in ["signature", "sign"]):
        return FieldType.SIGNATURE

    if any(kw in label_lower for kw in ["age", "number", "quantity", "amount"]):
        return FieldType.NUMBER

    if any(kw in label_lower for kw in ["description", "comments", "notes", "message"]):
        return FieldType.TEXTAREA

    return FieldType.TEXT


def extract_form_fields(raw_text: str, ocr_blocks: list[dict]) -> list[FormField]:
    """
    Extract form fields from raw text and OCR blocks.

    Args:
        raw_text: Raw form text
        ocr_blocks: OCR text blocks with positions

    Returns:
        List of FormField objects
    """
    fields = []

    # Pattern: Label followed by value
    # This is simplified - real implementation would use layout analysis
    import re

    patterns = [
        r"([A-Za-z\s]+):\s*(.+?)(?=\n|$)",  # Label: Value
        r"([A-Za-z\s]+)\s*\[\s*([xX\s]?)\s*\]",  # Label [ ] or [X]
    ]

    for pattern in patterns:
        matches = re.findall(pattern, raw_text)
        for match in matches:
            label = match[0].strip()
            value = match[1].strip() if len(match) > 1 else None

            # Detect if checkbox
            if pattern == patterns[1]:
                field_type = FieldType.CHECKBOX
                value = value.lower() == "x" if value else False
            else:
                field_type = detect_field_type(label, value)

            fields.append(FormField(
                label=label,
                value=value,
                field_type=field_type,
            ))

    return fields
