"""
Contract Extraction Schema.

Task 2.2.3: Creates schema and extraction logic for contract documents.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class ContractType(str, Enum):
    """Types of contracts."""

    EMPLOYMENT = "employment"
    SERVICE = "service"
    SALES = "sales"
    LEASE = "lease"
    LICENSE = "license"
    NDA = "nda"
    PARTNERSHIP = "partnership"
    CONSULTING = "consulting"
    OTHER = "other"
    UNKNOWN = "unknown"


@dataclass
class ContractParty:
    """Party involved in a contract."""

    name: str
    role: str | None = None
    address: str | None = None
    representative: str | None = None
    title: str | None = None
    contact_email: str | None = None
    contact_phone: str | None = None
    signature_present: bool = False
    signature_date: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ContractTerm:
    """Key term in a contract."""

    name: str
    value: Any = None
    section: str | None = None
    page: int | None = None
    confidence: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ContractClause:
    """Clause within a contract."""

    title: str
    content: str
    section_number: str | None = None
    page: int | None = None
    is_standard: bool = True
    risk_level: str = "low"  # low, medium, high


@dataclass
class ContractAmendment:
    """Amendment to a contract."""

    amendment_number: int
    date: str
    description: str
    changes: list[str] = field(default_factory=list)


@dataclass
class ContractSchema:
    """
    Schema for contract documents.

    Fields:
    - Parties involved
    - Effective date, term
    - Key terms and conditions
    - Signatures and dates
    - Amendment tracking
    """

    # Contract identification
    title: str
    contract_number: str | None = None
    contract_type: ContractType = ContractType.UNKNOWN

    # Parties
    parties: list[ContractParty] = field(default_factory=list)

    # Dates
    effective_date: str | None = None
    termination_date: str | None = None
    signing_date: str | None = None
    renewal_date: str | None = None

    # Duration
    term_length: str | None = None
    auto_renewal: bool = False
    notice_period: str | None = None

    # Financial terms
    contract_value: float | None = None
    payment_terms: str | None = None
    currency: str = "USD"

    # Key terms
    terms: list[ContractTerm] = field(default_factory=list)
    clauses: list[ContractClause] = field(default_factory=list)

    # Amendments
    amendments: list[ContractAmendment] = field(default_factory=list)

    # Document structure
    sections: list[str] = field(default_factory=list)
    page_count: int = 1
    has_exhibits: bool = False
    exhibit_count: int = 0

    # Signatures
    all_parties_signed: bool = False
    witness_required: bool = False
    notarization_required: bool = False

    # Metadata
    governing_law: str | None = None
    jurisdiction: str | None = None
    language: str = "en"
    confidence: float = 0.0
    raw_text: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def get_party_by_role(self, role: str) -> ContractParty | None:
        """Get party by role."""
        for party in self.parties:
            if party.role and party.role.lower() == role.lower():
                return party
        return None

    def get_term_by_name(self, name: str) -> ContractTerm | None:
        """Get term by name."""
        for term in self.terms:
            if term.name.lower() == name.lower():
                return term
        return None

    def is_active(self) -> bool:
        """Check if contract is currently active."""
        from datetime import datetime

        if not self.effective_date:
            return False

        try:
            effective = datetime.fromisoformat(self.effective_date)
            if effective > datetime.now():
                return False

            if self.termination_date:
                termination = datetime.fromisoformat(self.termination_date)
                if termination < datetime.now():
                    return False

            return True
        except ValueError:
            return False

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "title": self.title,
            "contract_number": self.contract_number,
            "contract_type": self.contract_type.value,
            "parties": [
                {
                    "name": p.name,
                    "role": p.role,
                    "address": p.address,
                    "signature_present": p.signature_present,
                }
                for p in self.parties
            ],
            "effective_date": self.effective_date,
            "termination_date": self.termination_date,
            "contract_value": self.contract_value,
            "terms": [
                {
                    "name": t.name,
                    "value": t.value,
                }
                for t in self.terms
            ],
            "page_count": self.page_count,
            "confidence": self.confidence,
        }


@dataclass
class ContractValidationResult:
    """Result of contract validation."""

    is_valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    missing_parties: bool = False
    date_issues: bool = False


def validate_contract(data: dict[str, Any]) -> ContractValidationResult:
    """
    Validate contract data.

    Args:
        data: Contract data dictionary

    Returns:
        ContractValidationResult with validation status
    """
    errors = []
    warnings = []
    missing_parties = False
    date_issues = False

    # Check for required parties
    parties = data.get("parties", [])
    if len(parties) < 1:
        errors.append("At least one party is required")
        missing_parties = True

    # Validate dates
    effective_date = data.get("effective_date")
    termination_date = data.get("termination_date")

    if effective_date and termination_date:
        if str(termination_date) < str(effective_date):
            errors.append("Termination date is before effective date")
            date_issues = True

    # Validate contract value
    value = data.get("contract_value")
    if value is not None:
        try:
            if float(value) < 0:
                errors.append("Contract value cannot be negative")
        except (ValueError, TypeError):
            warnings.append("Contract value is not a valid number")

    # Check for title
    if not data.get("title"):
        warnings.append("Contract title is missing")

    return ContractValidationResult(
        is_valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        missing_parties=missing_parties,
        date_issues=date_issues,
    )


def detect_contract_type(text: str) -> ContractType:
    """
    Detect contract type from text.

    Args:
        text: Contract text

    Returns:
        Detected ContractType
    """
    text_lower = text.lower()

    if any(kw in text_lower for kw in ["employment", "employee", "employer", "salary"]):
        return ContractType.EMPLOYMENT

    if any(kw in text_lower for kw in ["service agreement", "services", "consultant"]):
        return ContractType.SERVICE

    if any(kw in text_lower for kw in ["sale", "purchase", "buyer", "seller"]):
        return ContractType.SALES

    if any(kw in text_lower for kw in ["lease", "rental", "tenant", "landlord"]):
        return ContractType.LEASE

    if any(kw in text_lower for kw in ["license", "licensor", "licensee"]):
        return ContractType.LICENSE

    if any(kw in text_lower for kw in ["non-disclosure", "nda", "confidential"]):
        return ContractType.NDA

    if any(kw in text_lower for kw in ["partnership", "partner"]):
        return ContractType.PARTNERSHIP

    if any(kw in text_lower for kw in ["consulting", "consultant"]):
        return ContractType.CONSULTING

    return ContractType.UNKNOWN


def extract_parties(text: str) -> list[ContractParty]:
    """
    Extract parties from contract text.

    Args:
        text: Contract text

    Returns:
        List of ContractParty objects
    """
    parties = []
    import re

    # Common patterns for party identification
    patterns = [
        r"(?:between|by and between)\s+([A-Z][A-Za-z\s,\.]+?)(?:\s*\(\"?\w+\"?\)|,\s*a\s+)",
        r"(?:Party\s*[AB12]|First Party|Second Party)[:\s]+([A-Z][A-Za-z\s]+)",
        r"(?:Employer|Employee|Client|Contractor|Licensor|Licensee)[:\s]+([A-Z][A-Za-z\s]+)",
    ]

    for pattern in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for match in matches:
            name = match.strip()
            if name and len(name) > 2:
                # Detect role from context
                role = None
                text_before = text[:text.find(name)][-50:].lower()
                if "employer" in text_before:
                    role = "employer"
                elif "employee" in text_before:
                    role = "employee"
                elif "client" in text_before:
                    role = "client"
                elif "contractor" in text_before:
                    role = "contractor"
                elif "party a" in text_before or "first party" in text_before:
                    role = "party_a"
                elif "party b" in text_before or "second party" in text_before:
                    role = "party_b"

                parties.append(ContractParty(name=name, role=role))

    return parties
