"""
Receipt Extraction Schema.

Task 2.2.1: Creates schema and extraction logic for receipt documents.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from src.core.logging import get_logger

logger = get_logger(__name__)


class PaymentMethod(str, Enum):
    """Payment method types."""

    CASH = "cash"
    CREDIT_CARD = "credit_card"
    DEBIT_CARD = "debit_card"
    CHECK = "check"
    MOBILE_PAYMENT = "mobile_payment"
    GIFT_CARD = "gift_card"
    OTHER = "other"
    UNKNOWN = "unknown"


@dataclass
class ReceiptItem:
    """Individual line item on a receipt."""

    name: str
    quantity: float = 1.0
    unit_price: float = 0.0
    total_price: float = 0.0
    sku: str | None = None
    discount: float = 0.0
    category: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Calculate total if not provided."""
        if self.total_price == 0.0 and self.unit_price > 0:
            self.total_price = self.quantity * self.unit_price - self.discount


@dataclass
class ReceiptSchema:
    """
    Schema for receipt documents.

    Fields:
    - Store information (name, address, phone)
    - Transaction info (date, time, receipt number)
    - Items (name, quantity, price)
    - Totals (subtotal, tax, total)
    - Payment method
    """

    # Required fields
    total: float = 0.0

    # Store information
    store_name: str | None = None
    store_address: str | None = None
    store_phone: str | None = None
    store_logo_detected: bool = False

    # Transaction information
    date: str | None = None
    time: str | None = None
    receipt_number: str | None = None
    transaction_id: str | None = None

    # Line items
    items: list[ReceiptItem] = field(default_factory=list)

    # Totals
    subtotal: float | None = None
    tax: float | None = None
    discount: float = 0.0
    tip: float = 0.0

    # Payment information
    payment_method: PaymentMethod = PaymentMethod.UNKNOWN
    card_last_four: str | None = None
    change_given: float | None = None

    # Additional metadata
    cashier: str | None = None
    register_number: str | None = None
    barcode: str | None = None
    confidence: float = 0.0
    raw_text: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def calculate_items_total(self) -> float:
        """Calculate total from line items."""
        return sum(item.total_price for item in self.items)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "store_name": self.store_name,
            "store_address": self.store_address,
            "store_phone": self.store_phone,
            "date": self.date,
            "time": self.time,
            "receipt_number": self.receipt_number,
            "items": [
                {
                    "name": item.name,
                    "quantity": item.quantity,
                    "unit_price": item.unit_price,
                    "total_price": item.total_price,
                }
                for item in self.items
            ],
            "subtotal": self.subtotal,
            "tax": self.tax,
            "total": self.total,
            "payment_method": self.payment_method.value,
            "confidence": self.confidence,
        }


@dataclass
class ReceiptValidationResult:
    """Result of receipt validation."""

    is_valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def validate_receipt(data: dict[str, Any]) -> ReceiptValidationResult:
    """
    Validate receipt data.

    Args:
        data: Receipt data dictionary

    Returns:
        ReceiptValidationResult with validation status
    """
    errors = []
    warnings = []

    # Extract values
    items = data.get("items", [])
    subtotal = data.get("subtotal")
    tax = data.get("tax")
    total = data.get("total")

    # Validate items total matches subtotal
    if items and subtotal is not None:
        items_total = sum(
            float(item.get("total_price", 0)) for item in items
        )
        if abs(items_total - float(subtotal)) > 0.02:
            warnings.append(
                f"Items total ({items_total}) doesn't match subtotal ({subtotal})"
            )

    # Validate subtotal + tax = total
    if subtotal is not None and tax is not None and total is not None:
        expected_total = float(subtotal) + float(tax)
        if abs(expected_total - float(total)) > 0.02:
            errors.append(
                f"Total ({total}) doesn't match subtotal + tax ({expected_total})"
            )

    # Validate positive values
    if total is not None and float(total) < 0:
        errors.append("Total cannot be negative")

    # Check for required fields
    if total is None:
        errors.append("Total is required")

    return ReceiptValidationResult(
        is_valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
    )


def parse_receipt_items(raw_items: list[dict]) -> list[ReceiptItem]:
    """
    Parse raw item data into ReceiptItem objects.

    Args:
        raw_items: List of raw item dictionaries

    Returns:
        List of ReceiptItem objects
    """
    items = []
    for item in raw_items:
        receipt_item = ReceiptItem(
            name=item.get("name", "Unknown Item"),
            quantity=float(item.get("quantity", 1)),
            unit_price=float(item.get("unit_price", 0)),
            total_price=float(item.get("total_price", 0)),
            sku=item.get("sku"),
            discount=float(item.get("discount", 0)),
            category=item.get("category"),
        )
        items.append(receipt_item)
    return items


def detect_payment_method(text: str) -> PaymentMethod:
    """
    Detect payment method from text.

    Args:
        text: Raw receipt text

    Returns:
        Detected PaymentMethod
    """
    text_lower = text.lower()

    if any(kw in text_lower for kw in ["visa", "mastercard", "amex", "credit"]):
        return PaymentMethod.CREDIT_CARD
    elif any(kw in text_lower for kw in ["debit", "interac"]):
        return PaymentMethod.DEBIT_CARD
    elif "cash" in text_lower:
        return PaymentMethod.CASH
    elif any(kw in text_lower for kw in ["check", "cheque"]):
        return PaymentMethod.CHECK
    elif any(kw in text_lower for kw in ["apple pay", "google pay", "venmo"]):
        return PaymentMethod.MOBILE_PAYMENT
    elif "gift card" in text_lower:
        return PaymentMethod.GIFT_CARD

    return PaymentMethod.UNKNOWN
