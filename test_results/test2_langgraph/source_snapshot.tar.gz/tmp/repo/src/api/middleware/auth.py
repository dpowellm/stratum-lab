"""
JWT Authentication Middleware.

Provides JWT-based authentication with API key support for service-to-service
communication. Integrates with the existing RBAC system.
"""

from datetime import UTC, datetime, timedelta
from typing import Any

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel

from src.config.settings import get_settings
from src.core.logging import get_logger
from src.services.security.rbac import Permission, get_rbac_manager

logger = get_logger(__name__)

# Security schemes
bearer_scheme = HTTPBearer(auto_error=False)
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

# JWT Configuration
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60
REFRESH_TOKEN_EXPIRE_DAYS = 7


class TokenData(BaseModel):
    """Decoded JWT token data."""

    sub: str  # user_id
    username: str
    roles: list[str] = []
    is_admin: bool = False
    exp: datetime | None = None
    token_type: str = "access"  # noqa: S105


class AuthUser(BaseModel):
    """Authenticated user context available in request handlers."""

    user_id: str
    username: str
    roles: list[str] = []
    is_admin: bool = False
    permissions: list[str] = []


# In-memory API key store (production should use DB)
_api_keys: dict[str, dict[str, Any]] = {}


def register_api_key(key: str, name: str, permissions: list[str] | None = None) -> None:
    """Register an API key for service-to-service auth."""
    _api_keys[key] = {
        "name": name,
        "permissions": permissions or ["*"],
        "created_at": datetime.now(tz=UTC).isoformat(),
    }


def create_access_token(
    user_id: str,
    username: str,
    roles: list[str] | None = None,
    is_admin: bool = False,
    expires_delta: timedelta | None = None,
) -> str:
    """Create a JWT access token."""
    settings = get_settings()
    secret_key = settings.app.secret_key.get_secret_value()

    expire = datetime.now(tz=UTC) + (
        expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )

    payload = {
        "sub": user_id,
        "username": username,
        "roles": roles or [],
        "is_admin": is_admin,
        "exp": expire,
        "token_type": "access",
        "iat": datetime.now(tz=UTC),
    }

    return jwt.encode(payload, secret_key, algorithm=ALGORITHM)


def create_refresh_token(user_id: str, username: str) -> str:
    """Create a JWT refresh token."""
    settings = get_settings()
    secret_key = settings.app.secret_key.get_secret_value()

    expire = datetime.now(tz=UTC) + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)

    payload = {
        "sub": user_id,
        "username": username,
        "exp": expire,
        "token_type": "refresh",
        "iat": datetime.now(tz=UTC),
    }

    return jwt.encode(payload, secret_key, algorithm=ALGORITHM)


def decode_token(token: str) -> TokenData:
    """Decode and validate a JWT token."""
    settings = get_settings()
    secret_key = settings.app.secret_key.get_secret_value()

    try:
        payload = jwt.decode(token, secret_key, algorithms=[ALGORITHM])
        return TokenData(
            sub=payload["sub"],
            username=payload.get("username", ""),
            roles=payload.get("roles", []),
            is_admin=payload.get("is_admin", False),
            exp=datetime.fromtimestamp(payload["exp"], tz=UTC) if "exp" in payload else None,
            token_type=payload.get("token_type", "access"),
        )
    except JWTError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid token: {e}",
            headers={"WWW-Authenticate": "Bearer"},
        ) from e


async def get_current_user(
    request: Request,  # noqa: ARG001
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    api_key: str | None = Depends(api_key_header),
) -> AuthUser:
    """
    Extract the current authenticated user from request.

    Supports both JWT Bearer tokens and API keys.
    In development mode, allows unauthenticated access with a default dev user.
    """
    settings = get_settings()

    # Check API key first
    if api_key and api_key in _api_keys:
        key_info = _api_keys[api_key]
        logger.debug("API key authenticated", key_name=key_info["name"])
        return AuthUser(
            user_id=f"apikey:{key_info['name']}",
            username=key_info["name"],
            roles=["operator"],
            is_admin=False,
            permissions=key_info.get("permissions", []),
        )

    # Check Bearer token
    if credentials:
        token_data = decode_token(credentials.credentials)

        if token_data.token_type != "access":  # noqa: S105
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token type",
                headers={"WWW-Authenticate": "Bearer"},
            )

        # Build permissions from RBAC
        rbac = get_rbac_manager()
        permissions: list[str] = []
        if token_data.is_admin:
            permissions = [p.value for p in Permission]
        else:
            for role_id in token_data.roles:
                role = rbac.get_role(role_id)
                if role:
                    permissions.extend(p.value for p in role.permissions)

        return AuthUser(
            user_id=token_data.sub,
            username=token_data.username,
            roles=token_data.roles,
            is_admin=token_data.is_admin,
            permissions=list(set(permissions)),
        )

    # Development mode: allow unauthenticated with dev user
    if settings.is_development:
        return AuthUser(
            user_id="dev-user",
            username="developer",
            roles=["admin"],
            is_admin=True,
            permissions=[p.value for p in Permission],
        )

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
        headers={"WWW-Authenticate": "Bearer"},
    )


async def get_optional_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    api_key: str | None = Depends(api_key_header),
) -> AuthUser | None:
    """Get current user if authenticated, None otherwise."""
    try:
        return await get_current_user(request, credentials, api_key)
    except HTTPException:
        return None


def require_permission(permission: Permission):
    """Dependency that requires a specific permission."""

    async def _check(user: AuthUser = Depends(get_current_user)) -> AuthUser:
        if user.is_admin:
            return user
        if "*" in user.permissions or permission.value in user.permissions:
            return user
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Permission required: {permission.value}",
        )

    return _check


def require_any_permission(*permissions: Permission):
    """Dependency that requires any of the specified permissions."""

    async def _check(user: AuthUser = Depends(get_current_user)) -> AuthUser:
        if user.is_admin:
            return user
        user_perms = set(user.permissions)
        if "*" in user_perms:
            return user
        required = {p.value for p in permissions}
        if user_perms & required:
            return user
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"One of these permissions required: {', '.join(p.value for p in permissions)}",
        )

    return _check
