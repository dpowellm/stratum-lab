"""
Rate Limiting Middleware.

Uses slowapi to provide per-endpoint and global rate limiting.
Backed by in-memory storage (development) or Redis (production).
"""

from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address
from starlette.requests import Request

from src.core.logging import get_logger

logger = get_logger(__name__)


def _key_func(request: Request) -> str:
    """Rate limit key: use X-Forwarded-For if behind proxy, else remote address."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return get_remote_address(request)


# Global limiter instance
limiter = Limiter(
    key_func=_key_func,
    default_limits=["200/minute"],
    storage_uri="memory://",
)

# Re-export for use in route decorators
rate_limit_exceeded_handler = _rate_limit_exceeded_handler


def configure_rate_limiter(app) -> None:
    """Configure rate limiting on the FastAPI app."""
    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
    logger.info("Rate limiter configured", default_limits="200/minute")
