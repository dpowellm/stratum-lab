"""FastAPI application module."""
