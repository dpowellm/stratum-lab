"""
Prometheus Metrics Endpoint.

Exposes application metrics in Prometheus format for monitoring.
Tracks document processing, council performance, and system health.
"""

from fastapi import APIRouter, Response
from prometheus_client import (
    CONTENT_TYPE_LATEST,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)

from src.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(tags=["Metrics"])

# --- Document Metrics ---
DOCUMENTS_UPLOADED = Counter(
    "documents_uploaded_total",
    "Total number of documents uploaded",
    ["document_type"],
)
DOCUMENTS_PROCESSED = Counter(
    "documents_processed_total",
    "Total number of documents processed",
    ["status"],  # completed, failed, human_review
)
DOCUMENT_PROCESSING_TIME = Histogram(
    "document_processing_seconds",
    "Time taken to process a document end-to-end",
    buckets=[1, 5, 10, 30, 60, 120, 300, 600],
)

# --- Council Metrics ---
COUNCIL_SESSIONS = Counter(
    "council_sessions_total",
    "Total council deliberation sessions",
    ["voting_strategy"],
)
COUNCIL_CONSENSUS_SCORE = Histogram(
    "council_consensus_score",
    "Distribution of consensus scores",
    buckets=[0.5, 0.6, 0.7, 0.8, 0.85, 0.9, 0.95, 1.0],
)
COUNCIL_PROCESSING_TIME = Histogram(
    "council_processing_seconds",
    "Time for council deliberation",
    buckets=[1, 2, 5, 10, 30, 60],
)
MEMBER_EXTRACTION_TIME = Histogram(
    "member_extraction_seconds",
    "Extraction time per council member",
    ["member_name"],
    buckets=[0.5, 1, 2, 5, 10, 30],
)
JUDGE_INVOCATIONS = Counter(
    "judge_invocations_total",
    "Total judge model invocations for conflict resolution",
)
CONFLICTS_DETECTED = Counter(
    "conflicts_detected_total",
    "Total field conflicts detected",
    ["conflict_level"],
)

# --- HITL Metrics ---
HITL_ITEMS_ADDED = Counter(
    "hitl_items_added_total",
    "Total items added to HITL review queue",
    ["priority"],
)
HITL_REVIEWS_COMPLETED = Counter(
    "hitl_reviews_completed_total",
    "Total HITL reviews completed",
)
HITL_QUEUE_SIZE = Gauge(
    "hitl_queue_size",
    "Current number of items in HITL queue",
    ["status"],
)

# --- Extraction Quality ---
EXTRACTION_CONFIDENCE = Histogram(
    "extraction_confidence",
    "Distribution of extraction confidence scores",
    ["member_name"],
    buckets=[0.3, 0.5, 0.6, 0.7, 0.8, 0.85, 0.9, 0.95, 1.0],
)
CALIBRATION_ECE = Gauge(
    "calibration_ece",
    "Expected Calibration Error",
    ["model_name"],
)

# --- System Metrics ---
ACTIVE_TASKS = Gauge(
    "active_celery_tasks",
    "Number of currently active Celery tasks",
    ["queue"],
)
API_REQUESTS = Counter(
    "api_requests_total",
    "Total API requests",
    ["method", "endpoint", "status_code"],
)
API_LATENCY = Histogram(
    "api_request_seconds",
    "API request latency",
    ["method", "endpoint"],
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5],
)


@router.get("/metrics", include_in_schema=False)
async def prometheus_metrics():
    """Expose Prometheus metrics."""
    return Response(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST,
    )
