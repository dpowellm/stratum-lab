"""Extraction result and correction endpoints."""

import uuid
from datetime import datetime
from typing import Any

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Path,
    Query,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.logging import get_logger
from src.models.database.base import get_session
from src.models.database.document import DocumentType
from src.models.database.extraction import (
    ExtractedField as DBExtractedField,
    Extraction as DBExtraction,
    ValidationStatus as DBValidationStatus,
)
from src.models.schemas.extraction import (
    ExtractedField,
    ExtractionMetrics,
    ExtractionResult,
    FieldConfidenceLevel,
    QualityTier,
    ValidationResult,
    ValidationStatus,
)
from src.services.document.repository import DocumentRepository

logger = get_logger(__name__)

router = APIRouter(prefix="/extractions", tags=["Extractions"])


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _classify_confidence(confidence: float) -> FieldConfidenceLevel:
    """Classify a numeric confidence score into a confidence level.

    Thresholds:
        >= 0.95  ->  VERY_HIGH
        >= 0.85  ->  HIGH
        >= 0.70  ->  MEDIUM
        >= 0.50  ->  LOW
        <  0.50  ->  VERY_LOW
    """
    if confidence >= 0.95:
        return FieldConfidenceLevel.VERY_HIGH
    if confidence >= 0.85:
        return FieldConfidenceLevel.HIGH
    if confidence >= 0.70:
        return FieldConfidenceLevel.MEDIUM
    if confidence >= 0.50:
        return FieldConfidenceLevel.LOW
    return FieldConfidenceLevel.VERY_LOW


def _determine_quality_tier(confidence: float) -> QualityTier:
    """Determine quality tier from overall confidence.

    Thresholds:
        >= 0.95  ->  EXCELLENT
        >= 0.85  ->  GOOD
        >= 0.70  ->  FAIR
        <  0.70  ->  POOR
    """
    if confidence >= 0.95:
        return QualityTier.EXCELLENT
    if confidence >= 0.85:
        return QualityTier.GOOD
    if confidence >= 0.70:
        return QualityTier.FAIR
    return QualityTier.POOR


def _map_validation_status(db_status: DBValidationStatus) -> ValidationStatus:
    """Map database validation status to the schema enum."""
    mapping = {
        DBValidationStatus.VALID: ValidationStatus.VALID,
        DBValidationStatus.INVALID: ValidationStatus.INVALID,
        DBValidationStatus.HUMAN_VERIFIED: ValidationStatus.VALID,
        DBValidationStatus.CORRECTED: ValidationStatus.VALID,
        DBValidationStatus.PENDING: ValidationStatus.UNKNOWN,
    }
    return mapping.get(db_status, ValidationStatus.UNKNOWN)


def _db_field_to_schema(
    db_field: DBExtractedField,
    include_alternatives: bool = False,
) -> ExtractedField:
    """Convert a database ExtractedField to the schema ExtractedField."""
    source_location: dict[str, Any] | None = None
    if db_field.page_number is not None or db_field.bounding_box is not None:
        source_location = {}
        if db_field.page_number is not None:
            source_location["page"] = db_field.page_number
        if db_field.bounding_box is not None:
            source_location["bbox"] = db_field.bounding_box

    alternatives: list[dict[str, Any]] = []
    if include_alternatives and db_field.alternative_values:
        alternatives = db_field.alternative_values

    return ExtractedField(
        name=db_field.field_name,
        value=db_field.value,
        confidence=db_field.confidence,
        confidence_level=_classify_confidence(db_field.confidence),
        raw_text=db_field.raw_value,
        source_location=source_location,
        validation_status=_map_validation_status(db_field.validation_status),
        alternatives=alternatives,
        metadata={
            "source_model": db_field.source_model,
            "field_type": db_field.field_type.value if db_field.field_type else "text",
            "was_corrected": db_field.was_corrected,
        },
    )


def _fields_from_extracted_data(
    extracted_data: dict[str, Any],
) -> list[ExtractedField]:
    """Convert the JSONB ``extracted_data`` dict into schema fields.

    The pipeline stores fields as ``{name: {value, confidence}}`` in the
    ``extracted_data`` column.  This helper converts that to a list of
    ``ExtractedField`` objects so the API response is populated even when
    individual ``ExtractedField`` DB records were not created.
    """
    fields: list[ExtractedField] = []
    for name, data in extracted_data.items():
        if isinstance(data, dict) and "value" in data:
            conf = float(data.get("confidence", 0.85))
            fields.append(
                ExtractedField(
                    name=name,
                    value=data["value"],
                    confidence=conf,
                    confidence_level=_classify_confidence(conf),
                    raw_text=None,
                    source_location=None,
                    validation_status=ValidationStatus.UNKNOWN,
                    alternatives=[],
                    metadata={"source_model": "council_consensus", "field_type": "text"},
                )
            )
        else:
            # Plain value (e.g. from older pipelines)
            fields.append(
                ExtractedField(
                    name=name,
                    value=data,
                    confidence=0.85,
                    confidence_level=_classify_confidence(0.85),
                    raw_text=None,
                    source_location=None,
                    validation_status=ValidationStatus.UNKNOWN,
                    alternatives=[],
                    metadata={"source_model": "council_consensus", "field_type": "text"},
                )
            )
    return fields


def _build_extraction_result(
    extraction: DBExtraction,
    document_type: str,
    include_alternatives: bool = False,
    include_validation: bool = True,
) -> ExtractionResult:
    """Build an ExtractionResult schema from a database Extraction."""
    # Convert fields from DB relationship first
    schema_fields = [
        _db_field_to_schema(f, include_alternatives=include_alternatives) for f in extraction.fields
    ]

    # Fallback: if no DB field records, build from extracted_data JSONB
    if not schema_fields and extraction.extracted_data:
        schema_fields = _fields_from_extracted_data(extraction.extracted_data)

    # Compute metrics
    total_fields = len(schema_fields)
    extracted_fields = sum(1 for f in schema_fields if f.value is not None)
    missing_fields = total_fields - extracted_fields
    average_confidence = (
        sum(f.confidence for f in schema_fields) / total_fields if total_fields > 0 else 0.0
    )
    high_conf = sum(1 for f in schema_fields if f.confidence >= 0.85)
    low_conf = sum(1 for f in schema_fields if f.confidence < 0.70)
    quality_tier = _determine_quality_tier(extraction.overall_confidence)

    metrics = ExtractionMetrics(
        total_fields=total_fields,
        extracted_fields=extracted_fields,
        missing_fields=missing_fields,
        average_confidence=round(average_confidence, 4),
        high_confidence_fields=high_conf,
        low_confidence_fields=low_conf,
        quality_tier=quality_tier,
    )

    # Build validation result
    if include_validation:
        valid_count = sum(1 for f in schema_fields if f.validation_status == ValidationStatus.VALID)
        invalid_count = sum(
            1 for f in schema_fields if f.validation_status == ValidationStatus.INVALID
        )
        is_valid = invalid_count == 0
        validation = ValidationResult(
            is_valid=is_valid,
            valid_fields=valid_count,
            invalid_fields=invalid_count,
        )
    else:
        validation = ValidationResult(
            is_valid=True,
            valid_fields=total_fields,
            invalid_fields=0,
        )

    # Determine if review is needed
    requires_review = extraction.overall_confidence < 0.70
    review_reason = "Overall confidence below threshold" if requires_review else None

    return ExtractionResult(
        extraction_id=str(extraction.id),
        document_id=str(extraction.document_id),
        document_type=document_type,
        extracted_at=extraction.created_at,
        fields=schema_fields,
        metrics=metrics,
        validation=validation,
        confidence=extraction.overall_confidence,
        quality_tier=quality_tier,
        requires_review=requires_review,
        review_reason=review_reason,
        metadata={
            "version": extraction.version,
            "is_latest": extraction.is_latest,
            "council_session_id": (
                str(extraction.council_session_id) if extraction.council_session_id else None
            ),
        },
    )


# ---------------------------------------------------------------------------
# Request / response models local to this router
# ---------------------------------------------------------------------------


class FieldCorrection(BaseModel):
    """Correction for a single extracted field."""

    field_name: str = Field(..., description="Name of field to correct")
    corrected_value: Any = Field(..., description="New corrected value")
    reason: str = Field(..., description="Reason for correction")
    correction_source: str = Field(
        default="human",
        description="Source of correction (human, judge, auto)",
    )
    reviewer_id: str | None = Field(default=None, description="ID of reviewer")

    model_config = {
        "json_schema_extra": {
            "example": {
                "field_name": "company_name",
                "corrected_value": "Corrected Company Name",
                "reason": "OCR misread text",
                "correction_source": "human",
                "reviewer_id": "user_001",
            }
        }
    }


class ExtractionCorrectionRequest(BaseModel):
    """Request to submit corrections for an extraction."""

    corrections: list[FieldCorrection] = Field(..., description="List of field corrections")
    overall_feedback: str | None = Field(default=None, description="Overall feedback on extraction")
    review_notes: str | None = Field(default=None, description="Reviewer notes")

    model_config = {
        "json_schema_extra": {
            "example": {
                "corrections": [
                    {
                        "field_name": "company_name",
                        "corrected_value": "Acme Inc",
                        "reason": "OCR error",
                        "correction_source": "human",
                        "reviewer_id": "user_001",
                    }
                ],
                "overall_feedback": "Extraction was mostly accurate",
                "review_notes": "Minor OCR issues in header",
            }
        }
    }


class ExtractionCorrectionResponse(BaseModel):
    """Response after applying corrections."""

    extraction_id: str = Field(..., description="Extraction ID")
    document_id: str = Field(..., description="Document ID")
    corrections_applied: int = Field(..., description="Number of corrections")
    updated_at: datetime = Field(..., description="When updated")
    new_version: int = Field(..., ge=1, description="New extraction version")
    validation_status: ValidationStatus = Field(
        ..., description="Validation status after corrections"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "extraction_id": "ext_001",
                "document_id": "doc_001",
                "corrections_applied": 2,
                "updated_at": "2025-01-29T16:35:00Z",
                "new_version": 2,
                "validation_status": "valid",
            }
        }
    }


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/{document_id}",
    response_model=ExtractionResult,
    status_code=status.HTTP_200_OK,
    summary="Get extraction result",
    description="Retrieve the extraction result for a document.",
    responses={
        200: {"description": "Extraction found"},
        404: {"description": "Document or extraction not found"},
        503: {"description": "Service unavailable"},
    },
)
async def get_extraction(
    document_id: str = Path(..., description="Document ID"),
    include_alternatives: bool = Query(
        default=False,
        description="Include alternative values for fields",
    ),
    include_validation: bool = Query(
        default=True,
        description="Include validation results",
    ),
    session: AsyncSession = Depends(get_session),
) -> ExtractionResult:
    """
    Get the extraction result for a document.

    Retrieves the final extraction result after council deliberation
    and consensus.

    Args:
        document_id: ID of the document
        include_alternatives: Include alternative field values
        include_validation: Include validation results
        session: Database session (injected)

    Returns:
        ExtractionResult with extracted fields and confidence scores

    Raises:
        HTTPException: If document or extraction not found
    """
    try:
        logger.info(
            "Retrieving extraction",
            document_id=document_id,
        )

        # Parse and validate UUID
        try:
            doc_uuid = uuid.UUID(document_id)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Invalid document ID format: {document_id}",
            ) from exc

        repo = DocumentRepository(session)

        # Look up the document
        document = await repo.get_by_id(doc_uuid)
        if document is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        # Get the latest extraction for this document
        extraction = await repo.get_latest_extraction(doc_uuid)
        if extraction is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Extraction not found for document {document_id}",
            )

        # Resolve document type string
        doc_type = (
            document.document_type.value
            if document.document_type != DocumentType.UNKNOWN
            else "unknown"
        )

        result = _build_extraction_result(
            extraction,
            document_type=doc_type,
            include_alternatives=include_alternatives,
            include_validation=include_validation,
        )

        logger.info(
            "Extraction retrieved successfully",
            document_id=document_id,
            extraction_id=str(extraction.id),
            field_count=len(result.fields),
        )

        return result

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Error retrieving extraction",
            document_id=document_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to retrieve extraction",
        ) from e


@router.post(
    "/{document_id}/correct",
    response_model=ExtractionCorrectionResponse,
    status_code=status.HTTP_200_OK,
    summary="Submit extraction corrections",
    description="Submit corrections for extracted fields.",
    responses={
        200: {"description": "Corrections applied successfully"},
        400: {"description": "Invalid correction data"},
        404: {"description": "Document or extraction not found"},
        409: {"description": "Extraction already finalized"},
        503: {"description": "Service unavailable"},
    },
)
async def submit_correction(
    document_id: str = Path(..., description="Document ID"),
    correction_request: ExtractionCorrectionRequest = None,
    session: AsyncSession = Depends(get_session),
) -> ExtractionCorrectionResponse:
    """
    Submit corrections for an extraction.

    Allows reviewers to correct extracted field values and provide
    feedback on the extraction quality.

    Args:
        document_id: ID of the document
        correction_request: Corrections to apply
        session: Database session (injected)

    Returns:
        ExtractionCorrectionResponse with update confirmation

    Raises:
        HTTPException: If document/extraction not found or already finalized
    """
    try:
        if not correction_request:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Correction request is required",
            )

        if not correction_request.corrections:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="At least one correction is required",
            )

        logger.info(
            "Applying extraction corrections",
            document_id=document_id,
            correction_count=len(correction_request.corrections),
        )

        # Parse and validate UUID
        try:
            doc_uuid = uuid.UUID(document_id)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Invalid document ID format: {document_id}",
            ) from exc

        repo = DocumentRepository(session)

        # Verify document exists
        document = await repo.get_by_id(doc_uuid)
        if document is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document not found: {document_id}",
            )

        # Retrieve the latest extraction
        extraction = await repo.get_latest_extraction(doc_uuid)
        if extraction is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Extraction not found for document {document_id}",
            )

        # Validate that all requested field names exist in the extraction
        existing_field_names = {f.field_name for f in extraction.fields}
        for correction in correction_request.corrections:
            if correction.field_name not in existing_field_names:
                raise ValueError(
                    f"Field '{correction.field_name}' does not exist in "
                    f"the extraction. Available fields: "
                    f"{sorted(existing_field_names)}"
                )

        # Create a new versioned extraction via the DB model helper
        new_extraction = extraction.create_new_version()
        session.add(new_extraction)
        await session.flush()
        await session.refresh(new_extraction)

        # Copy existing fields into the new extraction and apply corrections
        correction_map = {c.field_name: c for c in correction_request.corrections}
        corrections_applied = 0

        for old_field in extraction.fields:
            new_field = DBExtractedField(
                extraction_id=new_extraction.id,
                field_name=old_field.field_name,
                field_type=old_field.field_type,
                value=old_field.value,
                raw_value=old_field.raw_value,
                confidence=old_field.confidence,
                source_model=old_field.source_model,
                page_number=old_field.page_number,
                bounding_box=old_field.bounding_box,
                alternative_values=old_field.alternative_values,
                validation_status=old_field.validation_status,
                validation_errors=old_field.validation_errors,
                was_corrected=old_field.was_corrected,
                original_value=old_field.original_value,
                correction_source=old_field.correction_source,
                corrected_at=old_field.corrected_at,
                corrected_by=old_field.corrected_by,
            )

            if old_field.field_name in correction_map:
                corr = correction_map[old_field.field_name]
                new_field.correct(
                    new_value=corr.corrected_value,
                    source=corr.correction_source,
                    corrected_by=corr.reviewer_id,
                )
                # Update the denormalized extracted_data on the new extraction
                new_extraction.extracted_data[old_field.field_name] = corr.corrected_value
                corrections_applied += 1

            session.add(new_field)

        # Update new extraction metadata
        new_extraction.human_corrections_count = corrections_applied
        new_extraction.validation_status = DBValidationStatus.CORRECTED
        new_extraction.field_count = len(extraction.fields)

        await session.flush()
        await session.refresh(new_extraction)

        logger.info(
            "Corrections applied successfully",
            document_id=document_id,
            extraction_id=str(new_extraction.id),
            corrections_applied=corrections_applied,
            new_version=new_extraction.version,
        )

        # Feed corrections to quality evaluator and calibration tracker
        try:
            from src.services.evals.calibration import get_calibration_tracker
            from src.services.evals.quality import get_quality_evaluator

            evaluator = get_quality_evaluator()
            tracker = get_calibration_tracker()
            for corr in correction_request.corrections:
                # Find original field to get its confidence and model
                original_field = next(
                    (f for f in extraction.fields if f.field_name == corr.field_name),
                    None,
                )
                if original_field:
                    evaluator.record_correction(
                        field_name=corr.field_name,
                        original_value=original_field.value,
                        corrected_value=corr.corrected_value,
                        model_name=original_field.source_model or "council_consensus",
                        document_type=doc_type
                        if (
                            doc_type := (
                                document.document_type.value
                                if hasattr(document, "document_type") and document.document_type
                                else "unknown"
                            )
                        )
                        else "unknown",
                    )
                    tracker.record_prediction(
                        confidence=original_field.confidence,
                        was_correct=False,
                        model_name=original_field.source_model or "council_consensus",
                        field_name=corr.field_name,
                    )
        except Exception as eval_err:
            logger.warning("Failed to record eval metrics", error=str(eval_err))

        return ExtractionCorrectionResponse(
            extraction_id=str(new_extraction.id),
            document_id=document_id,
            corrections_applied=corrections_applied,
            updated_at=new_extraction.updated_at,
            new_version=new_extraction.version,
            validation_status=ValidationStatus.VALID,
        )

    except HTTPException:
        raise
    except ValueError as e:
        logger.warning(
            "Invalid correction data",
            document_id=document_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid correction data: {e!s}",
        ) from e
    except Exception as e:
        logger.error(
            "Error applying corrections",
            document_id=document_id,
            error=str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Failed to apply corrections",
        ) from e
