"""API route modules."""

from src.api.routes.council import router as council_router
from src.api.routes.documents import router as documents_router
from src.api.routes.extraction import router as extraction_router
from src.api.routes.health import router as health_router

__all__ = [
    "council_router",
    "documents_router",
    "extraction_router",
    "health_router",
]
