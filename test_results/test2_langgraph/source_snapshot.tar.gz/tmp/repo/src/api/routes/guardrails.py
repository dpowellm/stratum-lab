"""Guardrails and evaluation endpoints."""

from typing import Any

from fastapi import APIRouter, Body, HTTPException, Query, status

from src.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(prefix="/guardrails", tags=["Guardrails & Evals"])


@router.get(
    "/input/stats",
    status_code=status.HTTP_200_OK,
    summary="Get input guard statistics",
    responses={200: {"description": "Input guard stats"}},
)
async def get_input_stats() -> dict[str, Any]:
    """Get aggregate input validation statistics."""
    from src.services.guardrails.input_guard import get_input_guard

    guard = get_input_guard()
    return guard.get_stats()


@router.get(
    "/input/config",
    status_code=status.HTTP_200_OK,
    summary="Get input guard configuration",
    responses={200: {"description": "Input guard config"}},
)
async def get_input_config() -> dict[str, Any]:
    """Get current input guard configuration."""
    from src.services.guardrails.input_guard import get_input_guard

    guard = get_input_guard()
    return guard.get_config()


@router.get(
    "/output/gates",
    status_code=status.HTTP_200_OK,
    summary="Get output gate configuration and stats",
    responses={200: {"description": "Gate config and stats"}},
)
async def get_output_gates() -> dict[str, Any]:
    """Get output gate configuration and pass/fail statistics."""
    from src.services.guardrails.output_gate import get_output_gate

    gate = get_output_gate()
    return {
        "config": gate.get_config(),
        "stats": gate.get_stats(),
    }


@router.put(
    "/output/gates",
    status_code=status.HTTP_200_OK,
    summary="Update output gate thresholds",
    responses={200: {"description": "Updated gate config"}},
)
async def update_output_gates(
    config: dict[str, float] = Body(..., description="Gate threshold updates"),
) -> dict[str, Any]:
    """Update output gate thresholds at runtime."""
    from src.services.guardrails.output_gate import get_output_gate

    gate = get_output_gate()
    try:
        gate.update_config(config)
        logger.info("Output gate config updated", updates=config)
        return {"config": gate.get_config(), "message": "Configuration updated"}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid configuration: {e}",
        ) from e


@router.get(
    "/evals/quality",
    status_code=status.HTTP_200_OK,
    summary="Get extraction quality metrics",
    responses={200: {"description": "Quality metrics"}},
)
async def get_quality_metrics(
    doc_type: str | None = Query(None, description="Filter by document type"),
    model: str | None = Query(None, description="Filter by model name"),
) -> dict[str, Any]:
    """Get F1/precision/recall per field, filterable by document type and model."""
    from src.services.evals.quality import get_quality_evaluator

    evaluator = get_quality_evaluator()
    report = evaluator.compute_overall_metrics()
    result = report.model_dump()

    # Apply filters if specified
    if doc_type and report.per_doc_type_metrics:
        result["filtered_doc_type"] = doc_type
        result["doc_type_metrics"] = report.per_doc_type_metrics.get(doc_type, {})

    if model and report.per_model_metrics:
        result["filtered_model"] = model
        result["model_metrics"] = report.per_model_metrics.get(model, {})

    return result


@router.get(
    "/evals/quality/worst-fields",
    status_code=status.HTTP_200_OK,
    summary="Get worst performing fields",
    responses={200: {"description": "Worst fields"}},
)
async def get_worst_fields(
    n: int = Query(5, ge=1, le=50, description="Number of fields to return"),
) -> dict[str, Any]:
    """Get N worst-performing fields by F1 score."""
    from src.services.evals.quality import get_quality_evaluator

    evaluator = get_quality_evaluator()
    fields = evaluator.get_worst_performing_fields(n)
    return {"worst_fields": [f.model_dump() for f in fields]}


@router.get(
    "/evals/calibration",
    status_code=status.HTTP_200_OK,
    summary="Get confidence calibration metrics",
    responses={200: {"description": "Calibration report"}},
)
async def get_calibration() -> dict[str, Any]:
    """Get ECE, calibration buckets, and overconfidence metrics."""
    from src.services.evals.calibration import get_calibration_tracker

    tracker = get_calibration_tracker()
    report = tracker.compute_calibration()
    return report.model_dump()


@router.get(
    "/evals/calibration/reliability-diagram",
    status_code=status.HTTP_200_OK,
    summary="Get reliability diagram data",
    responses={200: {"description": "Reliability diagram data points"}},
)
async def get_reliability_diagram() -> dict[str, Any]:
    """Get data points for reliability diagram chart."""
    from src.services.evals.calibration import get_calibration_tracker

    tracker = get_calibration_tracker()
    data = tracker.get_reliability_diagram_data()
    return {"data_points": data}


@router.get(
    "/evals/drift",
    status_code=status.HTTP_200_OK,
    summary="Get drift detection results",
    responses={200: {"description": "Drift report"}},
)
async def get_drift() -> dict[str, Any]:
    """Get drift detection results across input and output distributions."""
    from src.services.evals.drift import get_drift_detector

    detector = get_drift_detector()
    report = detector.check_drift()
    return report.model_dump()


@router.get(
    "/evals/regression",
    status_code=status.HTTP_200_OK,
    summary="Get regression detection results",
    responses={200: {"description": "Regression report"}},
)
async def get_regression() -> dict[str, Any]:
    """Get quality regression detection results."""
    from src.services.evals.regression import get_regression_detector

    detector = get_regression_detector()
    report = detector.check_regression()
    return report.model_dump()
