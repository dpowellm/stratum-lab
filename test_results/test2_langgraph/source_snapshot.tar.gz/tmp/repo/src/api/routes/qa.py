"""Q&A (Question Answering) endpoints for RAG.

Provides endpoints for querying documents using a combination of:
- TF-IDF text search on extracted document content
- Structured field matching on extraction data
- Optional vector-based RAG retrieval when available

The system works in two modes:
1. **Text search mode** (always available): Searches document text and
   extracted fields using TF-IDF scoring with context window extraction.
2. **RAG mode** (when vector store available): Adds vector-based semantic
   retrieval for improved accuracy on complex queries.
"""

import asyncio
import uuid
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.logging import get_logger
from src.models.database.base import get_session
from src.models.database.document import ProcessingStatus
from src.services.document.repository import DocumentRepository
from src.services.rag.service import (
    RAGResult,
    build_answer_from_matches,
    get_rag_service,
    search_document_text,
)

logger = get_logger(__name__)

router = APIRouter(prefix="/qa", tags=["Q&A"])


# Request/Response Models


class ConversationMessage(BaseModel):
    """A single message in conversation history."""

    role: str = Field(..., description="Message role: 'user' or 'assistant'")
    content: str = Field(..., description="Message content")


class QuestionRequest(BaseModel):
    """Request for asking a question."""

    question: str = Field(..., min_length=1, max_length=2000, description="Question to answer")
    document_ids: list[str] | None = Field(None, description="Limit to specific documents")
    top_k: int = Field(5, ge=1, le=20, description="Number of context chunks to retrieve")
    include_sources: bool = Field(True, description="Include source citations")
    model: str | None = Field(None, description="LLM model to use for generation")
    conversation_history: list[ConversationMessage] | None = Field(
        None, description="Previous conversation messages for context"
    )


class SourceCitation(BaseModel):
    """A source citation for an answer."""

    document_id: str
    chunk_id: str
    text_preview: str
    page: int | None
    score: float


class AnswerResponse(BaseModel):
    """Response containing the generated answer."""

    answer_id: str
    question: str
    answer: str
    confidence: float
    sources: list[SourceCitation]
    model_used: str
    generated_at: str
    tokens_used: int | None


class BatchQuestionRequest(BaseModel):
    """Request for batch question answering."""

    questions: list[QuestionRequest] = Field(..., min_length=1, max_length=10)


class BatchAnswerResponse(BaseModel):
    """Response containing multiple answers."""

    answers: list[AnswerResponse]
    total_questions: int
    successful: int
    failed: int
    errors: list[dict[str, str]] = Field(default_factory=list)


class SearchRequest(BaseModel):
    """Request for semantic search."""

    query: str = Field(..., min_length=1, max_length=1000)
    document_ids: list[str] | None = Field(None)
    top_k: int = Field(10, ge=1, le=100)
    score_threshold: float = Field(0.0, ge=0.0, le=1.0)
    search_mode: str = Field(
        "text",
        description="Search mode: 'text' (BGE-M3 only), 'visual' (ColPali only), 'hybrid' (both)",
        pattern="^(text|visual|hybrid)$",
    )


class SearchResult(BaseModel):
    """A search result."""

    chunk_id: str
    document_id: str
    text: str
    score: float
    page: int | None
    metadata: dict[str, Any]


class SearchResponse(BaseModel):
    """Response containing search results."""

    query: str
    results: list[SearchResult]
    total_results: int


# ---------------------------------------------------------------------------
# Thread-safe answer store
# ---------------------------------------------------------------------------

_answers_store: dict[str, dict] = {}
_store_lock = asyncio.Lock()


async def _store_answer(answer_id: str, answer_data: dict) -> None:
    """Store an answer in the thread-safe in-memory store."""
    async with _store_lock:
        _answers_store[answer_id] = answer_data
        # Evict old entries if store grows too large (keep last 1000)
        if len(_answers_store) > 1000:
            oldest_keys = sorted(
                _answers_store.keys(),
                key=lambda k: _answers_store[k].get("generated_at", ""),
            )
            for key in oldest_keys[: len(_answers_store) - 1000]:
                _answers_store.pop(key, None)


async def _get_answer(answer_id: str) -> dict | None:
    """Retrieve an answer from the thread-safe store."""
    async with _store_lock:
        return _answers_store.get(answer_id)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _gather_extractions(
    repo: DocumentRepository,
    document_ids: list[str] | None,
    _session: AsyncSession,
) -> list[dict[str, Any]]:
    """Fetch extraction data for the given documents (or all completed)."""
    docs_with_data: list[dict[str, Any]] = []

    if document_ids:
        for did in document_ids:
            try:
                doc = await repo.get_by_id(uuid.UUID(did))
            except (ValueError, AttributeError):
                logger.warning("Invalid document ID in Q&A request", document_id=did)
                continue
            if doc is None or doc.status != ProcessingStatus.COMPLETED:
                continue
            extraction = await repo.get_latest_extraction(doc.id)
            docs_with_data.append(
                {
                    "document_id": str(doc.id),
                    "filename": doc.filename,
                    "fields": extraction.extracted_data if extraction else {},
                }
            )
    else:
        # Use all completed documents
        docs, _ = await repo.list_documents(page=1, page_size=50, status=ProcessingStatus.COMPLETED)
        for doc in docs:
            extraction = await repo.get_latest_extraction(doc.id)
            docs_with_data.append(
                {
                    "document_id": str(doc.id),
                    "filename": doc.filename,
                    "fields": extraction.extracted_data if extraction else {},
                }
            )

    return docs_with_data


async def _try_rag_retrieval(
    question: str,
    document_ids: list[str] | None,
    top_k: int,
) -> RAGResult:
    """Attempt RAG-based retrieval. Returns empty result on failure."""
    try:
        rag_service = await get_rag_service()
        if rag_service.is_available:
            return await rag_service.retrieve(
                query=question,
                document_ids=document_ids,
                top_k=top_k,
            )
    except Exception as e:
        logger.debug("RAG retrieval unavailable", error=str(e))
    return RAGResult()


async def _try_llm_answer(
    question: str,
    matches: list,
    doc_extractions: list[dict[str, Any]] | None = None,
    conversation_history: list[dict[str, str]] | None = None,
) -> tuple[str, float] | None:
    """Attempt LLM-based answer generation. Returns None on failure."""
    try:
        from src.services.rag.llm_answer import LLMAnswerGenerator

        generator = LLMAnswerGenerator.get_instance()
        if not generator.is_available:
            return None

        context_chunks = [m.text for m in matches if m.text]

        # Fallback: when no matches, extract summary/text from doc_extractions
        if not context_chunks and doc_extractions:
            from src.services.rag.service import _get_field_value

            for doc_info in doc_extractions:
                fields = doc_info.get("fields", {})
                summary = _get_field_value(fields.get("summary", {}))
                if summary:
                    context_chunks.append(summary)
                doc_text = _get_field_value(fields.get("document_text", {}))
                if doc_text and doc_text != "(no text extracted)":
                    context_chunks.append(doc_text[:800])

        if not context_chunks:
            return None

        result = generator.generate(question, context_chunks, conversation_history)
        return result
    except Exception as e:
        logger.debug("LLM answer generation unavailable", error=str(e))
        return None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/ask",
    response_model=AnswerResponse,
    status_code=status.HTTP_200_OK,
    summary="Ask a question",
    description="Ask a question and get an answer based on document content and extracted data.",
)
async def ask_question(
    request: QuestionRequest,
    session: AsyncSession = Depends(get_session),
) -> AnswerResponse:
    """Ask a question and get an answer from document content and extracted data.

    Uses a two-stage approach:
    1. Text search: TF-IDF scoring on document text and extracted fields
    2. RAG retrieval: Vector-based semantic search (when available)

    Results from both stages are merged and ranked to produce the answer.
    """
    answer_id = str(uuid4())
    repo = DocumentRepository(session)

    logger.info(
        "Processing Q&A request",
        answer_id=answer_id,
        question_length=len(request.question),
        document_ids=request.document_ids,
    )

    # Gather extraction data from relevant documents
    doc_extractions = await _gather_extractions(repo, request.document_ids, session)

    # Stage 1: Text search on extracted content
    text_matches = search_document_text(
        query=request.question,
        doc_extractions=doc_extractions,
        top_k=request.top_k * 2,  # Get more candidates for ranking
    )

    # Stage 2: RAG retrieval (optional, graceful degradation)
    rag_result = await _try_rag_retrieval(
        question=request.question,
        document_ids=request.document_ids,
        top_k=request.top_k,
    )

    # Merge RAG results into text matches if available
    if rag_result.chunks:
        from src.services.rag.service import TextMatch

        for chunk in rag_result.chunks:
            text_matches.append(
                TextMatch(
                    text=chunk.get("text", ""),
                    score=chunk.get("score", 0.5),
                    document_id=chunk.get("document_id", ""),
                    field_name="rag_chunk",
                    page=chunk.get("page"),
                )
            )
        # Re-sort by score
        text_matches.sort(key=lambda m: m.score, reverse=True)
        text_matches = text_matches[: request.top_k * 2]

    # Try LLM-based answer generation first
    answer_text: str | None = None
    confidence: float = 0.0
    matched_sources: list[dict[str, Any]] = []
    model_used = "text-search"
    # Convert conversation history to plain dicts for the generator
    history_dicts: list[dict[str, str]] | None = None
    if request.conversation_history:
        history_dicts = [
            {"role": msg.role, "content": msg.content}
            for msg in request.conversation_history
        ]

    llm_answer = await _try_llm_answer(
        request.question,
        text_matches[: request.top_k],
        doc_extractions=doc_extractions,
        conversation_history=history_dicts,
    )
    if llm_answer is not None:
        answer_text, confidence = llm_answer
        model_used = "qwen-gguf"
        if rag_result.chunks:
            model_used = f"qwen-gguf+rag({rag_result.method})"
        # Still build sources from matches
        _, _, matched_sources = build_answer_from_matches(
            question=request.question,
            matches=text_matches[: request.top_k],
            doc_extractions=doc_extractions,
        )
    else:
        # Fallback to rule-based answer
        answer_text, confidence, matched_sources = build_answer_from_matches(
            question=request.question,
            matches=text_matches[: request.top_k],
            doc_extractions=doc_extractions,
        )
        if rag_result.chunks:
            model_used = f"text-search+rag({rag_result.method})"

    # Format sources
    sources: list[SourceCitation] = []
    if request.include_sources:
        for src_data in matched_sources[: request.top_k]:
            sources.append(
                SourceCitation(
                    document_id=src_data["document_id"],
                    chunk_id=src_data["chunk_id"],
                    text_preview=src_data["text_preview"],
                    page=src_data.get("page"),
                    score=src_data["score"],
                )
            )

    answer = AnswerResponse(
        answer_id=answer_id,
        question=request.question,
        answer=answer_text,
        confidence=confidence,
        sources=sources,
        model_used=model_used,
        generated_at=datetime.now(UTC).isoformat(),
        tokens_used=None,
    )

    await _store_answer(answer_id, answer.model_dump())

    logger.info(
        "Q&A request completed",
        answer_id=answer_id,
        confidence=confidence,
        source_count=len(sources),
        model_used=model_used,
    )

    return answer


@router.post(
    "/ask/batch",
    response_model=BatchAnswerResponse,
    status_code=status.HTTP_200_OK,
    summary="Batch question answering",
    description="Ask multiple questions in a single request.",
)
async def ask_batch(
    request: BatchQuestionRequest,
    session: AsyncSession = Depends(get_session),
) -> BatchAnswerResponse:
    """Ask multiple questions in batch with proper error handling."""
    answers = []
    failed = 0
    errors: list[dict[str, str]] = []

    for i, q_request in enumerate(request.questions):
        try:
            answer = await ask_question(q_request, session)
            answers.append(answer)
        except Exception as e:
            failed += 1
            error_msg = str(e)
            logger.error(
                "Batch Q&A question failed",
                question_index=i,
                question=q_request.question[:100],
                error=error_msg,
            )
            errors.append(
                {
                    "question_index": str(i),
                    "question": q_request.question[:100],
                    "error": error_msg,
                }
            )

    return BatchAnswerResponse(
        answers=answers,
        total_questions=len(request.questions),
        successful=len(answers),
        failed=failed,
        errors=errors,
    )


@router.post(
    "/search",
    response_model=SearchResponse,
    status_code=status.HTTP_200_OK,
    summary="Semantic search",
    description="Search documents using TF-IDF scoring on extracted content.",
)
async def search_documents(
    request: SearchRequest,
    session: AsyncSession = Depends(get_session),
) -> SearchResponse:
    """Search extracted document data using TF-IDF text search."""
    repo = DocumentRepository(session)
    doc_extractions = await _gather_extractions(repo, request.document_ids, session)

    # Text search with TF-IDF scoring
    matches = search_document_text(
        query=request.query,
        doc_extractions=doc_extractions,
        top_k=request.top_k * 2,
    )

    # Also try RAG retrieval
    rag_result = await _try_rag_retrieval(
        question=request.query,
        document_ids=request.document_ids,
        top_k=request.top_k,
    )

    results: list[SearchResult] = []

    # Convert text matches to search results
    for match in matches:
        if match.score < request.score_threshold:
            continue
        results.append(
            SearchResult(
                chunk_id=f"{match.document_id}_field_{match.field_name}",
                document_id=match.document_id,
                text=match.text[:500],
                score=round(match.score, 3),
                page=match.page,
                metadata={
                    "field_name": match.field_name or "content",
                    "source": "text_search",
                },
            )
        )

    # Merge RAG results
    seen_ids = {r.chunk_id for r in results}
    for chunk in rag_result.chunks:
        chunk_id = chunk.get("chunk_id", "")
        if chunk_id in seen_ids:
            continue
        score = chunk.get("score", 0.0)
        if score < request.score_threshold:
            continue
        results.append(
            SearchResult(
                chunk_id=chunk_id,
                document_id=chunk.get("document_id", ""),
                text=chunk.get("text", "")[:500],
                score=round(score, 3),
                page=chunk.get("page"),
                metadata={"source": "rag"},
            )
        )

    results.sort(key=lambda r: r.score, reverse=True)
    results = results[: request.top_k]

    return SearchResponse(
        query=request.query,
        results=results,
        total_results=len(results),
    )


@router.get(
    "/answers/{answer_id}",
    response_model=AnswerResponse,
    summary="Get answer by ID",
    description="Retrieve a previously generated answer.",
)
async def get_answer(answer_id: str) -> AnswerResponse:
    """Get a previously generated answer by ID."""
    stored = await _get_answer(answer_id)
    if stored is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Answer '{answer_id}' not found",
        )
    return AnswerResponse(**stored)


def _suggestions_for_fields(field_names: list[str], filename: str) -> list[str]:
    """Generate question suggestions from extracted field names."""
    suggestions: list[str] = []
    field_to_question: dict[str, str] = {
        "total_amount": "What is the total amount?",
        "invoice_number": "What is the invoice number?",
        "email": "What is the email address?",
        "skills": "What skills are listed?",
        "education": "What education is mentioned?",
        "current_title": "What is the person's job title?",
        "summary": "What is the document about?",
        "document_title": "What is the document title?",
    }

    if "full_name" in field_names or "vendor_name" in field_names:
        suggestions.append(f"Who is mentioned in {filename}?")

    for field, question in field_to_question.items():
        if field in field_names:
            suggestions.append(question)

    if "invoice_date" in field_names or "date" in field_names:
        suggestions.append("What is the date on the document?")

    if "document_text" in field_names:
        suggestions.append("What are the key points in this document?")
        suggestions.append("Summarize the main content.")

    if "sections" in field_names:
        suggestions.append("What sections does the document contain?")

    if "tables" in field_names:
        suggestions.append("What data is in the tables?")

    # Generic suggestions from field names
    for fname in field_names[:3]:
        if fname in ("document_text", "sections", "tables", "diagrams", "summary"):
            continue
        label = fname.replace("_", " ")
        suggestions.append(f"What is the {label}?")

    return suggestions


@router.get(
    "/suggest",
    response_model=list[str],
    summary="Get question suggestions",
    description="Get suggested questions based on document content.",
)
async def get_suggestions(
    document_id: str | None = Query(None, description="Document to get suggestions for"),
    limit: int = Query(5, ge=1, le=10, description="Number of suggestions"),
    session: AsyncSession = Depends(get_session),
) -> list[str]:
    """Get suggested questions based on actual document extraction data."""
    repo = DocumentRepository(session)

    target_ids = [document_id] if document_id else None
    doc_extractions = await _gather_extractions(repo, target_ids, session)

    if not doc_extractions:
        return [
            "Upload a document to get started.",
            "What information can be extracted?",
        ][:limit]

    suggestions: list[str] = []
    for doc_info in doc_extractions:
        fields = doc_info["fields"]
        if fields:
            suggestions.extend(_suggestions_for_fields(list(fields.keys()), doc_info["filename"]))

    # Deduplicate while preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for s in suggestions:
        if s not in seen:
            seen.add(s)
            unique.append(s)

    return unique[:limit]


@router.post(
    "/feedback",
    status_code=status.HTTP_201_CREATED,
    summary="Submit answer feedback",
    description="Submit feedback on a generated answer.",
)
async def submit_feedback(
    answer_id: str,
    helpful: bool,
    comment: str | None = None,
) -> dict[str, Any]:
    """Submit feedback on a generated answer."""
    stored = await _get_answer(answer_id)
    if stored is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Answer '{answer_id}' not found",
        )

    logger.info(
        "Answer feedback received",
        answer_id=answer_id,
        helpful=helpful,
        has_comment=comment is not None,
    )

    return {
        "status": "feedback_recorded",
        "answer_id": answer_id,
        "helpful": helpful,
    }
