"""Verify image region export produces valid documents with OCR text.

Loads the demo screenshot, crops a region, and attempts to export
to every supported format: image, PDF, DOCX, markdown, blog.
Verifies that PDF and DOCX exports contain extracted OCR text.
"""

import io
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.services.layout.extractor import LayoutExtractor, is_image_file
from src.services.layout.models import RegionSelector


def verify():
    img_path = ROOT / "demo" / "Screenshot 2025-06-01 at 17.15.55.png"
    if not img_path.exists():
        print(f"FAIL: image not found at {img_path}")
        return False

    file_bytes = img_path.read_bytes()
    print(f"Image loaded: {len(file_bytes)} bytes")
    print(f"is_image_file: {is_image_file(img_path.name)}")

    extractor = LayoutExtractor()

    # Full image region
    full_region = RegionSelector(page_number=0, x0=0.0, y0=0.0, x1=1.0, y1=1.0)
    # Partial region (left half with the diagram)
    partial_region = RegionSelector(page_number=0, x0=0.0, y0=0.0, x1=0.6, y1=0.8)

    ok = True

    # 1. Test crop_image_region - full image
    print("\n--- 1. crop_image_region (full) ---")
    try:
        cropped_full = extractor.crop_image_region(file_bytes, full_region, fmt="png")
        from PIL import Image
        img = Image.open(io.BytesIO(cropped_full))
        print(f"OK: {len(cropped_full)} bytes, {img.size[0]}x{img.size[1]} px, mode={img.mode}")
    except Exception as e:
        print(f"FAIL: {e}")
        ok = False

    # 2. Test crop_image_region - partial region
    print("\n--- 2. crop_image_region (partial) ---")
    try:
        cropped_partial = extractor.crop_image_region(file_bytes, partial_region, fmt="png")
        img = Image.open(io.BytesIO(cropped_partial))
        print(f"OK: {len(cropped_partial)} bytes, {img.size[0]}x{img.size[1]} px")
    except Exception as e:
        print(f"FAIL: {e}")
        ok = False

    # 3. Test _ocr_cropped_region
    print("\n--- 3. _ocr_cropped_region ---")
    try:
        from src.api.routes.documents import _ocr_cropped_region
        extraction_data = _ocr_cropped_region(cropped_partial, "Architecture Diagram")
        if extraction_data:
            print(f"OK: Got extraction data with {len(extraction_data)} keys")
            summary = extraction_data.get("summary", "")
            print(f"  Summary: {summary[:200]}...")
            sections = extraction_data.get("sections", [])
            print(f"  Sections: {len(sections)}")
            entities = extraction_data.get("entities", {})
            print(f"  Entity types: {list(entities.keys())}")
        else:
            print("WARN: OCR returned empty extraction data (pytesseract may not be installed)")
    except Exception as e:
        print(f"FAIL: {e}")
        ok = False

    # 4. Test _render_pdf_with_image (with OCR text)
    print("\n--- 4. _render_pdf_with_image (with OCR text) ---")
    try:
        from src.api.routes.documents import _render_pdf_with_image
        pdf_bytes = _render_pdf_with_image(
            cropped_partial, "Test Architecture Diagram", extraction_data
        )
        print(f"Output: {len(pdf_bytes)} bytes")
        if pdf_bytes.startswith(b"%PDF"):
            print("OK: Valid PDF header detected")
        else:
            print(f"FAIL: Not a valid PDF. Starts with: {pdf_bytes[:50]}")
            ok = False

        # Check for text content in PDF
        try:
            import fitz
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
            pdf_text = ""
            for page in doc:
                pdf_text += page.get_text()
            doc.close()
            pdf_text = pdf_text.strip()
            if pdf_text:
                print(f"OK: PDF contains {len(pdf_text)} chars of text")
                print(f"  Preview: {pdf_text[:150]}...")
            else:
                print("WARN: PDF has no extractable text (may need OCR data)")
        except ImportError:
            print("SKIP: PyMuPDF not available for PDF text check")
    except Exception as e:
        print(f"FAIL: {e}")
        ok = False

    # 5. Test _render_docx_with_image (with OCR text)
    print("\n--- 5. _render_docx_with_image (with OCR text) ---")
    try:
        from src.api.routes.documents import _render_docx_with_image
        docx_bytes = _render_docx_with_image(
            cropped_partial, "Test Architecture Diagram", extraction_data
        )
        print(f"Output: {len(docx_bytes)} bytes")
        if docx_bytes[:2] == b"PK":
            print("OK: Valid DOCX (ZIP) header detected")
        else:
            print(f"FAIL: Not a valid DOCX. Starts with: {docx_bytes[:50]}")
            ok = False

        # Check for text content in DOCX
        try:
            from docx import Document as DocxDoc
            doc = DocxDoc(io.BytesIO(docx_bytes))
            docx_text = "\n".join(p.text for p in doc.paragraphs).strip()
            if docx_text and len(docx_text) > 50:
                print(f"OK: DOCX contains {len(docx_text)} chars of text")
                print(f"  Preview: {docx_text[:150]}...")
            elif docx_text:
                print(f"WARN: DOCX has only title text: '{docx_text[:100]}'")
            else:
                print("WARN: DOCX has NO text paragraphs")
        except ImportError:
            print("SKIP: python-docx not available for DOCX text check")
    except Exception as e:
        print(f"FAIL: {e}")
        ok = False

    # 6. Test markdown export with OCR text
    print("\n--- 6. Markdown export with OCR text ---")
    try:
        from unittest.mock import MagicMock

        from src.api.routes.documents import _export_image_region

        mock_body = MagicMock()
        mock_body.format = "markdown"
        mock_body.image_format = "png"

        response = _export_image_region(
            extractor, file_bytes, full_region, mock_body, "Architecture Diagram"
        )
        md_content = response.body.decode("utf-8")
        print(f"OK: {len(md_content)} chars markdown")
        has_image = "data:image/png;base64," in md_content
        has_text = "Extracted Content" in md_content or len(md_content) > 500
        print(f"  Has base64 image: {has_image}")
        print(f"  Has text content: {has_text}")
        if has_text:
            # Find text after image
            text_start = md_content.find("## Extracted Content")
            if text_start > 0:
                preview = md_content[text_start:text_start + 300]
                print(f"  Text preview: {preview[:200]}...")
    except Exception as e:
        print(f"FAIL: {e}")
        ok = False

    # 7. Test blog export with OCR text
    print("\n--- 7. Blog export with OCR text ---")
    try:
        mock_body = MagicMock()
        mock_body.format = "blog"
        mock_body.image_format = "png"

        response = _export_image_region(
            extractor, file_bytes, full_region, mock_body, "Architecture Diagram"
        )
        blog_content = response.body.decode("utf-8")
        print(f"OK: {len(blog_content)} chars blog markdown")
        has_intro = "Introduction" in blog_content
        has_conclusion = "Conclusion" in blog_content
        print(f"  Has introduction: {has_intro}")
        print(f"  Has conclusion: {has_conclusion}")
    except Exception as e:
        print(f"FAIL: {e}")
        ok = False

    # 8. Test render_image_as_png
    print("\n--- 8. render_image_as_png ---")
    try:
        png_bytes = extractor.render_image_as_png(file_bytes)
        img = Image.open(io.BytesIO(png_bytes))
        print(f"OK: {len(png_bytes)} bytes, {img.size[0]}x{img.size[1]} px, format={img.format}")
    except Exception as e:
        print(f"FAIL: {e}")
        ok = False

    # 9. Test multiple formats for crop
    print("\n--- 9. Multiple image formats ---")
    for fmt in ("png", "jpeg", "webp"):
        try:
            cropped = extractor.crop_image_region(file_bytes, full_region, fmt=fmt)
            print(f"  {fmt}: {len(cropped)} bytes OK")
        except Exception as e:
            print(f"  {fmt}: FAIL - {e}")
            ok = False

    # 10. Test DB extraction data fallback
    print("\n--- 10. DB extraction data fallback ---")
    try:
        from unittest.mock import MagicMock, patch as _patch

        db_data = {
            "summary": "Fallback summary from DB.",
            "document_type": "report",
            "sections": [
                {"title": "DB Section", "content": "Content from database extraction.", "level": 1}
            ],
            "tables": [],
            "entities": {"dates": ["2024-01-01"]},
        }

        mock_body = MagicMock()
        mock_body.format = "markdown"
        mock_body.image_format = "png"

        with _patch("src.api.routes.documents._ocr_cropped_region", return_value={}):
            response = _export_image_region(
                extractor, file_bytes, full_region, mock_body, "DB Fallback Test",
                db_extraction_data=db_data,
            )

        md_content = response.body.decode("utf-8")
        has_db_text = "Content from database extraction" in md_content
        has_image = "data:image/png;base64," in md_content
        print(f"  Has DB fallback text: {has_db_text}")
        print(f"  Has base64 image: {has_image}")
        if has_db_text and has_image:
            print("OK: DB fallback works correctly")
        else:
            print("FAIL: DB fallback did not produce expected content")
            ok = False
    except Exception as e:
        print(f"FAIL: {e}")
        ok = False

    print(f"\n{'='*50}")
    print(f"Overall: {'PASS' if ok else 'FAIL'}")
    return ok


if __name__ == "__main__":
    success = verify()
    sys.exit(0 if success else 1)
