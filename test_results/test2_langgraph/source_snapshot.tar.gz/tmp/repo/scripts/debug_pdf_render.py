"""Debug _render_pdf_with_image failure."""

import io
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

img_path = ROOT / "demo" / "Screenshot 2025-06-01 at 17.15.55.png"
file_bytes = img_path.read_bytes()

# Crop a region
from src.services.layout.extractor import LayoutExtractor
from src.services.layout.models import RegionSelector

extractor = LayoutExtractor()
region = RegionSelector(page_number=0, x0=0.0, y0=0.0, x1=0.6, y1=0.8)
cropped_png = extractor.crop_image_region(file_bytes, region, fmt="png")
print(f"Cropped PNG: {len(cropped_png)} bytes")

# Now debug the PDF rendering step by step
print("\n--- Step 1: Import reportlab ---")
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfgen.canvas import Canvas
    print("OK: reportlab imported")
except ImportError as e:
    print(f"FAIL: {e}")
    sys.exit(1)

print("\n--- Step 2: Create ImageReader ---")
try:
    img_reader = ImageReader(io.BytesIO(cropped_png))
    iw, ih = img_reader.getSize()
    print(f"OK: ImageReader created, size={iw}x{ih}")
except Exception as e:
    print(f"FAIL: {e}")
    traceback.print_exc()

print("\n--- Step 3: Create Canvas and draw ---")
try:
    buf = io.BytesIO()
    page_w, page_h = A4
    c = Canvas(buf, pagesize=A4)
    c.setTitle("Test")

    margin = 36
    max_w = page_w - 2 * margin
    max_h = page_h - 2 * margin
    scale = min(max_w / iw, max_h / ih, 1.0)
    draw_w = iw * scale
    draw_h = ih * scale
    x = (page_w - draw_w) / 2
    y = page_h - margin - draw_h

    print(f"  page_size=({page_w:.1f}, {page_h:.1f})")
    print(f"  img_size=({iw}, {ih})")
    print(f"  scale={scale:.4f}")
    print(f"  draw_size=({draw_w:.1f}, {draw_h:.1f})")
    print(f"  pos=({x:.1f}, {y:.1f})")

    c.drawImage(img_reader, x, y, draw_w, draw_h)
    c.save()
    pdf_bytes = buf.getvalue()
    print(f"OK: PDF generated, {len(pdf_bytes)} bytes")
    print(f"  Starts with: {pdf_bytes[:20]}")
except Exception as e:
    print(f"FAIL: {e}")
    traceback.print_exc()

print("\n--- Step 4: Test with preserveAspectRatio flag ---")
try:
    buf2 = io.BytesIO()
    c2 = Canvas(buf2, pagesize=A4)
    c2.setTitle("Test 2")
    img_reader2 = ImageReader(io.BytesIO(cropped_png))
    c2.drawImage(img_reader2, 36, 36, page_w - 72, page_h - 72, preserveAspectRatio=True)
    c2.save()
    pdf_bytes2 = buf2.getvalue()
    print(f"OK: PDF generated, {len(pdf_bytes2)} bytes, starts={pdf_bytes2[:10]}")
except Exception as e:
    print(f"FAIL: {e}")
    traceback.print_exc()
