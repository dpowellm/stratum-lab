#!/usr/bin/env python3
"""
Project verification script.

Verifies that all project files are valid, key modules can be imported,
and services are reachable (when running).

Usage:
    uv run python scripts/verify_project.py
"""

import ast
import sys
from pathlib import Path


def check_python_syntax(file_path: Path) -> tuple[bool, str]:
    """Check if a Python file has valid syntax."""
    try:
        source = file_path.read_text(encoding="utf-8")
        ast.parse(source)
        return True, "OK"
    except SyntaxError as e:
        return False, f"Syntax error at line {e.lineno}: {e.msg}"
    except Exception as e:
        return False, str(e)


def check_yaml_syntax(file_path: Path) -> tuple[bool, str]:
    """Check if a YAML file is valid (basic check)."""
    try:
        content = file_path.read_text(encoding="utf-8")
        if not content.strip():
            return False, "Empty file"
        return True, "OK"
    except Exception as e:
        return False, str(e)


def check_imports() -> list[str]:
    """Try importing key modules and report failures."""
    errors = []
    modules = [
        ("src.config.settings", "Settings configuration"),
        ("src.core.logging", "Logging module"),
        ("src.api.main", "FastAPI application"),
        ("src.council.consensus", "Council consensus"),
        ("src.services.document.pipeline", "Document pipeline"),
        ("src.services.document.repository", "Document repository"),
        ("src.models.schemas.document", "Document schemas"),
    ]

    for module_path, description in modules:
        try:
            __import__(module_path)
            print(f"  ✓ {description} ({module_path})")
        except Exception as e:
            msg = f"{description} ({module_path}): {e}"
            print(f"  ✗ {msg}")
            errors.append(msg)

    return errors


def check_settings() -> list[str]:
    """Verify settings load correctly."""
    errors = []
    try:
        from src.config.settings import get_settings

        s = get_settings()
        print(f"  ✓ Settings loaded: {s.app.name} v{s.app.version} ({s.app.env})")
        print(f"  ✓ Council members: {s.enabled_council_members}")
        print(f"  ✓ Council mode: {s.council.council_mode}")
    except Exception as e:
        msg = f"Settings failed to load: {e}"
        print(f"  ✗ {msg}")
        errors.append(msg)
    return errors


def check_services() -> list[str]:
    """Check if services are reachable (non-critical, just informational)."""
    warnings = []

    # Check API
    try:
        import requests

        resp = requests.get("http://localhost:8000/health", timeout=3)
        if resp.status_code == 200:
            print("  ✓ API server is reachable (http://localhost:8000)")
        else:
            print(f"  ⚠ API returned status {resp.status_code}")
            warnings.append("API server returned non-200 status")
    except Exception:
        print("  ⚠ API server not reachable (not running?)")
        warnings.append("API server not reachable")

    # Check Redis
    try:
        import redis

        r = redis.Redis(host="localhost", port=6379, socket_timeout=2)
        r.ping()
        print("  ✓ Redis is reachable (localhost:6379)")
    except Exception:
        print("  ⚠ Redis not reachable")
        warnings.append("Redis not reachable")

    # Check database
    try:
        import asyncpg  # noqa: F401

        print("  ✓ asyncpg driver available")
    except ImportError:
        print("  ⚠ asyncpg not installed")
        warnings.append("asyncpg not installed")

    # Check GGUF models
    cache_dir = Path.home() / ".cache" / "huggingface" / "hub"
    if cache_dir.exists():
        gguf_files = list(cache_dir.rglob("*.gguf"))
        if gguf_files:
            print(f"  ✓ Found {len(gguf_files)} GGUF model file(s)")
        else:
            print("  ⚠ No GGUF models found (will use mock mode)")
            warnings.append("No GGUF models downloaded")
    else:
        print("  ⚠ HuggingFace cache directory not found")
        warnings.append("HuggingFace cache directory not found")

    return warnings


def main() -> int:
    """Run project verification."""
    project_root = Path(__file__).parent.parent

    print("=" * 60)
    print("Agentic Document Extraction System - Project Verification")
    print("=" * 60)
    print()

    errors = []
    warnings = []
    checked = 0

    # Check Python files
    print("Checking Python files...")
    py_files = list(project_root.glob("src/**/*.py")) + list(project_root.glob("tests/**/*.py"))

    for py_file in py_files:
        relative_path = py_file.relative_to(project_root)
        is_valid, message = check_python_syntax(py_file)
        checked += 1

        if is_valid:
            print(f"  ✓ {relative_path}")
        else:
            print(f"  ✗ {relative_path}: {message}")
            errors.append(f"{relative_path}: {message}")

    print()

    # Check YAML files
    print("Checking YAML files...")
    yaml_files = list(project_root.glob("**/*.yml")) + list(project_root.glob("**/*.yaml"))

    for yaml_file in yaml_files:
        relative_path = yaml_file.relative_to(project_root)
        is_valid, message = check_yaml_syntax(yaml_file)
        checked += 1

        if is_valid:
            print(f"  ✓ {relative_path}")
        else:
            print(f"  ✗ {relative_path}: {message}")
            errors.append(f"{relative_path}: {message}")

    print()

    # Check required files exist
    print("Checking required files...")
    required_files = [
        "pyproject.toml",
        "Makefile",
        ".env.example",
        ".pre-commit-config.yaml",
        "alembic.ini",
        "src/__init__.py",
        "src/api/main.py",
        "src/config/settings.py",
        "src/core/logging.py",
        "src/council/consensus.py",
        "src/services/ocr/base.py",
        "tests/conftest.py",
        "deploy/docker/docker-compose.yml",
        "deploy/docker/Dockerfile",
    ]

    for file_name in required_files:
        file_path = project_root / file_name
        checked += 1

        if file_path.exists():
            print(f"  ✓ {file_name}")
        else:
            print(f"  ✗ {file_name}: File not found")
            errors.append(f"{file_name}: File not found")

    print()

    # Check directory structure
    print("Checking directory structure...")
    required_dirs = [
        "src/api/routes",
        "src/config",
        "src/core",
        "src/models/database",
        "src/models/schemas",
        "src/services/ocr",
        "src/council",
        "src/agents",
        "src/workers/tasks",
        "tests/unit",
        "tests/integration",
        "tests/e2e",
        "tests/council",
        "deploy/docker",
        "deploy/kubernetes",
        "alembic/versions",
        "docs",
        ".github/workflows",
    ]

    for dir_name in required_dirs:
        dir_path = project_root / dir_name
        checked += 1

        if dir_path.exists() and dir_path.is_dir():
            print(f"  ✓ {dir_name}/")
        else:
            print(f"  ✗ {dir_name}/: Directory not found")
            warnings.append(f"{dir_name}/: Directory not found")

    print()

    # Check Python imports
    print("Checking Python imports...")
    import_errors = check_imports()
    errors.extend(import_errors)
    print()

    # Check settings
    print("Checking settings...")
    settings_errors = check_settings()
    errors.extend(settings_errors)
    print()

    # Check running services (informational only)
    print("Checking services (informational)...")
    service_warnings = check_services()
    warnings.extend(service_warnings)
    print()

    # Summary
    print("=" * 60)
    print("VERIFICATION SUMMARY")
    print("=" * 60)
    print(f"  Files/directories checked: {checked}")
    print(f"  Errors: {len(errors)}")
    print(f"  Warnings: {len(warnings)}")
    print()

    if errors:
        print("ERRORS:")
        for error in errors:
            print(f"  - {error}")
        print()

    if warnings:
        print("WARNINGS:")
        for warning in warnings:
            print(f"  - {warning}")
        print()

    if not errors:
        print("✓ All critical checks passed!")
        print()
        print("Quick start:")
        print("  make setup       # Install deps, start infra, migrate, download models")
        print("  make start       # Start API + workers")
        print("  make docker-start  # Or start everything via Docker")
        print()
        print("Service URLs:")
        print("  Frontend:   http://localhost:8000")
        print("  API:        http://localhost:8000")
        print("  API Docs:   http://localhost:8000/docs")
        print("  Flower:     http://localhost:5555")
        return 0
    else:
        print("✗ Verification failed with errors")
        return 1


if __name__ == "__main__":
    sys.exit(main())
