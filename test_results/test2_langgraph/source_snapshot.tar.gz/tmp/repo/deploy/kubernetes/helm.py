"""
Helm Chart Configuration.

Task 3.3.1: Creates Helm charts for Kubernetes deployment.
"""

from dataclasses import dataclass, field
from typing import Any
from enum import Enum

from src.core.logging import get_logger

logger = get_logger(__name__)


class ChartType(str, Enum):
    """Types of Helm charts."""

    APPLICATION = "application"
    LIBRARY = "library"


@dataclass
class HelmValues:
    """Helm chart values configuration."""

    # Image configuration
    image_repository: str = "doc-extraction-system"
    image_tag: str = "latest"
    image_pull_policy: str = "IfNotPresent"

    # Replica configuration
    replicas: int = 2
    min_replicas: int = 1
    max_replicas: int = 10

    # Resource configuration
    cpu_request: str = "500m"
    cpu_limit: str = "2000m"
    memory_request: str = "1Gi"
    memory_limit: str = "4Gi"
    gpu_enabled: bool = False
    gpu_count: int = 1

    # Service configuration
    service_type: str = "ClusterIP"
    service_port: int = 8000

    # Ingress configuration
    ingress_enabled: bool = True
    ingress_host: str = "doc-extraction.local"
    ingress_tls_enabled: bool = True

    # Persistence
    persistence_enabled: bool = True
    persistence_size: str = "10Gi"
    persistence_storage_class: str = "standard"

    # Environment
    environment: str = "production"
    log_level: str = "INFO"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "image": {
                "repository": self.image_repository,
                "tag": self.image_tag,
                "pullPolicy": self.image_pull_policy,
            },
            "replicaCount": self.replicas,
            "autoscaling": {
                "enabled": True,
                "minReplicas": self.min_replicas,
                "maxReplicas": self.max_replicas,
            },
            "resources": {
                "requests": {
                    "cpu": self.cpu_request,
                    "memory": self.memory_request,
                },
                "limits": {
                    "cpu": self.cpu_limit,
                    "memory": self.memory_limit,
                },
            },
            "gpu": {
                "enabled": self.gpu_enabled,
                "count": self.gpu_count,
            },
            "service": {
                "type": self.service_type,
                "port": self.service_port,
            },
            "ingress": {
                "enabled": self.ingress_enabled,
                "host": self.ingress_host,
                "tls": self.ingress_tls_enabled,
            },
            "persistence": {
                "enabled": self.persistence_enabled,
                "size": self.persistence_size,
                "storageClass": self.persistence_storage_class,
            },
            "env": {
                "ENVIRONMENT": self.environment,
                "LOG_LEVEL": self.log_level,
            },
        }


@dataclass
class HelmChart:
    """Helm chart configuration."""

    name: str
    version: str
    app_version: str
    description: str
    chart_type: ChartType = ChartType.APPLICATION
    dependencies: list[dict[str, str]] = field(default_factory=list)
    values: HelmValues = field(default_factory=HelmValues)

    def get_chart_yaml(self) -> dict[str, Any]:
        """Generate Chart.yaml content."""
        return {
            "apiVersion": "v2",
            "name": self.name,
            "version": self.version,
            "appVersion": self.app_version,
            "description": self.description,
            "type": self.chart_type.value,
            "dependencies": self.dependencies,
        }


class HelmChartManager:
    """
    Helm Chart Manager.

    Features:
    - Chart generation
    - Values management
    - Template rendering
    - Dependency management
    """

    DEFAULT_DEPENDENCIES = [
        {
            "name": "redis",
            "version": "17.x.x",
            "repository": "https://charts.bitnami.com/bitnami",
            "condition": "redis.enabled",
        },
        {
            "name": "postgresql",
            "version": "12.x.x",
            "repository": "https://charts.bitnami.com/bitnami",
            "condition": "postgresql.enabled",
        },
    ]

    def __init__(self):
        """Initialize Helm chart manager."""
        self._charts: dict[str, HelmChart] = {}
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize with default chart."""
        default_chart = HelmChart(
            name="doc-extraction-system",
            version="1.0.0",
            app_version="1.0.0",
            description="Document Extraction System with LLM Council",
            dependencies=self.DEFAULT_DEPENDENCIES,
        )
        self._charts[default_chart.name] = default_chart
        self._initialized = True
        logger.info("Helm chart manager initialized")
        return True

    def create_chart(
        self,
        name: str,
        version: str,
        app_version: str,
        description: str,
        values: HelmValues | None = None,
    ) -> HelmChart:
        """Create a new Helm chart."""
        chart = HelmChart(
            name=name,
            version=version,
            app_version=app_version,
            description=description,
            values=values or HelmValues(),
        )
        self._charts[name] = chart
        return chart

    def get_chart(self, name: str) -> HelmChart | None:
        """Get a chart by name."""
        return self._charts.get(name)

    def update_values(
        self,
        chart_name: str,
        **updates: Any,
    ) -> HelmValues | None:
        """Update chart values."""
        chart = self._charts.get(chart_name)
        if not chart:
            return None

        for key, value in updates.items():
            if hasattr(chart.values, key):
                setattr(chart.values, key, value)

        return chart.values

    def generate_deployment_yaml(
        self,
        chart_name: str,
    ) -> dict[str, Any]:
        """Generate Kubernetes Deployment manifest."""
        chart = self._charts.get(chart_name)
        if not chart:
            return {}

        values = chart.values

        return {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {
                "name": chart.name,
                "labels": {
                    "app": chart.name,
                    "version": chart.app_version,
                },
            },
            "spec": {
                "replicas": values.replicas,
                "selector": {
                    "matchLabels": {"app": chart.name},
                },
                "template": {
                    "metadata": {
                        "labels": {"app": chart.name},
                    },
                    "spec": {
                        "containers": [
                            {
                                "name": chart.name,
                                "image": f"{values.image_repository}:{values.image_tag}",
                                "ports": [{"containerPort": values.service_port}],
                                "resources": {
                                    "requests": {
                                        "cpu": values.cpu_request,
                                        "memory": values.memory_request,
                                    },
                                    "limits": {
                                        "cpu": values.cpu_limit,
                                        "memory": values.memory_limit,
                                    },
                                },
                            }
                        ],
                    },
                },
            },
        }

    def generate_service_yaml(
        self,
        chart_name: str,
    ) -> dict[str, Any]:
        """Generate Kubernetes Service manifest."""
        chart = self._charts.get(chart_name)
        if not chart:
            return {}

        values = chart.values

        return {
            "apiVersion": "v1",
            "kind": "Service",
            "metadata": {"name": chart.name},
            "spec": {
                "type": values.service_type,
                "ports": [
                    {
                        "port": values.service_port,
                        "targetPort": values.service_port,
                    }
                ],
                "selector": {"app": chart.name},
            },
        }

    def get_all_charts(self) -> list[HelmChart]:
        """Get all charts."""
        return list(self._charts.values())


# Singleton instance
_helm_manager: HelmChartManager | None = None


def get_helm_manager() -> HelmChartManager:
    """Get or create Helm chart manager singleton."""
    global _helm_manager
    if _helm_manager is None:
        _helm_manager = HelmChartManager()
        _helm_manager.initialize()
    return _helm_manager
