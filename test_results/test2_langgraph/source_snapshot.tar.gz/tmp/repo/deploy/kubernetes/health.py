"""
Health Checks and Probes Configuration.

Task 3.3.4: Implements liveness, readiness, and startup probes.
"""

from dataclasses import dataclass, field
from typing import Any
from enum import Enum

from src.core.logging import get_logger

logger = get_logger(__name__)


class ProbeType(str, Enum):
    """Types of Kubernetes probes."""

    LIVENESS = "livenessProbe"
    READINESS = "readinessProbe"
    STARTUP = "startupProbe"


class ProbeMethod(str, Enum):
    """Methods for health probes."""

    HTTP = "httpGet"
    TCP = "tcpSocket"
    EXEC = "exec"
    GRPC = "grpc"


@dataclass
class ProbeConfig:
    """Configuration for a health probe."""

    probe_type: ProbeType
    method: ProbeMethod
    path: str = "/health"
    port: int = 8000
    initial_delay_seconds: int = 10
    period_seconds: int = 10
    timeout_seconds: int = 5
    success_threshold: int = 1
    failure_threshold: int = 3
    command: list[str] | None = None

    def to_probe_spec(self) -> dict[str, Any]:
        """Generate Kubernetes probe spec."""
        probe: dict[str, Any] = {
            "initialDelaySeconds": self.initial_delay_seconds,
            "periodSeconds": self.period_seconds,
            "timeoutSeconds": self.timeout_seconds,
            "successThreshold": self.success_threshold,
            "failureThreshold": self.failure_threshold,
        }

        if self.method == ProbeMethod.HTTP:
            probe["httpGet"] = {
                "path": self.path,
                "port": self.port,
            }
        elif self.method == ProbeMethod.TCP:
            probe["tcpSocket"] = {
                "port": self.port,
            }
        elif self.method == ProbeMethod.EXEC:
            probe["exec"] = {
                "command": self.command or ["/bin/sh", "-c", "echo healthy"],
            }
        elif self.method == ProbeMethod.GRPC:
            probe["grpc"] = {
                "port": self.port,
            }

        return probe


@dataclass
class HealthCheckConfig:
    """Complete health check configuration for a service."""

    service_name: str
    liveness: ProbeConfig | None = None
    readiness: ProbeConfig | None = None
    startup: ProbeConfig | None = None
    health_endpoints: dict[str, str] = field(default_factory=dict)

    def to_container_spec(self) -> dict[str, Any]:
        """Generate container spec with probes."""
        spec: dict[str, Any] = {}

        if self.liveness:
            spec["livenessProbe"] = self.liveness.to_probe_spec()
        if self.readiness:
            spec["readinessProbe"] = self.readiness.to_probe_spec()
        if self.startup:
            spec["startupProbe"] = self.startup.to_probe_spec()

        return spec


class HealthCheckManager:
    """
    Health Check Manager.

    Features:
    - Liveness probe configuration
    - Readiness probe configuration
    - Startup probe configuration
    - Custom health endpoints
    """

    DEFAULT_ENDPOINTS = {
        "health": "/health",
        "ready": "/ready",
        "live": "/live",
        "startup": "/startup",
    }

    def __init__(self):
        """Initialize health check manager."""
        self._configs: dict[str, HealthCheckConfig] = {}
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize with default health check configurations."""
        # API service health checks
        api_config = HealthCheckConfig(
            service_name="doc-extraction-api",
            liveness=ProbeConfig(
                probe_type=ProbeType.LIVENESS,
                method=ProbeMethod.HTTP,
                path="/health/live",
                port=8000,
                initial_delay_seconds=15,
                period_seconds=20,
                failure_threshold=3,
            ),
            readiness=ProbeConfig(
                probe_type=ProbeType.READINESS,
                method=ProbeMethod.HTTP,
                path="/health/ready",
                port=8000,
                initial_delay_seconds=5,
                period_seconds=10,
                failure_threshold=3,
            ),
            startup=ProbeConfig(
                probe_type=ProbeType.STARTUP,
                method=ProbeMethod.HTTP,
                path="/health/startup",
                port=8000,
                initial_delay_seconds=0,
                period_seconds=5,
                failure_threshold=30,  # Allow up to 150s for startup
            ),
            health_endpoints=self.DEFAULT_ENDPOINTS,
        )
        self._configs[api_config.service_name] = api_config

        # Council worker health checks
        worker_config = HealthCheckConfig(
            service_name="council-worker",
            liveness=ProbeConfig(
                probe_type=ProbeType.LIVENESS,
                method=ProbeMethod.EXEC,
                command=["/bin/sh", "-c", "celery inspect ping -d celery@$HOSTNAME"],
                initial_delay_seconds=30,
                period_seconds=30,
                timeout_seconds=10,
            ),
            readiness=ProbeConfig(
                probe_type=ProbeType.READINESS,
                method=ProbeMethod.EXEC,
                command=["/bin/sh", "-c", "celery inspect active_queues -d celery@$HOSTNAME"],
                initial_delay_seconds=15,
                period_seconds=15,
            ),
        )
        self._configs[worker_config.service_name] = worker_config

        self._initialized = True
        logger.info("Health check manager initialized")
        return True

    def create_config(
        self,
        service_name: str,
        health_port: int = 8000,
    ) -> HealthCheckConfig:
        """Create a new health check configuration with defaults."""
        config = HealthCheckConfig(
            service_name=service_name,
            liveness=ProbeConfig(
                probe_type=ProbeType.LIVENESS,
                method=ProbeMethod.HTTP,
                path="/health/live",
                port=health_port,
            ),
            readiness=ProbeConfig(
                probe_type=ProbeType.READINESS,
                method=ProbeMethod.HTTP,
                path="/health/ready",
                port=health_port,
            ),
            health_endpoints=self.DEFAULT_ENDPOINTS,
        )
        self._configs[service_name] = config
        return config

    def get_config(self, service_name: str) -> HealthCheckConfig | None:
        """Get a configuration by service name."""
        return self._configs.get(service_name)

    def set_liveness_probe(
        self,
        service_name: str,
        probe: ProbeConfig,
    ) -> bool:
        """Set liveness probe for a service."""
        config = self._configs.get(service_name)
        if not config:
            return False
        config.liveness = probe
        return True

    def set_readiness_probe(
        self,
        service_name: str,
        probe: ProbeConfig,
    ) -> bool:
        """Set readiness probe for a service."""
        config = self._configs.get(service_name)
        if not config:
            return False
        config.readiness = probe
        return True

    def set_startup_probe(
        self,
        service_name: str,
        probe: ProbeConfig,
    ) -> bool:
        """Set startup probe for a service."""
        config = self._configs.get(service_name)
        if not config:
            return False
        config.startup = probe
        return True

    def generate_health_handler_code(self) -> str:
        """Generate FastAPI health endpoint code."""
        return '''
from fastapi import APIRouter, Response
from datetime import datetime

router = APIRouter(prefix="/health", tags=["Health"])

@router.get("/live")
async def liveness():
    """Liveness probe - is the service running?"""
    return {"status": "alive", "timestamp": datetime.utcnow().isoformat()}

@router.get("/ready")
async def readiness():
    """Readiness probe - is the service ready to accept traffic?"""
    # Check dependencies (database, redis, etc.)
    return {"status": "ready", "timestamp": datetime.utcnow().isoformat()}

@router.get("/startup")
async def startup():
    """Startup probe - has the service finished initializing?"""
    return {"status": "started", "timestamp": datetime.utcnow().isoformat()}

@router.get("")
async def health():
    """General health check."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0",
    }
'''

    def get_all_configs(self) -> list[HealthCheckConfig]:
        """Get all health check configurations."""
        return list(self._configs.values())


# Singleton instance
_health_manager: HealthCheckManager | None = None


def get_health_check_manager() -> HealthCheckManager:
    """Get or create health check manager singleton."""
    global _health_manager
    if _health_manager is None:
        _health_manager = HealthCheckManager()
        _health_manager.initialize()
    return _health_manager
