"""
KEDA Auto-scaling Configuration.

Task 3.3.2: Configures event-driven auto-scaling based on queue depth.
"""

from dataclasses import dataclass, field
from typing import Any
from enum import Enum

from src.core.logging import get_logger

logger = get_logger(__name__)


class ScalerType(str, Enum):
    """Types of KEDA scalers."""

    RABBITMQ = "rabbitmq"
    REDIS = "redis"
    KAFKA = "kafka"
    PROMETHEUS = "prometheus"
    CRON = "cron"
    CPU = "cpu"
    MEMORY = "memory"


@dataclass
class ScalerConfig:
    """Configuration for a KEDA scaler."""

    scaler_type: ScalerType
    metadata: dict[str, Any] = field(default_factory=dict)
    authentication_ref: str | None = None

    def to_trigger(self) -> dict[str, Any]:
        """Convert to KEDA trigger spec."""
        trigger = {
            "type": self.scaler_type.value,
            "metadata": self.metadata,
        }
        if self.authentication_ref:
            trigger["authenticationRef"] = {"name": self.authentication_ref}
        return trigger


@dataclass
class KEDAConfig:
    """KEDA ScaledObject configuration."""

    name: str
    deployment_name: str
    min_replicas: int = 1
    max_replicas: int = 10
    cooldown_period: int = 300  # seconds
    polling_interval: int = 30  # seconds
    scalers: list[ScalerConfig] = field(default_factory=list)

    def to_scaled_object(self) -> dict[str, Any]:
        """Generate KEDA ScaledObject manifest."""
        return {
            "apiVersion": "keda.sh/v1alpha1",
            "kind": "ScaledObject",
            "metadata": {
                "name": self.name,
            },
            "spec": {
                "scaleTargetRef": {
                    "name": self.deployment_name,
                },
                "minReplicaCount": self.min_replicas,
                "maxReplicaCount": self.max_replicas,
                "cooldownPeriod": self.cooldown_period,
                "pollingInterval": self.polling_interval,
                "triggers": [s.to_trigger() for s in self.scalers],
            },
        }


class KEDAManager:
    """
    KEDA Auto-scaling Manager.

    Features:
    - Queue-based scaling
    - CPU/Memory scaling
    - Custom metrics scaling
    - Cron-based scaling
    """

    def __init__(self):
        """Initialize KEDA manager."""
        self._configs: dict[str, KEDAConfig] = {}
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize with default configurations."""
        # Default council worker scaling
        council_config = KEDAConfig(
            name="council-worker-scaler",
            deployment_name="council-worker",
            min_replicas=2,
            max_replicas=20,
            scalers=[
                ScalerConfig(
                    scaler_type=ScalerType.RABBITMQ,
                    metadata={
                        "queueName": "document_extraction",
                        "queueLength": "5",
                        "host": "amqp://rabbitmq.default.svc.cluster.local",
                    },
                ),
            ],
        )
        self._configs[council_config.name] = council_config

        # API scaling
        api_config = KEDAConfig(
            name="api-scaler",
            deployment_name="doc-extraction-api",
            min_replicas=2,
            max_replicas=10,
            scalers=[
                ScalerConfig(
                    scaler_type=ScalerType.PROMETHEUS,
                    metadata={
                        "serverAddress": "http://prometheus.monitoring.svc:9090",
                        "metricName": "http_requests_total",
                        "query": 'sum(rate(http_requests_total{job="api"}[1m]))',
                        "threshold": "100",
                    },
                ),
            ],
        )
        self._configs[api_config.name] = api_config

        self._initialized = True
        logger.info("KEDA manager initialized")
        return True

    def create_config(
        self,
        name: str,
        deployment_name: str,
        scalers: list[ScalerConfig],
        min_replicas: int = 1,
        max_replicas: int = 10,
    ) -> KEDAConfig:
        """Create a new KEDA configuration."""
        config = KEDAConfig(
            name=name,
            deployment_name=deployment_name,
            min_replicas=min_replicas,
            max_replicas=max_replicas,
            scalers=scalers,
        )
        self._configs[name] = config
        return config

    def get_config(self, name: str) -> KEDAConfig | None:
        """Get a configuration by name."""
        return self._configs.get(name)

    def add_queue_scaler(
        self,
        config_name: str,
        queue_name: str,
        queue_length: int = 5,
    ) -> bool:
        """Add a queue-based scaler."""
        config = self._configs.get(config_name)
        if not config:
            return False

        scaler = ScalerConfig(
            scaler_type=ScalerType.RABBITMQ,
            metadata={
                "queueName": queue_name,
                "queueLength": str(queue_length),
            },
        )
        config.scalers.append(scaler)
        return True

    def add_cpu_scaler(
        self,
        config_name: str,
        target_utilization: int = 80,
    ) -> bool:
        """Add a CPU-based scaler."""
        config = self._configs.get(config_name)
        if not config:
            return False

        scaler = ScalerConfig(
            scaler_type=ScalerType.CPU,
            metadata={
                "type": "Utilization",
                "value": str(target_utilization),
            },
        )
        config.scalers.append(scaler)
        return True

    def add_cron_scaler(
        self,
        config_name: str,
        start: str,
        end: str,
        desired_replicas: int,
        timezone: str = "UTC",
    ) -> bool:
        """Add a cron-based scaler for scheduled scaling."""
        config = self._configs.get(config_name)
        if not config:
            return False

        scaler = ScalerConfig(
            scaler_type=ScalerType.CRON,
            metadata={
                "timezone": timezone,
                "start": start,
                "end": end,
                "desiredReplicas": str(desired_replicas),
            },
        )
        config.scalers.append(scaler)
        return True

    def generate_manifests(self) -> list[dict[str, Any]]:
        """Generate all KEDA manifests."""
        return [config.to_scaled_object() for config in self._configs.values()]

    def get_all_configs(self) -> list[KEDAConfig]:
        """Get all configurations."""
        return list(self._configs.values())


# Singleton instance
_keda_manager: KEDAManager | None = None


def get_keda_manager() -> KEDAManager:
    """Get or create KEDA manager singleton."""
    global _keda_manager
    if _keda_manager is None:
        _keda_manager = KEDAManager()
        _keda_manager.initialize()
    return _keda_manager
