"""
Core CrewAI Platform components.

Provides the fundamental building blocks for:
- Agent orchestration
- Tool management  
- Monitoring and analytics
- Base agent classes
""" 