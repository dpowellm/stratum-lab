"""
Example workflows for learning and demonstration purposes.

These workflows showcase basic CrewAI Platform capabilities and serve as 
starting points for building custom workflows.
""" 