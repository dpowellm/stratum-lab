"""
Workflows package for CrewAI Platform.

Contains both official platform workflows and community-contributed workflows.
""" 