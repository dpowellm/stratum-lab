"""
Community-contributed workflows for CrewAI Platform.

This package contains workflows contributed by the community.
All workflows here follow the contribution guidelines and quality standards.
""" 