"""
Community-contributed integrations for CrewAI Platform.
""" 