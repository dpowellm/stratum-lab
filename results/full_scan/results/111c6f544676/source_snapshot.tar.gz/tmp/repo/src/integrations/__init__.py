"""
Integrations package for CrewAI Platform.

Contains both official platform integrations and community-contributed integrations.
""" 