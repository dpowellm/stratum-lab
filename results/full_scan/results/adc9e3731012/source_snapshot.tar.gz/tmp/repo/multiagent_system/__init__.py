"""
Multi-Agent System for Daily AI Package Blog Generation
"""

__version__ = "1.0.0"
