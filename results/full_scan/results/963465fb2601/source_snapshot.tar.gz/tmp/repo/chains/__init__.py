"""
LCEL (LangChain Expression Language) chain examples.

This module demonstrates modern LangChain patterns using LCEL.
"""