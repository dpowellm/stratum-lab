"""Tests for MultiAgentBench benchmark."""
