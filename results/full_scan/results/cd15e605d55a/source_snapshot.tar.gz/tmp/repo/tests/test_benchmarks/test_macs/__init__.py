"""Tests for MACS benchmark."""
