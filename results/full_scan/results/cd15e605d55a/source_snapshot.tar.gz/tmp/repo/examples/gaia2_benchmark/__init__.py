"""Gaia2 Benchmark Example Package."""
