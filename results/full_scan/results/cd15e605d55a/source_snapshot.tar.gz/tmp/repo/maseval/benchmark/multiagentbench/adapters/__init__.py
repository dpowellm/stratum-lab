"""Agent adapters for MultiAgentBench."""

from maseval.benchmark.multiagentbench.adapters.marble_adapter import (
    MarbleAgentAdapter,
)

__all__ = ["MarbleAgentAdapter"]
