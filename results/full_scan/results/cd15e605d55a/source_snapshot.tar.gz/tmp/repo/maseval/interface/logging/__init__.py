"""Logging integrations for various platforms.

This package contains adapters for different logging platforms.
"""

__all__ = []

# TODO: Add wandb, langfuse adapters
