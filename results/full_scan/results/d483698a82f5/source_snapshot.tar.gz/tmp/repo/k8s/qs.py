import pandas as pd

df = pd.read_csv('D:\\K8\\dataSynthetic.csv')
print("Columns in dataSynthetic.csv:", df.columns.tolist())