import os
import shutil
from datetime import datetime
import requests

import streamlit as st
from streamlit_searchbox import st_searchbox
from assignment.crew import NewsSummarizationCrew

from db import init_db, insert_history, fetch_history

# Initialize the DB
init_db()

EDITORIAL_MD_PATH = os.getenv("EDITORIAL_MD_PATH")
EXPLANATORY_MD_PATH = os.getenv("EXPLANATORY_MD_PATH")
GLOSSARY_MD_PATH = os.getenv("GLOSSARY_MD_PATH")
INTERMEDIATE_DIR = os.getenv("INTERMEDIATE_DIR")

def save_files_with_timestamp(timestamp_str):
    """Save current output and intermediate files with a timestamped directory name.

    Args:
        timestamp_str (str): The timestamp string to use for directory naming.

    Returns:
        dict: A dictionary with keys for the new file paths (editorial_path, explanatory_path, glossary_path, intermediate_files).
    """
    timestamp_clean = timestamp_str.replace(':', '-').replace(' ', '_')
    saved_files = {}

    # Create timestamped directories
    editorial_dir = f"output/editorial/{timestamp_clean}"
    explanatory_dir = f"output/explanatory/{timestamp_clean}"
    glossary_dir = f"output/glossary/{timestamp_clean}"
    intermediate_dir = f"output/metadata/{timestamp_clean}"

    os.makedirs(editorial_dir, exist_ok=True)
    os.makedirs(explanatory_dir, exist_ok=True)
    os.makedirs(glossary_dir, exist_ok=True)
    os.makedirs(intermediate_dir, exist_ok=True)

    # Copy editorial file
    if os.path.exists(EDITORIAL_MD_PATH):
        new_editorial_path = f"{editorial_dir}/final_editorial_content.md"
        shutil.copy2(EDITORIAL_MD_PATH, new_editorial_path)
        saved_files['editorial_path'] = new_editorial_path

    # Copy explanatory file
    if os.path.exists(EXPLANATORY_MD_PATH):
        new_explanatory_path = f"{explanatory_dir}/final_explanatory_article.md"
        shutil.copy2(EXPLANATORY_MD_PATH, new_explanatory_path)
        saved_files['explanatory_path'] = new_explanatory_path

    # Copy glossary file
    if os.path.exists(GLOSSARY_MD_PATH):
        new_glossary_path = f"{glossary_dir}/final_technical_glossary.md"
        shutil.copy2(GLOSSARY_MD_PATH, new_glossary_path)
        saved_files['glossary_path'] = new_glossary_path

    # Copy intermediate files
    intermediate_files = []
    if os.path.exists(INTERMEDIATE_DIR):
        for fname in os.listdir(INTERMEDIATE_DIR):
            fpath = os.path.join(INTERMEDIATE_DIR, fname)
            if os.path.isfile(fpath):
                new_fpath = f"{intermediate_dir}/{fname}"
                shutil.copy2(fpath, new_fpath)
                intermediate_files.append(new_fpath)

    saved_files['intermediate_files'] = '|'.join(intermediate_files)
    return saved_files

def google_suggestions(query: str):
    """Fetch Google search suggestions for a given query string.

    Args:
        query (str): The search query string.

    Returns:
        list: A list of suggestion strings from Google, or an empty list if none found or on error.
    """
    if not query:
        return []
    try:
        url = f"https://suggestqueries.google.com/complete/search?client=firefox&q={query}"
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()[1]
    except Exception as e:
        print(f"Suggestion fetch error: {e}")
    return []

# -------------- Streamlit UI ---------------

st.set_page_config(page_title="AI News Summarizer", layout="centered")
st.title("📰 AI News Summarizer")
st.write("Enter a topic and let a team of autonomous agents generate editorial, explanatory, and glossary content!")

# Replacing st_searchbox with text input + suggestions
query = st.text_input("Enter a topic to summarize")
suggestions = google_suggestions(query) if query else []

if suggestions:
    topic = st.selectbox("Suggestions (optional):", suggestions, index=0)
else:
    topic = query

if st.button("Run Summarization Crew") and topic:
    st.info("🚀 Crew started...")
    with st.spinner("Working..."):
        try:
            result = NewsSummarizationCrew().crew().kickoff(inputs={"topic": topic})

            # Save files with timestamp and get their paths
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            saved_files = save_files_with_timestamp(timestamp)

            insert_history(
                topic,
                saved_files.get('editorial_path'),
                saved_files.get('explanatory_path'),
                saved_files.get('glossary_path'),
                saved_files.get('intermediate_files')
            )

            st.success("✅ Crew completed successfully!")
        except Exception as e:
            st.error(f"An error occurred: {e}")


st.markdown("---")
tabs = st.tabs(["Editorial Content", "Explanatory Article", "Technical Glossary", "History"])

# -------- Editorial tab
with tabs[0]:
    st.subheader("📝 Editorial Content")
    if os.path.exists(EDITORIAL_MD_PATH):
        with open(EDITORIAL_MD_PATH, encoding="utf-8") as f:
            st.markdown(f.read(), unsafe_allow_html=True)
    else:
        st.info("Editorial content will appear here after generation.")

# -------- Explanatory tab
with tabs[1]:
    st.subheader("📚 Explanatory Article")
    if os.path.exists(EXPLANATORY_MD_PATH):
        with open(EXPLANATORY_MD_PATH, encoding="utf-8") as f:
            st.markdown(f.read(), unsafe_allow_html=True)
    else:
        st.info("Explanatory article will appear here after generation.")

# -------- Glossary tab
with tabs[2]:
    st.subheader("📖 Technical Glossary")
    if os.path.exists(GLOSSARY_MD_PATH):
        with open(GLOSSARY_MD_PATH, encoding="utf-8") as f:
            st.markdown(f.read(), unsafe_allow_html=True)
    else:
        st.info("Technical glossary will appear here after generation.")

# -------- History tab
with tabs[3]:
    st.subheader("📜 History")
    rows = fetch_history()
    if not rows:
        st.info("No history found.")
    else:
        for row in rows:
            id, topic, timestamp, editorial_path, explanatory_path, glossary_path, intermediate_files = row
            with st.expander(f"📋 {topic} - {timestamp}", expanded=False):
                st.markdown(f"**Topic:** {topic}")
                st.markdown(f"**Timestamp:** {timestamp}")

                st.markdown("### 📄 Final Files")
                if editorial_path and os.path.exists(editorial_path):
                    with st.expander("📝 Editorial Content"):
                        with open(editorial_path, encoding="utf-8") as f:
                            editorial_content = f.read()
                            st.markdown(editorial_content, unsafe_allow_html=True)
                            st.download_button(
                                label="Download Editorial Content",
                                data=editorial_content,
                                file_name=os.path.basename(editorial_path),
                                mime="text/markdown",
                                key=f"download_editorial_{id}"
                            )
                if explanatory_path and os.path.exists(explanatory_path):
                    with st.expander("📚 Explanatory Article"):
                        with open(explanatory_path, encoding="utf-8") as f:
                            explanatory_content = f.read()
                            st.markdown(explanatory_content, unsafe_allow_html=True)
                            st.download_button(
                                label="Download Explanatory Article",
                                data=explanatory_content,
                                file_name=os.path.basename(explanatory_path),
                                mime="text/markdown",
                                key=f"download_explanatory_{id}"
                            )
                if glossary_path and os.path.exists(glossary_path):
                    with st.expander("📖 Technical Glossary"):
                        with open(glossary_path, encoding="utf-8") as f:
                            glossary_content = f.read()
                            st.markdown(glossary_content, unsafe_allow_html=True)
                            st.download_button(
                                label="Download Technical Glossary",
                                data=glossary_content,
                                file_name=os.path.basename(glossary_path),
                                mime="text/markdown",
                                key=f"download_glossary_{id}"
                            )

                st.markdown("### 🔧 Intermediate Files")
                if intermediate_files:
                    for fpath in intermediate_files.split("|"):
                        if fpath and os.path.exists(fpath):
                            fname = os.path.basename(fpath)
                            with st.expander(fname):
                                with open(fpath, encoding="utf-8") as f:
                                    file_content = f.read()
                                    st.markdown(file_content, unsafe_allow_html=True)
                                    st.download_button(
                                        label=f"Download {fname}",
                                        data=file_content,
                                        file_name=fname,
                                        mime="text/markdown",
                                        key=f"download_intermediate_{id}_{fname}"
                                    )

                st.markdown("---")
