import os
import requests
from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
from datetime import datetime, timedelta

class MediaStackToolInput(BaseModel):
    """Input schema for MediaStackTool. Defines the expected input for querying news articles, specifically the search query string."""
    query: str = Field(..., description="The search query for news articles.")

class MediaStackTool(BaseTool):
    """Tool for searching news articles using the MediaStack API. Returns recent news articles with relevant metadata and summaries."""
    name: str = "MediaStack News API Tool"
    description: str = (
        "Search for news articles using MediaStack API. "
        "Returns articles with title, source, publication date, and summary from the last 3 days. "
        "IMPORTANT: Only returns recent news articles."
    )
    args_schema: Type[BaseModel] = MediaStackToolInput

    def _run(self, query: str) -> str:
        """Search for news articles using the MediaStack API based on the provided query string.
        Returns a formatted string with article details or an error message if the request fails or no articles are found.
        Args:
            query (str): The search query for news articles.
        Returns:
            str: Formatted results or error message.
        """
        api_key = os.getenv("MEDIASTACK_API_KEY")
        if not api_key:
            return "Error: MEDIASTACK_API_KEY not found in environment variables."

        try:
            # MediaStack API endpoint
            url = "http://api.mediastack.com/v1/news"

            # Calculate date range for last 3 days from today
            today = datetime.utcnow().date()
            from_date = (today - timedelta(days=3)).strftime("%Y-%m-%d")
            to_date = today.strftime("%Y-%m-%d")

            params = {
                "access_key": api_key,
                "keywords": f"{query} recent",
                "languages": "en",
                "limit": 10,
                "date": f"{from_date},{to_date}",
                "sort": "published_desc"
            }

            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()

            data = response.json()

            if data.get("error"):
                return f"Error: {data.get('error', {}).get('info', 'Unknown error from MediaStack')}"

            articles = data.get("data", [])

            if not articles:
                return f"No articles found for '{query}' in the last 3 days ({from_date} to {to_date})."

            # Format the results
            formatted_articles = []
            formatted_articles.append(f"**MediaStack Results for '{query}' (Last 3 days: {from_date} to {to_date}):**\n")

            for i, article in enumerate(articles[:8], 1):
                title = article.get("title", "No title")
                source = article.get("source", "Unknown source")
                pub_date = article.get("published_at", "Unknown date")
                description = article.get("description", "No description available")
                url = article.get("url", "")

                # Create a 2-sentence summary
                if description and len(description) > 150:
                    summary = description[:150] + "..."
                else:
                    summary = description or "No summary available"

                formatted_article = f"{i}. **Title:** {title}\n   **Source:** {source}\n   **Publication Date:** {pub_date}\n   **Summary:** {summary}\n   **URL:** {url}\n"
                formatted_articles.append(formatted_article)

            return "\n".join(formatted_articles)

        except requests.exceptions.RequestException as e:
            return f"Error making request to MediaStack: {str(e)}"
        except Exception as e:
            return f"Error processing MediaStack response: {str(e)}"