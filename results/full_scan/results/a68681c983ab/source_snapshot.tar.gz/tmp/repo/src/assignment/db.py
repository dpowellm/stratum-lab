import sqlite3
from pathlib import Path

DB_PATH = "db/chroma.sqlite3"

def init_db():
    """Create the 'history' table in the database if it does not exist. Ensures the 'db' directory exists."""
    Path("db").mkdir(exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                topic TEXT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                editorial_path TEXT,
                explanatory_path TEXT,
                glossary_path TEXT,
                intermediate_files TEXT
            )
        """)
        conn.commit()

def insert_history(topic, editorial_path, explanatory_path, glossary_path, intermediate_files):
    """
    Insert a new record into the 'history' table.

    Args:
        topic (str): The topic of the news summary.
        editorial_path (str): Path to the editorial content file.
        explanatory_path (str): Path to the explanatory article file.
        glossary_path (str): Path to the technical glossary file.
        intermediate_files (str): Paths to intermediate files (comma-separated or JSON string).
    """
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO history (topic, editorial_path, explanatory_path, glossary_path, intermediate_files)
            VALUES (?, ?, ?, ?, ?)
        """, (
            topic,
            editorial_path,
            explanatory_path,
            glossary_path,
            intermediate_files
        ))
        conn.commit()

def fetch_history():
    """
    Fetch all records from the 'history' table, ordered by most recent timestamp first.

    Returns:
        list: List of tuples containing (id, topic, timestamp, editorial_path, explanatory_path, glossary_path, intermediate_files).
    """
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, topic, timestamp, editorial_path, explanatory_path, glossary_path, intermediate_files
            FROM history ORDER BY timestamp DESC
        """)
        return cursor.fetchall()
