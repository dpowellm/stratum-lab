# -------------------------------------------------------------------------------------------
#  Copyright (c) 2024.  SupportVectors AI Lab
#
#  This code is part of the training material, and therefore part of the intellectual property.
#  It may not be reused or shared without the explicit, written permission of SupportVectors.
#
#  Use is limited to the duration and purpose of the training at SupportVectors.
#
#  Author: SupportVectors AI Training
# -------------------------------------------------------------------------------------------



from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task
from crewai.agents.agent_builder.base_agent import BaseAgent
from typing import List




from assignment.tools.newsapi_tool import NewsAPITool
from assignment.tools.news_data_tool import NewsDataTool
from assignment.tools.mediastack_tool import MediaStackTool


from crewai_tools import SerperDevTool
web_search_tool = SerperDevTool()


@CrewBase
class NewsSummarizationCrew:
    """
    Agentic Crew for Automated News Summarization.

    This class defines the agents and tasks involved in the news summarization pipeline, including searching, validating, analyzing, and generating editorial, explanatory, and glossary content from news sources.

    Attributes:
        agents (List[BaseAgent]): List of agent definitions for the crew.
        tasks (List[Task]): List of task definitions for the crew.
    """

    agents: List[BaseAgent]
    tasks: List[Task]

    @agent
    def coordinator(self) -> Agent:
        """
        Returns the coordinator agent responsible for managing and delegating tasks within the crew.

        Returns:
            Agent: The coordinator agent instance.
        """
        return Agent(
            config=self.agents_config['coordinator'],  # type: ignore
            allow_delegation=True,
            verbose=True,
            memory = True,
            llm = LLM(model="gpt-4o")
        )

    @agent
    def search_agent_serper(self) -> Agent:
        """
        Returns the search agent that uses the SerperDevTool for web-based news searches.

        Returns:
            Agent: The search agent instance using SerperDevTool.
        """
        return Agent(
            config=self.agents_config['search_agent_serper'],  # type: ignore
            tools=[web_search_tool],
            verbose=True,
        )

    @agent
    def newsapi_agent(self) -> Agent:
        """
        Returns the agent that interacts with the NewsAPI tool to fetch news articles.

        Returns:
            Agent: The agent instance using NewsAPITool.
        """
        return Agent(
            config=self.agents_config['newsapi_agent'], # type: ignore[index]
            tools=[NewsAPITool()],
            verbose=True,
        )

    @agent
    def newsdata_agent(self) -> Agent:
        """
        Returns the agent that interacts with the NewsData tool to fetch news articles.

        Returns:
            Agent: The agent instance using NewsDataTool.
        """
        return Agent(
            config=self.agents_config['newsdata_agent'], # type: ignore[index]
            tools=[NewsDataTool()],
            verbose=True,
        )

    @agent
    def mediastack_agent(self) -> Agent:
        """
        Returns the agent that interacts with the MediaStack tool to fetch news articles.

        Returns:
            Agent: The agent instance using MediaStackTool.
        """
        return Agent(
            config=self.agents_config['mediastack_agent'],
            tools=[MediaStackTool()],
            verbose=True,
        )

    @agent
    def validator(self) -> Agent:
        """
        Returns the validator agent responsible for fact-checking and validating news content.

        Returns:
            Agent: The validator agent instance.
        """
        return Agent(
            config=self.agents_config['validator'],  # type: ignore
            verbose=True,
        )

    @agent
    def analyst(self) -> Agent:
        """
        Returns the analyst agent responsible for analyzing validated news content.

        Returns:
            Agent: The analyst agent instance.
        """
        return Agent(
            config=self.agents_config['analyst'],  # type: ignore
            verbose=True,
        )

    
    @agent
    def editorial_content_generator(self) -> Agent:
        """
        Returns the agent responsible for generating editorial content from analyzed news.

        Returns:
            Agent: The editorial content generator agent instance.
        """
        return Agent(
            config=self.agents_config['editorial_content_generator'],
            verbose=True,
        )

    @agent
    def explanatory_article_generator(self) -> Agent:
        """
        Returns the agent responsible for generating explanatory articles from analyzed news.

        Returns:
            Agent: The explanatory article generator agent instance.
        """
        return Agent(
            config=self.agents_config['explanatory_article_generator'],
            verbose=True,
        )

    @agent
    def technical_glossary_generator(self) -> Agent:
        """
        Returns the agent responsible for generating a technical glossary from analyzed news.

        Returns:
            Agent: The technical glossary generator agent instance.
        """
        return Agent(
            config=self.agents_config['technical_glossary_generator'],
            verbose=True,
        )

    @agent
    def senior_editor(self) -> Agent:
        """
        Returns the senior editor agent responsible for reviewing and editing generated content.

        Returns:
            Agent: The senior editor agent instance.
        """
        return Agent(
            config=self.agents_config['senior_editor'],  # type: ignore
            verbose=True,
        )



    @task
    def orchestrate_pipeline_task(self) -> Task:
        """
        Returns the main orchestration task that manages the overall news summarization pipeline.

        Returns:
            Task: The orchestration pipeline task instance.
        """
        return Task(
            config=self.tasks_config['orchestrate_pipeline_task'],
            output_file="output/metadata/orchestration_log.md"
        )

    @task
    def search_news_task(self) -> Task:
        """
        Returns the task for searching news articles using the SerperDevTool.

        Returns:
            Task: The search news task instance for SerperDevTool.
        """
        return Task(
            config=self.tasks_config['search_news_task'],
            output_file="output/metadata/articles_list_serper.md"
        )

    @task
    def search_newsapi_task(self) -> Task:
        """
        Returns the task for searching news articles using the NewsAPI tool.

        Returns:
            Task: The search news task instance for NewsAPI.
        """
        return Task(
            config=self.tasks_config['search_newsapi_task'], # type: ignore[index]
            output_file="output/metadata/articles_list_newsapi.md"
        )

    @task
    def search_newsdata_task(self) -> Task:
        """
        Returns the task for searching news articles using the NewsData tool.

        Returns:
            Task: The search news task instance for NewsData.
        """
        return Task(
            config=self.tasks_config['search_newsdata_task'], # type: ignore[index]
            output_file="output/metadata/articles_list_newsdata.md"
        )

    @task
    def search_mediastack_task(self) -> Task:
        """
        Returns the task for searching news articles using the MediaStack tool.

        Returns:
            Task: The search news task instance for MediaStack.
        """
        return Task(
            config=self.tasks_config['search_mediastack_task'],
            output_file='output/metadata/articles_list_mediastack.md'
        )

    @task
    def validate_news_task(self) -> Task:
        """
        Returns the task for validating and fact-checking news articles from all sources.

        Returns:
            Task: The validate news task instance.
        """
        return Task(
            config=self.tasks_config['validate_news_task'],
            context=[self.search_news_task(), self.search_newsapi_task(), self.search_newsdata_task(), self.search_mediastack_task()],
            output_file="output/metadata/validated_facts.md"
        )


    @task
    def analyze_content_task(self) -> Task:
        """
        Returns the task for analyzing validated news content.

        Returns:
            Task: The analyze content task instance.
        """
        return Task(
            config=self.tasks_config['analyze_content_task'],
            context=[self.validate_news_task()],
            output_file="output/metadata/analysis.md"
        )

    @task
    def generate_editorial_content_task(self) -> Task:
        """
        Returns the task for generating editorial content from analyzed news.

        Returns:
            Task: The generate editorial content task instance.
        """
        return Task(
            config=self.tasks_config['generate_editorial_content_task'],
            context=[self.analyze_content_task()],
            output_file="output/metadata/editorial_content.md"
        )

    @task
    def generate_explanatory_article_task(self) -> Task:
        """
        Returns the task for generating explanatory articles from analyzed news.

        Returns:
            Task: The generate explanatory article task instance.
        """
        return Task(
            config=self.tasks_config['generate_explanatory_article_task'],
            context=[self.analyze_content_task()],
            output_file="output/metadata/explanatory_article.md"
        )

    @task
    def generate_technical_glossary_task(self) -> Task:
        """
        Returns the task for generating a technical glossary from analyzed news.

        Returns:
            Task: The generate technical glossary task instance.
        """
        return Task(
            config=self.tasks_config['generate_technical_glossary_task'],
            context=[self.analyze_content_task()],
            output_file="output/metadata/technical_glossary.md"
        )

    @task
    def edit_editorial_content_task(self) -> Task:
        """
        Returns the task for editing and finalizing the editorial content.

        Returns:
            Task: The edit editorial content task instance.
        """
        return Task(
            config=self.tasks_config['edit_summary_task'],
            context=[self.generate_editorial_content_task()],
            output_file="output/editorial/final_editorial_content.md"
        )

    @task
    def edit_explanatory_article_task(self) -> Task:
        """
        Returns the task for editing and finalizing the explanatory article.

        Returns:
            Task: The edit explanatory article task instance.
        """
        return Task(
            config=self.tasks_config['edit_summary_task'],
            context=[self.generate_explanatory_article_task()],
            output_file="output/explanatory/final_explanatory_article.md"
        )

    @task
    def edit_technical_glossary_task(self) -> Task:
        """
        Returns the task for editing and finalizing the technical glossary.

        Returns:
            Task: The edit technical glossary task instance.
        """
        return Task(
            config=self.tasks_config['edit_summary_task'],
            context=[self.generate_technical_glossary_task()],
            output_file="output/glossary/final_technical_glossary.md"
        )

    @crew
    def crew(self) -> Crew:
        """
        Returns the assembled Crew object, containing all agents and tasks, ready to execute the news summarization pipeline.

        Returns:
            Crew: The assembled Crew object for the news summarization pipeline.
        """
        return Crew(
            agents=[
                self.search_agent_serper(),
                self.newsapi_agent(),
                self.newsdata_agent(),
                self.mediastack_agent(),
                self.validator(),
                self.analyst(),
                self.editorial_content_generator(),
                self.explanatory_article_generator(),
                self.technical_glossary_generator(),
                self.senior_editor()
            ],
            tasks=self.tasks,
            process=Process.hierarchical,
            manager_agent=self.coordinator(),
            verbose=True
        )