import os
import requests
from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field

class NewsDataToolInput(BaseModel):
    """Input schema for NewsDataTool. Defines the expected input for querying news articles, specifically the search query string."""
    query: str = Field(..., description="The search query for news articles.")

class NewsDataTool(BaseTool):
    """Tool for searching news articles using the NewsData.io API. Returns articles with relevant metadata and summaries based on a search query."""
    name: str = "NewsData.io Search Tool"
    description: str = (
        "Search for news articles using NewsData.io API. "
        "Returns articles with title, source, publication date, and summary."
    )
    args_schema: Type[BaseModel] = NewsDataToolInput

    def _run(self, query: str) -> str:
        """Search for news articles using the NewsData.io API based on the provided query string.
        Returns a formatted string with article details or an error message if the request fails or no articles are found.
        Args:
            query (str): The search query for news articles.
        Returns:
            str: Formatted results or error message.
        """
        api_key = os.getenv("NEWSDATA_API_KEY")
        if not api_key:
            return "Error: NEWSDATA_API_KEY not found in environment variables."

        try:
            # NewsData.io API endpoint
            url = "https://newsdata.io/api/1/news"
            params = {
                "apikey": api_key,
                "q": query,
                "language": "en",
                "size": 8  # Limit to 8 articles
            }

            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()

            data = response.json()

            if data.get("status") != "success":
                return f"Error: {data.get('message', 'Unknown error from NewsData.io')}"

            articles = data.get("results", [])

            if not articles:
                return "No articles found for the given query."

            # Format the results
            formatted_articles = []
            for article in articles:
                title = article.get("title", "No title")
                source = article.get("source_id", "Unknown source")
                pub_date = article.get("pubDate", "Unknown date")
                description = article.get("description", "No description available")

                # Create a 2-sentence summary
                summary = description[:200] + "..." if len(description) > 200 else description

                formatted_article = f"""
**Title:** {title}
**Source:** {source}
**Publication Date:** {pub_date}
**Summary:** {summary}
"""
                formatted_articles.append(formatted_article)

            return f"Found {len(formatted_articles)} articles from NewsData.io:\n\n" + "\n".join(formatted_articles)

        except requests.exceptions.RequestException as e:
            return f"Error making request to NewsData.io: {str(e)}"
        except Exception as e:
            return f"Error processing NewsData.io response: {str(e)}"