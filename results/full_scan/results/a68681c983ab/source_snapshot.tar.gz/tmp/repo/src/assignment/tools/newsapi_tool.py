from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
import os
import requests


class MyCustomToolInput(BaseModel):
    """Input schema for MyCustomTool. Defines the expected input for the custom tool, specifically the argument string."""
    argument: str = Field(..., description="Description of the argument.")

class MyCustomTool(BaseTool):
    """Example custom tool template. Replace with your own tool logic and description."""
    name: str = "Name of my tool"
    description: str = (
        "Clear description for what this tool is useful for, your agent will need this information to use it."
    )
    args_schema: Type[BaseModel] = MyCustomToolInput

    def _run(self, argument: str) -> str:
        """Run the custom tool with the provided argument. Returns a placeholder output string."""
        # Implementation goes here
        return "this is an example of a tool output, ignore it and move along."

# --- NewsAPI Tool ---
class NewsAPIToolInput(BaseModel):
    """Input schema for NewsAPITool. Defines the expected input for querying news articles, specifically the search query string."""
    query: str = Field(..., description="The topic or keywords to search for in news articles.")

class NewsAPITool(BaseTool):
    """Tool for fetching news articles from NewsAPI.org. Returns a list of articles with relevant metadata and summaries based on a search query."""
    name: str = "NewsAPI.org Article Fetcher"
    description: str = (
        "Fetches news articles from NewsAPI.org for a given query/topic. Returns a list of articles with title, source, publication date, and a 2-sentence summary per article."
    )
    args_schema: Type[BaseModel] = NewsAPIToolInput

    def _run(self, query: str) -> str:
        """Fetch news articles from NewsAPI.org based on the provided query string.
        Returns a formatted string with article details or an error message if the request fails or no articles are found.
        Args:
            query (str): The search query for news articles.
        Returns:
            str: Formatted results or error message.
        """
        api_key = os.getenv("NEWSAPI_API_KEY")
        if not api_key:
            return "NewsAPI API key not set. Please set NEWSAPI_API_KEY in your environment."
        url = "https://newsapi.org/v2/everything"
        params = {
            "q": query,
            "language": "en",
            "sortBy": "publishedAt",
            "pageSize": 8,
            "apiKey": api_key
        }
        response = requests.get(url, params=params)
        if response.status_code != 200:
            return f"NewsAPI request failed: {response.status_code} {response.text}"
        data = response.json()
        articles = data.get("articles", [])
        results = []
        for article in articles:
            title = article.get("title", "")
            source = article.get("source", {}).get("name", "")
            published_at = article.get("publishedAt", "")
            description = article.get("description", "")
            summary = description if description else "No summary available."
            results.append(f"- Title: {title}\n  Source: {source}\n  Date: {published_at}\n  Summary: {summary}")
        return "\n\n".join(results) if results else "No articles found."

# --- NewsData Tool ---
class NewsDataToolInput(BaseModel):
    """Input schema for NewsDataTool. Defines the expected input for querying news articles, specifically the search query string."""
    query: str = Field(..., description="The search query for news articles.")

class NewsDataTool(BaseTool):
    """Tool for searching news articles using the NewsData.io API. Returns articles with relevant metadata and summaries based on a search query."""
    name: str = "NewsData.io Search Tool"
    description: str = (
        "Search for news articles using NewsData.io API. "
        "Returns articles with title, source, publication date, and summary."
    )
    args_schema: Type[BaseModel] = NewsDataToolInput

    def _run(self, query: str) -> str:
        """Search for news articles using the NewsData.io API based on the provided query string.
        Returns a formatted string with article details or an error message if the request fails or no articles are found.
        Args:
            query (str): The search query for news articles.
        Returns:
            str: Formatted results or error message.
        """
        api_key = os.getenv("NEWSDATA_API_KEY")
        if not api_key:
            return "Error: NEWSDATA_API_KEY not found in environment variables."

        try:
            # NewsData.io API endpoint
            url = "https://newsdata.io/api/1/news"
            params = {
                "apikey": api_key,
                "q": query,
                "language": "en",
                "size": 8  # Limit to 8 articles
            }

            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()

            data = response.json()

            if data.get("status") != "success":
                return f"Error: {data.get('message', 'Unknown error from NewsData.io')}"

            articles = data.get("results", [])

            if not articles:
                return "No articles found for the given query."

            # Format the results
            formatted_articles = []
            for article in articles:
                title = article.get("title", "No title")
                source = article.get("source_id", "Unknown source")
                pub_date = article.get("pubDate", "Unknown date")
                description = article.get("description", "No description available")

                # Create a 2-sentence summary
                summary = description[:200] + "..." if len(description) > 200 else description

                formatted_article = f"""
**Title:** {title}
**Source:** {source}
**Publication Date:** {pub_date}
**Summary:** {summary}
"""
                formatted_articles.append(formatted_article)

            return f"Found {len(formatted_articles)} articles from NewsData.io:\n\n" + "\n".join(formatted_articles)

        except requests.exceptions.RequestException as e:
            return f"Error making request to NewsData.io: {str(e)}"
        except Exception as e:
            return f"Error processing NewsData.io response: {str(e)}"
