import matplotlib.pyplot as plt
import numpy as np

# Data for visualization
issue_types = ['API Issue', 'Login Issue', 'Report Generation', 'Data Import', 
               'Feature Request', 'Billing Issue', 'UI Bug']
ticket_volume = [8, 8, 5, 15, 7, 12, 7]
avg_resolution_time = [680.88, 649.25, 272.40, 612.73, 682.14, 510.92, 478.71]
avg_satisfaction_score = [3.88, 3.62, 2.60, 3.00, 2.85, 2.25, 3.14]

# Create figure and axes with constrained layout
fig, axs = plt.subplots(3, 1, figsize=(10, 15), constrained_layout=True)

# Custom colors for better visual distinction
colors = ['#1f77b4', '#ff7f0e', '#2ca02c']

# Chart 1: Ticket Volume by Category
axs[0].barh(issue_types, ticket_volume, color=colors[0])
axs[0].set_title('Ticket Volume by Category', pad=20, fontweight='bold')
axs[0].set_xlabel('Number of Tickets', labelpad=10)
axs[0].set_ylabel('Issue Type', labelpad=10)
axs[0].set_xlim(0, max(ticket_volume) + 5)
# Add value labels
for i, v in enumerate(ticket_volume):
    axs[0].text(v + 0.5, i, str(v), color='black', va='center')

# Chart 2: Average Resolution Time by Issue Type
axs[1].barh(issue_types, avg_resolution_time, color=colors[1])
axs[1].set_title('Average Resolution Time by Issue Type (Minutes)', pad=20, fontweight='bold')
axs[1].set_xlabel('Average Resolution Time (Minutes)', labelpad=10)
axs[1].set_ylabel('Issue Type', labelpad=10)
axs[1].set_xlim(0, max(avg_resolution_time) + 100)
# Add value labels
for i, v in enumerate(avg_resolution_time):
    axs[1].text(v + 20, i, f"{v:.1f}", color='black', va='center')

# Chart 3: Customer Satisfaction Scores by Issue Type
axs[2].barh(issue_types, avg_satisfaction_score, color=colors[2])
axs[2].set_title('Customer Satisfaction Scores by Issue Type', pad=20, fontweight='bold')
axs[2].set_xlabel('Average Satisfaction Score (1-5)', labelpad=10)
axs[2].set_ylabel('Issue Type', labelpad=10)
axs[2].set_xlim(0, 5)
# Add value labels
for i, v in enumerate(avg_satisfaction_score):
    axs[2].text(v + 0.1, i, f"{v:.2f}", color='black', va='center')

# Add overall title
fig.suptitle('Support Ticket Analysis', y=1.02, fontsize=16, fontweight='bold')

# Remove plt.tight_layout() since we're using constrained_layout
plt.show()