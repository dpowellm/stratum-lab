import os
import warnings
import pandas as pd
from typing import List
from pydantic import BaseModel, Field
from crewai import Agent, Task, Crew
from IPython.display import display, Markdown

# Suppress warnings
warnings.filterwarnings('ignore')

# Set model
os.environ['OPENAI_MODEL_NAME'] = 'gpt-4o-mini'

# Structured output model
class TaskEstimate(BaseModel):
    task_name: str = Field(..., description="Name of the task")
    estimated_time_hours: float = Field(..., description="Estimated time to complete the task in hours")
    required_resources: List[str] = Field(..., description="List of resources required to complete the task")

class Milestone(BaseModel):
    milestone_name: str = Field(..., description="Name of the milestone")
    tasks: List[str] = Field(..., description="List of task IDs associated with this milestone")

class ProjectPlan(BaseModel):
    tasks: List[TaskEstimate]
    milestones: List[Milestone]

# Define Agents
project_planning_agent = Agent(
    role="Project Planning Agent",
    goal="Break down the project into manageable tasks",
    backstory="Expert in decomposing large projects into actionable steps",
    verbose=True
)

estimation_agent = Agent(
    role="Estimation Agent",
    goal="Estimate time and resources for tasks",
    backstory="Skilled in effort estimation and resource planning",
    verbose=True
)

resource_allocation_agent = Agent(
    role="Resource Allocation Agent",
    goal="Create milestones and allocate team resources",
    backstory="Organizes projects efficiently based on team capabilities",
    verbose=True
)

# Define Tasks
task_breakdown = Task(
    description="Break down the project into smaller, actionable tasks",
    expected_output="A list of task names with short descriptions",
    agent=project_planning_agent
)

time_resource_estimation = Task(
    description="Estimate time and resources needed for each task",
    expected_output="A list of tasks with time estimates and needed resources",
    agent=estimation_agent
)

resource_allocation = Task(
    description="Group tasks into milestones and allocate team resources accordingly",
    expected_output="A project plan with task estimates and milestones",
    agent=resource_allocation_agent,
    output_pydantic=ProjectPlan
)

# Define Crew
crew = Crew(
    agents=[project_planning_agent, estimation_agent, resource_allocation_agent],
    tasks=[task_breakdown, time_resource_estimation, resource_allocation],
    verbose=True
)

# Define Project Inputs
project = "Website"
industry = "Technology"
project_objectives = "Create a website for a small business"
team_members = """
- John Doe (Project Manager)
- Jane Doe (Software Engineer)
- Bob Smith (Designer)
- Alice Johnson (QA Engineer)
- Tom Brown (QA Engineer)
"""
project_requirements = """
- Responsive design for desktop and mobile
- Modern, clean UI
- Intuitive navigation menu
- About Us, Services, Contact pages
- Blog section for updates
- SEO optimization
- Social media integration
- Testimonials section
"""

# Display Project Info
display(Markdown(f"""
### 🚀 Project Overview
**Type:** {project}  
**Industry:** {industry}  
**Objectives:** {project_objectives}  

**Team Members:**  
{team_members}  

**Requirements:**  
{project_requirements}
"""))

# Run the Crew
inputs = {
    'project_type': project,
    'project_objectives': project_objectives,
    'industry': industry,
    'team_members': team_members,
    'project_requirements': project_requirements
}
result = crew.kickoff(inputs=inputs)

# Calculate and print cost
costs = 0.150 * (crew.usage_metrics.prompt_tokens + crew.usage_metrics.completion_tokens) / 1_000_000
print(f"\n💰 Total Cost: ${costs:.4f}")

# Display usage
df_usage_metrics = pd.DataFrame([crew.usage_metrics.dict()])
display(df_usage_metrics)

# Display tasks
df_tasks = pd.DataFrame(result.pydantic.dict()['tasks'])
display(df_tasks.style.set_table_attributes('border="1"').set_caption("📋 Task Breakdown"))

# Display milestones
df_milestones = pd.DataFrame(result.pydantic.dict()['milestones'])
display(df_milestones.style.set_table_attributes('border="1"').set_caption("🎯 Milestones"))
