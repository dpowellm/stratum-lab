# Warning control
import warnings
warnings.filterwarnings('ignore')

# Load environment variables
import os
from dotenv import load_dotenv
load_dotenv()

from crewai import Agent, Task, Crew
from crewai_tools import FileReadTool

# Set the correct file path
csv_path = r'C:\Users\Acer\Desktop\AI_AGENT\Multi AI Agent Systems with crewAI\config\support_tickets_data.csv'

# Load CSV tool with error handling
try:
    csv_tool = FileReadTool(file_path=csv_path)
    print(f"Successfully loaded CSV file from: {csv_path}")
except Exception as e:
    print(f"Error loading CSV file: {e}")
    print("Creating sample data file...")
    
    try:
        import pandas as pd
        from datetime import datetime, timedelta
        import numpy as np
        
        # Generate realistic sample data
        np.random.seed(42)
        num_tickets = 50
        ticket_types = ['Technical', 'Account', 'Billing']
        priorities = ['Low', 'Medium', 'High']
        
        data = {
            'ticket_id': [f'TKT-{1000+i}' for i in range(num_tickets)],
            'created_date': [(datetime.now() - timedelta(days=np.random.randint(0, 30))).strftime('%Y-%m-%d') for _ in range(num_tickets)],
            'ticket_type': np.random.choice(ticket_types, num_tickets),
            'priority': np.random.choice(priorities, num_tickets, p=[0.5, 0.3, 0.2]),
            'status': np.random.choice(['Open', 'Resolved', 'Pending'], num_tickets),
            'resolution_time_hours': np.random.uniform(1, 24, num_tickets).round(1),
            'customer_satisfaction': np.random.randint(1, 6, num_tickets),
            'agent': [f'Agent-{chr(65+i%5)}' for i in range(num_tickets)]
        }
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        
        # Save sample data
        pd.DataFrame(data).to_csv(csv_path, index=False)
        csv_tool = FileReadTool(file_path=csv_path)
        print(f"Created sample data at: {csv_path}")
    except Exception as e:
        print(f"Failed to create sample data: {e}")
        raise

# Creating Agents
try:
    suggestion_generation_agent = Agent(
        role="Support Data Analyst",
        goal="Analyze support ticket data to generate improvement suggestions",
        backstory="""You are an expert at analyzing customer support data and identifying patterns
        that can lead to improved customer satisfaction and operational efficiency.""",
        tools=[csv_tool],
        verbose=True
    )

    reporting_agent = Agent(
        role="Report Generator",
        goal="Create comprehensive reports from data analysis",
        backstory="""You specialize in compiling data insights into clear, actionable reports
        that stakeholders can easily understand.""",
        tools=[csv_tool],
        verbose=True
    )

    chart_generation_agent = Agent(
        role="Data Visualizer",
        goal="Create visual representations of data insights",
        backstory="""You are skilled at transforming complex data into clear charts and graphs
        that make patterns immediately visible.""",
        allow_delegation=False,
        verbose=True
    )
except Exception as e:
    print(f"Error creating agents: {e}")
    raise

# Creating Tasks
try:
    suggestion_generation = Task(
        description="""Analyze the support ticket data to identify common issues, trends, and
        areas for improvement. Generate specific suggestions for how to improve support operations.""",
        expected_output="A list of 5-7 actionable suggestions for improving support operations based on the data.",
        agent=suggestion_generation_agent,
        output_file="suggestions.txt"
    )

    table_generation = Task(
        description="""Process the support ticket data and generate summary tables showing key metrics
        like ticket volume by category, resolution times, and customer satisfaction scores.""",
        expected_output="Markdown formatted tables summarizing key support metrics.",
        agent=reporting_agent,
        output_file="tables.md"
    )

    chart_generation = Task(
        description="""Create visual representations of the most important trends in the support data.
        Focus on the key metrics that would be most valuable to leadership.""",
        expected_output="Python code to generate charts (using matplotlib or similar) that visualize the key trends.",
        agent=chart_generation_agent,
        output_file="charts.py"
    )

    final_report_assembly = Task(
        description="""Compile all the analysis, tables, and charts into a final comprehensive report.
        The report should be well-organized and suitable for presentation to company leadership.""",
        expected_output="A complete markdown report with executive summary, key findings, and recommendations.",
        agent=reporting_agent,
        context=[suggestion_generation, table_generation, chart_generation],
        output_file="final_report.md"
    )
except Exception as e:
    print(f"Error creating tasks: {e}")
    raise

# Creating Crew
try:
    support_report_crew = Crew(
        agents=[
            suggestion_generation_agent,
            reporting_agent,
            chart_generation_agent
        ],
        tasks=[
            suggestion_generation,
            table_generation,
            chart_generation,
            final_report_assembly
        ],
        verbose=True
    )
except Exception as e:
    print(f"Error creating crew: {e}")
    raise

# Execute the crew and handle output
try:
    print("Starting crew execution...")
    result = support_report_crew.kickoff()
    
    # Display results
    from IPython.display import display, Markdown
    
    def display_result(crew_output):
        """Helper function to display crew output properly"""
        if hasattr(crew_output, 'raw') and crew_output.raw:
            display(Markdown(crew_output.raw))
        elif hasattr(crew_output, 'tasks_output'):
            for task_output in crew_output.tasks_output:
                if hasattr(task_output, 'raw') and task_output.raw:
                    display(Markdown(f"### {task_output.agent}"))
                    display(Markdown(task_output.raw))
        else:
            display(Markdown(str(crew_output)))
    
    display_result(result)
    
    # Save all outputs
    output_dir = r'C:\Users\Acer\Desktop\AI_AGENT\Multi AI Agent Systems with crewAI\outputs'
    os.makedirs(output_dir, exist_ok=True)
    
    def save_output(content, filename):
        """Save content to a file in the output directory"""
        path = os.path.join(output_dir, filename)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Saved output to: {path}")
    
    if hasattr(result, 'raw'):
        save_output(result.raw, 'full_report.md')
    
    if hasattr(result, 'tasks_output'):
        for task in result.tasks_output:
            if hasattr(task, 'raw') and hasattr(task, 'output_file'):
                save_output(task.raw, task.output_file)
    
    print("All outputs saved successfully!")
    
except Exception as e:
    print(f"Error during execution: {e}")
    raise

print("Process completed!")