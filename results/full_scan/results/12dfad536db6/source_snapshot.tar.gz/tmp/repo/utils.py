from dotenv import load_dotenv
import os

def get_openai_api_key():
    load_dotenv()
    return os.getenv("OPENAI_API_KEY")
def get_serper_api_key():
    load_dotenv()
    return os.getenv("get_serper_api_key")
def pretty_print_result(result):
    import json
    print(json.dumps(result, indent=2))