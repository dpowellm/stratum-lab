import os
from dotenv import load_dotenv
from crewai import Agent, Task, Crew

# Load environment variables
load_dotenv()

# Set up your API keys (example using OpenAI)
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")

# Define your agents
def create_researcher_agent():
    return Agent(
        role='Senior Research Analyst',
        goal='Uncover groundbreaking technologies in AI',
        backstory="""You're an expert in identifying emerging AI trends and technologies.
        Your research helps companies stay ahead of the curve.""",
        verbose=True,
        allow_delegation=False
    )

def create_writer_agent():
    return Agent(
        role='Technical Content Strategist',
        goal='Create compelling content about AI advancements',
        backstory="""You transform complex AI concepts into engaging narratives
        for technical audiences.""",
        verbose=True,
        allow_delegation=False
    )

def create_reviewer_agent():
    return Agent(
        role='Quality Assurance Specialist',
        goal='Ensure the highest quality of research and content',
        backstory="""You have an eye for detail and ensure all technical content
        meets the highest standards of accuracy and clarity.""",
        verbose=True,
        allow_delegation=False
    )

# Define your tasks
def create_research_task(agent, topic):
    return Task(
        description=f"""Conduct a comprehensive analysis of the latest advancements in {topic}.
        Identify key trends, breakthrough technologies, and potential industry impacts.
        Your final report should provide clear insights for business strategy.""",
        agent=agent,
        expected_output="A detailed research report with bullet points on key findings."
    )

def create_write_task(agent, research_data):
    return Task(
        description=f"""Using the following research data, create an engaging blog post:
        {research_data}
        The post should be technical yet accessible, with clear examples.""",
        agent=agent,
        expected_output="A well-structured blog post in markdown format."
    )

def create_review_task(agent, content):
    return Task(
        description=f"""Review this content for accuracy and clarity:
        {content}
        Provide detailed feedback and suggest improvements.""",
        agent=agent,
        expected_output="A markdown document with reviewed content and improvement suggestions."
    )

# Create and run your crew
def generate_ai_report(topic="Generative AI"):
    # Create agents
    researcher = create_researcher_agent()
    writer = create_writer_agent()
    reviewer = create_reviewer_agent()

    # Create tasks
    research_task = create_research_task(researcher, topic)
    write_task = create_write_task(writer, research_task)
    review_task = create_review_task(reviewer, write_task)

    # Form the crew
    crew = Crew(
        agents=[researcher, writer, reviewer],
        tasks=[research_task, write_task, review_task],
        verbose=True  # Changed from 2 to True
    )

    # Execute the workflow
    result = crew.kickoff()
    return result

if __name__ == "__main__":
    # Example usage
    report = generate_ai_report("Multi-Agent Systems")
    print("\n\nFinal Report:")
    print(report)