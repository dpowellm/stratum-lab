import os
import warnings
from dotenv import load_dotenv
import json
from datetime import datetime
from crewai import Agent, Task, Crew

# Configuration
load_dotenv()
warnings.filterwarnings('ignore')
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["OPENAI_MODEL_NAME"] = "gpt-4-turbo"

# Content Batch Processing Setup
CONTENT_BATCH = [
    {"topic": "AI in Healthcare", "target_audience": "medical professionals", "content_type": "comprehensive guide"},
    {"topic": "Sustainable Web Design", "target_audience": "web developers", "content_type": "tutorial"},
    {"topic": "Quantum Computing Basics", "target_audience": "tech enthusiasts", "content_type": "explainer"}
]

# Output Directory Setup
output_dir = f"content_output_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
os.makedirs(output_dir, exist_ok=True)

# Agents ======================================================================

strategist = Agent(
    role="Content Strategist",
    goal="Develop comprehensive content strategies for {topic} targeting {target_audience}",
    backstory=("With 10+ years in digital marketing, you create content frameworks "
               "that maximize engagement and conversions for specific audiences."),
    allow_delegation=False,
    verbose=True
)

researcher = Agent(
    role="Lead Researcher",
    goal="Find the most current and reliable information about {topic}",
    backstory=("As a former academic researcher, you know how to find trustworthy sources "
               "and extract key insights on any subject."),
    allow_delegation=False,
    verbose=True
)

writer = Agent(
    role="Senior Content Writer",
    goal="Write exceptional {content_type} about {topic} for {target_audience}",
    backstory=("An award-winning journalist turned content specialist, you adapt "
               "your writing style to different formats and audiences."),
    allow_delegation=False,
    verbose=True
)

seo_analyst = Agent(
    role="SEO Specialist",
    goal="Optimize content for search engines and readability",
    backstory=("You've spent years analyzing search algorithms and know exactly "
               "how to make content rank without sacrificing quality."),
    allow_delegation=False,
    verbose=True
)

quality_controller = Agent(
    role="Quality Assurance Editor",
    goal="Ensure all content meets our high standards",
    backstory=("As a former editor at major publications, you catch every error "
               "and improve clarity while preserving the author's voice."),
    allow_delegation=False,
    verbose=True
)

# Tasks ======================================================================

def create_strategy_task():
    return Task(
        description=(
            "Develop complete content strategy for: {topic}\n"
            "1. Identify 3-5 key angles/approaches\n"
            "2. Define primary and secondary keywords\n"
            "3. Outline content pillars\n"
            "4. Specify best content formats (blog, video, etc.)\n"
            "Target audience: {target_audience}"
        ),
        expected_output="Detailed strategy document in JSON format",
        agent=strategist,
        output_file="strategy.json"  # Added output file specification
    )

def create_research_task():
    return Task(
        description=(
            "Research topic: {topic}\n"
            "1. Find latest statistics and trends\n"
            "2. Identify authoritative sources\n"
            "3. Note common misconceptions\n"
            "4. Highlight audience pain points"
        ),
        expected_output="Comprehensive research report with sources",
        agent=researcher,
        output_file="research.md"
    )

def create_writing_task():
    return Task(
        description=(
            "Write 1500-word {content_type} about {topic}\n"
            "1. Use strategy and research materials\n"
            "2. Include engaging examples\n"
            "3. Add practical applications\n"
            "4. Tailor to {target_audience} audience"
        ),
        expected_output="Full-length article in markdown format",
        agent=writer,
        output_file="draft.md"
    )

def create_seo_task():
    return Task(
        description=(
            "Optimize content about {topic}\n"
            "1. Add semantic keywords\n"
            "2. Improve meta elements\n"
            "3. Enhance readability\n"
            "4. Check mobile-friendliness"
        ),
        expected_output="SEO-optimized version of the content",
        agent=seo_analyst,
        output_file="seo_optimized.md"
    )

def create_qa_task():
    return Task(
        description=(
            "Quality check for {topic} content\n"
            "1. Verify factual accuracy\n"
            "2. Check brand voice consistency\n"
            "3. Eliminate fluff\n"
            "4. Ensure logical flow"
        ),
        expected_output="Final approved content version",
        agent=quality_controller,
        output_file="final.md"
    )

# Content Pipeline ============================================================

def process_content_batch():
    results = []
    
    for index, topic_data in enumerate(CONTENT_BATCH, 1):
        print(f"\n🚀 Processing content #{index}: {topic_data['topic']}")
        
        # Create topic-specific directory
        topic_dir = f"{output_dir}/{topic_data['topic'].replace(' ', '_')}"
        os.makedirs(topic_dir, exist_ok=True)
        
        # Create tasks for this topic
        tasks = [
            create_strategy_task(),
            create_research_task(),
            create_writing_task(),
            create_seo_task(),
            create_qa_task()
        ]
        
        # Assemble crew
        content_crew = Crew(
            agents=[strategist, researcher, writer, seo_analyst, quality_controller],
            tasks=tasks,
            verbose=2
        )
        
        # Execute
        result = content_crew.kickoff(inputs=topic_data)
        
        # Save final output
        final_filename = f"{topic_dir}/final_output.md"
        with open(final_filename, 'w', encoding='utf-8') as f:
            content = result.output if hasattr(result, 'output') else str(result)
            f.write(content)
        
        results.append({
            "topic": topic_data['topic'],
            "file": final_filename,
            "word_count": len(content.split())
        })
    
    # Generate batch report
    report_path = f"{output_dir}/_batch_report.json"
    with open(report_path, 'w') as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "content_count": len(results),
            "total_words": sum(item['word_count'] for item in results),
            "details": results
        }, f, indent=2)
    
    return results, report_path

# Main Execution ==============================================================

if __name__ == "__main__":
    print(f"📦 Starting batch content creation for {len(CONTENT_BATCH)} topics")
    print(f"📂 Output directory: {output_dir}")
    
    try:
        batch_results, report_path = process_content_batch()
        print("\n✅ Batch content creation completed!")
        print(f"📝 Total articles created: {len(batch_results)}")
        print(f"📊 Total words generated: {sum(item['word_count'] for item in batch_results)}")
        print(f"🔍 Batch report saved to: {report_path}")
        
        # Print sample output path
        sample_output = batch_results[0]['file']
        print(f"\nSample output: file://{os.path.abspath(sample_output)}")
        
    except Exception as e:
        print(f"\n❌ Error occurred: {str(e)}")
        print("Possible solutions:")
        print("1. Verify your OpenAI API key in .env file")
        print("2. Check your internet connection")
        print("3. Ensure you have sufficient API credits")
        print("4. Try reducing the content length if hitting token limits")