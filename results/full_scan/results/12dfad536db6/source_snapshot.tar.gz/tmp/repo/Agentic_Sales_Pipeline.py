import os
import yaml
import warnings
import textwrap
import pandas as pd
from pydantic import BaseModel, Field
from typing import Optional, List
from IPython.display import IFrame, display, HTML

from crewai import Agent, Task, Crew, Flow
from crewai.flow.flow import listen, start
from crewai_tools import SerperDevTool, ScrapeWebsiteTool

# Suppress warnings
warnings.filterwarnings("ignore")

# Load environment variable
os.environ["OPENAI_MODEL_NAME"] = "gpt-4o-mini"

# Define structured Pydantic models
class LeadPersonalInfo(BaseModel):
    name: str = Field(..., description="The full name of the lead.")
    job_title: str = Field(..., description="The job title of the lead.")
    role_relevance: int = Field(..., ge=0, le=10)
    professional_background: Optional[str]

class CompanyInfo(BaseModel):
    company_name: str = Field(..., description="Name of the company.")
    industry: str
    company_size: int
    revenue: Optional[float]
    market_presence: int = Field(..., ge=0, le=10)

class LeadScore(BaseModel):
    score: int = Field(..., ge=0, le=100)
    scoring_criteria: List[str]
    validation_notes: Optional[str]

class LeadScoringResult(BaseModel):
    personal_info: LeadPersonalInfo
    company_info: CompanyInfo
    lead_score: LeadScore

# Load YAML config files
def load_yaml(path):
    with open(path, 'r') as f:
        return yaml.safe_load(f)

lead_agents_config = load_yaml('config/lead_qualification_agents.yaml')
lead_tasks_config = load_yaml('config/lead_qualification_tasks.yaml')
email_agents_config = load_yaml('config/email_engagement_agents.yaml')
email_tasks_config = load_yaml('config/email_engagement_tasks.yaml')

# Create Agents
lead_data_agent = Agent(config=lead_agents_config['lead_data_agent'], tools=[SerperDevTool(), ScrapeWebsiteTool()])
cultural_fit_agent = Agent(config=lead_agents_config['cultural_fit_agent'], tools=[SerperDevTool(), ScrapeWebsiteTool()])
scoring_validation_agent = Agent(config=lead_agents_config['scoring_validation_agent'], tools=[SerperDevTool(), ScrapeWebsiteTool()])

email_content_specialist = Agent(config=email_agents_config['email_content_specialist'])
engagement_strategist = Agent(config=email_agents_config['engagement_strategist'])

# Create Tasks
lead_data_task = Task(config=lead_tasks_config['lead_data_collection'], agent=lead_data_agent)
cultural_fit_task = Task(config=lead_tasks_config['cultural_fit_analysis'], agent=cultural_fit_agent)
scoring_validation_task = Task(
    config=lead_tasks_config['lead_scoring_and_validation'],
    agent=scoring_validation_agent,
    context=[lead_data_task, cultural_fit_task],
    output_pydantic=LeadScoringResult
)

email_drafting = Task(config=email_tasks_config['email_drafting'], agent=email_content_specialist)
engagement_optimization = Task(config=email_tasks_config['engagement_optimization'], agent=engagement_strategist)

# Create Crews
lead_scoring_crew = Crew(
    agents=[lead_data_agent, cultural_fit_agent, scoring_validation_agent],
    tasks=[lead_data_task, cultural_fit_task, scoring_validation_task],
    verbose=True
)

email_writing_crew = Crew(
    agents=[email_content_specialist, engagement_strategist],
    tasks=[email_drafting, engagement_optimization],
    verbose=True
)

# Define the Flow
class SalesPipeline(Flow):
    @start()
    def fetch_leads(self):
        return [
            {
                "lead_data": {
                    "name": "João Moura",
                    "job_title": "Director of Engineering",
                    "company": "Clearbit",
                    "email": "joao@clearbit.com",
                    "use_case": "Using AI Agent to do better data enrichment."
                },
            }
        ]

    @listen(fetch_leads)
    def score_leads(self, leads):
        scores = lead_scoring_crew.kickoff_for_each(leads)
        self.state["score_crews_results"] = scores
        return scores

    @listen(score_leads)
    def store_leads_score(self, scores):
        return scores

    @listen(score_leads)
    def filter_leads(self, scores):
        return [score for score in scores if score['lead_score'].score > 70]

    @listen(filter_leads)
    def write_email(self, leads):
        return email_writing_crew.kickoff_for_each([lead.to_dict() for lead in leads])

    @listen(write_email)
    def send_email(self, emails):
        return emails

# Run Flow
flow = SalesPipeline()
flow.plot("crewai_flow.html")
display(IFrame(src='./crewai_flow.html', width='100%', height=600))

# ⚠️ Only run this in async context (e.g., Jupyter or async script)
# Uncomment if running inside Jupyter:
# emails = await flow.kickoff()

# Process Results (example placeholder)
# scores = flow.state["score_crews_results"]
# lead_scoring_result = scores[0].pydantic

# data = {
#     'Name': lead_scoring_result.personal_info.name,
#     'Job Title': lead_scoring_result.personal_info.job_title,
#     'Role Relevance': lead_scoring_result.personal_info.role_relevance,
#     'Professional Background': lead_scoring_result.personal_info.professional_background,
#     'Company Name': lead_scoring_result.company_info.company_name,
#     'Industry': lead_scoring_result.company_info.industry,
#     'Company Size': lead_scoring_result.company_info.company_size,
#     'Revenue': lead_scoring_result.company_info.revenue,
#     'Market Presence': lead_scoring_result.company_info.market_presence,
#     'Lead Score': lead_scoring_result.lead_score.score,
#     'Scoring Criteria': ', '.join(lead_scoring_result.lead_score.scoring_criteria),
#     'Validation Notes': lead_scoring_result.lead_score.validation_notes
# }

# df = pd.DataFrame.from_dict(data, orient='index', columns=['Value']).reset_index().rename(columns={'index': 'Attribute'})
# html_table = df.style.set_properties(**{'text-align': 'left'}).format({'Attribute': lambda x: f'<b>{x}</b>'}).hide(axis='index').to_html()
# display(HTML(html_table))

# Print email result example
# print(textwrap.fill(emails[0].raw, width=80))
