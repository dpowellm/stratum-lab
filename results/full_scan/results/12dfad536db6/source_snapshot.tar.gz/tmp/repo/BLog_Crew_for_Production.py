import os
import warnings
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Suppress warnings
warnings.filterwarnings('ignore')

# Import core modules
from crewai import Agent, Task, Crew
from utils import get_openai_api_key

# Set OpenAI API key and model
openai_api_key = get_openai_api_key()
os.environ["OPENAI_API_KEY"] = openai_api_key
os.environ["OPENAI_MODEL_NAME"] = os.getenv("OPENAI_MODEL_NAME", "gpt-4-turbo")

# Define Agents
researcher = Agent(
    role="Research Specialist",
    goal="Gather in-depth insights and data on {topic}",
    backstory="You are an expert researcher who scours reliable sources to find "
              "the latest trends, statistics, and expert opinions on {topic}. "
              "Your work ensures the blog post is well-informed and credible.",
    allow_delegation=False,
    verbose=True
)

writer = Agent(
    role="Blog Writer",
    goal="Write an engaging, well-structured blog post on {topic}",
    backstory="You are a skilled content writer who transforms research into "
              "compelling narratives. You specialize in making complex topics "
              "accessible and interesting to readers while maintaining accuracy.",
    allow_delegation=False,
    verbose=True
)

seo_editor = Agent(
    role="SEO & Style Editor",
    goal="Optimize content for search engines and brand voice",
    backstory="You are a meticulous editor with expertise in SEO best practices "
              "and brand consistency. You ensure the content ranks well while "
              "maintaining readability and engagement.",
    allow_delegation=False,
    verbose=True
)

# Define Tasks
research_task = Task(
    description=(
        "1. Conduct thorough research on {topic}, focusing on recent developments.\n"
        "2. Identify key statistics, case studies, and expert opinions.\n"
        "3. Highlight potential angles or unique perspectives for the blog post.\n"
        "4. Compile a list of credible sources and references."
    ),
    expected_output="A detailed research report with key findings, data points, and sources.",
    agent=researcher,
)

writing_task = Task(
    description=(
        "1. Use the research report to draft a 1000-word blog post on {topic}.\n"
        "2. Structure the post with an engaging hook, clear sections, and a strong conclusion.\n"
        "3. Incorporate storytelling elements to make the content relatable.\n"
        "4. Ensure technical accuracy while keeping language simple and engaging."
    ),
    expected_output="A complete blog post draft in markdown format with proper headings and subheadings.",
    agent=writer,
)

editing_task = Task(
    description=(
        "1. Review and refine the blog post for clarity and flow.\n"
        "2. Optimize content with relevant keywords without compromising quality.\n"
        "3. Ensure consistency with brand voice and style guidelines.\n"
        "4. Check for grammatical errors and readability issues."
    ),
    expected_output="A polished, SEO-optimized blog post ready for publication.",
    agent=seo_editor,
)

# Create and Run Crew
blog_crew = Crew(
    agents=[researcher, writer, seo_editor],
    tasks=[research_task, writing_task, editing_task],
    verbose=True
)

if __name__ == "__main__":
    topic = "The Future of Renewable Energy"
    result = blog_crew.kickoff(inputs={"topic": topic})
    
    # Handle the CrewOutput object properly
    try:
        # Try to get the output directly (newer CrewAI versions)
        output_content = result.output
    except AttributeError:
        # Fallback for older versions or different output formats
        output_content = str(result)
    
    # Ensure we have a string to write
    if not isinstance(output_content, str):
        output_content = str(output_content)
    
    # Save to file
    with open("blog_post.md", "w", encoding="utf-8") as f:
        f.write(output_content)
    
    # Print success message with some stats
    word_count = len(output_content.split())
    print(f"✅ Blog post successfully generated!")
    print(f"📄 Saved to: blog_post.md")
    print(f"📝 Word count: {word_count}")
    print(f"🔤 Character count: {len(output_content)}")