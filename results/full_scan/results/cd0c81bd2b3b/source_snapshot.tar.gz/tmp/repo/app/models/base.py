"""
Base declarative class for all database models.
"""

from sqlalchemy.orm import declarative_base

Base = declarative_base()
