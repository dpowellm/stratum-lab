"""Test package initialization"""
