from typing import Dict, List

from pydantic import BaseModel, Field


class Patient(BaseModel):
    name: str = Field(..., description="The name of the patient")
    age: int = Field(..., ge=0, description="The age of the patient in years")
    weight: float = Field(None, ge=0, description="The weight of the patient in kg")
    married: bool = Field(False, description="Marital status of the patient")
    allergies: List[str]
    contact_details: Dict[str, str]


def insert_patient(patient: Patient):
    # Simulate inserting a patient into a database
    print(
        f"Inserting patient: {patient.name}, Age: {patient.age}, Weight: {patient.weight}"
    )
    print("Patient inserted successfully!")


patient_info = {
    "name": "John Doe",
    "age": 30,
    "weight": 70,
    "married": True,
    "allergies": ["pollen", "dust"],
    "contact_details": {"email": "abc@gmail.com", "phone_number": "123456789"},
}

new_patient = Patient(**patient_info)
insert_patient(new_patient)
