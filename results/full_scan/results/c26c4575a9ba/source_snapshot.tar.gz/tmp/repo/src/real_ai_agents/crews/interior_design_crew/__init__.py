"""Interior Design Crew module."""
from real_ai_agents.crews.interior_design_crew.interior_design_crew import InteriorDesignCrew

__all__ = ["InteriorDesignCrew"]
