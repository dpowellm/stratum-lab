"""Research Agent Crew - Handles property discovery and data extraction."""
