"""Location Analyzer Crew - Handles geospatial analysis for approved properties."""
