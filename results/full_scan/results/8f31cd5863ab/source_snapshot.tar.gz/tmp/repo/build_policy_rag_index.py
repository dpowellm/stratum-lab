"""
build_policy_rag_index.py

Builds a Chroma vector index over policies.json using Ollama embeddings
(nomic-embed-text). Run this ONCE (or whenever policies change) before
running the adjudication agent.

Usage:
    python build_policy_rag_index.py
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.schema import Document

# ---------------------------------------------------------------------
# Paths & config
# ---------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
DATASET_DIR = BASE_DIR / "dataset"
POLICIES_PATH = DATASET_DIR / "policies.json"

RAG_BASE_DIR = BASE_DIR / "rag_store"
RAG_POLICIES_DIR = RAG_BASE_DIR / "policies"

EMBED_MODEL = "nomic-embed-text"


def _load_json(path: Path) -> Any:
    if not path.exists():
        raise FileNotFoundError(f"JSON file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def build_policy_documents(policies: List[Dict[str, Any]]) -> List[Document]:
    """
    Flatten policies into granular 'policy + procedure' text chunks
    suitable for semantic search.
    """
    docs: List[Document] = []

    for pol in policies:
        policy_id = pol.get("policy_id", "UNKNOWN")
        plan_name = pol.get("plan_name", "")
        cps = pol.get("covered_procedures", [])

        # If no covered_procedures, still index a stub
        if not cps:
            text = f"Policy {policy_id} (plan: {plan_name}). No covered procedures listed."
            docs.append(
                Document(
                    page_content=text,
                    metadata={"policy_id": policy_id},
                )
            )
            continue

        for cp in cps:
            proc = cp.get("procedure_code", "UNKNOWN")
            diag_list = cp.get("covered_diagnosis", [])
            diag_str = ", ".join(diag_list) if diag_list else "None"

            age = cp.get("age_range", {})
            age_min = age.get("min", "NA")
            age_max = age.get("max", "NA")

            gender = cp.get("gender", "Any")
            preauth = cp.get("requires_preauthorization", False)
            notes = cp.get("notes", "")

            text = (
                f"Policy {policy_id} (plan: {plan_name}).\n"
                f"Procedure code: {proc}.\n"
                f"Notes: {notes}\n"
                f"Covered diagnoses (ICD-10): {diag_str}.\n"
                f"Age range allowed: {age_min}–{age_max} years.\n"
                f"Allowed gender: {gender}.\n"
                f"Requires preauthorization: {preauth}."
            )

            meta = {
                "policy_id": policy_id,
                "procedure_code": proc,
            }

            docs.append(Document(page_content=text, metadata=meta))

    return docs


def main() -> None:
    print(f"[INFO] Loading policies from: {POLICIES_PATH}")
    raw = _load_json(POLICIES_PATH)
    policies: List[Dict[str, Any]] = raw.get("policies", raw)

    print(f"[INFO] Loaded {len(policies)} policies.")
    docs = build_policy_documents(policies)
    print(f"[INFO] Built {len(docs)} policy snippets for RAG indexing.")

    RAG_POLICIES_DIR.mkdir(parents=True, exist_ok=True)

    print(f"[INFO] Creating embeddings with Ollama model: {EMBED_MODEL}")
    embeddings = OllamaEmbeddings(model=EMBED_MODEL)

    print(f"[INFO] Building Chroma index in: {RAG_POLICIES_DIR}")
    _ = Chroma.from_documents(
        documents=docs,
        embedding=embeddings,
        persist_directory=str(RAG_POLICIES_DIR),
    )

    print("[INFO] Done. Policy RAG index ready.")


if __name__ == "__main__":
    main()
