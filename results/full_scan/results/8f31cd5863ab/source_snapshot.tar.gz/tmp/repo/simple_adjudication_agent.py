"""
simple_adjudication_agent.py

ReAct-style + Agentic RAG Claims Adjudication Agent using:
    - local LLM (Ollama, OpenAI-compatible)
    - cloud LLM (Google Gemini 2.5 Pro / Flash)

DATA FILES (expected under ./dataset):
    - policies.json
    - test_claims_500_with_target.json
    - production_claims_1000_without_target.json
    - codes.json

MODES:
  1) Adjudicate claims (batch, ReAct + RAG over policies)
  2) Policy / Code Q&A (interactive RAG chat)

FLOW FOR EACH CLAIM (mode 1):
    Start → Start Node → Agent Node → Tool Node (loop as needed) → Agent Node → End

The agent uses tools:
    - load_claim
    - load_policy
    - load_codes
    - rag_search_policies        (Agentic RAG over policies)
    - compare_policy_claim       (LLM + rule-based helper; computes FACT_* flags)
    - model_validation           (ML helper + LLM/ML reconciliation; enforces that
                                  any disagreement or ML error → Human Review)

Run:
    python simple_adjudication_agent.py
"""

from __future__ import annotations

import json
import os
import time
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum

import requests
import numpy as np
import pandas as pd
import joblib
from pydantic import BaseModel, Field

from langchain_core.tools import tool
from langchain_core.messages import (
    AIMessage,
    HumanMessage,
    SystemMessage,
)
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END, MessagesState
from langgraph.prebuilt import ToolNode

# RAG imports
from langchain_chroma import Chroma
from langchain_ollama import OllamaEmbeddings

# Google Gemini
from langchain_google_genai import ChatGoogleGenerativeAI


# ============================================================================#
# 1. GLOBAL CONFIG
# ============================================================================#

# Ollama base (HTTP) and OpenAI-compatible base for ChatOpenAI
OLLAMA_HTTP_BASE = "http://localhost:11434"
OLLAMA_BASE_URL = f"{OLLAMA_HTTP_BASE}/v1"
OLLAMA_API_KEY = "ollama"  # dummy; Ollama ignores it but LangChain expects something

# Candidate OLLAMA models (we'll probe what is actually installed & responsive)
OLLAMA_CANDIDATE_MODELS = [
    "qwen2.5:1.5b",
    "qwen2.5:3b",
    "qwen2.5:7b",
]

# Candidate GEMINI models
GEMINI_CANDIDATE_MODELS = [
    "gemini-2.5-pro",
]

# Verbose tool logging: prints loaded claim, policy, helper reasoning, etc.
VERBOSE = True


# ============================================================================#
# 2. DATASET & PROMPT LOADING
# ============================================================================#

BASE_DIR = Path(__file__).resolve().parent
DATASET_DIR = BASE_DIR / "dataset"

POLICIES_PATH = DATASET_DIR / "policies.json"
TEST_CLAIMS_PATH = DATASET_DIR / "test_claims_500_with_target.json"
PROD_CLAIMS_PATH = DATASET_DIR / "production_claims_1000_without_target.json"
CODES_PATH = DATASET_DIR / "codes.json"
SYSTEM_PROMPT_PATH = BASE_DIR / "prompts" / "simple_adjudication_system_prompt.txt"

# ML model path (for the model_validation tool) – produced by model_selector.py
ML_MODEL_PATH = BASE_DIR / "best_claims_model.pkl"

# Directories where we persist the RAG indexes
RAG_DIR_POLICIES = BASE_DIR / "rag_store" / "policies_chroma"
RAG_DIR_CODES = BASE_DIR / "rag_store" / "codes_chroma"


def _load_json(path: Path) -> Any:
    if not path.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _load_text(path: Path) -> str:
    """
    Load a UTF-8 text file and return its content as a string.
    Used for externalizing the system prompt.
    """
    if not path.exists():
        raise FileNotFoundError(f"System prompt file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        return f.read()


# Load system prompt from external file
SYSTEM_PROMPT_LOAD: str = _load_text(SYSTEM_PROMPT_PATH)

# Load policies
_policies_raw = _load_json(POLICIES_PATH)
POLICIES: List[Dict[str, Any]] = _policies_raw.get("policies", _policies_raw)

# Build lookup by policy_id
POLICY_INDEX: Dict[str, Dict[str, Any]] = {
    p["policy_id"]: p for p in POLICIES if "policy_id" in p
}

# Load claims (both test + production for flexibility)
_test_claims_raw = _load_json(TEST_CLAIMS_PATH)
TEST_CLAIMS: List[Dict[str, Any]] = _test_claims_raw.get("claims", _test_claims_raw)

_prod_claims_raw = _load_json(PROD_CLAIMS_PATH)
PROD_CLAIMS: List[Dict[str, Any]] = _prod_claims_raw.get("claims", _prod_claims_raw)

# Load codebook (ICD-10 + CPT)
CODEBOOK: Dict[str, Any] = _load_json(CODES_PATH)

# Build simple lookup maps for ICD & CPT descriptions
ICD_DESC_MAP: Dict[str, str] = {}
CPT_DESC_MAP: Dict[str, str] = {}

_icd_list = (
    CODEBOOK.get("icd_10_codes")
    or CODEBOOK.get("icd10")
    or CODEBOOK.get("icd")
    or []
)
if isinstance(_icd_list, list):
    for entry in _icd_list:
        if not isinstance(entry, dict):
            continue
        code = entry.get("code") or entry.get("icd_code") or entry.get("id")
        desc = entry.get("description") or entry.get("desc") or ""
        if code:
            ICD_DESC_MAP[str(code).strip()] = str(desc).strip()

_cpt_list = (
    CODEBOOK.get("cpt_codes")
    or CODEBOOK.get("cpt")
    or []
)
if isinstance(_cpt_list, list):
    for entry in _cpt_list:
        if not isinstance(entry, dict):
            continue
        code = entry.get("code") or entry.get("cpt_code") or entry.get("id")
        desc = entry.get("description") or entry.get("desc") or ""
        if code:
            CPT_DESC_MAP[str(code).strip()] = str(desc).strip()


# ============================================================================#
# 3. RAG: BUILD / LOAD VECTOR STORES (POLICIES + CODES)
# ============================================================================#

def build_or_load_policy_vectorstore() -> Chroma:
    """
    Build (or load) a Chroma vector store over policies.json using
    Ollama's nomic-embed-text model as embeddings.

    Each document is the full JSON of a policy, with metadata {"policy_id": ...}.
    """
    embedding = OllamaEmbeddings(
        model="nomic-embed-text",
        base_url=OLLAMA_HTTP_BASE,
    )

    # If we already have a persisted index, just load it
    if RAG_DIR_POLICIES.exists():
        if VERBOSE:
            print(f"[RAG] Loading existing policy vectorstore from: {RAG_DIR_POLICIES}")
        vs = Chroma(
            persist_directory=str(RAG_DIR_POLICIES),
            embedding_function=embedding,
        )
        return vs

    # Otherwise, build from scratch
    if VERBOSE:
        print(f"[RAG] Building new policy vectorstore at: {RAG_DIR_POLICIES}")

    texts: List[str] = []
    metadatas: List[Dict[str, Any]] = []

    for p in POLICIES:
        pid = p.get("policy_id", "")
        # Store as JSON string
        txt = json.dumps(p, ensure_ascii=False)
        texts.append(txt)
        metadatas.append({"policy_id": pid})

    vs = Chroma.from_texts(
        texts=texts,
        embedding=embedding,
        metadatas=metadatas,
        persist_directory=str(RAG_DIR_POLICIES),
    )
    return vs


def _flatten_codebook_for_rag(codebook: Dict[str, Any]) -> Tuple[List[str], List[Dict[str, Any]]]:
    """
    Flatten codes.json into (texts, metadata) for a vector store.
    """
    texts: List[str] = []
    metas: List[Dict[str, Any]] = []

    # ICD-10 section
    icd_list = (
        codebook.get("icd_10_codes")
        or codebook.get("icd10")
        or codebook.get("icd")
        or []
    )
    if isinstance(icd_list, list):
        for entry in icd_list:
            if not isinstance(entry, dict):
                continue
            code = entry.get("code") or entry.get("icd_code") or entry.get("id")
            desc = entry.get("description") or entry.get("desc") or ""
            if not code:
                continue
            txt = f"ICD-10 code {code}: {desc}"
            texts.append(txt)
            metas.append({"code": code, "code_type": "ICD-10"})

    # CPT section
    cpt_list = (
        codebook.get("cpt_codes")
        or codebook.get("cpt")
        or []
    )
    if isinstance(cpt_list, list):
        for entry in cpt_list:
            if not isinstance(entry, dict):
                continue
            code = entry.get("code") or entry.get("cpt_code") or entry.get("id")
            desc = entry.get("description") or entry.get("desc") or ""
            typical_fee = entry.get("typical_fee")
            if not code:
                continue

            if typical_fee is not None:
                txt = f"CPT code {code}: {desc} (typical_fee={typical_fee})"
            else:
                txt = f"CPT code {code}: {desc}"

            texts.append(txt)
            metas.append({"code": code, "code_type": "CPT"})

    # Fallback: store full JSON if nothing extracted
    if not texts:
        texts.append(json.dumps(codebook, ensure_ascii=False))
        metas.append({"code_type": "raw_codebook"})

    return texts, metas


def build_or_load_codes_vectorstore() -> Chroma:
    """
    Build (or load) a Chroma vector store over codes.json using
    Ollama's nomic-embed-text model.
    """
    embedding = OllamaEmbeddings(
        model="nomic-embed-text",
        base_url=OLLAMA_HTTP_BASE,
    )

    if RAG_DIR_CODES.exists():
        if VERBOSE:
            print(f"[RAG] Loading existing codes vectorstore from: {RAG_DIR_CODES}")
        vs = Chroma(
            persist_directory=str(RAG_DIR_CODES),
            embedding_function=embedding,
        )
        return vs

    if VERBOSE:
        print(f"[RAG] Building new codes vectorstore at: {RAG_DIR_CODES}")

    texts, metadatas = _flatten_codebook_for_rag(CODEBOOK)

    vs = Chroma.from_texts(
        texts=texts,
        embedding=embedding,
        metadatas=metadatas,
        persist_directory=str(RAG_DIR_CODES),
    )
    return vs


# Build/load once at import time
POLICY_VECTORSTORE: Chroma = build_or_load_policy_vectorstore()
CODES_VECTORSTORE: Chroma = build_or_load_codes_vectorstore()


# ============================================================================#
# 4. UTILS
# ============================================================================#

def extract_text_from_content(content: Any) -> str:
    """
    Robustly extract user-visible text from an LLM 'content' field.

    Handles:
      - plain strings
      - Gemini-style list-of-chunks: [{'type': 'text', 'text': '...'}, ...]
      - other iterable structures by joining any 'text' attributes.
    """
    if isinstance(content, str):
        return content

    # LangChain ChatGoogleGenerativeAI / multi-part content
    if isinstance(content, (list, tuple)):
        parts: List[str] = []
        for item in content:
            if isinstance(item, dict) and "text" in item:
                parts.append(str(item["text"]))
            elif hasattr(item, "text"):
                parts.append(str(item.text))
            elif isinstance(item, str):
                parts.append(item)
        if parts:
            return "\n".join(parts)

    # Fallback
    return str(content or "")


def safe_parse_json(s: Any) -> dict:
    """
    Extract and parse the FIRST top-level JSON object found in a string.

    More defensive version:
      - Handles code fences.
      - Handles strings that contain extra text around JSON.
      - Scans for first '{' that yields valid JSON.
    """
    # If we've already got a dict, just return it
    if isinstance(s, dict):
        return s

    # If we've got a Gemini-style content list, strip it down to text
    if isinstance(s, (list, tuple)):
        s = extract_text_from_content(s)

    if s is None:
        raise ValueError("Empty or None string")

    s = str(s).strip()
    if not s:
        raise ValueError("Empty string")

    # Strip markdown fences if present
    if s.startswith("```"):
        parts = s.split("```")
        inner = "".join(parts[1:-1]).strip()
        if inner:
            s = inner

    decoder = json.JSONDecoder()
    last_err: Optional[Exception] = None

    # Try direct parse first (pure JSON case)
    try:
        obj, _ = decoder.raw_decode(s)
        if obj is not None:
            return obj
    except json.JSONDecodeError as e:
        last_err = e

    # Otherwise scan for first '{' that starts valid JSON
    for i, ch in enumerate(s):
        if ch.isspace():
            continue
        if ch != "{":
            continue
        try:
            obj, _ = decoder.raw_decode(s[i:])
            return obj
        except json.JSONDecodeError as e:
            last_err = e
            continue

    snippet = s[:300]
    if last_err:
        raise ValueError(
            f"No valid JSON object found. First 300 chars: {snippet!r}. "
            f"Last JSON error: {last_err}"
        ) from last_err
    else:
        raise ValueError(
            f"No valid JSON object found. First 300 chars: {snippet!r}"
        )


def get_installed_ollama_models(base_url: str, api_key: str) -> List[str]:
    """
    Ask the local /v1/models endpoint which models exist and return all their ids.
    """
    try:
        url = base_url.rstrip("/") + "/models"
        headers = {"Authorization": f"Bearer {api_key}"}
        resp = requests.get(url, headers=headers, timeout=5)
        resp.raise_for_status()
        data = resp.json()
        ids = [m.get("id") for m in data.get("data", []) if isinstance(m, dict)]
        return [mid for mid in ids if isinstance(mid, str) and mid]
    except Exception:
        return []


def probe_ollama_model(model_tag: str, base_url: str, api_key: str, timeout: int = 120) -> bool:
    """
    Tiny health-check for an Ollama model: expect string 'PING_OK'.
    """
    try:
        client = ChatOpenAI(
            model=model_tag,
            api_key=api_key,
            base_url=base_url,
            temperature=0.0,
            max_tokens=16,
            timeout=timeout,
        )
        resp = client.invoke("Respond only with: PING_OK")
        txt = extract_text_from_content(getattr(resp, "content", ""))
        return "PING_OK" in txt
    except Exception:
        return False


def _extract_policy_ids_from_question(q: str) -> List[str]:
    """
    Extract policy IDs of the form POL1234 from the user's question.
    """
    if not q:
        return []
    q_upper = q.upper()
    ids = re.findall(r"\bPOL\d+\b", q_upper)
    seen = set()
    result: List[str] = []
    for pid in ids:
        if pid not in seen:
            seen.add(pid)
            result.append(pid)
    return result


# ============================================================================#
# 5. GEMINI HELPERS
# ============================================================================#

def _get_gemini_api_key() -> str:
    key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not key:
        raise RuntimeError("Set GEMINI_API_KEY or GOOGLE_API_KEY for Gemini.")
    return key


def make_gemini_llm(model_name: str) -> ChatGoogleGenerativeAI:
    api_key = _get_gemini_api_key()
    return ChatGoogleGenerativeAI(
        model=model_name,
        google_api_key=api_key,
        temperature=0.0,
        max_output_tokens=1024,  # ⬆️ increased from 512 to give room after reasoning
        convert_system_message_to_human=True,
    )


def probe_gemini_model(model_name: str) -> bool:
    """
    Tiny health-check for a Gemini model: expect 'PING_OK'.
    """
    try:
        llm = make_gemini_llm(model_name)
        resp = llm.invoke("Respond only with: PING_OK")
        txt = extract_text_from_content(getattr(resp, "content", ""))
        return "PING_OK" in txt
    except Exception as e:
        print(f"[probe_gemini_model] {model_name} error: {type(e).__name__}: {e}")
        return False


# ============================================================================#
# 6. OUTPUT SCHEMA
# ============================================================================#

class AdjudicationDecision(BaseModel):
    """
    Structured result of a single adjudication run.
    """
    decision: str = Field(pattern=r"^(PASS|Human Review)$")
    reasoning: str


class BackendType(str, Enum):
    """
    Backend type enum so static type-checkers are happy and we
    still have nice string values at runtime.
    """
    OLLAMA = "ollama"
    GEMINI = "gemini"


# ============================================================================#
# 6.5 ML FEATURE ENGINEERING (MIRRORS model_selector.py)
# ============================================================================#

# These must match model_selector.py
ML_NUMERIC_FEATURES = [
    "patient_age",
    "charged_amount",
    "allowed_amount",
    "paid_amount",
    "patient_responsibility",
    "out_of_network_flag",
    "allowed_to_charged_ratio",
    "paid_to_allowed_ratio",
    "patient_resp_to_charged_ratio",
]

ML_CATEGORICAL_FEATURES = [
    "policy_id",
    "patient_gender",
    "provider_specialty",
    "claim_type",
    "primary_diagnosis_code",
    "procedure_code_cpt",
    "age_bin",
]

_ML_PIPELINE_CACHE = None  # lazy-loaded best_claims_model.pkl
_ML_EPSILON = 1e-6


def _load_ml_pipeline():
    """
    Lazy-load and cache the sklearn Pipeline saved by model_selector.py.
    Uses joblib.load to avoid pickle compatibility issues.
    """
    global _ML_PIPELINE_CACHE

    if _ML_PIPELINE_CACHE is not None:
        return _ML_PIPELINE_CACHE

    if not ML_MODEL_PATH.exists():
        raise FileNotFoundError(f"ML model file not found at {ML_MODEL_PATH}")

    model = joblib.load(ML_MODEL_PATH)
    _ML_PIPELINE_CACHE = model
    if VERBOSE:
        print(f"[ML] Loaded ML pipeline from {ML_MODEL_PATH}")
    return _ML_PIPELINE_CACHE


def _identify_ml_model_name(model: Any) -> str:
    """
    Best-effort extractor for the underlying ML model's name
    from a sklearn Pipeline or plain estimator.
    """
    try:
        from sklearn.pipeline import Pipeline  # type: ignore
        if isinstance(model, Pipeline):
            final_est = model.steps[-1][1]
        else:
            final_est = model
    except Exception:
        final_est = model

    return final_est.__class__.__name__


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        if x is None:
            return default
        return float(x)
    except (TypeError, ValueError):
        return default


def _age_to_bin(age: Any) -> str:
    """
    Same binning as model_selector.py:
        [0,17] -> child
        (17,45] -> adult
        (45,65] -> middle_aged
        (65,120] -> senior
    If age is missing/invalid, default to 'adult'.
    """
    try:
        a = float(age)
    except (TypeError, ValueError):
        return "adult"

    if a <= 17:
        return "child"
    elif a <= 45:
        return "adult"
    elif a <= 65:
        return "middle_aged"
    else:
        return "senior"


def build_ml_input_from_claim(claim: Dict[str, Any]) -> pd.DataFrame:
    """
    Build a single-row DataFrame with the same engineered features as in model_selector.py
    from a raw claim dict.
    """
    # Raw numeric fields
    patient_age = _safe_float(claim.get("patient_age"), default=0.0)
    charged_amount = _safe_float(claim.get("charged_amount"), default=0.0)
    allowed_amount = _safe_float(claim.get("allowed_amount"), default=0.0)
    paid_amount = _safe_float(claim.get("paid_amount"), default=0.0)
    patient_responsibility = _safe_float(
        claim.get("patient_responsibility"), default=0.0
    )

    # out_of_network flag -> numeric
    out_of_network_flag = int(bool(claim.get("out_of_network", False)))

    # Ratios (with epsilon to avoid division by zero)
    allowed_to_charged_ratio = allowed_amount / (charged_amount + _ML_EPSILON)
    paid_to_allowed_ratio = paid_amount / (allowed_amount + _ML_EPSILON)
    patient_resp_to_charged_ratio = (
        patient_responsibility / (charged_amount + _ML_EPSILON)
    )

    # Age bucket
    age_bin = _age_to_bin(patient_age)

    # Categorical fields (as strings, default "UNKNOWN" if missing)
    def _cat(key: str) -> str:
        v = claim.get(key)
        if v is None:
            return "UNKNOWN"
        return str(v)

    row: Dict[str, Any] = {
        # numeric
        "patient_age": patient_age,
        "charged_amount": charged_amount,
        "allowed_amount": allowed_amount,
        "paid_amount": paid_amount,
        "patient_responsibility": patient_responsibility,
        "out_of_network_flag": out_of_network_flag,
        "allowed_to_charged_ratio": allowed_to_charged_ratio,
        "paid_to_allowed_ratio": paid_to_allowed_ratio,
        "patient_resp_to_charged_ratio": patient_resp_to_charged_ratio,
        # categorical
        "policy_id": _cat("policy_id"),
        "patient_gender": _cat("patient_gender"),
        "provider_specialty": _cat("provider_specialty"),
        "claim_type": _cat("claim_type"),
        "primary_diagnosis_code": _cat("primary_diagnosis_code"),
        "procedure_code_cpt": _cat("procedure_code_cpt"),
        "age_bin": age_bin,
    }

    # Ensure all required keys exist (safety)
    for k in ML_NUMERIC_FEATURES:
        row.setdefault(k, 0.0)
    for k in ML_CATEGORICAL_FEATURES:
        row.setdefault(k, "UNKNOWN")

    # Preserve column order
    columns = ML_NUMERIC_FEATURES + ML_CATEGORICAL_FEATURES
    df = pd.DataFrame([row], columns=columns)
    return df


# ============================================================================#
# 7. AGENT FACTORY: LLM → TOOLS → SYSTEM PROMPT → REACT+RAG GRAPH → RUN
# ============================================================================#

def create_simple_agent_runner(backend: BackendType, model_tag: str):
    """
    Build a LangGraph ReAct + Agentic RAG agent for one specific model.

    Components:
        1. LLM
        2. Tools:
             - load_claim
             - load_policy
             - load_codes
             - rag_search_policies
             - compare_policy_claim
             - model_validation
        3. System prompt (loaded from external file)
        4. ReAct graph:
             Start → start → agent → tools ↔ agent → End
        5. run_for_claim(claim, verbose=False)
           returns (AdjudicationDecision|None, messages_list, ml_info_dict|None)
    """

    # 7.1 LLM
    if backend is BackendType.OLLAMA:
        llm = ChatOpenAI(
            model=model_tag,
            api_key=OLLAMA_API_KEY,
            base_url=OLLAMA_BASE_URL,
            temperature=0.0,
            max_tokens=256,
            timeout=300,
        )
    elif backend is BackendType.GEMINI:
        llm = make_gemini_llm(model_tag)
    else:
        raise ValueError(f"Unknown backend: {backend}")

    # State shared between tools and runner
    current_claim: Optional[Dict[str, Any]] = None
    last_claim: Optional[Dict[str, Any]] = None
    last_policy: Optional[Dict[str, Any]] = None

    # Tracking for LLM comparison helper
    comparison_done: bool = False
    last_compare_result: Optional[Dict[str, Any]] = None

    # Tracking for ML / fused validation tool
    ml_done: bool = False
    last_ml_result: Optional[Dict[str, Any]] = None

    # 7.2 TOOLS -------------------------------------------------------#

    @tool
    def load_claim() -> Dict[str, Any]:
        """
        Return the claim that is currently being adjudicated.
        (Set by the runner before each invocation.)
        """
        nonlocal current_claim, last_claim
        if current_claim is None:
            raise ValueError("current_claim is not set. This is a runner bug.")
        last_claim = current_claim
        if VERBOSE:
            print("\n[load_claim] Loaded claim:")
            print(json.dumps(last_claim, indent=2))
        return last_claim

    @tool
    def load_policy() -> Dict[str, Any]:
        """
        Return the policy corresponding to the current claim's policy_id.
        """
        nonlocal current_claim, last_claim, last_policy

        if current_claim is None:
            raise ValueError("current_claim is not set. This is a runner bug.")

        claim_src = last_claim or current_claim
        policy_id = claim_src.get("policy_id")
        if not policy_id:
            raise ValueError("Claim has no policy_id field.")

        policy = POLICY_INDEX.get(policy_id)
        if policy is None:
            raise ValueError(f"No policy found for policy_id={policy_id}")

        last_policy = policy

        if VERBOSE:
            print("\n[load_policy] Loaded policy:")
            print(json.dumps(last_policy, indent=2))

        return last_policy

    @tool
    def load_codes() -> Dict[str, Any]:
        """
        Return ICD-10 & CPT code dictionaries.
        """
        if VERBOSE:
            print("\n[load_codes] Returning codebook (ICD + CPT).")
        return CODEBOOK

    @tool
    def compare_policy_claim() -> Dict[str, Any]:
        """
        LLM-based comparison of claim vs policy with robust fallback.

        Returns dict:
          {
            "decision": "PASS" | "Human Review",
            "reasoning": "...",
            "facts": { ... }   # FACT_* dict for downstream tools
          }
        """
        nonlocal current_claim, last_claim, last_policy
        nonlocal comparison_done, last_compare_result

        # -----------------------------#
        # Resolve claim & policy
        # -----------------------------#
        claim = last_claim or current_claim
        if claim is None:
            raise ValueError(
                "No claim available for comparison. "
                "current_claim / last_claim are None."
            )

        policy = last_policy
        if policy is None:
            policy_id = claim.get("policy_id")
            if not policy_id:
                raise ValueError("Claim has no policy_id field.")
            policy = POLICY_INDEX.get(policy_id)
            if policy is None:
                raise ValueError(f"No policy found for policy_id={policy_id}")
            last_policy = policy

        last_claim = claim  # keep cache consistent

        # -----------------------------#
        # Pull core fields
        # -----------------------------#
        claim_pid = str(claim.get("policy_id", "")).strip()
        proc_code = str(claim.get("procedure_code_cpt", "")).strip()
        diag_code = str(claim.get("primary_diagnosis_code", "")).strip()
        age = claim.get("patient_age")
        gender = str(claim.get("patient_gender", "")).strip()
        out_of_network = bool(claim.get("out_of_network", False))

        cpt_desc_claim = CPT_DESC_MAP.get(proc_code, "").strip()
        icd_desc_claim = ICD_DESC_MAP.get(diag_code, "").strip()

        if not cpt_desc_claim and proc_code:
            cpt_desc_claim = "No description found in codebook"
        if not icd_desc_claim and diag_code:
            icd_desc_claim = "No description found in codebook"

        # Claim summary text (for LLM)
        claim_summary_lines = [
            "Claim:",
            f"- policy_id: {claim_pid or 'None'}",
            f"- claim_type: {claim.get('claim_type', 'None')}",
            f"- patient_age: {age}",
            f"- patient_gender: {gender or 'None'}",
            f"- primary_diagnosis: {diag_code or 'None'}"
            + (f" ({icd_desc_claim})" if icd_desc_claim else ""),
            f"- procedure_code_cpt: {proc_code or 'None'}"
            + (f" ({cpt_desc_claim})" if cpt_desc_claim else ""),
            f"- out_of_network: {out_of_network}",
            f"- charged_amount: {claim.get('charged_amount')}",
            f"- allowed_amount: {claim.get('allowed_amount')}",
            f"- paid_amount: {claim.get('paid_amount')}",
            f"- patient_responsibility: {claim.get('patient_responsibility')}",
        ]
        claim_summary = "\n".join(claim_summary_lines)

        # Policy fields
        policy_pid = str(policy.get("policy_id", "")).strip()
        plan_name = str(policy.get("plan_name", "")).strip()
        cps = policy.get("covered_procedures") or []

        # -----------------------------#
        # FACT_* flags (deterministic ground truth)
        # -----------------------------#
        policy_match = bool(claim_pid and policy_pid and claim_pid == policy_pid)

        matching_cps = [
            cp for cp in cps
            if str(cp.get("procedure_code", "")).strip() == proc_code
        ]
        cpt_covered_by_policy = len(matching_cps) > 0

        diag_covered_for_that_cpt = False
        age_in_range_for_that_cpt = False
        gender_compatible_for_that_cpt = False
        preauth_required_for_that_cpt = False
        fully_eligible_procedure_found = False

        if matching_cps:
            for cp in matching_cps:
                cp_diags = cp.get("covered_diagnosis") or []
                cp_diags_norm = [str(d).strip() for d in cp_diags]
                diag_match = bool(diag_code and diag_code in cp_diags_norm)

                ar = cp.get("age_range") or {}
                age_min = ar.get("min")
                age_max = ar.get("max")
                age_match = False
                if isinstance(age, (int, float)) and age_min is not None and age_max is not None:
                    age_match = (age_min <= age <= age_max)

                cp_gender = cp.get("gender", "Any")
                gender_match = (cp_gender == "Any") or (gender and cp_gender == gender)

                cp_preauth = bool(cp.get("requires_preauthorization", False))

                if diag_match:
                    diag_covered_for_that_cpt = True
                if age_match:
                    age_in_range_for_that_cpt = True
                if gender_match:
                    gender_compatible_for_that_cpt = True
                if cp_preauth:
                    preauth_required_for_that_cpt = True
                if diag_match and age_match and gender_match:
                    fully_eligible_procedure_found = True

        facts_lines = [
            "FACT_policy_id_match: " + str(policy_match),
            "FACT_cpt_covered_by_policy: " + str(cpt_covered_by_policy),
            "FACT_diag_covered_for_that_cpt: " + str(diag_covered_for_that_cpt),
            "FACT_age_in_range_for_that_cpt: " + str(age_in_range_for_that_cpt),
            "FACT_gender_compatible_for_that_cpt: " + str(gender_compatible_for_that_cpt),
            "FACT_fully_eligible_procedure_found: " + str(fully_eligible_procedure_found),
            "FACT_out_of_network: " + str(out_of_network),
            "FACT_preauth_required_for_that_cpt: " + str(preauth_required_for_that_cpt),
        ]
        facts_section = "\n".join(facts_lines)

        # Policy summary text (for LLM)
        policy_lines = [
            "Policy:",
            f"- policy_id: {policy_pid or 'None'}",
            f"- plan_name: {plan_name or 'None'}",
            "- covered_procedures (each line: CPT, description, dx list with descriptions, age_range, gender, preauth, notes):",
        ]
        for cp in cps:
            cp_cpt = str(cp.get("procedure_code", "")).strip()
            cp_cpt_desc = CPT_DESC_MAP.get(cp_cpt, "").strip()
            if not cp_cpt_desc and cp_cpt:
                cp_cpt_desc = "No description found in codebook"
            cp_diags = cp.get("covered_diagnosis") or []
            diag_parts = []
            for d in cp_diags:
                d_str = str(d).strip()
                d_desc = ICD_DESC_MAP.get(d_str, "").strip()
                if d_desc:
                    diag_parts.append(f"{d_str} ({d_desc})")
                else:
                    diag_parts.append(d_str)
            diag_str = ", ".join(diag_parts) if diag_parts else "None"

            ar = cp.get("age_range") or {}
            age_min = ar.get("min", "None")
            age_max = ar.get("max", "None")
            cp_gender = cp.get("gender", "Any")
            preauth = bool(cp.get("requires_preauthorization", False))
            notes = cp.get("notes", "")

            policy_lines.append(
                f"  - CPT {cp_cpt or 'None'}"
                + (f" ({cp_cpt_desc})" if cp_cpt_desc else "")
                + f" | covered_diagnosis: [{diag_str}]"
                + f" | age_range: {age_min}-{age_max}"
                + f" | gender: {cp_gender}"
                + f" | requires_preauthorization: {preauth}"
                + (f" | notes: {notes}" if notes else "")
            )
        policy_summary = "\n".join(policy_lines)

        # Pack facts into a dict for downstream tools
        facts = {
            "policy_match": policy_match,
            "cpt_covered_by_policy": cpt_covered_by_policy,
            "diag_covered_for_that_cpt": diag_covered_for_that_cpt,
            "age_in_range_for_that_cpt": age_in_range_for_that_cpt,
            "gender_compatible_for_that_cpt": gender_compatible_for_that_cpt,
            "fully_eligible_procedure_found": fully_eligible_procedure_found,
            "out_of_network": out_of_network,
            "preauth_required_for_that_cpt": preauth_required_for_that_cpt,
        }

        # -----------------------------#
        # Rule-based fallback from FACT_* flags
        # -----------------------------#
        def rule_based_decision_from_facts() -> Dict[str, Any]:
            decision = "PASS"
            reasons = []

            if not facts["policy_match"]:
                decision = "Human Review"
                reasons.append("Policy ID in claim does not match the loaded policy.")

            if not facts["cpt_covered_by_policy"]:
                decision = "Human Review"
                reasons.append("Claim CPT code is not listed as a covered procedure in the policy.")

            # ✅ Only talk about diagnosis/age/gender when the CPT is actually covered.
            if facts["cpt_covered_by_policy"]:
                if not facts["diag_covered_for_that_cpt"]:
                    decision = "Human Review"
                    reasons.append("Primary diagnosis is not listed as covered for this CPT in the policy.")

                if not facts["age_in_range_for_that_cpt"]:
                    decision = "Human Review"
                    reasons.append("Patient age is outside the policy's allowed age range for this CPT.")

                if not facts["gender_compatible_for_that_cpt"]:
                    decision = "Human Review"
                    reasons.append("Patient gender is not compatible with the policy rule for this CPT.")

            if facts["out_of_network"]:
                decision = "Human Review"
                reasons.append("Claim is out-of-network; requires manual review.")

            if facts["preauth_required_for_that_cpt"]:
                decision = "Human Review"
                reasons.append("Procedure requires preauthorization; status is not explicitly provided in the claim.")

            if decision == "PASS":
                reasons.insert(
                    0,
                    "All core eligibility checks are satisfied: policy ID matches, CPT and diagnosis are covered, "
                    "age and gender fit the policy rules, claim is in-network, and preauthorization is not required."
                )

            # Also echo the FACT_* state in a compact way
            reasons.append(
                f"FACT summary -> "
                f"policy_match={facts['policy_match']}, "
                f"cpt_covered={facts['cpt_covered_by_policy']}, "
                f"diag_covered={facts['diag_covered_for_that_cpt']}, "
                f"age_in_range={facts['age_in_range_for_that_cpt']}, "
                f"gender_ok={facts['gender_compatible_for_that_cpt']}, "
                f"out_of_network={facts['out_of_network']}, "
                f"preauth_required={facts['preauth_required_for_that_cpt']}"
            )

            return {"decision": decision, "reasoning": " ".join(reasons), "facts": facts}

        # -----------------------------#
        # Try LLM-based decision first
        # -----------------------------#
        try:
            system_msg = (
                "You are a healthcare claims adjudication helper.\n"
                "You will be given:\n"
                "  - A concise summary of one claim (with ICD/CPT descriptions when available),\n"
                "  - A concise summary of its matching policy (with ICD/CPT descriptions), and\n"
                "  - A list of FACT_* lines which are precomputed booleans from the raw JSON.\n\n"
                "The FACT_* lines are GROUND TRUTH. You must not contradict them.\n"
                "You must decide whether the claim should be PASS or Human Review.\n\n"
                "OUTPUT FORMAT (STRICT JSON ONLY):\n"
                "{\n"
                '  \"decision\": \"PASS\" or \"Human Review\",\n'
                '  \"reasoning\": \"Short explanation.\"\n'
                "}\n"
                "Do not wrap in markdown. JSON only."
            )

            user_msg = (
                "Here is the summarized data:\n\n"
                f"{claim_summary}\n\n"
                f"{policy_summary}\n\n"
                "Derived coverage facts (FACT_* lines – ground truth booleans):\n"
                f"{facts_section}\n\n"
                "Now adjudicate this claim according to the rules above and return ONLY the JSON object."
            )

            resp = llm.invoke(
                [
                    SystemMessage(content=system_msg),
                    HumanMessage(content=user_msg),
                ]
            )

            raw_content = getattr(resp, "content", "")
            txt = extract_text_from_content(raw_content)

            if not txt.strip():
                if VERBOSE:
                    print("\n[compare_policy_claim] EMPTY LLM response. Full AIMessage:")
                    print(resp)
                raise ValueError("Empty response from LLM (content='').")

            if VERBOSE:
                print("\n[compare_policy_claim] Raw LLM content before JSON parse:")
                print(txt)

            parsed = safe_parse_json(txt)

            raw_decision = str(parsed.get("decision", "Human Review")).strip()
            if raw_decision.upper() == "PASS":
                decision = "PASS"
            else:
                decision = "Human Review"

            reasoning = str(parsed.get("reasoning", "")).strip()
            if not reasoning:
                reasoning = "No detailed reasoning provided by the model."

            out = {"decision": decision, "reasoning": reasoning, "facts": facts}

        except Exception as e:
            # Any failure -> rule-based fallback using FACT_*.
            if VERBOSE:
                print(
                    "\n[compare_policy_claim] LLM error, using rule-based fallback "
                    f"from FACT_* flags: {type(e).__name__}: {e}"
                )
            out = rule_based_decision_from_facts()
            # Annotate that this came from fallback
            out["reasoning"] += f" [Fallback due to LLM error: {type(e).__name__}]"

        # -----------------------------#
        # Store + log result
        # -----------------------------#
        comparison_done = True
        last_compare_result = out

        if VERBOSE:
            print(
                "\n[compare_policy_claim] Decision + reasoning (LLM or fallback):"
            )
            print(json.dumps(out, indent=2))

        return out

    @tool
    def rag_search_policies(query: str, top_k: int = 5) -> Dict[str, Any]:
        """
        Agentic RAG over policies.json with simple reranking.
        """
        nonlocal current_claim

        if not query or not query.strip():
            return {"query": query, "results": []}

        top_k = max(1, min(int(top_k), 10))  # clamp [1,10]
        base_k = top_k * 3  # retrieve a bit more, then rerank

        try:
            docs_scores = POLICY_VECTORSTORE.similarity_search_with_score(
                query, k=base_k
            )
        except Exception as e:
            if VERBOSE:
                print(f"[rag_search_policies] ERROR during vector search: {e}")
            return {
                "query": query,
                "results": [],
                "error": f"Vector search error: {type(e).__name__}: {e}",
            }

        if not docs_scores:
            return {"query": query, "results": []}

        # Simple rerank: boost documents whose policy_id matches the current claim
        target_pid = None
        if current_claim is not None:
            target_pid = current_claim.get("policy_id")

        reranked: List[Tuple[Any, float]] = []
        for doc, score in docs_scores:
            effective_score = float(score)
            pid = (doc.metadata or {}).get("policy_id")

            if target_pid and pid == target_pid:
                effective_score -= 0.5  # boost matching policy

            reranked.append((doc, effective_score))

        reranked.sort(key=lambda x: x[1])
        top_docs = reranked[:top_k]

        results = []
        for doc, eff_score in top_docs:
            pid = (doc.metadata or {}).get("policy_id")
            text = doc.page_content
            if len(text) > 1200:
                text = text[:1200] + "...(truncated)"

            results.append(
                {
                    "policy_id": pid,
                    "score": eff_score,
                    "text": text,
                }
            )

        if VERBOSE:
            print("\n[rag_search_policies] RAG results (after rerank):")
            for r in results:
                print(
                    f"  policy_id={r['policy_id']!r}, "
                    f"score={r['score']:.3f}, "
                    f"text[0:120]={r['text'][:120]!r}"
                )

        return {"query": query, "results": results}

    @tool
    def model_validation() -> Dict[str, Any]:
        """
        Fused LLM + ML validation tool.

        PRECONDITION:
          - compare_policy_claim() MUST have been called successfully first.

        Behavior:
          - Reads the last compare_policy_claim() result (LLM helper decision + reasoning).
          - Builds ML features from the current claim and runs best_claims_model.pkl.
          - Maps the ML prediction to PASS / Human Review.
          - Enforces that:
               * If ML status is error → final_decision = Human Review (safety).
               * If ML and LLM decisions disagree → final_decision = Human Review.
               * Otherwise final_decision = shared decision.

        Returns a dict like:
          {
            "status": "ok" | "error",
            "llm_decision": "PASS" | "Human Review",
            "llm_reasoning": "...",
            "ml_status": "ok" | "error",
            "ml_decision": "PASS" | "Human Review" | null,
            "ml_raw_pred": "...",
            "ml_proba_class1": float | null,
            "ml_error": "...",
            "ml_model_name": "...",
            "agree": true | false | null,
            "final_decision": "PASS" | "Human Review",
            "final_reasoning": "...",
            "feature_names": [...]
          }
        """
        nonlocal current_claim, comparison_done, last_compare_result
        nonlocal ml_done, last_ml_result

        if current_claim is None:
            raise ValueError("current_claim is not set. This is a runner bug.")

        if not comparison_done or last_compare_result is None:
            raise ValueError(
                "compare_policy_claim must be called before model_validation."
            )

        if VERBOSE:
            print("\n[model_validation] Invoked fused ML+LLM validation tool.")

        # --- Extract LLM helper decision ---
        llm_decision_raw = str(last_compare_result.get("decision", "Human Review")).strip()
        llm_reasoning = str(last_compare_result.get("reasoning", "")).strip()
        if not llm_reasoning:
            llm_reasoning = "No detailed reasoning from compare_policy_claim."

        llm_decision_norm = "PASS" if llm_decision_raw.upper() == "PASS" else "Human Review"

        # --- Run ML model ---
        ml_status = "ok"
        ml_decision = None
        ml_raw_pred = None
        ml_proba = None
        ml_error = None
        ml_model_name = None

        try:
            model = _load_ml_pipeline()
            ml_model_name = _identify_ml_model_name(model)
            X_df = build_ml_input_from_claim(current_claim)

            raw_pred = model.predict(X_df)[0]
            ml_raw_pred = str(raw_pred)

            if hasattr(model, "predict_proba"):
                proba_arr = model.predict_proba(X_df)[0]
                if len(proba_arr) == 2:
                    ml_proba = float(proba_arr[1])

            raw_upper = ml_raw_pred.upper()
            if raw_upper in {"1", "HUMAN REVIEW", "REVIEW"}:
                ml_decision = "Human Review"
            elif raw_upper in {"0", "PASS", "PAID"}:
                ml_decision = "PASS"
            else:
                ml_decision = "Human Review"

        except Exception as e:
            ml_status = "error"
            ml_error = f"{type(e).__name__}: {e}"
            if VERBOSE:
                print("[model_validation] Error during ML pipeline or prediction:", ml_error)

        # --- Fuse decisions ---
        if ml_status != "ok" or ml_decision is None:
            agree = None
            final_decision = "Human Review"
            final_reasoning = (
                f"{llm_reasoning} "
                "[ML validation could not be computed reliably; "
                "escalating to Human Review for safety.]"
            )
        else:
            ml_decision_norm = ml_decision  # already PASS/Human Review
            agree = (llm_decision_norm == ml_decision_norm)

            if agree:
                final_decision = llm_decision_norm
                final_reasoning = (
                    f"{llm_reasoning} "
                    f"[ML validation decision ({ml_decision_norm}) agrees with the LLM helper. "
                    f"Model raw prediction={ml_raw_pred}"
                    + (f", p(class1)={ml_proba:.3f}" if ml_proba is not None else "")
                    + ".]"
                )
            else:
                final_decision = "Human Review"
                final_reasoning = (
                    f"{llm_reasoning} "
                    f"[ML validation disagrees with the LLM helper "
                    f"(LLM={llm_decision_norm}, ML={ml_decision_norm}); "
                    "final decision escalated to Human Review.]"
                )

        result = {
            "status": "ok" if ml_status == "ok" else "error",
            "llm_decision": llm_decision_norm,
            "llm_reasoning": llm_reasoning,
            "ml_status": ml_status,
            "ml_decision": ml_decision,
            "ml_raw_pred": ml_raw_pred,
            "ml_proba_class1": ml_proba,
            "ml_error": ml_error,
            "ml_model_name": ml_model_name,
            "agree": agree,
            "final_decision": final_decision,
            "final_reasoning": final_reasoning,
            "feature_names": ML_NUMERIC_FEATURES + ML_CATEGORICAL_FEATURES,
        }

        ml_done = True
        last_ml_result = result

        if VERBOSE:
            print("\n[model_validation] Fused LLM+ML result:")
            print(json.dumps(result, indent=2))

        return result

    # Bind all tools (including RAG + fused ML validation) to the LLM
    tools = [
        load_claim,
        load_policy,
        load_codes,
        rag_search_policies,
        compare_policy_claim,
        model_validation,
    ]
    tool_node = ToolNode(tools)
    llm_with_tools = llm.bind_tools(tools)

    SYSTEM_PROMPT = SYSTEM_PROMPT_LOAD

    # 7.3 REACT + RAG GRAPH ------------------------------------------#

    def start_node(state: MessagesState) -> dict:
        """
        Seed the conversation with a strong instruction about tool order and final JSON.
        """
        initial_msg = HumanMessage(
            content=(
                "You are a Claims Adjudication Specialist Agent using ReAct.\n"
                "For the current claim, you MUST:\n"
                "  1) Call load_claim() to inspect the claim.\n"
                "  2) Call load_policy() to attach the matching policy.\n"
                "  3) Optionally use load_codes() or rag_search_policies() for extra context.\n"
                "  4) Call compare_policy_claim() exactly once to get the policy-based decision.\n"
                "  5) After that, call model_validation() exactly once as the FINAL tool.\n"
                "     This tool returns a fused JSON object with final_decision and final_reasoning.\n"
                "  6) After model_validation(), DO NOT call any more tools.\n"
                "     Instead, produce a single JSON object:\n"
                '       {\"decision\": \"PASS\" or \"Human Review\", \"reasoning\": \"...\"}\n'
                "     with no extra text before or after.\n"
            )
        )
        return {"messages": [initial_msg]}

    def agent_node(state: MessagesState) -> dict:
        """
        Core ReAct agent node:
          - Prefixes conversation with SYSTEM_PROMPT.
          - Lets the LLM either call a tool or emit the final JSON.
        """
        try:
            msgs = [SystemMessage(content=SYSTEM_PROMPT)] + state["messages"]
            resp = llm_with_tools.invoke(msgs)
            return {"messages": [resp]}
        except Exception as e:
            if VERBOSE:
                import traceback
                print("\n[agent_node] LLM error, falling back to Human Review:")
                traceback.print_exc()

            fallback = AIMessage(
                content=json.dumps(
                    {
                        "decision": "Human Review",
                        "reasoning": f"Agent LLM error: {type(e).__name__}: {e}",
                    }
                )
            )
            return {"messages": [fallback]}

    def route(state: MessagesState) -> str:
        last = state["messages"][-1]
        if isinstance(last, AIMessage) and getattr(last, "tool_calls", None):
            return "tools"
        return "__end__"

    graph = StateGraph(MessagesState)
    graph.add_node("start", start_node)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", tool_node)

    graph.set_entry_point("start")
    graph.add_edge("start", "agent")

    graph.add_conditional_edges(
        "agent",
        route,
        {
            "tools": "tools",
            "__end__": END,
        },
    )
    graph.add_edge("tools", "agent")

    app = graph.compile()

    # 7.4 RUNNER (one claim) ------------------------------------------#

    def run_for_claim(
        claim: Dict[str, Any],
        verbose: bool = False,
    ) -> Tuple[Optional[AdjudicationDecision], List[Any], Optional[Dict[str, Any]]]:

        nonlocal current_claim, last_claim, last_policy
        nonlocal comparison_done, last_compare_result
        nonlocal ml_done, last_ml_result

        current_claim = claim
        last_claim = None
        last_policy = None

        comparison_done = False
        last_compare_result = None

        ml_done = False
        last_ml_result = None

        initial_state = {"messages": []}

        try:
            res = app.invoke(initial_state, config={"recursion_limit": 30})
            messages = res["messages"]

            if verbose:
                print("\n[TRACE] Conversation messages:")
                for i, msg in enumerate(messages, start=1):
                    print(f"\n--- Message {i} ({msg.__class__.__name__}) ---")
                    print(msg)

            last_msg = messages[-1]
            raw_content = getattr(last_msg, "content", "")
            txt = extract_text_from_content(raw_content) if raw_content else str(last_msg)
            parsed = safe_parse_json(txt)
            decision = AdjudicationDecision(**parsed)
            return decision, messages, last_ml_result

        except Exception as e:
            if verbose:
                import traceback
                print(
                    f"\n[DEBUG] Error while running model="
                    f"{backend.value}:{model_tag}"
                )
                traceback.print_exc()
            else:
                print(
                    f"[ERROR] {backend.value}:{model_tag} failed: "
                    f"{type(e).__name__}: {e}"
                )
            return None, [], last_ml_result

    return run_for_claim


# ============================================================================#
# 8. MODEL SELECTION
# ============================================================================#

def select_ollama_models() -> List[Tuple[BackendType, str]]:
    installed = set(get_installed_ollama_models(OLLAMA_BASE_URL, OLLAMA_API_KEY))
    candidates: List[str] = []

    if installed:
        print(f"Installed models on Ollama: {', '.join(sorted(installed))}")

        for m in OLLAMA_CANDIDATE_MODELS:
            if m in installed:
                candidates.append(m)

        missing = [m for m in OLLAMA_CANDIDATE_MODELS if m not in installed]
        if missing:
            print(
                "[WARN] These Ollama models are in list but not installed: "
                + ", ".join(missing)
            )

        if not candidates:
            print("[WARN] None of the candidate Ollama models are installed; using list as-is.")
            candidates = OLLAMA_CANDIDATE_MODELS[:]
    else:
        print("[WARN] Could not fetch installed models from Ollama; using candidate list.")
        candidates = OLLAMA_CANDIDATE_MODELS[:]

    responsive: List[Tuple[BackendType, str]] = []
    for m in candidates:
        print(f"\nProbing Ollama model: {m} ...", end="", flush=True)
        if probe_ollama_model(m, OLLAMA_BASE_URL, OLLAMA_API_KEY):
            print(" OK")
            responsive.append((BackendType.OLLAMA, m))
        else:
            print(" SKIP")

    return responsive


def select_gemini_models() -> List[Tuple[BackendType, str]]:
    responsive: List[Tuple[BackendType, str]] = []
    for m in GEMINI_CANDIDATE_MODELS:
        print(f"\nProbing Gemini model: {m} ...", end="", flush=True)
        if probe_gemini_model(m):
            print(" OK")
            responsive.append((BackendType.GEMINI, m))
        else:
            print(" SKIP (Gemini)")
    return responsive


# ============================================================================#
# 9. QA MODE: POLICY / CODE Q&A (RAG CHAT)
# ============================================================================#

def run_policy_code_qa() -> None:
    """
    Interactive Q&A mode over policies + codes using RAG + direct policy_id lookup.
    Uses the first available model from chosen provider.
    """
    print("\nSelect model provider for Q&A:")
    print("  1) Ollama (local)")
    print("  2) Google Gemini 2.5 (cloud)")
    provider_choice = input("Enter choice [1]: ").strip() or "1"

    if provider_choice == "2":
        models_to_run = select_gemini_models()
    else:
        models_to_run = select_ollama_models()

    if not models_to_run:
        print("[ERROR] No responsive models for Q&A. Exiting.")
        return

    backend, qa_model = models_to_run[0]
    label = f"{backend.value}:{qa_model}."
    print(f"\n[QA] Using model for Q&A: {label}")

    if backend is BackendType.OLLAMA:
        llm = ChatOpenAI(
            model=qa_model,
            api_key=OLLAMA_API_KEY,
            base_url=OLLAMA_BASE_URL,
            temperature=0.0,
            max_tokens=512,
            timeout=300,
        )
    else:
        llm = make_gemini_llm(qa_model)

    print("\n=== Policy / Code Q&A Mode ===")
    print("Ask any question about policies or codes.")
    print("You can also ask about a specific policy, e.g. 'Tell me about POL5554'.")
    print("Type 'exit' or 'quit' to end.\n")

    while True:
        q = input("Your question: ").strip()

        if q.lower() in {"exit", "quit"}:
            print("\n[QA] Exiting Q&A mode.")
            break

        if not q:
            print("Please type a question, or 'exit' to quit.\n")
            continue

        context_chunks: List[str] = []

        # 1) Direct policy_id lookup via POLICY_INDEX
        policy_ids = _extract_policy_ids_from_question(q)
        for pid in policy_ids:
            policy = POLICY_INDEX.get(pid)
            if policy is not None:
                context_chunks.append(
                    f"[POLICY_BY_ID policy_id={pid}]\n"
                    f"{json.dumps(policy, indent=2)}\n"
                )

        # 2) Vector search over policies and codes
        try:
            policy_docs = POLICY_VECTORSTORE.similarity_search_with_score(q, k=3)
        except Exception as e:
            print(f"[QA] Policy vector search error: {type(e).__name__}: {e}")
            policy_docs = []

        try:
            code_docs = CODES_VECTORSTORE.similarity_search_with_score(q, k=3)
        except Exception as e:
            print(f"[QA] Codes vector search error: {type(e).__name__}: {e}")
            code_docs = []

        for doc, score in policy_docs:
            pid = (doc.metadata or {}).get("policy_id")
            text = doc.page_content
            if len(text) > 1200:
                text = text[:1200] + "...(truncated)"
            context_chunks.append(
                f"[POLICY_RAG score={score:.3f}, policy_id={pid}]\n{text}\n"
            )

        for doc, score in code_docs:
            text = doc.page_content
            if len(text) > 1200:
                text = text[:1200] + "...(truncated)"
            context_chunks.append(
                f"[CODE_RAG score={score:.3f}, code_type={doc.metadata.get('code_type')}, "
                f"code={doc.metadata.get('code')}]\n{text}\n"
            )

        context_text = "\n\n---\n\n".join(context_chunks) or "(no retrieved context)"

        system_msg = (
            "You are a helpful assistant for healthcare policy and medical codes.\n"
            "Use ONLY the provided context to answer. If the answer is unclear or "
            "not covered, say you are not sure rather than hallucinating.\n"
        )

        user_msg = (
            f"User question:\n{q}\n\n"
            f"Retrieved context:\n{context_text}\n\n"
            "Now answer the user's question in a clear and concise way."
        )

        resp = llm.invoke(
            [
                SystemMessage(content=system_msg),
                HumanMessage(content=user_msg),
            ]
        )

        answer = extract_text_from_content(getattr(resp, "content", str(resp)))
        print("\n[ANSWER]")
        print(answer)
        print("\n" + "-" * 80 + "\n")


# ============================================================================#
# 10. MAIN: MENU + MODES
# ============================================================================#

def main() -> None:
    print("Select mode:")
    print("  1) Adjudicate claims (batch, ReAct + RAG)")
    print("  2) Policy / Code Q&A (interactive RAG chat)")
    mode_choice = input("Enter choice [1]: ").strip() or "1"

    if mode_choice == "2":
        run_policy_code_qa()
        return

    # === MODE 1: Adjudicate Claims ==================================#

    print("\nSelect model provider:")
    print("  1) Ollama (local)")
    print("  2) Google Gemini 2.5 (cloud)")
    print("  3) Both Ollama + Gemini")
    provider_choice = input("Enter choice [3]: ").strip() or "3"

    models_to_run: List[Tuple[BackendType, str]] = []

    if provider_choice in {"1", "3"}:
        models_to_run.extend(select_ollama_models())

    if provider_choice in {"2", "3"}:
        models_to_run.extend(select_gemini_models())

    if not models_to_run:
        print("\n[ERROR] No responsive models for chosen provider(s). Exiting.")
        return

    model_labels = [f"{backend.value}:{m}" for backend, m in models_to_run]
    print("\nModels selected for adjudication:", ", ".join(model_labels))

    # -------- interactive dataset choice ----------#
    choice = input("\nRun on (prod/test)? [prod]: ").strip().lower()
    if choice in ("test", "t"):
        dataset_name = "test"
        all_claims = TEST_CLAIMS
    else:
        dataset_name = "production"
        all_claims = PROD_CLAIMS

    total_claims = len(all_claims)
    default_str = str(total_claims)

    num_str = input(
        f"How many claims do you want to adjudicate? [all={default_str}]: "
    ).strip()

    if num_str:
        try:
            limit = int(num_str)
        except ValueError:
            limit = total_claims
            print(f"[WARN] Invalid number; defaulting to all={total_claims}.")
    else:
        limit = total_claims

    limit = max(1, min(limit, total_claims))
    claims_to_run = all_claims[:limit]

    n_claims = len(claims_to_run)
    print(
        f"\nRunning ReAct + Agentic RAG agent on {n_claims} {dataset_name} claims "
        f"(out of {total_claims})."
    )

    output_dir = BASE_DIR / "outputs"
    output_dir.mkdir(exist_ok=True)

    for backend, model_name in models_to_run:
        label = f"{backend.value}:{model_name}"
        print("\n" + "=" * 60)
        print(f"ReAct + RAG Adjudication Agent – Model: {label}")
        print("=" * 60)

        run_for_claim = create_simple_agent_runner(backend, model_name)

        safe_label = label.replace(":", "_").replace("/", "_")
        out_path = output_dir / f"adjudication_{dataset_name}_{safe_label}.jsonl"
        print(f"\n[INFO] Writing results for model {label} to: {out_path}")

        with out_path.open("w", encoding="utf-8") as f_out:
            for idx, claim in enumerate(claims_to_run, start=1):
                cid = claim.get("claim_id", f"idx_{idx}")
                pid = claim.get("policy_id", "")

                print(
                    f"\n--- Model {label} | Claim {idx}/{n_claims} "
                    f"| claim_id={cid} | policy_id={pid} ---"
                )

                start = time.time()
                res, _messages, ml_info = run_for_claim(claim, verbose=False)
                elapsed = time.time() - start

                if res:
                    print(f"Decision:  {res.decision}")
                    short_reason = (
                        res.reasoning[:300] + "..."
                        if len(res.reasoning) > 300
                        else res.reasoning
                    )
                    print(f"Reasoning: {short_reason}")
                    print(f"Time:      {elapsed:.2f}s")

                    record: Dict[str, Any] = {
                        "claim_id": cid,
                        "policy_id": pid,
                        "backend": backend.value,
                        "model": model_name,
                        "decision": res.decision,
                        "reasoning": res.reasoning,
                        "elapsed_sec": elapsed,
                    }
                else:
                    print(f"[ERROR] No result (took {elapsed:.2f}s)")
                    record = {
                        "claim_id": cid,
                        "policy_id": pid,
                        "backend": backend.value,
                        "model": model_name,
                        "decision": None,
                        "reasoning": None,
                        "error": "No result",
                        "elapsed_sec": elapsed,
                    }

                # Attach ML details if available
                if isinstance(ml_info, dict):
                    record.update(
                        {
                            "llm_decision": ml_info.get("llm_decision"),
                            "ml_model_name": ml_info.get("ml_model_name"),
                            "ml_status": ml_info.get("ml_status"),
                            "ml_decision": ml_info.get("ml_decision"),
                            "ml_raw_pred": ml_info.get("ml_raw_pred"),
                            "ml_proba_class1": ml_info.get("ml_proba_class1"),
                            "ml_error": ml_info.get("ml_error"),
                            "agree": ml_info.get("agree"),
                        }
                    )

                f_out.write(json.dumps(record) + "\n")

        print(
            f"\n[INFO] Completed model {label}. Results saved to: {out_path}\n"
        )


if __name__ == "__main__":
    main()
