"""Simple file-backed memory manager for experiments.

Each model has a JSON file under memory/data/<model>.json that stores a list
of interactions (timestamp, transcript, decision, metadata).
"""
from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List

MEMORY_DIR = os.path.join(os.path.dirname(__file__), "data")

os.makedirs(MEMORY_DIR, exist_ok=True)


def _model_path(model_name: str) -> str:
    safe = model_name.replace(":", "_").replace("/", "_")
    return os.path.join(MEMORY_DIR, f"{safe}.json")


def append_interaction(model_name: str, interaction: Dict[str, Any]) -> None:
    """Append an interaction dict to the model's memory file."""

    path = _model_path(model_name)
    now = time.time()
    entry = {"ts": now, **interaction}
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        else:
            data = []
        data.append(entry)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception:
        # Best-effort: do not raise in experiments
        pass


def read_memory(model_name: str) -> List[Dict[str, Any]]:
    """Read the model's memory file, return list of interactions.

    Returns empty list if no memory exists or on error.
    """

    path = _model_path(model_name)
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return []
