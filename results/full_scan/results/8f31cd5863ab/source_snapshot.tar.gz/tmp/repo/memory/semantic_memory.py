"""Semantic Memory for Policy Adjudication

This module reads a policies.json file and produces normalized "rule atoms"
for retrieval and adjudication. Each policy is denormalized into atomic facts
with strongly-typed fields and a simple TF-IDF based embedding/index for text fields.

Usage:
    python semantic_memory.py --policies policies.json --out data/

Input:
    policies.json - JSON file with policy entries containing fields:
        - policyid (str, required)
        - planname (str, required)
        - procedurecode (str, required)
        - covereddiagnosis (list[str], required)
        - agerange: {min: int, max: int} (required)
        - gender (str, required): "M"|"F"|"Any"
        - requirespreauthorization (bool, required)
        - notes (str, optional)
        - effective_from (str, optional): ISO date
        - effective_to (str, optional): ISO date
        - jurisdiction (str, optional)

Output:
    data/semantic_atoms.parquet: Normalized policy atoms
    data/semantic_index.pkl: Optional vector embeddings for text fields
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import pathlib
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set

import pandas as pd
from pydantic import BaseModel, Field, field_validator, model_validator

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Constants
DEFAULT_EFFECTIVE_FROM = "2020-01-01"  # Policies without dates start here
DEFAULT_EFFECTIVE_TO = "2099-12-31"    # ...and end here
REQUIRED_FIELDS = {"policyid", "planname", "procedurecode", "covereddiagnosis",
                  "agerange", "gender", "requirespreauthorization"}
VALID_GENDERS = {"M", "F", "Any", "*"}  # "Any" will be coerced to "*"
TEXT_FIELDS = ["planname", "notes", "procedurecode"]  # Fields to embed


class PolicyAtom(BaseModel):
    """Strongly-typed normalized policy atom.

    This is the core data model for semantic policy facts. Each field
    is validated and normalized during construction.
    """
    policyid: str = Field(..., min_length=1)
    planname: str = Field(..., min_length=1)
    procedurecode: str = Field(..., min_length=1)
    covereddiagnosis: List[str] = Field(..., min_length=1)
    agerange_min: int = Field(..., ge=0)
    agerange_max: int = Field(..., ge=0)
    gender: str = Field(..., pattern="^[MF*]$")
    requirespreauthorization: bool
    notes: Optional[str] = None
    effective_from: str = Field(DEFAULT_EFFECTIVE_FROM)
    effective_to: str = Field(DEFAULT_EFFECTIVE_TO)
    jurisdiction: Optional[str] = None

    @field_validator("gender", mode="before")
    def normalize_gender(cls, v: str) -> str:
        """Normalize gender field: coerce 'Any' to '*' wildcard."""
        if v not in VALID_GENDERS:
            raise ValueError(f"Invalid gender '{v}'. Must be one of: {VALID_GENDERS}")
        return "*" if v == "Any" else v

    @field_validator("agerange_max")
    def validate_age_range(cls, v: int, info) -> int:
        """Ensure agerange_max >= agerange_min."""
        min_val = info.data.get("agerange_min")
        if min_val is not None and v < min_val:
            raise ValueError(f"agerange_max ({v}) must be >= agerange_min ({min_val})")
        return v

    @field_validator("effective_from", "effective_to")
    def validate_date(cls, v: str) -> str:
        """Ensure date strings are ISO format."""
        try:
            datetime.fromisoformat(v.replace('Z', '+00:00'))
            return v
        except ValueError as e:
            raise ValueError(f"Invalid date format: {v}. Use ISO format (YYYY-MM-DD)") from e

    @field_validator("effective_to")
    def validate_date_range(cls, v: str, info) -> str:
        """Ensure effective_to >= effective_from."""
        from_date = info.data.get("effective_from")
        if from_date:
            from_dt = datetime.fromisoformat(from_date.replace('Z', '+00:00'))
            to_dt = datetime.fromisoformat(v.replace('Z', '+00:00'))
            if to_dt < from_dt:
                raise ValueError(f"effective_to ({v}) must be >= effective_from ({from_date})")
        return v


def load_policies(path: str) -> List[Dict[str, Any]]:
    """Load and validate policies from JSON file.

    Args:
        path: Path to policies.json file

    Returns:
        List of policy dictionaries

    Raises:
        ValueError: If file is missing required fields
        FileNotFoundError: If file does not exist
        json.JSONDecodeError: If file is not valid JSON
    """
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    if not isinstance(raw, dict) or "policies" not in raw:
        raise ValueError("policies.json must contain a 'policies' list")

    policies = raw["policies"]
    if not isinstance(policies, list):
        raise ValueError("policies.json 'policies' field must be a list")

    # Validate required fields
    for i, p in enumerate(policies):
        missing = REQUIRED_FIELDS - set(p.keys())
        if missing:
            raise ValueError(f"Policy at index {i} missing required fields: {missing}")

    return policies


def denormalize_policies(policies: List[Dict[str, Any]]) -> List[PolicyAtom]:
    """Convert policies into normalized atomic facts.

    Args:
        policies: List of policy dictionaries from load_policies()

    Returns:
        List of PolicyAtom objects with normalized fields

    Raises:
        ValueError: If any policy fails validation
    """
    atoms: List[PolicyAtom] = []
    seen_ids: Set[str] = set()

    for i, p in enumerate(policies):
        # Extract agerange min/max
        try:
            age_min = int(p["agerange"]["min"])
            age_max = int(p["agerange"]["max"])
        except (KeyError, ValueError, TypeError) as e:
            raise ValueError(f"Invalid agerange in policy {i}: {e}") from e

        # Ensure policyid uniqueness
        if p["policyid"] in seen_ids:
            raise ValueError(f"Duplicate policyid: {p['policyid']}")
        seen_ids.add(p["policyid"])

        # Convert to strongly-typed atom
        try:
            atom = PolicyAtom(
                policyid=p["policyid"],
                planname=p["planname"],
                procedurecode=p["procedurecode"],
                covereddiagnosis=p["covereddiagnosis"],
                agerange_min=age_min,
                agerange_max=age_max,
                gender=p["gender"],
                requirespreauthorization=bool(p["requirespreauthorization"]),
                notes=p.get("notes"),
                effective_from=p.get("effective_from", DEFAULT_EFFECTIVE_FROM),
                effective_to=p.get("effective_to", DEFAULT_EFFECTIVE_TO),
                jurisdiction=p.get("jurisdiction"),
            )
            atoms.append(atom)
        except ValueError as e:
            raise ValueError(f"Validation failed for policy {i}: {e}") from e

    return atoms


def build_embeddings(atoms: List[PolicyAtom], text_fields: Optional[List[str]] = None) -> Any:
    """Build vector embeddings for text fields in policy atoms.

    If chromadb is available, creates a collection with embeddings for the
    specified text fields. Falls back to a simple tf-idf if chromadb not found.

    Args:
        atoms: List of PolicyAtom objects
        text_fields: List of field names to embed (default: global TEXT_FIELDS)

    Returns:
        chromadb.Collection if available, else sklearn.TfidfVectorizer
    """
    if not text_fields:
        text_fields = TEXT_FIELDS

    # Validate field names
    invalid = set(text_fields) - set(PolicyAtom.model_json_schema()["properties"].keys())
    if invalid:
        raise ValueError(f"Invalid text fields: {invalid}")

    # Build TF-IDF vectors for the supplied text fields (simple, dependency-light)
    from sklearn.feature_extraction.text import TfidfVectorizer
    docs: List[str] = []
    for atom in atoms:
        text = " ".join(str(getattr(atom, f)) for f in text_fields if getattr(atom, f))
        docs.append(text)
    vectorizer = TfidfVectorizer(max_features=64)
    vectorizer.fit(docs)
    return vectorizer


def save_semantic(store_path: str, atoms: List[PolicyAtom], embeddings: Any = None) -> None:
    """Save normalized atoms and optional embeddings to disk.

    Args:
        store_path: Output directory path
        atoms: List of PolicyAtom objects
        embeddings: Optional embeddings object from build_embeddings()
    """
    os.makedirs(store_path, exist_ok=True)

    # Save normalized atoms as parquet
    df = pd.DataFrame([a.model_dump() for a in atoms])
    df.to_parquet(os.path.join(store_path, "semantic_atoms.parquet"), index=False)

    # Save embeddings if provided
    if embeddings is not None:
        import pickle
        with open(os.path.join(store_path, "semantic_index.pkl"), "wb") as f:
            pickle.dump(embeddings, f)


def main():
    """CLI entrypoint."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--policies", required=True, help="Path to policies.json input file")
    parser.add_argument("--out", required=True, help="Output directory for semantic store")
    parser.add_argument("--fields", nargs="+", help=f"Text fields to embed (default: {TEXT_FIELDS})")
    args = parser.parse_args()

    try:
        # Load and normalize
        logger.info("Loading policies from %s", args.policies)
        policies = load_policies(args.policies)

        logger.info("Denormalizing into atoms")
        atoms = denormalize_policies(policies)
        logger.info("Generated %d policy atoms", len(atoms))

        # Build embeddings
        logger.info("Building embeddings for fields: %s",
                   args.fields if args.fields else TEXT_FIELDS)
        embeddings = build_embeddings(atoms, text_fields=args.fields)

        # Save outputs
        logger.info("Saving semantic store to %s", args.out)
        save_semantic(args.out, atoms, embeddings)

    except Exception as e:
        logger.error("Failed to process policies: %s", e)
        raise


if __name__ == "__main__":
    main()