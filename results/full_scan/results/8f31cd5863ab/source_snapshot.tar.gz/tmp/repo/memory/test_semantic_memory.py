"""Unit tests for semantic memory policy normalization.

Tests that verify policy denormalization rules:
- Required fields present and correctly typed
- Age range validation
- Gender normalization (Any -> *)
- Default dates when missing
- Duplicate policy ID detection
"""
import json
import os
import shutil
from datetime import datetime
from pathlib import Path

import pytest
from memory.semantic_memory import (DEFAULT_EFFECTIVE_FROM, DEFAULT_EFFECTIVE_TO,
                           PolicyAtom, denormalize_policies, load_policies)

@pytest.fixture
def test_dir():
    """Create and clean up a temporary test directory."""
    test_dir = Path("test_data")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    test_dir.mkdir()
    yield test_dir
    shutil.rmtree(test_dir)

def test_load_policies_minimal(test_dir):
    """Test loading minimal valid policy."""
    test_file = test_dir / "minimal_policy.json"
    with open(test_file, "w", encoding="utf-8") as f:
        json.dump({
            "policies": [{
                "policyid": "P1",
                "planname": "Plan",
                "procedurecode": "CODE1",
                "covereddiagnosis": ["D1"],
                "agerange": {"min": 0, "max": 100},
                "gender": "Any",
                "requirespreauthorization": False
            }]
        }, f)
    policies = load_policies(str(test_file))
    assert len(policies) == 1
    assert policies[0]["policyid"] == "P1"


def test_load_policies_missing_required(test_dir):
    """Test loading policy with missing required field."""
    test_file = test_dir / "invalid_policy.json"
    with open(test_file, "w", encoding="utf-8") as f:
        json.dump({
            "policies": [{
                "policyid": "P1",
                # missing planname
                "procedurecode": "CODE1"
            }]
        }, f)
    with pytest.raises(ValueError, match=r".*missing required fields.*"):
        load_policies(str(test_file))


def test_denormalize_policies_age_validation():
    """Test age range validation during denormalization."""
    policies = [{
        "policyid": "P1",
        "planname": "Plan",
        "procedurecode": "CODE1",
        "covereddiagnosis": ["D1"],
        "agerange": {"min": 50, "max": 20},  # invalid: max < min
        "gender": "M",
        "requirespreauthorization": False
    }]
    with pytest.raises(ValueError, match=r".*must be >= agerange_min.*"):
        denormalize_policies(policies)


def test_denormalize_policies_gender_normalization():
    """Test gender field normalization (Any -> *)."""
    policies = [{
        "policyid": "P1",
        "planname": "Plan",
        "procedurecode": "CODE1",
        "covereddiagnosis": ["D1"],
        "agerange": {"min": 0, "max": 100},
        "gender": "Any",  # should become "*"
        "requirespreauthorization": False
    }]
    atoms = denormalize_policies(policies)
    assert len(atoms) == 1
    assert atoms[0].gender == "*"


def test_denormalize_policies_default_dates():
    """Test default effective dates when missing."""
    policies = [{
        "policyid": "P1",
        "planname": "Plan",
        "procedurecode": "CODE1",
        "covereddiagnosis": ["D1"],
        "agerange": {"min": 0, "max": 100},
        "gender": "M",
        "requirespreauthorization": False
        # no effective_from/to
    }]
    atoms = denormalize_policies(policies)
    assert len(atoms) == 1
    assert atoms[0].effective_from == DEFAULT_EFFECTIVE_FROM
    assert atoms[0].effective_to == DEFAULT_EFFECTIVE_TO


def test_denormalize_policies_duplicate_id():
    """Test duplicate policy ID detection."""
    policies = [
        {
            "policyid": "P1",  # duplicate ID
            "planname": "Plan1",
            "procedurecode": "CODE1",
            "covereddiagnosis": ["D1"],
            "agerange": {"min": 0, "max": 100},
            "gender": "M",
            "requirespreauthorization": False
        },
        {
            "policyid": "P1",  # duplicate ID
            "planname": "Plan2",
            "procedurecode": "CODE2",
            "covereddiagnosis": ["D2"],
            "agerange": {"min": 0, "max": 100},
            "gender": "F",
            "requirespreauthorization": True
        }
    ]
    with pytest.raises(ValueError, match=r".*Duplicate policyid.*"):
        denormalize_policies(policies)


def test_policy_atom_date_validation():
    """Test effective date range validation in PolicyAtom."""
    with pytest.raises(ValueError, match=r".*must be >= effective_from.*"):
        PolicyAtom(
            policyid="P1",
            planname="Plan",
            procedurecode="CODE1",
            covereddiagnosis=["D1"],
            agerange_min=0,
            agerange_max=100,
            gender="M",
            requirespreauthorization=False,
            effective_from="2024-01-01",
            effective_to="2023-12-31"  # invalid: before effective_from
        )


def test_policy_atom_diagnosis_validation():
    """Test covered diagnosis validation in PolicyAtom."""
    with pytest.raises(ValueError):
        PolicyAtom(
            policyid="P1",
            planname="Plan",
            procedurecode="CODE1",
            covereddiagnosis=[],  # invalid: empty list
            agerange_min=0,
            agerange_max=100,
            gender="M",
            requirespreauthorization=False
        )


def test_denormalize_policies_full():
    """Test full policy denormalization with all fields."""
    policies = [{
        "policyid": "POL123",
        "planname": "Comprehensive Plan",
        "procedurecode": "PROC456",
        "covereddiagnosis": ["D1", "D2", "D3"],
        "agerange": {"min": 18, "max": 65},
        "gender": "Any",
        "requirespreauthorization": True,
        "notes": "Some notes",
        "effective_from": "2023-01-01",
        "effective_to": "2024-12-31",
        "jurisdiction": "NY"
    }]
    
    atoms = denormalize_policies(policies)
    assert len(atoms) == 1
    atom = atoms[0]
    
    # Check all fields
    assert atom.policyid == "POL123"
    assert atom.planname == "Comprehensive Plan"
    assert atom.procedurecode == "PROC456"
    assert atom.covereddiagnosis == ["D1", "D2", "D3"]
    assert atom.agerange_min == 18
    assert atom.agerange_max == 65
    assert atom.gender == "*"  # normalized from "Any"
    assert atom.requirespreauthorization is True
    assert atom.notes == "Some notes"
    assert atom.effective_from == "2023-01-01"
    assert atom.effective_to == "2024-12-31"
    assert atom.jurisdiction == "NY"

    # Validate dates can be parsed
    from_dt = datetime.fromisoformat(atom.effective_from)
    to_dt = datetime.fromisoformat(atom.effective_to)
    assert to_dt > from_dt