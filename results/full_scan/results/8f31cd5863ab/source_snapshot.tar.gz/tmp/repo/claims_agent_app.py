# claims_agent_app.py
#
# Streamlit UI for simple_adjudication_agent.py
# - Single-claim and batch adjudication
# - Shows LLM model + ML output in a grid when the agent returns ML info
#   (decision, messages, ml_info). If your agent only returns (decision, messages),
#   ML columns will just be empty but the app still runs.
# - Gemini API key:
#     * Prefers GEMINI_API_KEY / GOOGLE_API_KEY from environment
#     * Can be overridden from the UI
#     * "Test Gemini key" button only checks Gemini connectivity

import os
import json
import time
from typing import List, Tuple, Dict, Any

import pandas as pd
import streamlit as st

from simple_adjudication_agent import (
    create_simple_agent_runner,
    select_ollama_models,
    select_gemini_models,
    TEST_CLAIMS,
    PROD_CLAIMS,
    BackendType,
    probe_gemini_model,
    GEMINI_CANDIDATE_MODELS,
)

# -------------------------------------------------------------------
# Gemini key handling: env first, then UI override
# -------------------------------------------------------------------

DEFAULT_GEMINI_ENV_KEY = (
    os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY") or ""
)

if "gemini_api_key" not in st.session_state:
    st.session_state["gemini_api_key"] = DEFAULT_GEMINI_ENV_KEY


# -------------------------------------------------------------------
# Streamlit page config + simple styling
# -------------------------------------------------------------------

st.set_page_config(
    page_title="Claims Adjudication Agent",
    page_icon="⚖️",
    layout="wide",
)

st.markdown(
    """
    <style>
    .big-title {
        font-size: 30px;
        font-weight: 800;
        background: linear-gradient(90deg, #00f5a0, #00d9f5);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.5rem;
    }
    .subtle-card {
        padding: 1rem 1.25rem;
        border-radius: 0.85rem;
        background-color: #0e1117;
        border: 1px solid #262730;
        margin-bottom: 0.75rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    '<div class="big-title">ReAct + RAG Claims Adjudication Dashboard</div>',
    unsafe_allow_html=True,
)
st.caption(
    "Local Ollama + Gemini LLMs with ML validation (best_claims_model.pkl)."
)


# -------------------------------------------------------------------
# Model discovery per provider (NOT cached so key changes take effect)
# -------------------------------------------------------------------

def get_models_for_provider(provider_choice: str) -> List[Tuple[BackendType, str]]:
    """
    Probe Ollama / Gemini depending on provider_choice:
        'Ollama', 'Gemini', or 'Both'.
    Not cached: respects Gemini key changes from the UI.
    """
    models: List[Tuple[BackendType, str]] = []

    if provider_choice in ("Ollama", "Both"):
        models.extend(select_ollama_models())

    if provider_choice in ("Gemini", "Both"):
        models.extend(select_gemini_models())

    return models


# -------------------------------------------------------------------
# Sidebar: dataset + providers + models + Gemini key
# -------------------------------------------------------------------

with st.sidebar:
    st.header("⚙️ Configuration")

    # Dataset choice
    dataset_label = st.radio(
        "Dataset",
        ["Production", "Test"],
        index=0,
    )

    if dataset_label == "Production":
        claims = PROD_CLAIMS
    else:
        claims = TEST_CLAIMS

    st.write(f"Total claims in **{dataset_label}** dataset: `{len(claims)}`")

    st.markdown("---")
    st.subheader("🤖 Models")

    # Provider choice
    provider_choice = st.radio(
        "LLM provider(s)",
        ["Ollama", "Gemini", "Both"],
        index=2,
        help="Same idea as CLI: run only Ollama, only Gemini, or both.",
    )

    # Gemini API key override from UI, only shown when Gemini is relevant
    if provider_choice in ("Gemini", "Both"):
        gemini_key = st.text_input(
            "Gemini API key (override)",
            type="password",
            value=st.session_state["gemini_api_key"],
            help=(
                "If left blank, the app will use GEMINI_API_KEY / GOOGLE_API_KEY "
                "from the environment where you launched Streamlit."
            ),
        )
        # Save latest to session
        st.session_state["gemini_api_key"] = gemini_key

        # Update process environment so simple_adjudication_agent sees it
        if gemini_key.strip():
            os.environ["GEMINI_API_KEY"] = gemini_key.strip()
            os.environ["GOOGLE_API_KEY"] = gemini_key.strip()

        # Button to only probe Gemini connectivity
        if st.button("Test Gemini key", key="btn_test_gemini"):
            test_model = (
                GEMINI_CANDIDATE_MODELS[0]
                if GEMINI_CANDIDATE_MODELS
                else "gemini-2.5-pro"
            )
            ok = probe_gemini_model(test_model)
            if ok:
                st.success(f"Gemini key looks OK (model `{test_model}` responded).")
            else:
                st.error(
                    "Gemini probe failed. Check key / network; "
                    "see terminal logs for details."
                )

    # Discover models AFTER key handling so new key is used
    models_for_provider = get_models_for_provider(provider_choice)

    if not models_for_provider:
        st.error(
            "No responsive models detected for this provider choice.\n\n"
            "• For Ollama: check that the Ollama service is running and models are pulled.\n"
            "• For Gemini: ensure GEMINI_API_KEY / GOOGLE_API_KEY is set "
            "or provided via the sidebar field."
        )
        st.stop()

    # If user asked for Gemini but none detected, show a clear warning.
    if provider_choice in ("Gemini", "Both") and not any(
        b is BackendType.GEMINI for (b, _) in models_for_provider
    ):
        st.warning(
            "Gemini selected, but no responsive Gemini model was found.\n\n"
            "Check:\n"
            "  • Gemini API key (sidebar field)\n"
            "  • Environment variable GEMINI_API_KEY or GOOGLE_API_KEY\n"
            "  • Internet connectivity / firewall\n"
            "  • Any errors in the terminal (look for 'Probing Gemini model ... SKIP')."
        )

    # Build label → (backend, model_name) map for multiselect
    model_label_map: Dict[str, Tuple[BackendType, str]] = {}
    for backend, name in models_for_provider:
        label = f"{backend.value}:{name}"
        model_label_map[label] = (backend, name)

    model_labels = list(model_label_map.keys())

    selected_model_labels = st.multiselect(
        "Select LLM models to run",
        options=model_labels,
        default=model_labels,  # select all by default
    )

    if not selected_model_labels:
        st.warning("Select at least one model from the list above.")
        st.stop()

    selected_models: List[Tuple[BackendType, str]] = [
        model_label_map[label] for label in selected_model_labels
    ]


# -------------------------------------------------------------------
# Helpers: run agent (single & batch) and extract ML info if available
# -------------------------------------------------------------------

def _call_runner_with_optional_ml(
    runner, claim: Dict[str, Any]
) -> Tuple[Any, List[Any], Dict[str, Any]]:
    """
    Call runner(claim, verbose=False) and be robust to:
        - (decision, messages)
        - (decision, messages, ml_info)
    Returns (decision, messages, ml_info_dict).
    """
    out = runner(claim, verbose=False)

    decision = None
    messages: List[Any] = []
    ml_info: Dict[str, Any] = {}

    if isinstance(out, tuple):
        # Safely unpack 2- or 3-tuple
        if len(out) == 3:
            decision, messages, ml_info = out
        elif len(out) == 2:
            decision, messages = out
        elif len(out) >= 1:
            decision = out[0]
            if len(out) >= 2:
                messages = out[1]
            if len(out) >= 3 and isinstance(out[2], dict):
                ml_info = out[2]
    else:
        # Fallback: treat as decision only
        decision = out

    if not isinstance(ml_info, dict):
        ml_info = {}

    return decision, messages, ml_info


def run_single_claim(
    claim: Dict[str, Any],
    models: List[Tuple[BackendType, str]],
) -> pd.DataFrame:
    """
    Run the adjudication agent for a single claim across multiple models.

    Returns:
        DataFrame with one row per (model, claim) containing:
            - backend, llm_model
            - claim_id, policy_id
            - final_decision, final_reasoning
            - llm_decision, ml_decision, ml_proba_class1, agree
            - elapsed_sec, error
    """
    rows: List[Dict[str, Any]] = []

    for backend, model_name in models:
        label = f"{backend.value}:{model_name}"
        runner = create_simple_agent_runner(backend, model_name)

        start = time.time()
        try:
            decision, messages, ml_info = _call_runner_with_optional_ml(runner, claim)
            elapsed = time.time() - start

            if decision is None:
                row = {
                    "backend": backend.value,
                    "llm_model": model_name,
                    "claim_id": claim.get("claim_id"),
                    "policy_id": claim.get("policy_id"),
                    "final_decision": None,
                    "final_reasoning": None,
                    "llm_decision": ml_info.get("llm_decision"),
                    "ml_decision": ml_info.get("ml_decision"),
                    "ml_proba_class1": ml_info.get("ml_proba_class1"),
                    "agree": ml_info.get("agree"),
                    "elapsed_sec": elapsed,
                    "error": "No result",
                }
            else:
                row = {
                    "backend": backend.value,
                    "llm_model": model_name,
                    "claim_id": claim.get("claim_id"),
                    "policy_id": claim.get("policy_id"),
                    "final_decision": getattr(decision, "decision", None),
                    "final_reasoning": getattr(decision, "reasoning", None),
                    "llm_decision": ml_info.get("llm_decision"),
                    "ml_decision": ml_info.get("ml_decision"),
                    "ml_proba_class1": ml_info.get("ml_proba_class1"),
                    "agree": ml_info.get("agree"),
                    "elapsed_sec": elapsed,
                    "error": None,
                }
        except Exception as e:
            elapsed = time.time() - start
            row = {
                "backend": backend.value,
                "llm_model": model_name,
                "claim_id": claim.get("claim_id"),
                "policy_id": claim.get("policy_id"),
                "final_decision": None,
                "final_reasoning": None,
                "llm_decision": None,
                "ml_decision": None,
                "ml_proba_class1": None,
                "agree": None,
                "elapsed_sec": elapsed,
                "error": f"{type(e).__name__}: {e}",
            }

        rows.append(row)

    df = pd.DataFrame(rows)
    return df


def run_batch(
    claims_subset: List[Dict[str, Any]],
    models: List[Tuple[BackendType, str]],
    progress_placeholder,
) -> pd.DataFrame:
    """
    Run multiple claims across multiple models.

    Returns:
        DataFrame with one row per (model, claim).
    """
    rows: List[Dict[str, Any]] = []
    total = len(claims_subset) * len(models)
    done = 0

    for claim_idx, claim in enumerate(claims_subset, start=1):
        for backend, model_name in models:
            label = f"{backend.value}:{model_name}"
            runner = create_simple_agent_runner(backend, model_name)
            start = time.time()

            try:
                decision, messages, ml_info = _call_runner_with_optional_ml(
                    runner, claim
                )
                elapsed = time.time() - start

                if decision is None:
                    row = {
                        "backend": backend.value,
                        "llm_model": model_name,
                        "claim_index": claim_idx,
                        "claim_id": claim.get("claim_id"),
                        "policy_id": claim.get("policy_id"),
                        "final_decision": None,
                        "final_reasoning": None,
                        "llm_decision": ml_info.get("llm_decision"),
                        "ml_decision": ml_info.get("ml_decision"),
                        "ml_proba_class1": ml_info.get("ml_proba_class1"),
                        "agree": ml_info.get("agree"),
                        "elapsed_sec": elapsed,
                        "error": "No result",
                    }
                else:
                    row = {
                        "backend": backend.value,
                        "llm_model": model_name,
                        "claim_index": claim_idx,
                        "claim_id": claim.get("claim_id"),
                        "policy_id": claim.get("policy_id"),
                        "final_decision": getattr(decision, "decision", None),
                        "final_reasoning": getattr(decision, "reasoning", None),
                        "llm_decision": ml_info.get("llm_decision"),
                        "ml_decision": ml_info.get("ml_decision"),
                        "ml_proba_class1": ml_info.get("ml_proba_class1"),
                        "agree": ml_info.get("agree"),
                        "elapsed_sec": elapsed,
                        "error": None,
                    }
            except Exception as e:
                elapsed = time.time() - start
                row = {
                    "backend": backend.value,
                    "llm_model": model_name,
                    "claim_index": claim_idx,
                    "claim_id": claim.get("claim_id"),
                    "policy_id": claim.get("policy_id"),
                    "final_decision": None,
                    "final_reasoning": None,
                    "llm_decision": None,
                    "ml_decision": None,
                    "ml_proba_class1": None,
                    "agree": None,
                    "elapsed_sec": elapsed,
                    "error": f"{type(e).__name__}: {e}",
                }

            rows.append(row)
            done += 1
            if progress_placeholder is not None:
                progress_placeholder.progress(done / total)

    df = pd.DataFrame(rows)
    return df


# -------------------------------------------------------------------
# Main layout: tabs for Single vs Batch
# -------------------------------------------------------------------

tab_single, tab_batch = st.tabs(["🔍 Single Claim", "📦 Batch Run"])

# ------------------------- Single Claim Tab -------------------------#
with tab_single:
    st.subheader("Single Claim Adjudication")

    if not claims:
        st.warning("No claims found in the selected dataset.")
    else:
        # Build a friendly dropdown label
        options = [
            f"{idx}: {c.get('claim_id', '<no id>')} (policy {c.get('policy_id', '-')})"
            for idx, c in enumerate(claims)
        ]
        sel = st.selectbox(
            "Select a claim",
            options=options,
            index=0,
        )

        sel_idx = int(sel.split(":")[0])
        claim = claims[sel_idx]

        with st.expander("View raw claim JSON", expanded=False):
            st.json(claim)

        if st.button("Run adjudication for this claim", type="primary"):
            with st.spinner("Running agent for selected claim..."):
                df_single = run_single_claim(claim, selected_models)

            st.success("Run completed. See model + ML grid below.")
            st.dataframe(
                df_single[
                    [
                        "backend",
                        "llm_model",
                        "claim_id",
                        "policy_id",
                        "final_decision",
                        "llm_decision",
                        "ml_decision",
                        "ml_proba_class1",
                        "agree",
                        "elapsed_sec",
                        "error",
                    ]
                ],
                use_container_width=True,
            )

            # Optional: show detailed reasoning per model
            with st.expander("Detailed reasoning (final_reasoning) per model"):
                for _, row in df_single.iterrows():
                    st.markdown(f"**{row['backend']}:{row['llm_model']}**")
                    st.write(row.get("final_reasoning"))


# ------------------------- Batch Tab -------------------------#
with tab_batch:
    st.subheader("Batch Adjudication")

    if not claims:
        st.warning("No claims found in the selected dataset.")
    else:
        max_claims = len(claims)
        default_n = min(10, max_claims)

        n_to_run = st.number_input(
            "Number of claims to run (from start of dataset)",
            min_value=1,
            max_value=max_claims,
            value=default_n,
            step=1,
        )

        if st.button("Run batch on selected models", type="primary"):
            subset = claims[:n_to_run]

            progress = st.progress(0.0)
            with st.spinner(
                f"Running batch ({len(subset)} claims × {len(selected_models)} models)..."
            ):
                df_batch = run_batch(subset, selected_models, progress)

            st.success(
                "Batch run completed. Grid below shows all (model, claim) results."
            )
            st.dataframe(
                df_batch[
                    [
                        "claim_index",
                        "claim_id",
                        "policy_id",
                        "backend",
                        "llm_model",
                        "final_decision",
                        "llm_decision",
                        "ml_decision",
                        "ml_proba_class1",
                        "agree",
                        "elapsed_sec",
                        "error",
                    ]
                ],
                use_container_width=True,
            )

            # Simple aggregate: agreement rate & decision counts
            with st.expander("Batch summary"):
                if "agree" in df_batch.columns:
                    st.write("Agreement (LLM vs ML):")
                    st.write(df_batch["agree"].value_counts(dropna=False))

                if "final_decision" in df_batch.columns:
                    st.write("Final decision distribution:")
                    st.write(df_batch["final_decision"].value_counts(dropna=False))
