"""Claim Adjudication Agent

This module runs multi-model experiments for an insurance claim adjudication
task: compare candidate models on correctness (PASS/DENY), reasoning quality,
latency, and robustness. It supports two execution modes:

- Tool-enabled agent: models that support tool/function calling use tools to
  fetch CLAIM and POLICY data before deciding.
- Prompt-only fallback: models that do not support tools receive the claim and
  policy in the prompt and must return STRICT JSON.

Features:
- Centralized ground-truth (CLAIM, POLICY, EXPECTED_DECISION) used for tests
  (not used in production).
- Robust JSON extraction from model responses (handles wrapped commentary).
- Timeouts for model runs (Windows-compatible implementation).
- Simple weighted scorer to pick the best model for production and persist
  selection to `best_model.txt`.

Usage:
    python claim_adjudication_agent.py

Notes:
 - This file is intended for experimentation/offline evaluation. In production,
   do NOT pass EXPECTED_DECISION to live calls; instead use the selected
   `best_model.txt` to route live decisions.
"""

from __future__ import annotations

import json
import time
import threading
import _thread
import os
import pathlib
from datetime import datetime
from typing import Any, Dict, Optional, List, Tuple

from pydantic import BaseModel, Field
from langchain_core.messages import BaseMessage, AIMessage, HumanMessage, ToolMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END, MessagesState
from langgraph.prebuilt import ToolNode

from memory.semantic_memory import PolicyAtom, build_embeddings, load_policies, denormalize_policies

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------
# Models that are known to support Ollama-style tools/function-calling
TOOL_CAPABLE_MODELS = {
    "qwen2.5:3b": True,
    "neural-chat:7b": False,
    "mistral:7b-instruct": False,
    "codellama:7b": False,
    "llama2:7b": False,
}

# Candidate models to evaluate (order: prefer smaller/fast first)
CANDIDATE_MODELS = [
    "qwen2.5:3b",
    "neural-chat:7b",
    "mistral:7b-instruct",
    "llama2:7b",
]

# Judge model (used to synthesize a verdict during experimentation)
JUDGE_MODEL = "qwen2.5:3b"

# Timeouts (seconds)
MODEL_TIMEOUT = 180
JUDGE_TIMEOUT = 120

# Centralized test ground-truth (used for offline experiments only)
CLAIM = {"name": "Arun Kumar", "age": 36, "policyId": "POL-7788"}
POLICY = {"policyNumber": "POL-7788", "ageMin": 18, "ageMax": 60}
EXPECTED_DECISION = "PASS"

BASE_URL = "http://localhost:11434/v1"
API_KEY = "ollama"
RECURSION_LIMIT = 100

VERBOSE = True
TOOL_UNSUPPORTED_MSG = "does not support tools"
USER_TASK = "Check if the claim should PASS or DENY using the policy rules. Return ONLY JSON."


# ----------------------------------------------------------------------------
# Data models
# ----------------------------------------------------------------------------
class Decision(BaseModel):
    """Schema for model decisions.

    decision must be either PASS or DENY and reason is a short string.
    """

    decision: str = Field(pattern=r"^(PASS|DENY)$")
    reason: str


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
def _thread_interrupt_main():
    """Interrupt the main thread (used by our timeout implementation)."""

    _thread.interrupt_main()


def _content(x: BaseMessage | dict) -> str:
    """Return the textual content of a LangChain message or raw dict."""

    if isinstance(x, dict):
        return str(x.get("content", ""))
    return str(getattr(x, "content", ""))


def _h(title: str):
    """Verbose header printer used throughout the script."""

    if VERBOSE:
        print("\n" + "=" * 10 + f" {title} " + "=" * 10 + "\n")


def _transcript(model_tag: str, messages: List[BaseMessage | dict]):
    """Pretty-print a model transcript (used when VERBOSE=True)."""

    if not VERBOSE:
        return
    _h(f"{model_tag} :: TRANSCRIPT")
    for m in messages:
        role = type(m).__name__ if not isinstance(m, dict) else m.get("role", "")
        print(f"[{role.lower()}]\n{_content(m)}\n")
        if isinstance(m, AIMessage) and getattr(m, "tool_calls", None):
            try:
                print("  tool_calls:", json.dumps(m.tool_calls, indent=2))
            except Exception:
                print("  tool_calls:", m.tool_calls)


def safe_parse_json(s: str) -> dict:
    """Extract and parse the first JSON object found in the string.

    Many models append commentary to the JSON. This helper finds the first
    '{' and last '}' and attempts to parse the substring.
    """

    if not s:
        raise ValueError("Empty string")
    i = s.find("{")
    j = s.rfind("}")
    if i == -1 or j == -1 or j < i:
        raise ValueError("No JSON object found")
    sub = s[i:j + 1]
    return json.loads(sub)


def load_prompt(name: str) -> str:
    """Load a prompt file from the `prompts/` directory next to this module.

    Falls back to empty string if file not found.
    """

    p = pathlib.Path(__file__).parent / "prompts" / f"{name}.txt"
    try:
        return p.read_text(encoding="utf-8")
    except Exception:
        return ""


# ----------------------------------------------------------------------------
# Tool-enabled agent (uses LangGraph state-machine + tools)
# ----------------------------------------------------------------------------
def create_agent_runner(model_tag: str):
    """Create a runner that uses tools (get_claim/get_policy) with the model.

    Returns a callable run(user_content) -> (Decision|None, messages, latency_s, error_str)
    """

    llm = ChatOpenAI(model=model_tag, api_key=API_KEY, base_url=BASE_URL, temperature=0.0, max_tokens=384)

    last_claim: Optional[Dict[str, Any]] = None
    last_policy: Optional[Dict[str, Any]] = None

    @tool
    def get_claim() -> Dict[str, Any]:
        """Tool: return the CLAIM used for this experiment (centralized)."""

        nonlocal last_claim
        last_claim = CLAIM
        return last_claim

    @tool
    def get_policy() -> Dict[str, Any]:
        """Tool: return the POLICY used for this experiment (centralized)."""

        nonlocal last_policy
        last_policy = POLICY
        return last_policy

    @tool
    def compare_policy_claim() -> Dict[str, Any]:
        """Tool: compare the last CLAIM and POLICY using a dedicated lightweight model ('llom').

        This tool calls the `llom` model to perform focused reasoning: verify whether the
        CLAIM satisfies the POLICY rules and return a short structured verdict and explanation.
        The agent should call this tool after get_claim() and get_policy().
        """

        # Use a small focused model for comparison/ reasoning
        try:
            llm_compare = ChatOpenAI(model="llom", api_key=API_KEY, base_url=BASE_URL, temperature=0.0, max_tokens=256, request_timeout=60)
            sys = (
                "You are a compact policy-checker assistant.\n"
                "You will be given a CLAIM and a POLICY.\n"
                "Return a STRICT JSON object with keys: {\"matches\": true|false, \"explanation\": \"short reason\"}.\n"
            )
            user = f"CLAIM: {json.dumps(last_claim)}\nPOLICY: {json.dumps(last_policy)}\nPlease state whether the claim meets the policy rules."
            resp = llm_compare.invoke([{"role": "system", "content": sys}, {"role": "user", "content": user}])
            txt = _content(resp)
            try:
                parsed = safe_parse_json(txt)
                return parsed
            except Exception:
                # Fallback: return a simple explanation when parsing fails
                return {"matches": False, "explanation": txt[:200]}
        except Exception as e:
            return {"matches": False, "explanation": f"Compare tool failed: {type(e).__name__}: {e}"}

    tools = [get_claim, get_policy, compare_policy_claim]
    tool_node = ToolNode(tools)
    llm_with_tools = llm.bind_tools(tools)

    SYSTEM = load_prompt("agent_system") or (
        "You are a claims adjudication assistant using ReAct.\n"
        "Fetch CLAIM and POLICY using tools and then decide PASS or DENY.\n"
        "Rules:\n"
        "- Call get_claim(), then get_policy(), then compare_policy_claim().\n"
        "- Use ONLY tool Observations and the compare tool's output to form your final decision.\n"
        "- Final message MUST be STRICT JSON only: {\"decision\":\"PASS|DENY\",\"reason\":\"<short>\"}.\n"
    )

    def agent_node(state: MessagesState) -> dict:
        resp = llm_with_tools.invoke([{"role": "system", "content": SYSTEM}] + state["messages"])
        return {"messages": [resp]}

    def route(state: MessagesState) -> str:
        last = state["messages"][-1]
        if isinstance(last, AIMessage) and getattr(last, "tool_calls", None):
            return "tools"
        if last_claim is None or last_policy is None:
            return "controller"
        c = _content(last).strip()
        return "finalize" if c.startswith("{") else "ask_final"

    def controller_node(state: MessagesState) -> dict:
        # Force tools to be called in order: get_claim -> get_policy -> compare_policy_claim
        if last_claim is None:
            forced = AIMessage(content="", tool_calls=[{"id": "force_get_claim", "type": "tool_call", "name": "get_claim", "args": {}}])
        elif last_policy is None:
            forced = AIMessage(content="", tool_calls=[{"id": "force_get_policy", "type": "tool_call", "name": "get_policy", "args": {}}])
        elif not any(isinstance(m, AIMessage) and getattr(m, "tool_calls", None) and any(tc.get("name") == "compare_policy_claim" for tc in m.tool_calls) for m in state["messages"]):
            # If compare tool hasn't been invoked yet, force it
            forced = AIMessage(content="", tool_calls=[{"id": "force_compare", "type": "tool_call", "name": "compare_policy_claim", "args": {}}])
        else:
            forced = AIMessage(content="")
        return {"messages": [forced]}

    def ask_final_node(state: MessagesState) -> dict:
        prompt = "Return ONLY the strict JSON decision now."
        resp = llm.invoke([{"role": "user", "content": prompt}])
        return {"messages": [resp]}

    def finalize_node(state: MessagesState) -> dict:
        raw = _content(state["messages"][-1])
        try:
            data = safe_parse_json(raw)
            out = Decision(**data).model_dump()
        except Exception:
            out = Decision(decision="DENY", reason="Non-JSON or invalid schema").model_dump()
        return {"messages": [{"role": "assistant", "content": json.dumps(out)}]}

    # Architecture (ReAct-style state machine):
    # Start --> agent
    # agent --(if needs data)--> loop with --> tool (calls tools in order)
    # agent --(after tools/observations)--> finalize --> END
    # In graph terms: entry=agent, agent can route to controller (which forces tools),
    # tools node returns observations back to agent (loop), and agent finally routes to finalize/END.
    graph = StateGraph(MessagesState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", tool_node)
    graph.add_node("controller", controller_node)
    graph.add_node("ask_final", ask_final_node)
    graph.add_node("finalize", finalize_node)

    graph.set_entry_point("agent")
    graph.add_conditional_edges("agent", route, {"tools": "tools", "controller": "controller", "ask_final": "ask_final", "finalize": "finalize"})
    graph.add_edge("controller", "tools")
    graph.add_edge("tools", "agent")
    graph.add_edge("ask_final", "finalize")
    graph.add_edge("finalize", END)

    app = graph.compile()

    def run(user_content: str) -> Tuple[Decision | None, List[BaseMessage | dict], float, str]:
        t0 = time.perf_counter()
        err = ""
        try:
            result = app.invoke({"messages": [{"role": "user", "content": user_content}]}, config={"recursion_limit": RECURSION_LIMIT})
            messages = result["messages"]
        except Exception as e:
            messages = []
            err = f"{type(e).__name__}: {e}"
        dt = time.perf_counter() - t0
        if VERBOSE:
            _transcript(model_tag, messages)
        for m in reversed(messages):
            c = _content(m).strip()
            if c.startswith("{"):
                try:
                    return Decision(**json.loads(c)), messages, dt, err
                except Exception:
                    break
        return None, messages, dt, err

    return run


# ----------------------------------------------------------------------------
# Prompt-only fallback runner
# ----------------------------------------------------------------------------
class PromptOnlyRunner:
    """Runner for models that don't support tools: supplies CLAIM/POLICY in prompt."""

    def __init__(self, model_tag: str):
        self.model_tag = model_tag
        self.llm = ChatOpenAI(model=model_tag, api_key=API_KEY, base_url=BASE_URL, temperature=0.0, max_tokens=384, request_timeout=180)

    def __call__(self, user_content: str) -> Tuple[Decision | None, List[BaseMessage | dict], float, str]:
        claim = CLAIM
        policy = POLICY
        sys = load_prompt("prompt_only_system") or (
            "You are a claims adjudication model. Decide PASS or DENY based only on the provided CLAIM and POLICY.\n"
            "Return ONLY strict JSON: {\"decision\":\"PASS|DENY\",\"reason\":\"<short>\"}."
        )
        usr = (f"CLAIM: {json.dumps(claim)}\n" f"POLICY: {json.dumps(policy)}\n" f"TASK: {user_content}")
        t0 = time.perf_counter()
        try:
            resp = self.llm.invoke([{"role": "system", "content": sys}, {"role": "user", "content": usr}])
            dt = time.perf_counter() - t0
            if VERBOSE:
                _h(f"{self.model_tag} :: PROMPT-ONLY")
                print("[system]\n" + sys + "\n")
                print("[user]\n" + usr + "\n")
                print("[ai]\n" + _content(resp) + "\n")
            c = _content(resp).strip()
            try:
                parsed = safe_parse_json(c)
                return Decision(**parsed), [resp], dt, ""
            except Exception as e:
                return Decision(decision="DENY", reason="Non-JSON or invalid schema"), [resp], dt, f"ParseError: {e}"
        except Exception as e:
            dt = time.perf_counter() - t0
            return None, [], dt, f"{type(e).__name__}: {e}"


# ----------------------------------------------------------------------------
# Judge / evaluator (offline testing)
# ----------------------------------------------------------------------------
def evaluate_models(judge_tag: str, payload: Dict[str, Any]) -> str:
    """Ask a judge model to evaluate candidates against the provided ground-truth.

    The payload should include keys: task, candidates, claim, policy, expected_decision.
    Returns the judge's raw JSON string (extracted from model output when possible).
    """

    try:
        with timeout(JUDGE_TIMEOUT, f"Judge({judge_tag})"):
            judge = ChatOpenAI(model=judge_tag, api_key=API_KEY, base_url=BASE_URL, temperature=0.0, max_tokens=512, request_timeout=120)
            system = load_prompt("judge_system") or (
                "You are a strict evaluation judge comparing model performance.\n"
                "You are GIVEN the CLAIM and POLICY and the expected (ground-truth) decision computed from them.\n"
                "First, compute the correct decision from the POLICY and CLAIM. Then compare each candidate's JSON decision against that ground truth.\n"
                "Evaluate models on these criteria:\n"
                "1. Correctness: does the model's decision match the expected decision exactly (PASS or DENY) and is the JSON valid?\n"
                "2. Reasoning: quality and relevance of the reason field (short and accurate).\n"
                "3. Efficiency: latency and whether tools were used correctly.\n"
                "4. Robustness: absence of errors and proper adherence to instructions (JSON-only).\n"
                "\n"
                "Return STRICT JSON with exactly these keys (no extra keys):\n"
                '{\n' '  "winner_model": "<name>",\n' '  "reasoning": "<detailed analysis>",\n' '  "per_model_notes": {\n' '    "<model1>": "<strengths and weaknesses>",\n' '    "<model2>": "<strengths and weaknesses>"\n' '  },\n' '  "rankings": ["1st_model", "2nd_model", ...],\n' '  "pick": "Use <name> because <reason>"\n' '}'
            )
            user = (
                "Task:\n" + payload["task"] + "\n\n" +
                "CLAIM:\n" + json.dumps(payload.get("claim", {}), indent=2) + "\n\n" +
                "POLICY:\n" + json.dumps(payload.get("policy", {}), indent=2) + "\n\n" +
                "EXPECTED_DECISION:\n" + json.dumps(payload.get("expected_decision", "")) + "\n\n" +
                "Candidates:\n" + json.dumps(payload["candidates"], indent=2)
            )
            resp = judge.invoke([{"role": "system", "content": system}, {"role": "user", "content": user}])
            c = _content(resp)
            i, j = c.find("{"), c.rfind("}")
            if i != -1 and j != -1:
                return c[i:j + 1]
    except TimeoutError as e:
        return json.dumps({
            "winner_model": next(iter(payload["candidates"].keys()), ""),
            "reasoning": f"Judge evaluation timed out after {JUDGE_TIMEOUT}s",
            "per_model_notes": {},
            "rankings": list(payload["candidates"].keys()),
            "pick": "Unable to complete full evaluation due to timeout",
        })
    except Exception as e:
        return json.dumps({
            "winner_model": next(iter(payload["candidates"].keys()), ""),
            "reasoning": f"Judge evaluation failed: {str(e)}",
            "per_model_notes": {},
            "rankings": list(payload["candidates"].keys()),
            "pick": "Unable to complete evaluation due to error",
        })
    # Fallback: if judge didn't return JSON, return a default structure
    first = next(iter(payload["candidates"].keys()), "")
    return json.dumps({
        "winner_model": first,
        "reasoning": "Judge returned non-JSON; defaulting to first candidate",
        "per_model_notes": {},
        "pick": f"Use {first} for this task",
    })


# ----------------------------------------------------------------------------
# Timeout context manager (threading-based, Windows compatible)
# ----------------------------------------------------------------------------
from contextlib import contextmanager


@contextmanager
def timeout(seconds: int, model_name: str):
    """Context manager that raises TimeoutError if block runs longer than seconds.

    Uses a background Timer that interrupts the main thread.
    """

    timer = threading.Timer(seconds, _thread_interrupt_main)
    timer.start()
    try:
        yield
    except KeyboardInterrupt:
        raise TimeoutError(f"Model {model_name} timed out after {seconds} seconds")
    finally:
        timer.cancel()


# ----------------------------------------------------------------------------
# Model experiment runner and selection logic
# ----------------------------------------------------------------------------
def select_best_model(results: Dict[str, Dict[str, Any]], expected: str) -> Tuple[str, Dict[str, float]]:
    """Score models and pick the best for production.

    Scores are computed using weighted sum: correctness (0.7), latency (0.2), robustness (0.1).
    """

    names = list(results.keys())
    latencies = [results[n].get("latency_sec") or 0 for n in names]
    if latencies:
        min_l, max_l = min(latencies), max(latencies)
        denom = (max_l - min_l) if max_l > min_l else 1.0
        latency_scores = {n: 1.0 - ((results[n].get("latency_sec") or 0) - min_l) / denom for n in names}
    else:
        latency_scores = {n: 1.0 for n in names}

    scores: Dict[str, float] = {}
    for n in names:
        r = results[n]
        try:
            decision = (r.get("decision_json") or {}).get("decision")
        except Exception:
            decision = None
        correctness = 1.0 if decision == expected else 0.0
        robustness = 1.0 if (not r.get("error") and r.get("success")) else 0.0
        latency_score = latency_scores.get(n, 0.0)
        w_correctness = 0.7
        w_latency = 0.2
        w_robust = 0.1
        score = w_correctness * correctness + w_latency * latency_score + w_robust * robustness
        scores[n] = round(score, 4)

    best = max(sorted(names), key=lambda x: (scores.get(x, 0.0), - (results[x].get("latency_sec") or 0)))
    return best, scores


def initialize_semantic_memory() -> None:
    """Initialize semantic memory and verify it's working."""
    try:
        # Create a test atom to verify storage works
        test_atom = PolicyAtom(
            policyid="test-init",
            planname="INIT",
            procedurecode="TEST",
            covereddiagnosis=["TEST"],
            agerange_min=0,
            agerange_max=100,
            gender="*",
            requirespreauthorization=False,
            notes="Semantic memory initialization test",
            effective_from=datetime.now().isoformat()
        )
        embeddings = build_embeddings([test_atom])
        print("✓ Semantic memory initialized successfully")
        return True
    except Exception as e:
        print(f"⚠ Failed to initialize semantic memory: {str(e)}")
        return False

def main() -> None:
    """Run experiments across candidate models and pick the best model for production.

    This function is intended for offline evaluation; it writes the selected model
    to `best_model.txt` for use by production processes.
    """

    # Initialize semantic memory
    if not initialize_semantic_memory():
        print("⚠ Warning: Proceeding without semantic memory")

    # Initialize runners
    runners: Dict[str, Any] = {}
    for m in CANDIDATE_MODELS:
        _h(f"INITIALIZING {m}")
        if TOOL_CAPABLE_MODELS.get(m, False):
            try:
                runners[m] = create_agent_runner(m)
                print(f"✓ Initialized {m} with tool support")
            except Exception as e:
                print(f"✗ Failed to initialize {m} with tools, falling back to prompt-only: {str(e)}")
                runners[m] = PromptOnlyRunner(m)
        else:
            runners[m] = PromptOnlyRunner(m)
            print(f"ℹ Initialized {m} in prompt-only mode (no tool support)")

    results: Dict[str, Dict[str, Any]] = {}
    successful_runs = 0
    total_runs = len(runners)

    for m, run in runners.items():
        _h(f"RUN {m}")
        try:
            with timeout(MODEL_TIMEOUT, m):
                decision, transcript, latency_s, error = run(USER_TASK)
                success = bool(decision and not error)
                if success:
                    successful_runs += 1
                results[m] = {
                    "decision_json": decision.model_dump() if decision else None,
                    "latency_sec": round(latency_s, 3),
                    "error": error,
                    "transcript_len": len(transcript),
                    "success": success,
                    "used_tools": any(isinstance(msg, ToolMessage) for msg in transcript) if transcript else False,
                }
                # Persist interaction to semantic memory (best-effort)
                try:
                    # Convert interaction to policy atom format
                    atom = PolicyAtom(
                        policyid=f"{m}-{int(time.time())}",
                        planname=m,
                        procedurecode="ADJUDICATION",
                        covereddiagnosis=["DECISION"],
                        agerange_min=0,
                        agerange_max=100,
                        gender="*",
                        requirespreauthorization=False,
                        notes="\n".join(_content(msg) for msg in transcript),
                        effective_from=datetime.now().isoformat(),
                        jurisdiction=results[m]["decision_json"]["decision"] if results[m]["decision_json"] else "ERROR"
                    )
                    # Build/update embeddings
                    embeddings = build_embeddings([atom], ["planname", "notes"])
                    print(f"✓ {m} interaction saved to semantic memory (embeddings updated)")
                except Exception as e:
                    print(f"⚠ Failed to save {m} interaction to memory: {str(e)}")
                if success:
                    print(f"✓ {m} completed successfully in {round(latency_s, 3)}s")
                else:
                    print(f"✗ {m} failed: {error}")
        except TimeoutError as e:
            print(f"⚠ {m} timed out after {MODEL_TIMEOUT}s")
            results[m] = {
                "decision_json": None,
                "latency_sec": MODEL_TIMEOUT,
                "error": str(e),
                "transcript_len": 0,
                "success": False,
                "used_tools": False,
            }
        except Exception as e:
            results[m] = {
                "decision_json": None,
                "latency_sec": 0,
                "error": f"Unexpected error: {str(e)}",
                "transcript_len": 0,
                "success": False,
                "used_tools": False,
            }
            print(f"✗ {m} failed with exception: {str(e)}")

    _h("EXPERIMENT SUMMARY")
    print(f"Success rate: {successful_runs}/{total_runs} models ({(successful_runs/total_runs)*100:.1f}%)")

    _h("PER-MODEL RESULTS")
    print(json.dumps(results, indent=2))

    # Select best model using the centralized ground-truth
    best_model, model_scores = select_best_model(results, EXPECTED_DECISION)
    _h("BEST MODEL (scored)")
    print("Scores:", json.dumps(model_scores, indent=2))
    print(f"Selected best model for production: {best_model}")
    try:
        with open("best_model.txt", "w", encoding="utf-8") as f:
            f.write(best_model)
    except Exception:
        pass

    # Ask the judge model (offline) to provide a human-readable verdict
    verdict = evaluate_models(JUDGE_MODEL, {"task": USER_TASK, "candidates": results, "claim": CLAIM, "policy": POLICY, "expected_decision": EXPECTED_DECISION})
    _h("JUDGE VERDICT (raw)")
    print(verdict)

    try:
        v = json.loads(verdict)
        _h("SUMMARY")
        print(f"Winner: {v.get('winner_model', '')}")
        print(f"Pick:   {v.get('pick', '')}")
        print(f"Why:    {v.get('reasoning', '')}")
    except Exception:
        pass


if __name__ == "__main__":
    main()
