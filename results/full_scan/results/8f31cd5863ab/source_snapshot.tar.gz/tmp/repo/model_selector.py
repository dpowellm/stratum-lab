# ============================================================
# 1. Imports and configuration
# ============================================================

from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
)

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

import xgboost as xgb
import lightgbm as lgb
import joblib

RANDOM_STATE = 42

# ============================================================
# 2. Load JSON data from dataset folder
#    (handles nested "claims" field)
# ============================================================

project_root = Path(__file__).parent
json_path = project_root / "dataset" / "test_claims_500_with_target.json"

if not json_path.exists():
    raise FileNotFoundError(f"JSON file not found at: {json_path}")

print(f"Loading data from: {json_path}")
df_raw = pd.read_json(json_path)

print("\nRaw DataFrame shape:", df_raw.shape)
print("\nRaw DataFrame info:")
print(df_raw.info())
print("\nRaw describe (include='all'):")
print(df_raw.describe(include="all"))

# If file is of the form {"claims":[{...},{...}]}, flatten it
if "claims" in df_raw.columns and isinstance(df_raw.loc[0, "claims"], dict):
    print("\nDetected nested 'claims' column with dicts, normalizing...")
    df = pd.json_normalize(df_raw["claims"])
else:
    df = df_raw.copy()

print("\nFlattened data shape:", df.shape)
print("\nFlattened DataFrame info:")
print(df.info())
print("\nFlattened describe (include='all'):")
print(df.describe(include="all"))

# ============================================================
# 3. Basic EDA for target and key categorical columns
# ============================================================

print("\nRaw target value counts:")
print(df["target"].value_counts(dropna=False))

# Normalize target text
df["target_clean"] = df["target"].astype(str).str.upper().str.strip()

print("\nNormalized target value counts:")
print(df["target_clean"].value_counts(dropna=False))

# Map HUMAN REVIEW -> 1, others -> 0
df["target_binary"] = np.where(df["target_clean"] == "HUMAN REVIEW", 1, 0)

print("\nBinary target distribution (HUMAN REVIEW=1, others=0):")
print(df["target_binary"].value_counts())
print("\nBinary target proportions:")
print(df["target_binary"].value_counts(normalize=True))

# Quick EDA on some categorical columns
categorical_for_eda = [
    "policy_id",
    "patient_gender",
    "provider_specialty",
    "claim_type",
    "primary_diagnosis_code",
    "procedure_code_cpt",
    "out_of_network",
]

for col in categorical_for_eda:
    print(f"\nColumn: {col}")
    print(df[col].value_counts().head(15))
    print("Proportion:")
    print(df[col].value_counts(normalize=True).head(15))

# Numeric summary
numeric_cols_raw = [
    "patient_age",
    "charged_amount",
    "allowed_amount",
    "paid_amount",
    "patient_responsibility",
]
print("\nNumeric summary for selected features:")
print(df[numeric_cols_raw].describe())

# Comment summary (EDA):
# - Target is highly imbalanced: ~98% HUMAN REVIEW vs ~2% PAID.
# - Many high-cardinality categorical features (policy_id, diagnosis, CPT).
# - out_of_network is also imbalanced.
# - Amount columns have a wide spread, so scaling helps tree-boost models.


# ============================================================
# 4. Feature engineering
# ============================================================

data = df.copy()

# 4.1 Numeric flag for out_of_network
data["out_of_network_flag"] = data["out_of_network"].astype(int)

# 4.2 Simple ratios for money columns
epsilon = 1e-6

data["allowed_to_charged_ratio"] = (
    data["allowed_amount"] / (data["charged_amount"] + epsilon)
)
data["paid_to_allowed_ratio"] = (
    data["paid_amount"] / (data["allowed_amount"] + epsilon)
)
data["patient_resp_to_charged_ratio"] = (
    data["patient_responsibility"] / (data["charged_amount"] + epsilon)
)

# 4.3 Age buckets
data["age_bin"] = pd.cut(
    data["patient_age"],
    bins=[0, 17, 45, 65, 120],
    labels=["child", "adult", "middle_aged", "senior"],
    right=True,
    include_lowest=True,
)

print("\nFeature engineering complete. Example rows:")
print(
    data[
        [
            "patient_age",
            "age_bin",
            "charged_amount",
            "allowed_amount",
            "paid_amount",
            "patient_responsibility",
            "out_of_network",
            "out_of_network_flag",
            "allowed_to_charged_ratio",
            "paid_to_allowed_ratio",
            "patient_resp_to_charged_ratio",
        ]
    ].head()
)

# FE findings (in words):
# - Ratios capture how generous the payment is relative to charge.
# - Age buckets allow the model to pick up non-linear age effects.
# - out_of_network_flag gives a clean numeric representation for that status.


# ============================================================
# 5. Define features and target
# ============================================================

numeric_features = [
    "patient_age",
    "charged_amount",
    "allowed_amount",
    "paid_amount",
    "patient_responsibility",
    "out_of_network_flag",
    "allowed_to_charged_ratio",
    "paid_to_allowed_ratio",
    "patient_resp_to_charged_ratio",
]

categorical_features = [
    "policy_id",
    "patient_gender",
    "provider_specialty",
    "claim_type",
    "primary_diagnosis_code",
    "procedure_code_cpt",
    "age_bin",
]

X = data[numeric_features + categorical_features]
y = data["target_binary"]

print("\nFinal numeric features:", numeric_features)
print("Final categorical features:", categorical_features)

# ============================================================
# 6. Train/test split (stratified)
# ============================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=RANDOM_STATE,
    stratify=y,
)

print("\nTrain shape:", X_train.shape, "Test shape:", X_test.shape)
print("Train target distribution:")
print(y_train.value_counts())
print("Test target distribution:")
print(y_test.value_counts())

# ============================================================
# 7. Preprocessing pipeline (scaling + one-hot)
# ============================================================

numeric_transformer = StandardScaler()
categorical_transformer = OneHotEncoder(handle_unknown="ignore")

preprocessor = ColumnTransformer(
    transformers=[
        ("num", numeric_transformer, numeric_features),
        ("cat", categorical_transformer, categorical_features),
    ],
    remainder="drop",
)

# ============================================================
# 8. Base models (no SMOTE, handle imbalance via class_weight + metric)
# ============================================================

models = {
    "LogisticRegression": LogisticRegression(
        max_iter=2000,
        class_weight="balanced",
        solver="lbfgs",
        random_state=RANDOM_STATE,
    ),
    "DecisionTree": DecisionTreeClassifier(
        max_depth=6,
        min_samples_leaf=5,
        class_weight="balanced",
        random_state=RANDOM_STATE,
    ),
    "RandomForest": RandomForestClassifier(
        n_estimators=200,
        max_depth=None,
        min_samples_leaf=2,
        n_jobs=-1,
        class_weight="balanced",
        random_state=RANDOM_STATE,
    ),
    "XGBoost": xgb.XGBClassifier(
        n_estimators=300,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.9,
        colsample_bytree=0.9,
        random_state=RANDOM_STATE,
        eval_metric="logloss",
        n_jobs=-1,
    ),
    "LightGBM": lgb.LGBMClassifier(
        n_estimators=200,
        max_depth=-1,
        learning_rate=0.05,
        subsample=0.9,
        colsample_bytree=0.9,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1,
    ),
}

# ============================================================
# 9. RandomizedSearchCV parameter spaces (3-fold CV)
# ============================================================

param_distributions = {
    "LogisticRegression": {
        "model__C": np.logspace(-2, 2, 10),
        "model__penalty": ["l2"],
    },
    "DecisionTree": {
        "model__max_depth": [3, 4, 5, 6, 8, None],
        "model__min_samples_leaf": [1, 2, 5, 10],
        "model__min_samples_split": [2, 5, 10],
    },
    "RandomForest": {
        "model__n_estimators": [100, 200, 300],
        "model__max_depth": [None, 4, 6, 8, 12],
        "model__min_samples_leaf": [1, 2, 5],
        "model__max_features": ["sqrt", "log2", 0.5, 0.8],
    },
    "XGBoost": {
        "model__n_estimators": [100, 200, 300],
        "model__max_depth": [3, 4, 5],
        "model__learning_rate": [0.01, 0.05, 0.1],
        "model__subsample": [0.7, 0.9, 1.0],
        "model__colsample_bytree": [0.7, 0.9, 1.0],
    },
    "LightGBM": {
        "model__n_estimators": [100, 200, 400],
        "model__num_leaves": [15, 31, 63],
        "model__max_depth": [-1, 4, 6, 8],
        "model__learning_rate": [0.01, 0.05, 0.1],
    },
}

# ============================================================
# 10. Train, tune with 3-fold RandomizedSearchCV, and evaluate
# ============================================================

pipelines = {}
results = []

for name, base_model in models.items():
    print("\n" + "=" * 70)
    print(f"Model: {name}")
    print("=" * 70)

    pipe = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("model", base_model),
        ]
    )

    if name in param_distributions:
        print("Running 3-fold RandomizedSearchCV for tuning")
        search = RandomizedSearchCV(
            estimator=pipe,
            param_distributions=param_distributions[name],
            n_iter=10,  # adjust if you want more/less tuning
            scoring="balanced_accuracy",
            cv=3,
            n_jobs=-1,
            random_state=RANDOM_STATE,
            verbose=1,
        )
        search.fit(X_train, y_train)
        print("\nBest params from RandomizedSearchCV:")
        print(search.best_params_)
        print(
            "Best mean CV balanced accuracy:",
            f"{search.best_score_:.4f}",
        )
        pipe = search.best_estimator_
    else:
        pipe.fit(X_train, y_train)

    y_pred = pipe.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    bal_acc = balanced_accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)

    print("\nClassification report on test set:")
    print(classification_report(y_test, y_pred, zero_division=0))

    print("Test metrics:")
    print(f"  Accuracy            : {acc:.4f}")
    print(f"  Balanced accuracy   : {bal_acc:.4f}")
    print(f"  Precision (class 1) : {prec:.4f}")
    print(f"  Recall (class 1)    : {rec:.4f}")
    print(f"  F1 (class 1)        : {f1:.4f}")

    pipelines[name] = pipe
    results.append(
        {
            "model": name,
            "accuracy": acc,
            "balanced_accuracy": bal_acc,
            "precision": prec,
            "recall": rec,
            "f1": f1,
        }
    )

results_df = pd.DataFrame(results).sort_values(
    by="balanced_accuracy", ascending=False
)
print("\nModel comparison sorted by balanced accuracy:")
print(results_df)

# ============================================================
# 11. Select best model and show feature importances
# ============================================================

best_row = results_df.iloc[0]
best_model_name = best_row["model"]
best_pipeline = pipelines[best_model_name]

print(f"\nBest model by balanced accuracy: {best_model_name}")
print("Best model test metrics:")
print(best_row)

print("\nComputing feature importances for best model...")

best_model = best_pipeline.named_steps["model"]
best_preprocessor = best_pipeline.named_steps["preprocessor"]

all_feature_names = best_preprocessor.get_feature_names_out(
    numeric_features + categorical_features
)

if hasattr(best_model, "feature_importances_"):
    importances = best_model.feature_importances_
elif hasattr(best_model, "coef_"):
    coefs = best_model.coef_
    if coefs.ndim == 1:
        importances = np.abs(coefs)
    else:
        importances = np.mean(np.abs(coefs), axis=0)
else:
    importances = None

if importances is not None:
    fi_df = pd.DataFrame(
        {"feature": all_feature_names, "importance": importances}
    ).sort_values(by="importance", ascending=False)

    print("\nTop 20 features by importance:")
    print(fi_df.head(20))
else:
    print("This model type does not expose feature importances or coefficients.")

# ============================================================
# 12. Save best pipeline
# ============================================================

model_path = project_root / "best_claims_model.pkl"
joblib.dump(best_pipeline, model_path)
print(f"\nSaved best model pipeline to: {model_path}")


print("\nDone.")
