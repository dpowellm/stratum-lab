from crewai_tools import BrowserbaseLoadTool

Browserbase = BrowserbaseLoadTool(text_content=True)